#!/usr/bin/env python3
"""Score Dify/RAGFlow NQ V2 + MuSiQue V3 with the Layer-C DeepSeek V4 Pro judge."""

from __future__ import annotations

import csv
import importlib.util
import json
import re
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path("/Users/yuguanghui/.slock/agents/a6ce9925-ec54-4b06-9540-0242f6d3de40")
PACK = ROOT / "results/eval-packs"
SECRET = ROOT / "secrets-local/sg-eval-account.env"
JUDGE_PATH = Path("/Users/yuguanghui/github/aperag-enterprise/aperag_eval/baselines/_judge_smoke20_layer_c.py")
JUDGE_BOT = "bota4d78a432f04bb9e"
JUDGE_MODEL = "mdlb42fd476da84b111"
CACHE = PACK / "horizontal-judge-cache.jsonl"
OUT = PACK / "horizontal-scored.json"

JOBS = [
    ("ragflow-nq-v2", PACK / "eval-final-4sets/ragflow-nq-v2.jsonl", "nq"),
    ("dify-nq-v2", PACK / "eval-final-4sets/dify-nq-v2.jsonl", "nq"),
    ("ragflow-musique-v3", PACK / "eval-final-4sets/ragflow-musique-v3.jsonl", "musique"),
    ("dify-musique-v3", PACK / "eval-final-4sets/dify-musique-v3.jsonl", "musique"),
]


def load_secret() -> dict[str, str]:
    secret: dict[str, str] = {}
    for raw in SECRET.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        secret[key] = value
    return secret


def load_module():
    spec = importlib.util.spec_from_file_location("layer_c_judge", JUDGE_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_gold() -> dict[str, dict]:
    gold: dict[str, dict] = {}
    nq_path = PACK / "nq-en-v2/dataset.jsonl"
    if not nq_path.exists():
        nq_path = PACK / "nq-v2-export/questions.jsonl"
    for line in nq_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        gold[row["case_key"]] = {
            "question": row["question"],
            "expected_answer": row.get("expected_answer") or [],
            "axis": row.get("axis"),
        }
    mq = PACK / "musique-v3-export/questions.jsonl"
    for line in mq.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        row = json.loads(line)
        gold[row["case_key"]] = {
            "question": row["question"],
            "expected_answer": row.get("expected_answer") or [],
            "axis": row.get("axis"),
            "hop": row.get("hop"),
        }
    return gold


def parse_verdict(content: str) -> tuple[str | None, str]:
    match = re.search(r"\{.*\}", content, re.DOTALL)
    parsed = None
    if match:
        try:
            parsed = json.loads(match.group(0))
        except json.JSONDecodeError:
            parsed = None
    verdict = None
    rationale = ""
    if isinstance(parsed, dict):
        raw = str(parsed.get("verdict", "")).upper().strip()
        if raw in {"PASS", "FAIL"}:
            verdict = raw
        elif raw in {"CORRECT", "TRUE", "YES"} or parsed.get("correct") is True:
            verdict = "PASS"
        elif raw in {"INCORRECT", "WRONG", "FALSE", "NO"} or parsed.get("correct") is False:
            verdict = "FAIL"
        rationale = str(parsed.get("rationale") or parsed.get("reason") or "")[:240]
    if verdict is None:
        m2 = re.search(r'"correct"\s*:\s*(true|false)', content, re.I)
        if m2:
            verdict = "PASS" if m2.group(1).lower() == "true" else "FAIL"
        else:
            m3 = re.search(r'"verdict"\s*:\s*"(PASS|FAIL|correct|incorrect)"', content, re.I)
            if m3:
                raw = m3.group(1).upper()
                verdict = "PASS" if raw in {"PASS", "CORRECT"} else "FAIL"
    return verdict, rationale or content[:240]


def call_judge(module, question: str, expected: list, candidate: str, api_key: str) -> dict:
    body = {
        "model": JUDGE_MODEL,
        "temperature": 0,
        "max_tokens": 256,
        "messages": [
            {"role": "system", "content": module._select_judge_system_prompt(expected)},
            {"role": "user", "content": module._build_user_prompt(question, expected, candidate)},
        ],
    }
    cmd = [
        "/usr/bin/curl",
        "-s",
        "--max-time",
        "90",
        "-A",
        "Mozilla/5.0",
        "-H",
        f"Authorization: Bearer {api_key}",
        "-H",
        "Content-Type: application/json",
        "-X",
        "POST",
        f"https://apemind.ai/v1/chat/completions?bot_id={JUDGE_BOT}",
        "-d",
        json.dumps(body, ensure_ascii=False),
    ]
    last_err = None
    for _ in range(4):
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=100)
        except subprocess.TimeoutExpired:
            last_err = "timeout"
            time.sleep(2)
            continue
        if result.returncode != 0 or not result.stdout.strip():
            last_err = f"rc={result.returncode}"
            time.sleep(2)
            continue
        try:
            resp = json.loads(result.stdout)
        except json.JSONDecodeError:
            last_err = f"json-decode:{result.stdout[:80]}"
            time.sleep(2)
            continue
        content = ((resp.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        if not content.strip():
            last_err = f"empty:{result.stdout[:80]}"
            time.sleep(2)
            continue
        verdict, rationale = parse_verdict(content)
        if verdict in {"PASS", "FAIL"}:
            return {"verdict": verdict, "rationale": rationale}
        last_err = f"bad-verdict:{content[:120]}"
    return {"verdict": "FAIL", "rationale": f"judge-error: {last_err}", "judge_error": True}


def cache_key(job: str, case_key: str) -> str:
    return f"{job}::{case_key}"


def main() -> int:
    api_key = load_secret()["EVAL_API_KEY"]
    module = load_module()
    gold = load_gold()
    cached: dict[str, dict] = {}
    if CACHE.exists():
        for line in CACHE.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("verdict") in {"PASS", "FAIL"} and not row.get("judge_error"):
                cached[cache_key(row["job"], row["case_key"])] = row

    todo = []
    for job, path, kind in JOBS:
        rows = [json.loads(l) for l in path.read_text().splitlines() if l.strip()]
        for rec in rows:
            ck = rec["case_key"]
            if ck not in gold:
                raise SystemExit(f"unknown case_key {ck} in {job}")
            if cache_key(job, ck) not in cached:
                todo.append((job, kind, rec, gold[ck]))
    print(f"JUDGE cached={len(cached)} todo={len(todo)}", flush=True)

    def score_one(item):
        job, kind, rec, g = item
        result = call_judge(module, g["question"], g.get("expected_answer") or [], rec.get("answer") or "", api_key)
        return {
            "job": job,
            "kind": kind,
            "case_key": rec["case_key"],
            "axis": g.get("axis"),
            "hop": g.get("hop"),
            "elapsed_s": rec.get("elapsed_s"),
            "tool_calls": rec.get("tool_calls"),
            **result,
        }

    with CACHE.open("a", encoding="utf-8") as handle:
        if todo:
            with ThreadPoolExecutor(max_workers=4) as pool:
                futs = [pool.submit(score_one, item) for item in todo]
                for i, fut in enumerate(as_completed(futs), 1):
                    row = fut.result()
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                    handle.flush()
                    if not row.get("judge_error"):
                        cached[cache_key(row["job"], row["case_key"])] = row
                    print(f"JUDGE {i}/{len(todo)} {row['job']} {row.get('verdict')} err={bool(row.get('judge_error'))}", flush=True)

    summary = {}
    errors = 0
    for job, path, kind in JOBS:
        rows = [json.loads(l) for l in path.read_text().splitlines() if l.strip()]
        scored = []
        for rec in rows:
            row = cached.get(cache_key(job, rec["case_key"]))
            if not row:
                errors += 1
                continue
            if row.get("judge_error"):
                errors += 1
            scored.append(row)
        passed = sum(r["verdict"] == "PASS" for r in scored)
        by_axis: dict[str, list] = {}
        for r in scored:
            by_axis.setdefault(str(r.get("axis") or "unknown"), []).append(r)
        summary[job] = {
            "kind": kind,
            "total": len(scored),
            "pass": passed,
            "fail": len(scored) - passed,
            "judge_errors": sum(bool(r.get("judge_error")) for r in scored),
            "by_axis": {
                axis: {"total": len(items), "pass": sum(i["verdict"] == "PASS" for i in items)}
                for axis, items in sorted(by_axis.items())
            },
            "cases": scored,
        }
        print(f"SUM {job} {passed}/{len(scored)} errors={summary[job]['judge_errors']}", flush=True)

    OUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("WROTE", OUT, "errors", errors, flush=True)
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
