#!/usr/bin/env python3
"""Latest three-way Dify / RAGFlow / ApeMind long image."""

from __future__ import annotations

import subprocess
from pathlib import Path

OUT = Path("/Users/yuguanghui/.slock/agents/a6ce9925-ec54-4b06-9540-0242f6d3de40/results/eval-packs")
HTML = OUT / "three-way-latest.html"
PNG = OUT / "three-way-latest.png"

html = r"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<style>
  html,body{margin:0;padding:0;background:#eef2ee}
  .page{width:1100px;margin:0 auto;background:#f3f6f3;color:#1a2a28;
        font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Hiragino Sans GB","Noto Sans SC",sans-serif}
  .hero{background:#163835;color:#fff;padding:36px 44px 26px;border-bottom:6px solid #d4a017}
  .hero h1{margin:0 0 8px;font-size:36px;font-weight:750}
  .hero p{margin:0;font-size:15px;opacity:.82}
  .body{padding:22px 40px 28px}
  .cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:0 0 20px}
  .card{background:#fff;border:1px solid #d5dfd6;padding:14px 12px 12px}
  .card b{display:block;font-size:24px;line-height:1.15;margin-bottom:6px}
  .card span{display:block;color:#5c6c69;font-size:12px;line-height:1.4}
  h2{margin:20px 0 8px;font-size:19px;font-weight:700}
  table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #d5dfd6}
  th,td{padding:8px 10px;text-align:left;font-size:13px;border-bottom:1px solid #e5ece6}
  th{background:#eef3ef;font-weight:650;color:#31423f}
  tr.hi td{background:#fff6d8}
</style></head>
<body><div class="page">
  <div class="hero">
    <h1>Dify · RAGFlow · ApeMind</h1>
    <p>NQ · MuSiQue · HotpotQA · RGB</p>
  </div>
  <div class="body">
    <div class="cards">
      <div class="card"><b>57 / 81 / 98</b><span>NQ · Dify / RAGFlow / ApeMind</span></div>
      <div class="card"><b>37 / 35 / 90</b><span>MuSiQue · Dify / RAGFlow / ApeMind</span></div>
      <div class="card"><b>123 / 110 / 145</b><span>HotpotQA · Dify / RAGFlow / ApeMind</span></div>
      <div class="card"><b>194 / 194 / 200</b><span>RGB · Dify / RAGFlow / ApeMind</span></div>
    </div>

    <h2>NQ · 118 题</h2>
    <table>
      <tr><th>系统</th><th>正确</th><th>正确率</th><th>短答案 · 61</th><th>长答案 · 20</th><th>是否 · 5</th><th>无答案 · 32</th></tr>
      <tr><td>Dify</td><td>57/118</td><td>48.3%</td><td>40/61</td><td>10/20</td><td>4/5</td><td>3/32</td></tr>
      <tr><td>RAGFlow</td><td>81/118</td><td>68.6%</td><td>48/61</td><td>15/20</td><td>4/5</td><td>14/32</td></tr>
      <tr class="hi"><td>ApeMind · Qwen3.6 27B</td><td>98/118</td><td>83.1%</td><td>60/61</td><td>16/20</td><td>5/5</td><td>17/32</td></tr>
      <tr><td>ApeMind · V4 Flash</td><td>95/118</td><td>80.5%</td><td>55/61</td><td>18/20</td><td>5/5</td><td>17/32</td></tr>
      <tr><td>ApeMind · V4 Pro</td><td>94/118</td><td>79.7%</td><td>58/61</td><td>17/20</td><td>4/5</td><td>15/32</td></tr>
      <tr><td>ApeMind · Qwen3.8 27B</td><td>91/118</td><td>77.1%</td><td>56/61</td><td>18/20</td><td>4/5</td><td>13/32</td></tr>
    </table>

    <h2>MuSiQue · 100 题</h2>
    <table>
      <tr><th>系统</th><th>正确</th><th>正确率</th><th>2 跳 · 51</th><th>3 跳 · 43</th><th>4 跳 · 6</th></tr>
      <tr><td>Dify</td><td>37/100</td><td>37.0%</td><td>18/51</td><td>16/43</td><td>3/6</td></tr>
      <tr><td>RAGFlow</td><td>35/100</td><td>35.0%</td><td>20/51</td><td>14/43</td><td>1/6</td></tr>
      <tr class="hi"><td>ApeMind · V4 Pro</td><td>90/100</td><td>90.0%</td><td>43/51</td><td>41/43</td><td>6/6</td></tr>
      <tr><td>ApeMind · Qwen3.8 27B</td><td>90/100</td><td>90.0%</td><td>42/51</td><td>42/43</td><td>6/6</td></tr>
      <tr><td>ApeMind · Qwen3.6 27B</td><td>87/100</td><td>87.0%</td><td>43/51</td><td>39/43</td><td>5/6</td></tr>
      <tr><td>ApeMind · V4 Flash</td><td>84/100</td><td>84.0%</td><td>40/51</td><td>40/43</td><td>4/6</td></tr>
    </table>

    <h2>HotpotQA · 150 题</h2>
    <table>
      <tr><th>系统</th><th>正确</th><th>正确率</th><th>桥接 · 126</th><th>对比 · 24</th></tr>
      <tr><td>Dify</td><td>123/150</td><td>82.0%</td><td>102/126</td><td>21/24</td></tr>
      <tr><td>RAGFlow</td><td>110/150</td><td>73.3%</td><td>92/126</td><td>18/24</td></tr>
      <tr class="hi"><td>ApeMind · Qwen3.6 27B</td><td>145/150</td><td>96.7%</td><td>121/126</td><td>24/24</td></tr>
      <tr><td>ApeMind · Qwen3.8 27B</td><td>143/150</td><td>95.3%</td><td>121/126</td><td>22/24</td></tr>
      <tr><td>ApeMind · V4 Flash</td><td>141/150</td><td>94.0%</td><td>119/126</td><td>22/24</td></tr>
      <tr><td>ApeMind · V4 Pro</td><td>139/150</td><td>92.7%</td><td>118/126</td><td>21/24</td></tr>
    </table>

    <h2>RGB · 200 题</h2>
    <table>
      <tr><th>系统</th><th>正确</th><th>正确率</th><th>噪声 · 50</th><th>反事实 · 50</th><th>拒答 · 50</th><th>整合 · 50</th></tr>
      <tr><td>Dify</td><td>194/200</td><td>97.0%</td><td>49/50</td><td>49/50</td><td>49/50</td><td>47/50</td></tr>
      <tr><td>RAGFlow</td><td>194/200</td><td>97.0%</td><td>50/50</td><td>47/50</td><td>50/50</td><td>47/50</td></tr>
      <tr class="hi"><td>ApeMind · V4 Pro</td><td>200/200</td><td>100%</td><td>50/50</td><td>50/50</td><td>50/50</td><td>50/50</td></tr>
      <tr><td>ApeMind · Qwen3.8 27B</td><td>199/200</td><td>99.5%</td><td>50/50</td><td>49/50</td><td>50/50</td><td>50/50</td></tr>
      <tr><td>ApeMind · V4 Flash</td><td>198/200</td><td>99.0%</td><td>50/50</td><td>49/50</td><td>50/50</td><td>50/50</td></tr>
      <tr><td>ApeMind · Qwen3.6 27B</td><td>196/200</td><td>98.0%</td><td>50/50</td><td>48/50</td><td>50/50</td><td>48/50</td></tr>
    </table>

    <h2>回答时间与工具</h2>
    <table>
      <tr><th>数据集</th><th>系统</th><th>P50</th><th>P95</th><th>最长</th><th>工具</th></tr>
      <tr><td>NQ</td><td>RAGFlow</td><td>19.5s</td><td>38.8s</td><td>49.5s</td><td>0</td></tr>
      <tr><td>NQ</td><td>ApeMind · V4 Pro</td><td>36.1s</td><td>131.6s</td><td>276.8s</td><td>6.2 / 31</td></tr>
      <tr><td>NQ</td><td>ApeMind · V4 Flash</td><td>42.7s</td><td>122.8s</td><td>165.9s</td><td>5.5 / 26</td></tr>
      <tr><td>NQ</td><td>ApeMind · Qwen3.6 27B</td><td>50.5s</td><td>259.5s</td><td>534.5s</td><td>5.8 / 24</td></tr>
      <tr><td>NQ</td><td>ApeMind · Qwen3.8 27B</td><td>86.7s</td><td>382.9s</td><td>654.9s</td><td>5.1 / 30</td></tr>
      <tr><td>MuSiQue</td><td>RAGFlow</td><td>9.2s</td><td>33.3s</td><td>89.4s</td><td>0</td></tr>
      <tr><td>MuSiQue</td><td>ApeMind · V4 Flash</td><td>59.4s</td><td>201.2s</td><td>465.0s</td><td>6.7 / 34</td></tr>
      <tr><td>MuSiQue</td><td>ApeMind · Qwen3.6 27B</td><td>65.1s</td><td>376.5s</td><td>1196.8s</td><td>7.1 / 53</td></tr>
      <tr><td>MuSiQue</td><td>ApeMind · V4 Pro</td><td>68.8s</td><td>311.8s</td><td>827.6s</td><td>7.9 / 56</td></tr>
      <tr><td>MuSiQue</td><td>ApeMind · Qwen3.8 27B</td><td>137.9s</td><td>388.6s</td><td>957.8s</td><td>6.6 / 19</td></tr>
      <tr><td>HotpotQA</td><td>Dify</td><td>3.6s</td><td>12.2s</td><td>277.3s</td><td>检索</td></tr>
      <tr><td>HotpotQA</td><td>RAGFlow</td><td>9.3s</td><td>20.0s</td><td>28.1s</td><td>0</td></tr>
      <tr><td>HotpotQA</td><td>ApeMind · V4 Pro</td><td>20.4s</td><td>86.9s</td><td>220.3s</td><td>4.1 / 35</td></tr>
      <tr><td>HotpotQA</td><td>ApeMind · V4 Flash</td><td>22.7s</td><td>54.5s</td><td>115.4s</td><td>3.4 / 23</td></tr>
      <tr><td>HotpotQA</td><td>ApeMind · Qwen3.6 27B</td><td>32.6s</td><td>101.2s</td><td>490.6s</td><td>3.6 / 42</td></tr>
      <tr><td>HotpotQA</td><td>ApeMind · Qwen3.8 27B</td><td>75.0s</td><td>267.4s</td><td>1188.0s</td><td>3.7 / 25</td></tr>
      <tr><td>RGB</td><td>Dify</td><td>2.9s</td><td>6.1s</td><td>19.4s</td><td>检索</td></tr>
      <tr><td>RGB</td><td>RAGFlow</td><td>11.5s</td><td>18.5s</td><td>31.3s</td><td>0</td></tr>
      <tr><td>RGB</td><td>ApeMind · V4 Flash</td><td>19.5s</td><td>45.6s</td><td>155.8s</td><td>2.7 / 27</td></tr>
      <tr><td>RGB</td><td>ApeMind · Qwen3.6 27B</td><td>21.0s</td><td>52.2s</td><td>321.6s</td><td>1.6 / 18</td></tr>
      <tr><td>RGB</td><td>ApeMind · V4 Pro</td><td>21.1s</td><td>67.6s</td><td>445.8s</td><td>3.7 / 34</td></tr>
      <tr><td>RGB</td><td>ApeMind · Qwen3.8 27B</td><td>73.8s</td><td>200.5s</td><td>2210.7s</td><td>2.8 / 15</td></tr>
    </table>
  </div>
</div></body></html>
"""


def main() -> int:
    HTML.write_text(html, encoding="utf-8")
    chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    subprocess.run(
        [
            chrome,
            "--headless=new",
            "--disable-gpu",
            "--hide-scrollbars",
            f"--screenshot={PNG}",
            "--window-size=1100,2480",
            "--default-background-color=00000000",
            HTML.as_uri(),
        ],
        check=True,
        capture_output=True,
        timeout=60,
    )
    print("wrote", PNG)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
