#!/usr/bin/env python3
"""Resume MuSiQue V3 Qwen3.8 candidates at concurrency 1."""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("/Users/yuguanghui/github/aperag-enterprise")
SECRET = ROOT / "secrets-local/sg-eval-account.env"
PENDING = ROOT / "results/musique-v3/qwen38-pending-questions.jsonl"
OUT = ROOT / "results/musique-v3/qwen38-resume.jsonl"
BOT_ID = "bot25009f03a523a194"
TIMEOUT_S = 3600
MAX_ATTEMPTS = 8

sys.path.insert(0, str(REPO))
from aperag_eval.lib.runner import load_secret, run_one  # noqa: E402


def load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def is_rate_limit(result: dict) -> bool:
    blob = " ".join(
        str(result.get(k) or "")
        for k in ("error", "status", "answer_text")
    ).lower()
    return any(
        tok in blob
        for tok in (
            "429",
            "rate",
            "限流",
            "temporarily",
            "unavailable",
            "quota",
            "auth_or_config",
            "credentials",
            "retrieval tool",
            "json decode",
            "please retry",
        )
    )


def main() -> int:
    pending = load_jsonl(PENDING)
    done = {row["question"] for row in load_jsonl(OUT) if row.get("status") == "COMPLETED" and row.get("answer_text")}
    todo = [row for row in pending if row["question"] not in done]
    secret = load_secret(SECRET)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    print(f"START pending={len(pending)} already={len(done)} todo={len(todo)}", flush=True)
    ok = 0
    fail = 0
    with OUT.open("a", encoding="utf-8") as handle:
        for i, case in enumerate(todo, start=1):
            question = case["question"]
            attempt = 1
            backoff = 45
            while attempt <= MAX_ATTEMPTS:
                result = run_one(
                    base_url=secret["APERAG_BASE_URL"],
                    api_key=secret["EVAL_API_KEY"],
                    bot_id=BOT_ID,
                    question=question,
                    timeout_per_turn=TIMEOUT_S,
                )
                row = {
                    **case,
                    **result,
                    "bot_id": BOT_ID,
                    "attempt": attempt,
                    "run_tag": "task100-musique-v3-qwen38-resume",
                }
                success = result.get("status") == "COMPLETED" and bool(result.get("answer_text"))
                if success:
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                    handle.flush()
                    ok += 1
                    print(
                        f"OK {i}/{len(todo)} attempt={attempt} "
                        f"status={result.get('status')} tools={result.get('tool_call_count')} "
                        f"s={result.get('wall_clock_s'):.1f}",
                        flush=True,
                    )
                    break
                if is_rate_limit(result) and attempt < MAX_ATTEMPTS:
                    print(
                        f"RETRY {i}/{len(todo)} attempt={attempt} "
                        f"status={result.get('status')} err={str(result.get('error'))[:120]} "
                        f"sleep={backoff}s",
                        flush=True,
                    )
                    time.sleep(backoff)
                    backoff = min(backoff * 2, 600)
                    attempt += 1
                    continue
                handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                handle.flush()
                fail += 1
                print(
                    f"FAIL {i}/{len(todo)} attempt={attempt} "
                    f"status={result.get('status')} err={str(result.get('error'))[:160]}",
                    flush=True,
                )
                break
    print(f"DONE ok={ok} fail={fail} todo={len(todo)}", flush=True)
    return 0 if fail == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
