#!/usr/bin/env python3
"""Judge MuSiQue V3 Qwen3.8 with the canonical Layer-C DeepSeek V4 Pro rubric."""

from __future__ import annotations

import importlib.util
import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results/musique-v3"
SECRET = ROOT / "secrets-local/sg-eval-account.env"
JUDGE_PATH = Path("/Users/yuguanghui/github/aperag-enterprise/aperag_eval/baselines/_judge_smoke20_layer_c.py")
CACHE = OUT / "qwen38-judge-cache.jsonl"
SCORED = OUT / "qwen38-scored.json"
JUDGE_BOT = "bota4d78a432f04bb9e"
JUDGE_MODEL = "mdlb42fd476da84b111"


def load_module():
    spec = importlib.util.spec_from_file_location("layer_c_judge", JUDGE_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def best_candidate(path: Path) -> dict[str, dict]:
    chosen: dict[str, dict] = {}
    for line in path.read_text(encoding="utf-8").splitlines()[1:]:
        if not line.strip():
            continue
        rec = json.loads(line)
        q = (rec.get("question") or "").strip()
        if rec.get("status") != "COMPLETED" or not (rec.get("answer") or "").strip():
            continue
        prev = chosen.get(q)
        if prev is None:
            chosen[q] = rec
    return chosen


def load_secret() -> dict[str, str]:
    secret: dict[str, str] = {}
    for raw in SECRET.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        secret[key] = value
    return secret


def call_judge(module, question: str, expected: list[str], candidate: str, api_key: str) -> dict:
    import json as _json
    import re
    import subprocess
    import time

    body = {
        "model": JUDGE_MODEL,
        "temperature": 0,
        "max_tokens": 2048,
        "messages": [
            {"role": "system", "content": module._select_judge_system_prompt(expected)},
            {"role": "user", "content": module._build_user_prompt(question, expected, candidate)},
        ],
    }
    cmd = [
        "/usr/bin/curl",
        "-s",
        "-A",
        "Mozilla/5.0",
        "-H",
        f"Authorization: Bearer {api_key}",
        "-H",
        "Content-Type: application/json",
        "-X",
        "POST",
        f"https://apemind.ai/v1/chat/completions?bot_id={JUDGE_BOT}",
        "-d",
        _json.dumps(body, ensure_ascii=False),
    ]
    last_err = None
    for _attempt in range(1, 4):
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        except subprocess.TimeoutExpired:
            last_err = "timeout"
            time.sleep(2)
            continue
        if result.returncode != 0 or not result.stdout.strip():
            last_err = f"rc={result.returncode}"
            time.sleep(2)
            continue
        try:
            resp = _json.loads(result.stdout)
        except _json.JSONDecodeError:
            last_err = "json-decode"
            time.sleep(2)
            continue
        content = ((resp.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
        if not content.strip():
            last_err = f"empty-content:{result.stdout[:180]}"
            time.sleep(2)
            continue
        verdict = None
        rationale = ""
        match = re.search(r"\{.*\}", content, re.DOTALL)
        parsed = None
        if match:
            try:
                parsed = _json.loads(match.group(0))
            except _json.JSONDecodeError:
                parsed = None
        if isinstance(parsed, dict):
            raw = str(parsed.get("verdict", "")).upper().strip()
            if raw in {"PASS", "FAIL"}:
                verdict = raw
            elif raw in {"CORRECT", "TRUE", "YES"} or parsed.get("correct") is True:
                verdict = "PASS"
            elif raw in {"INCORRECT", "WRONG", "FALSE", "NO"} or parsed.get("correct") is False:
                verdict = "FAIL"
            rationale = str(parsed.get("rationale") or parsed.get("reason") or "")[:240]
        if verdict is None:
            m2 = re.search(r'"correct"\s*:\s*(true|false)', content, re.I)
            if m2:
                verdict = "PASS" if m2.group(1).lower() == "true" else "FAIL"
            else:
                m3 = re.search(r'"verdict"\s*:\s*"(PASS|FAIL|correct|incorrect)"', content, re.I)
                if m3:
                    raw = m3.group(1).upper()
                    verdict = "PASS" if raw in {"PASS", "CORRECT"} else "FAIL"
        if verdict not in {"PASS", "FAIL"}:
            last_err = f"bad-verdict:{content[:160]}"
            continue
        return {"verdict": verdict, "rationale": rationale or content[:240]}
    return {"verdict": "FAIL", "rationale": f"judge-error: {last_err}", "judge_error": True}


def main() -> int:
    secret = load_secret()
    api_key = secret.get("EVAL_API_KEY")
    if not api_key:
        raise SystemExit("EVAL_API_KEY missing")
    judge = load_module()
    gold_rows = [json.loads(l) for l in (OUT / "v3-gold-from-official.jsonl").read_text().splitlines() if l.strip()]
    gold = {r["question"].strip(): r for r in gold_rows}
    cands = best_candidate(OUT / "qwen38-export.jsonl")
    if len(cands) != 100 or len(gold) != 100:
        raise SystemExit(f"expected 100/100, got cand={len(cands)} gold={len(gold)}")

    cached = {}
    if CACHE.exists():
        for line in CACHE.read_text().splitlines():
            if line.strip():
                row = json.loads(line)
                if row.get("verdict") in {"PASS", "FAIL"} and not row.get("judge_error"):
                    cached[row["question"]] = row

    todo = [q for q in gold if q not in cached]
    print(f"JUDGE start cached={len(cached)} todo={len(todo)}", flush=True)

    def score_one(q: str) -> dict:
        rec = cands[q]
        g = gold[q]
        result = call_judge(judge, q, g.get("gold") or [], rec.get("answer") or "", api_key)
        return {
            "question": q,
            "id": g.get("id"),
            "hop": g.get("hop"),
            "gold": g.get("gold"),
            "answer": rec.get("answer"),
            "chat_id": rec.get("chat_id"),
            "turn_started_at": rec.get("turn_started_at"),
            "turn_completed_at": rec.get("turn_completed_at"),
            **result,
        }

    with CACHE.open("a", encoding="utf-8") as handle:
        if todo:
            with ThreadPoolExecutor(max_workers=4) as pool:
                futs = {pool.submit(score_one, q): q for q in todo}
                for i, fut in enumerate(as_completed(futs), 1):
                    row = fut.result()
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                    handle.flush()
                    cached[row["question"]] = row
                    print(f"JUDGE {i}/{len(todo)} {row.get('verdict')} err={bool(row.get('judge_error'))}", flush=True)

    errors = [r for r in cached.values() if r.get("judge_error")]
    if errors:
        print(f"JUDGE_ERRORS {len(errors)}", flush=True)
        return 1
    rows = [cached[r["question"].strip()] for r in gold_rows]
    passed = sum(r["verdict"] == "PASS" for r in rows)
    by_hop = {}
    for hop in (2, 3, 4):
        items = [r for r in rows if r.get("hop") == hop]
        by_hop[str(hop)] = {
            "total": len(items),
            "pass": sum(r["verdict"] == "PASS" for r in items),
        }
    summary = {
        "total": 100,
        "pass": passed,
        "fail": 100 - passed,
        "judge_errors": 0,
        "judge_model": "deepseek/deepseek-v4-pro",
        "by_hop": by_hop,
        "cases": rows,
    }
    SCORED.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"DONE {passed}/100 hops={by_hop}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
