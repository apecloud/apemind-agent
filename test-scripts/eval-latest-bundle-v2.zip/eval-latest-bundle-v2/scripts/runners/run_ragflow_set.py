#!/usr/bin/env python3
"""Run a RAGFlow chat against a frozen eval question set and emit jsonl.

Records per-question elapsed_s and tool_call count.
Usage: python3 run_ragflow_set.py <questions.jsonl> <chat_id> <output.jsonl> [--concurrency 6]
"""
import argparse
import json
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

TOKEN = open("/tmp/ragflow_token.txt").read().strip()
BASE = "http://localhost"

def chat(chat_id, q, timeout=600):
    body = json.dumps({"question": q, "stream": False, "session_id": ""}).encode()
    req = urllib.request.Request(
        f"{BASE}/api/v1/chats/{chat_id}/completions",
        data=body,
        headers={"Authorization": f"Bearer {TOKEN}", "Content-Type": "application/json"},
        method="POST",
    )
    t0 = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            elapsed = round(time.time() - t0, 1)
            d = json.loads(r.read().decode())
            if d.get("code") != 0:
                return {"err": f"code={d.get('code')}: {str(d.get('message'))[:150]}"}, elapsed
            data = d.get("data") or {}
            answer = data.get("answer") or ""
            refs = data.get("reference") or []
            if isinstance(refs, dict):
                refs = refs.get("chunks") or []
            return {"answer": answer, "refs": len(refs)}, elapsed
    except Exception as e:
        return {"err": f"{type(e).__name__}: {e}"}, round(time.time() - t0, 1)

def run_one(chat_id, ck, q, max_retries):
    answer, failure, elapsed, refs = None, None, None, 0
    for attempt in range(1 + max_retries):
        res, el = chat(chat_id, q)
        elapsed = el
        if "err" not in res:
            answer = res["answer"]
            refs = res["refs"]
            if not answer:
                failure = "empty_answer"
            break
        failure = res["err"]
        if attempt < max_retries:
            time.sleep(3 * attempt)
    return ck, answer, failure, elapsed, refs

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("questions")
    ap.add_argument("chat_id")
    ap.add_argument("output")
    ap.add_argument("--concurrency", type=int, default=6)
    ap.add_argument("--max-retries", type=int, default=3)
    args = ap.parse_args()

    rows = [json.loads(l) for l in open(args.questions, encoding="utf-8") if l.strip()]
    out, fails = [], 0
    with ThreadPoolExecutor(max_workers=args.concurrency) as ex:
        futs = {ex.submit(run_one, args.chat_id, r["case_key"], r["question"], args.max_retries): r["case_key"] for r in rows}
        done = 0
        for fut in as_completed(futs):
            ck, answer, failure, elapsed, refs = fut.result()
            rec = {"case_key": ck, "answer": answer if answer is not None else "", "elapsed_s": elapsed, "tool_calls": 0, "retrieved_chunks": refs}
            if failure:
                rec["failure"] = failure
                fails += 1
            out.append(rec)
            done += 1
            if done % 20 == 0:
                print(f"[{done}/{len(rows)}] fails={fails}", flush=True)

    out.sort(key=lambda r: r["case_key"])
    with open(args.output, "w", encoding="utf-8") as f:
        for rec in out:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"DONE {len(out)} rows, {fails} failures -> {args.output}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
