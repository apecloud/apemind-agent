# Dify / RAGFlow 跑题脚本（徐陆恺 2026-08-19）

本地横向对比（NQ V2 + MuSiQue V3 最新集）实际使用的跑题脚本。

- `run_dify_set.py <questions.jsonl> <app_api_key> <out.jsonl> [--base-url http://localhost:8080] [--concurrency 6]`
  Dify 侧：chat-mode app（非 agent-chat；agent-chat 不支持 blocking 模式）。
  逐题一问一答（每问新会话），输出 jsonl：case_key + answer + elapsed_s + tool_calls；失败行带 failure。

- `run_ragflow_set.py <questions.jsonl> <chat_id> <out.jsonl> [--concurrency 6]`
  RAGFlow 侧：RAGFlow API token 从 `RAGFLOW_TOKEN` 环境变量或 `/tmp/ragflow_token.txt` 读取，
  逐题一问一答，输出 jsonl：case_key + answer + elapsed_s + tool_calls + retrieved_chunks（含引用）。

配置：两系统均 jina-clip-v2 向量化 + DeepSeek V4 Flash 生成。
注意：Dify 会话约 1h 过期需重新登录 console 拿 cookie；RAGFlow 登录为 RSA+base64 怪癖（见 notes/dify-eval-task99.md）。
