#!/usr/bin/env python3
"""Run a Dify app against a frozen eval question set (concurrent) and emit jsonl.

Usage: python3 run_dify_set.py <questions.jsonl> <app_api_key> <output.jsonl>
       [--base-url http://localhost:8080] [--concurrency 6] [--max-retries 3]
"""
import argparse
import json
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

def chat(base_url: str, api_key: str, query: str, timeout: int = 300) -> dict:
    body = json.dumps({
        "inputs": {},
        "query": query,
        "response_mode": "blocking",
        "user": "eval-run",
        "conversation_id": "",
    }).encode()
    req = urllib.request.Request(
        f"{base_url}/v1/chat-messages",
        data=body,
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return {"ok": True, "data": json.loads(resp.read().decode())}
    except urllib.error.HTTPError as e:
        return {"ok": False, "error": f"HTTP {e.code}: {e.read().decode()[:200]}"}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

def run_one(base_url, api_key, ck, q, max_retries):
    answer, failure = None, None
    for attempt in range(1 + max_retries):
        r = chat(base_url, api_key, q)
        if r["ok"]:
            d = r["data"]
            answer = d.get("answer")
            if not answer:
                failure = "empty_answer"
            break
        failure = r.get("error", "unknown")
        if attempt < max_retries:
            time.sleep(3 * attempt)
    return ck, answer, failure

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("questions")
    ap.add_argument("api_key")
    ap.add_argument("output")
    ap.add_argument("--base-url", default="http://localhost:8080")
    ap.add_argument("--concurrency", type=int, default=6)
    ap.add_argument("--max-retries", type=int, default=3)
    args = ap.parse_args()

    rows = [json.loads(l) for l in open(args.questions, encoding="utf-8") if l.strip()]
    out, fails = [], 0
    with ThreadPoolExecutor(max_workers=args.concurrency) as ex:
        futs = {ex.submit(run_one, args.base_url, args.api_key, r["case_key"], r["question"], args.max_retries): r["case_key"] for r in rows}
        done = 0
        for fut in as_completed(futs):
            ck, answer, failure = fut.result()
            rec = {"case_key": ck, "answer": answer if answer is not None else ""}
            if failure:
                rec["failure"] = failure
                fails += 1
            out.append(rec)
            done += 1
            if done % 20 == 0:
                print(f"[{done}/{len(rows)}] fails={fails}", flush=True)

    out.sort(key=lambda r: r["case_key"])
    with open(args.output, "w", encoding="utf-8") as f:
        for rec in out:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    print(f"DONE {len(out)} rows, {fails} failures -> {args.output}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
