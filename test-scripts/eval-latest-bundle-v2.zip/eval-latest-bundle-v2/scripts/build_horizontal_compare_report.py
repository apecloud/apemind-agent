#!/usr/bin/env python3
"""ApeMind vs RAGFlow vs Dify latest-set comparison image."""

from __future__ import annotations

import subprocess
from pathlib import Path

OUT = Path("/Users/yuguanghui/.slock/agents/a6ce9925-ec54-4b06-9540-0242f6d3de40/results/eval-packs")
HTML = OUT / "horizontal-compare.html"
PNG = OUT / "horizontal-compare.png"

html = r"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<style>
  html,body{margin:0;padding:0;background:#eef2ee}
  .page{width:1080px;margin:0 auto;background:#f3f6f3;color:#1a2a28;
        font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Hiragino Sans GB","Noto Sans SC",sans-serif}
  .hero{background:#163835;color:#fff;padding:36px 44px 26px;border-bottom:6px solid #d4a017}
  .hero h1{margin:0 0 8px;font-size:40px;font-weight:750}
  .hero p{margin:0;font-size:16px;opacity:.82}
  .body{padding:22px 44px 28px}
  .cards{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin:0 0 22px}
  .card{background:#fff;border:1px solid #d5dfd6;padding:14px}
  .card b{display:block;font-size:28px;margin-bottom:6px}
  .card span{color:#5c6c69;font-size:13px;line-height:1.4}
  h2{margin:22px 0 8px;font-size:20px;font-weight:700}
  table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #d5dfd6}
  th,td{padding:9px 12px;text-align:left;font-size:14px;border-bottom:1px solid #e5ece6}
  th{background:#eef3ef;font-weight:650;color:#31423f}
  tr.hi td{background:#fff6d8}
  .note{margin-top:16px;color:#6a7875;font-size:12px;line-height:1.5}
</style></head>
<body><div class="page">
  <div class="hero">
    <h1>ApeMind 横向对比</h1>
    <p>NQ V2 · MuSiQue V3 · DeepSeek V4 Pro 评分</p>
  </div>
  <div class="body">
    <div class="cards">
      <div class="card"><b>98/118</b><span>NQ V2 · 83.1% · ApeMind Qwen3.6 27B</span></div>
      <div class="card"><b>90/100</b><span>MuSiQue V3 · 90.0% · ApeMind V4 Pro / Qwen3.8</span></div>
    </div>

    <h2>NQ V2 · 118 题</h2>
    <table>
      <tr><th>系统</th><th>正确</th><th>正确率</th><th>短答案 · 61</th><th>长答案 · 20</th><th>是否 · 5</th><th>无答案 · 32</th></tr>
      <tr class="hi"><td>ApeMind · Qwen3.6 27B</td><td>98/118</td><td>83.1%</td><td>60/61</td><td>16/20</td><td>5/5</td><td>17/32</td></tr>
      <tr><td>RAGFlow · V4 Flash</td><td>81/118</td><td>68.6%</td><td>48/61</td><td>15/20</td><td>4/5</td><td>14/32</td></tr>
      <tr><td>Dify · V4 Flash</td><td>57/118</td><td>48.3%</td><td>40/61</td><td>10/20</td><td>4/5</td><td>3/32</td></tr>
    </table>

    <h2>MuSiQue V3 · 100 题</h2>
    <table>
      <tr><th>系统</th><th>正确</th><th>正确率</th><th>2 跳 · 51</th><th>3 跳 · 43</th><th>4 跳 · 6</th></tr>
      <tr class="hi"><td>ApeMind · V4 Pro</td><td>90/100</td><td>90.0%</td><td>43/51</td><td>41/43</td><td>6/6</td></tr>
      <tr><td>Dify · V4 Flash</td><td>37/100</td><td>37.0%</td><td>18/51</td><td>16/43</td><td>3/6</td></tr>
      <tr><td>RAGFlow · V4 Flash</td><td>35/100</td><td>35.0%</td><td>20/51</td><td>14/43</td><td>1/6</td></tr>
    </table>

    <div class="note">
      ApeMind 取该集四模型最高分。Dify / RAGFlow 为 jina-clip-v2 + DeepSeek V4 Flash。436 题评分 0 次失败。HotpotQA / RGB 未按新集重跑。
    </div>
  </div>
</div></body></html>
"""


def main() -> int:
    HTML.write_text(html, encoding="utf-8")
    chrome = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    subprocess.run(
        [
            chrome,
            "--headless=new",
            "--disable-gpu",
            "--hide-scrollbars",
            f"--screenshot={PNG}",
            "--window-size=1080,980",
            "--default-background-color=00000000",
            HTML.as_uri(),
        ],
        check=True,
        capture_output=True,
        timeout=60,
    )
    print("wrote", PNG)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
