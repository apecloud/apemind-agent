# RGB 导出包

线上四集评测使用的 RGB 中文固定 200 题。

## 内容

- `questions.csv` / `questions.jsonl` / `questions.md`：题目与标准答案
- `documents/`：测试文档

## 规模

- 题目：200
- 文档：1506
