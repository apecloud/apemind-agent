# RGB 测试题目与标准答案

共 200 题。

### rgb-noise-001

**问题：** 海底捞的新任首席执行官是谁？

**标准答案：** 杨利娟

**来源文档：** rgb-zh-noise-Q001-P00, rgb-zh-noise-Q001-P01, rgb-zh-noise-Q001-P02, rgb-zh-noise-Q001-P03, rgb-zh-noise-Q001-P04, rgb-zh-noise-Q001-P05, rgb-zh-noise-Q001-P06, rgb-zh-noise-Q001-P07, rgb-zh-noise-Q001-P08, rgb-zh-noise-Q001-P09, rgb-zh-noise-Q001-P11, rgb-zh-noise-Q001-P13, rgb-zh-noise-Q001-P14, rgb-zh-noise-Q001-P15, rgb-zh-noise-Q001-P16, rgb-zh-noise-Q001-P17, rgb-zh-noise-Q001-P18, rgb-zh-noise-Q001-P19

### rgb-noise-002

**问题：** 印度第三艘“歼敌者”级核潜艇下水的时间

**标准答案：** 2021年11月23日

**来源文档：** rgb-zh-noise-Q002-P00, rgb-zh-noise-Q002-P01, rgb-zh-noise-Q002-P02, rgb-zh-noise-Q002-P04

### rgb-noise-003

**问题：** 2022广州网球巡回赛U14组男单冠军是谁

**标准答案：** 王发

**来源文档：** rgb-zh-noise-Q003-P00, rgb-zh-noise-Q003-P01, rgb-zh-noise-Q003-P02, rgb-zh-noise-Q003-P03, rgb-zh-noise-Q003-P04, rgb-zh-noise-Q003-P05, rgb-zh-noise-Q003-P06, rgb-zh-noise-Q003-P07, rgb-zh-noise-Q003-P08, rgb-zh-noise-Q003-P09, rgb-zh-noise-Q003-P10, rgb-zh-noise-Q003-P11, rgb-zh-noise-Q003-P12, rgb-zh-noise-Q003-P13, rgb-zh-noise-Q003-P14, rgb-zh-noise-Q003-P15, rgb-zh-noise-Q003-P16, rgb-zh-noise-Q003-P17, rgb-zh-noise-Q003-P18, rgb-zh-noise-Q003-P19, rgb-zh-noise-Q003-P20, rgb-zh-noise-Q003-P21, rgb-zh-noise-Q003-P22, rgb-zh-noise-Q003-P23, rgb-zh-noise-Q003-P24

### rgb-noise-004

**问题：** 美国最高法院推翻了哪个堕胎判例

**标准答案：** 罗诉韦德案

**来源文档：** rgb-zh-noise-Q004-P00, rgb-zh-noise-Q004-P01, rgb-zh-noise-Q004-P02, rgb-zh-noise-Q004-P03, rgb-zh-noise-Q004-P04, rgb-zh-noise-Q004-P05, rgb-zh-noise-Q004-P06, rgb-zh-noise-Q004-P07, rgb-zh-noise-Q004-P08, rgb-zh-noise-Q004-P09, rgb-zh-noise-Q004-P10, rgb-zh-noise-Q004-P11, rgb-zh-noise-Q004-P12, rgb-zh-noise-Q004-P13, rgb-zh-noise-Q004-P14, rgb-zh-noise-Q004-P15, rgb-zh-noise-Q004-P16

### rgb-noise-005

**问题：** 《七人乐队》的导演是谁？

**标准答案：** 洪金宝; 许鞍华; 谭家明; 袁和平; 杜琪峰; 林岭东; 徐克

**来源文档：** rgb-zh-noise-Q005-P00, rgb-zh-noise-Q005-P01, rgb-zh-noise-Q005-P02, rgb-zh-noise-Q005-P03

### rgb-noise-006

**问题：** 神舟十三号飞船的成员有哪些

**标准答案：** 翟志刚; 王亚平; 叶光富

**来源文档：** rgb-zh-noise-Q006-P00, rgb-zh-noise-Q006-P01, rgb-zh-noise-Q006-P02, rgb-zh-noise-Q006-P03, rgb-zh-noise-Q006-P04, rgb-zh-noise-Q006-P05, rgb-zh-noise-Q006-P06, rgb-zh-noise-Q006-P07, rgb-zh-noise-Q006-P08

### rgb-noise-007

**问题：** 北京冬奥会男子500米速度滑冰金牌

**标准答案：** 高亭宇

**来源文档：** rgb-zh-noise-Q007-P00, rgb-zh-noise-Q007-P01, rgb-zh-noise-Q007-P02, rgb-zh-noise-Q007-P03, rgb-zh-noise-Q007-P04, rgb-zh-noise-Q007-P05, rgb-zh-noise-Q007-P06, rgb-zh-noise-Q007-P07, rgb-zh-noise-Q007-P08, rgb-zh-noise-Q007-P09, rgb-zh-noise-Q007-P10, rgb-zh-noise-Q007-P11, rgb-zh-noise-Q007-P12, rgb-zh-noise-Q007-P13, rgb-zh-noise-Q007-P14, rgb-zh-noise-Q007-P15, rgb-zh-noise-Q007-P16, rgb-zh-noise-Q007-P17, rgb-zh-noise-Q007-P18, rgb-zh-noise-Q007-P19, rgb-zh-noise-Q007-P20, rgb-zh-noise-Q007-P21, rgb-zh-noise-Q007-P22, rgb-zh-noise-Q007-P23, rgb-zh-noise-Q007-P24, rgb-zh-noise-Q007-P25, rgb-zh-noise-Q007-P26, rgb-zh-noise-Q007-P27, rgb-zh-noise-Q007-P28, rgb-zh-noise-Q007-P29, rgb-zh-noise-Q007-P30

### rgb-noise-008

**问题：** 《漫长的季节》的类型是什么？

**标准答案：** 悬疑

**来源文档：** rgb-zh-noise-Q008-P00, rgb-zh-noise-Q008-P01, rgb-zh-noise-Q008-P02, rgb-zh-noise-Q008-P03, rgb-zh-noise-Q008-P04, rgb-zh-noise-Q008-P05, rgb-zh-noise-Q008-P06, rgb-zh-noise-Q008-P07, rgb-zh-noise-Q008-P08, rgb-zh-noise-Q008-P09, rgb-zh-noise-Q008-P10, rgb-zh-noise-Q008-P11, rgb-zh-noise-Q008-P12, rgb-zh-noise-Q008-P13, rgb-zh-noise-Q008-P14, rgb-zh-noise-Q008-P15, rgb-zh-noise-Q008-P16

### rgb-noise-009

**问题：** 谁是北京冬奥会第一棒火炬手

**标准答案：** 罗致焕

**来源文档：** rgb-zh-noise-Q009-P00, rgb-zh-noise-Q009-P01, rgb-zh-noise-Q009-P02, rgb-zh-noise-Q009-P03, rgb-zh-noise-Q009-P04

### rgb-noise-010

**问题：** 2023年国考实际参考人数

**标准答案：** 152.5万

**来源文档：** rgb-zh-noise-Q010-P00, rgb-zh-noise-Q010-P01, rgb-zh-noise-Q010-P02, rgb-zh-noise-Q010-P03, rgb-zh-noise-Q010-P04, rgb-zh-noise-Q010-P05, rgb-zh-noise-Q010-P06, rgb-zh-noise-Q010-P07, rgb-zh-noise-Q010-P08, rgb-zh-noise-Q010-P09

### rgb-noise-011

**问题：** 2021年中国电影市场总票房是多少？

**标准答案：** 472.58亿元

**来源文档：** rgb-zh-noise-Q011-P00, rgb-zh-noise-Q011-P01, rgb-zh-noise-Q011-P02, rgb-zh-noise-Q011-P03

### rgb-noise-012

**问题：** 黑石集团预测2022年美联储将加息几次

**标准答案：** ['4次', '四次']

**来源文档：** rgb-zh-noise-Q012-P00, rgb-zh-noise-Q012-P02, rgb-zh-noise-Q012-P03, rgb-zh-noise-Q012-P04, rgb-zh-noise-Q012-P05, rgb-zh-noise-Q012-P06, rgb-zh-noise-Q012-P07

### rgb-noise-013

**问题：** 2022春节档票房冠军是哪部电影

**标准答案：** 长津湖之水门桥

**来源文档：** rgb-zh-noise-Q013-P00, rgb-zh-noise-Q013-P01, rgb-zh-noise-Q013-P02, rgb-zh-noise-Q013-P03, rgb-zh-noise-Q013-P04, rgb-zh-noise-Q013-P05, rgb-zh-noise-Q013-P06, rgb-zh-noise-Q013-P07

### rgb-noise-014

**问题：** 2022年上半年，西藏经济增长了多少？

**标准答案：** 4.8%

**来源文档：** rgb-zh-noise-Q014-P00

### rgb-noise-015

**问题：** 零壹空间是谁创立的？

**标准答案：** 舒畅

**来源文档：** rgb-zh-noise-Q015-P00, rgb-zh-noise-Q015-P01, rgb-zh-noise-Q015-P02, rgb-zh-noise-Q015-P03, rgb-zh-noise-Q015-P04, rgb-zh-noise-Q015-P05, rgb-zh-noise-Q015-P06, rgb-zh-noise-Q015-P07, rgb-zh-noise-Q015-P08, rgb-zh-noise-Q015-P09, rgb-zh-noise-Q015-P10, rgb-zh-noise-Q015-P11, rgb-zh-noise-Q015-P12, rgb-zh-noise-Q015-P13

### rgb-noise-016

**问题：** 众议院TikTok听证会的时间

**标准答案：** 3月23日

**来源文档：** rgb-zh-noise-Q016-P00, rgb-zh-noise-Q016-P01, rgb-zh-noise-Q016-P02, rgb-zh-noise-Q016-P03, rgb-zh-noise-Q016-P04, rgb-zh-noise-Q016-P05, rgb-zh-noise-Q016-P06, rgb-zh-noise-Q016-P07

### rgb-noise-017

**问题：** 美国2021年GDP增长多少

**标准答案：** 5.7%

**来源文档：** rgb-zh-noise-Q017-P00, rgb-zh-noise-Q017-P01, rgb-zh-noise-Q017-P02, rgb-zh-noise-Q017-P03, rgb-zh-noise-Q017-P04, rgb-zh-noise-Q017-P05, rgb-zh-noise-Q017-P06

### rgb-noise-018

**问题：** C919商业首飞路线

**标准答案：** 上海; 北京

**来源文档：** rgb-zh-noise-Q018-P00, rgb-zh-noise-Q018-P01, rgb-zh-noise-Q018-P02, rgb-zh-noise-Q018-P03, rgb-zh-noise-Q018-P04

### rgb-noise-019

**问题：** 2023年1月3日恒指收盘点数

**标准答案：** 20145.29

**来源文档：** rgb-zh-noise-Q019-P00

### rgb-noise-020

**问题：** 2023春运首日旅客发送量

**标准答案：** ['3473.6万人次', '3474万人次']

**来源文档：** rgb-zh-noise-Q020-P00, rgb-zh-noise-Q020-P01, rgb-zh-noise-Q020-P02, rgb-zh-noise-Q020-P03

### rgb-noise-021

**问题：** 2022年乒乓球团体世锦赛会在哪举行

**标准答案：** 成都

**来源文档：** rgb-zh-noise-Q021-P00, rgb-zh-noise-Q021-P01, rgb-zh-noise-Q021-P02, rgb-zh-noise-Q021-P03, rgb-zh-noise-Q021-P04, rgb-zh-noise-Q021-P05

### rgb-noise-022

**问题：** 果果合唱团是谁创办的？

**标准答案：** 刘超

**来源文档：** rgb-zh-noise-Q022-P00, rgb-zh-noise-Q022-P01, rgb-zh-noise-Q022-P02, rgb-zh-noise-Q022-P03, rgb-zh-noise-Q022-P04, rgb-zh-noise-Q022-P05, rgb-zh-noise-Q022-P06, rgb-zh-noise-Q022-P07, rgb-zh-noise-Q022-P08, rgb-zh-noise-Q022-P09, rgb-zh-noise-Q022-P10, rgb-zh-noise-Q022-P11, rgb-zh-noise-Q022-P12, rgb-zh-noise-Q022-P13, rgb-zh-noise-Q022-P14, rgb-zh-noise-Q022-P15, rgb-zh-noise-Q022-P16, rgb-zh-noise-Q022-P17, rgb-zh-noise-Q022-P18, rgb-zh-noise-Q022-P19

### rgb-noise-023

**问题：** 泸定地震造成多少人遇难？

**标准答案：** 93人

**来源文档：** rgb-zh-noise-Q023-P00, rgb-zh-noise-Q023-P01, rgb-zh-noise-Q023-P02, rgb-zh-noise-Q023-P03

### rgb-noise-024

**问题：** 首趟RCEP班列的起点？

**标准答案：** 南宁

**来源文档：** rgb-zh-noise-Q024-P00, rgb-zh-noise-Q024-P01, rgb-zh-noise-Q024-P02, rgb-zh-noise-Q024-P03, rgb-zh-noise-Q024-P04, rgb-zh-noise-Q024-P05

### rgb-noise-025

**问题：** 香港第六任行政长官选举结果？

**标准答案：** 李家超

**来源文档：** rgb-zh-noise-Q025-P00, rgb-zh-noise-Q025-P01, rgb-zh-noise-Q025-P02, rgb-zh-noise-Q025-P03, rgb-zh-noise-Q025-P04, rgb-zh-noise-Q025-P05, rgb-zh-noise-Q025-P06, rgb-zh-noise-Q025-P07, rgb-zh-noise-Q025-P08, rgb-zh-noise-Q025-P09, rgb-zh-noise-Q025-P10, rgb-zh-noise-Q025-P11, rgb-zh-noise-Q025-P12, rgb-zh-noise-Q025-P13, rgb-zh-noise-Q025-P14, rgb-zh-noise-Q025-P15, rgb-zh-noise-Q025-P16, rgb-zh-noise-Q025-P17, rgb-zh-noise-Q025-P18, rgb-zh-noise-Q025-P19, rgb-zh-noise-Q025-P20, rgb-zh-noise-Q025-P21, rgb-zh-noise-Q025-P22, rgb-zh-noise-Q025-P23

### rgb-noise-026

**问题：** 2022年G20峰会的时间？

**标准答案：** 11月15日; 16日

**来源文档：** rgb-zh-noise-Q026-P00, rgb-zh-noise-Q026-P01, rgb-zh-noise-Q026-P02, rgb-zh-noise-Q026-P03, rgb-zh-noise-Q026-P04, rgb-zh-noise-Q026-P05

### rgb-noise-027

**问题：** 2021-2022赛季欧冠冠军

**标准答案：** 皇家马德里

**来源文档：** rgb-zh-noise-Q027-P00, rgb-zh-noise-Q027-P01, rgb-zh-noise-Q027-P02, rgb-zh-noise-Q027-P03, rgb-zh-noise-Q027-P04, rgb-zh-noise-Q027-P05, rgb-zh-noise-Q027-P06, rgb-zh-noise-Q027-P07, rgb-zh-noise-Q027-P08, rgb-zh-noise-Q027-P09, rgb-zh-noise-Q027-P10, rgb-zh-noise-Q027-P11, rgb-zh-noise-Q027-P12

### rgb-noise-028

**问题：** 2022年百花奖最佳影片奖

**标准答案：** 长津湖

**来源文档：** rgb-zh-noise-Q028-P00, rgb-zh-noise-Q028-P01, rgb-zh-noise-Q028-P02, rgb-zh-noise-Q028-P03, rgb-zh-noise-Q028-P04, rgb-zh-noise-Q028-P05, rgb-zh-noise-Q028-P06, rgb-zh-noise-Q028-P07, rgb-zh-noise-Q028-P08, rgb-zh-noise-Q028-P09, rgb-zh-noise-Q028-P10, rgb-zh-noise-Q028-P11, rgb-zh-noise-Q028-P12, rgb-zh-noise-Q028-P13, rgb-zh-noise-Q028-P14, rgb-zh-noise-Q028-P15, rgb-zh-noise-Q028-P16

### rgb-noise-029

**问题：** 2022年世界互联网大会在哪里举办？

**标准答案：** 乌镇

**来源文档：** rgb-zh-noise-Q029-P00, rgb-zh-noise-Q029-P01, rgb-zh-noise-Q029-P02, rgb-zh-noise-Q029-P03, rgb-zh-noise-Q029-P04, rgb-zh-noise-Q029-P05, rgb-zh-noise-Q029-P06, rgb-zh-noise-Q029-P07, rgb-zh-noise-Q029-P08, rgb-zh-noise-Q029-P09, rgb-zh-noise-Q029-P10, rgb-zh-noise-Q029-P11, rgb-zh-noise-Q029-P12, rgb-zh-noise-Q029-P13, rgb-zh-noise-Q029-P14, rgb-zh-noise-Q029-P15, rgb-zh-noise-Q029-P16, rgb-zh-noise-Q029-P17, rgb-zh-noise-Q029-P18, rgb-zh-noise-Q029-P19, rgb-zh-noise-Q029-P20, rgb-zh-noise-Q029-P21, rgb-zh-noise-Q029-P22, rgb-zh-noise-Q029-P23, rgb-zh-noise-Q029-P24, rgb-zh-noise-Q029-P25, rgb-zh-noise-Q029-P26

### rgb-noise-030

**问题：** 《阿凡达：水之道》国内上映日期

**标准答案：** 12月16日

**来源文档：** rgb-zh-noise-Q030-P00, rgb-zh-noise-Q030-P01, rgb-zh-noise-Q030-P02, rgb-zh-noise-Q030-P03, rgb-zh-noise-Q030-P04, rgb-zh-noise-Q030-P05, rgb-zh-noise-Q030-P06, rgb-zh-noise-Q030-P07, rgb-zh-noise-Q030-P08, rgb-zh-noise-Q030-P09

### rgb-noise-031

**问题：** 北京冬奥会吉祥物叫什么

**标准答案：** 冰墩墩

**来源文档：** rgb-zh-noise-Q031-P00, rgb-zh-noise-Q031-P01, rgb-zh-noise-Q031-P02, rgb-zh-noise-Q031-P03, rgb-zh-noise-Q031-P04, rgb-zh-noise-Q031-P05, rgb-zh-noise-Q031-P06, rgb-zh-noise-Q031-P07, rgb-zh-noise-Q031-P08, rgb-zh-noise-Q031-P09, rgb-zh-noise-Q031-P10, rgb-zh-noise-Q031-P11, rgb-zh-noise-Q031-P12, rgb-zh-noise-Q031-P13, rgb-zh-noise-Q031-P14, rgb-zh-noise-Q031-P15, rgb-zh-noise-Q031-P16

### rgb-noise-032

**问题：** 神舟十四号的航天员有谁

**标准答案：** 陈冬; 刘洋; 蔡旭哲

**来源文档：** rgb-zh-noise-Q032-P00, rgb-zh-noise-Q032-P01, rgb-zh-noise-Q032-P02, rgb-zh-noise-Q032-P03, rgb-zh-noise-Q032-P04, rgb-zh-noise-Q032-P05, rgb-zh-noise-Q032-P06, rgb-zh-noise-Q032-P07, rgb-zh-noise-Q032-P08, rgb-zh-noise-Q032-P09, rgb-zh-noise-Q032-P10, rgb-zh-noise-Q032-P11, rgb-zh-noise-Q032-P12, rgb-zh-noise-Q032-P13

### rgb-noise-033

**问题：** 2022年APEC会议在哪里举行？

**标准答案：** 曼谷

**来源文档：** rgb-zh-noise-Q033-P00, rgb-zh-noise-Q033-P01, rgb-zh-noise-Q033-P02, rgb-zh-noise-Q033-P03, rgb-zh-noise-Q033-P04, rgb-zh-noise-Q033-P05, rgb-zh-noise-Q033-P06, rgb-zh-noise-Q033-P07, rgb-zh-noise-Q033-P08, rgb-zh-noise-Q033-P09, rgb-zh-noise-Q033-P10, rgb-zh-noise-Q033-P11, rgb-zh-noise-Q033-P12, rgb-zh-noise-Q033-P13, rgb-zh-noise-Q033-P14, rgb-zh-noise-Q033-P15, rgb-zh-noise-Q033-P17, rgb-zh-noise-Q033-P18

### rgb-noise-034

**问题：** 欧元区2022年8月通胀率是多少？

**标准答案：** 9.1%

**来源文档：** rgb-zh-noise-Q034-P00, rgb-zh-noise-Q034-P01, rgb-zh-noise-Q034-P02, rgb-zh-noise-Q034-P03, rgb-zh-noise-Q034-P04, rgb-zh-noise-Q034-P05

### rgb-noise-035

**问题：** 2022年冬奥会开幕式总导演是谁

**标准答案：** 张艺谋

**来源文档：** rgb-zh-noise-Q035-P00, rgb-zh-noise-Q035-P01, rgb-zh-noise-Q035-P02, rgb-zh-noise-Q035-P03, rgb-zh-noise-Q035-P04, rgb-zh-noise-Q035-P05, rgb-zh-noise-Q035-P06, rgb-zh-noise-Q035-P07, rgb-zh-noise-Q035-P08, rgb-zh-noise-Q035-P09, rgb-zh-noise-Q035-P10, rgb-zh-noise-Q035-P11, rgb-zh-noise-Q035-P12, rgb-zh-noise-Q035-P13, rgb-zh-noise-Q035-P14, rgb-zh-noise-Q035-P15, rgb-zh-noise-Q035-P16, rgb-zh-noise-Q035-P17, rgb-zh-noise-Q035-P18, rgb-zh-noise-Q035-P19, rgb-zh-noise-Q035-P20, rgb-zh-noise-Q035-P21, rgb-zh-noise-Q035-P22, rgb-zh-noise-Q035-P23, rgb-zh-noise-Q035-P24, rgb-zh-noise-Q035-P25

### rgb-noise-036

**问题：** 2023年春节档票房最高的三部电影

**标准答案：** 满江红; 流浪地球2; 熊出没

**来源文档：** rgb-zh-noise-Q036-P00, rgb-zh-noise-Q036-P01, rgb-zh-noise-Q036-P02, rgb-zh-noise-Q036-P03, rgb-zh-noise-Q036-P04, rgb-zh-noise-Q036-P05, rgb-zh-noise-Q036-P06, rgb-zh-noise-Q036-P07

### rgb-noise-037

**问题：** 浪姐4首播时间

**标准答案：** 5月5日

**来源文档：** rgb-zh-noise-Q037-P00, rgb-zh-noise-Q037-P01, rgb-zh-noise-Q037-P02, rgb-zh-noise-Q037-P03, rgb-zh-noise-Q037-P04, rgb-zh-noise-Q037-P05, rgb-zh-noise-Q037-P06

### rgb-noise-038

**问题：** iPhone SE 3的起售价是多少？

**标准答案：** 3499元

**来源文档：** rgb-zh-noise-Q038-P00, rgb-zh-noise-Q038-P01, rgb-zh-noise-Q038-P02, rgb-zh-noise-Q038-P03, rgb-zh-noise-Q038-P04

### rgb-noise-039

**问题：** 小米13系列手机发布时间？

**标准答案：** 12月11日

**来源文档：** rgb-zh-noise-Q039-P00, rgb-zh-noise-Q039-P01, rgb-zh-noise-Q039-P02, rgb-zh-noise-Q039-P03, rgb-zh-noise-Q039-P04, rgb-zh-noise-Q039-P05

### rgb-noise-040

**问题：** 北京冬奥会澳大利亚运动员数量

**标准答案：** 44

**来源文档：** rgb-zh-noise-Q040-P00

### rgb-noise-041

**问题：** 俄罗斯瓦格纳是什么

**标准答案：** 私营军事

**来源文档：** rgb-zh-noise-Q041-P00, rgb-zh-noise-Q041-P01, rgb-zh-noise-Q041-P02

### rgb-noise-042

**问题：** 《炽道》的主演

**标准答案：** 金晨; 王安宇

**来源文档：** rgb-zh-noise-Q042-P00, rgb-zh-noise-Q042-P01, rgb-zh-noise-Q042-P02, rgb-zh-noise-Q042-P03, rgb-zh-noise-Q042-P04, rgb-zh-noise-Q042-P05, rgb-zh-noise-Q042-P06, rgb-zh-noise-Q042-P07, rgb-zh-noise-Q042-P08, rgb-zh-noise-Q042-P09, rgb-zh-noise-Q042-P10, rgb-zh-noise-Q042-P11, rgb-zh-noise-Q042-P12, rgb-zh-noise-Q042-P13, rgb-zh-noise-Q042-P14, rgb-zh-noise-Q042-P15, rgb-zh-noise-Q042-P16

### rgb-noise-043

**问题：** 卡塔尔世界杯四强

**标准答案：** 阿根廷; 克罗地亚; 摩洛哥; 法国

**来源文档：** rgb-zh-noise-Q043-P00, rgb-zh-noise-Q043-P01, rgb-zh-noise-Q043-P02, rgb-zh-noise-Q043-P03, rgb-zh-noise-Q043-P04, rgb-zh-noise-Q043-P05, rgb-zh-noise-Q043-P06, rgb-zh-noise-Q043-P07, rgb-zh-noise-Q043-P08, rgb-zh-noise-Q043-P09

### rgb-noise-044

**问题：** 2023年北京市高考出分时间

**标准答案：** 6月25日

**来源文档：** rgb-zh-noise-Q044-P00, rgb-zh-noise-Q044-P01, rgb-zh-noise-Q044-P02, rgb-zh-noise-Q044-P03, rgb-zh-noise-Q044-P04, rgb-zh-noise-Q044-P05, rgb-zh-noise-Q044-P06, rgb-zh-noise-Q044-P07, rgb-zh-noise-Q044-P08, rgb-zh-noise-Q044-P09, rgb-zh-noise-Q044-P10, rgb-zh-noise-Q044-P11, rgb-zh-noise-Q044-P12, rgb-zh-noise-Q044-P13, rgb-zh-noise-Q044-P14, rgb-zh-noise-Q044-P15, rgb-zh-noise-Q044-P16, rgb-zh-noise-Q044-P17, rgb-zh-noise-Q044-P18, rgb-zh-noise-Q044-P19, rgb-zh-noise-Q044-P20, rgb-zh-noise-Q044-P21, rgb-zh-noise-Q044-P22

### rgb-noise-045

**问题：** 2022年高考报名人数

**标准答案：** 1193万

**来源文档：** rgb-zh-noise-Q045-P00, rgb-zh-noise-Q045-P01, rgb-zh-noise-Q045-P02, rgb-zh-noise-Q045-P03, rgb-zh-noise-Q045-P04, rgb-zh-noise-Q045-P05, rgb-zh-noise-Q045-P06, rgb-zh-noise-Q045-P07, rgb-zh-noise-Q045-P08, rgb-zh-noise-Q045-P09, rgb-zh-noise-Q045-P10, rgb-zh-noise-Q045-P11, rgb-zh-noise-Q045-P12, rgb-zh-noise-Q045-P13

### rgb-noise-046

**问题：** 微软花了多少钱收购动视暴雪

**标准答案：** 687亿美元

**来源文档：** rgb-zh-noise-Q046-P00, rgb-zh-noise-Q046-P01, rgb-zh-noise-Q046-P02, rgb-zh-noise-Q046-P03, rgb-zh-noise-Q046-P04

### rgb-noise-047

**问题：** 中国第三艘航母名字

**标准答案：** 福建

**来源文档：** rgb-zh-noise-Q047-P00, rgb-zh-noise-Q047-P01, rgb-zh-noise-Q047-P02, rgb-zh-noise-Q047-P03, rgb-zh-noise-Q047-P04, rgb-zh-noise-Q047-P05, rgb-zh-noise-Q047-P06, rgb-zh-noise-Q047-P07, rgb-zh-noise-Q047-P08, rgb-zh-noise-Q047-P09, rgb-zh-noise-Q047-P10, rgb-zh-noise-Q047-P11, rgb-zh-noise-Q047-P12, rgb-zh-noise-Q047-P13, rgb-zh-noise-Q047-P14, rgb-zh-noise-Q047-P15, rgb-zh-noise-Q047-P16, rgb-zh-noise-Q047-P17, rgb-zh-noise-Q047-P18, rgb-zh-noise-Q047-P19, rgb-zh-noise-Q047-P20, rgb-zh-noise-Q047-P21, rgb-zh-noise-Q047-P22, rgb-zh-noise-Q047-P23

### rgb-noise-048

**问题：** 汤臣倍健2022年上半年的营收为多少？

**标准答案：** 42.21亿元

**来源文档：** rgb-zh-noise-Q048-P00, rgb-zh-noise-Q048-P01, rgb-zh-noise-Q048-P02, rgb-zh-noise-Q048-P03, rgb-zh-noise-Q048-P04, rgb-zh-noise-Q048-P05, rgb-zh-noise-Q048-P06, rgb-zh-noise-Q048-P07, rgb-zh-noise-Q048-P08

### rgb-noise-049

**问题：** 浙江省第二届国际龙舟公开赛有多少支队伍参赛

**标准答案：** 32

**来源文档：** rgb-zh-noise-Q049-P00, rgb-zh-noise-Q049-P01, rgb-zh-noise-Q049-P02, rgb-zh-noise-Q049-P03, rgb-zh-noise-Q049-P04

### rgb-noise-050

**问题：** 北京2022年冬奥会口号是什么

**标准答案：** 一起向未来

**来源文档：** rgb-zh-noise-Q050-P00, rgb-zh-noise-Q050-P01, rgb-zh-noise-Q050-P02, rgb-zh-noise-Q050-P03, rgb-zh-noise-Q050-P04, rgb-zh-noise-Q050-P05, rgb-zh-noise-Q050-P06, rgb-zh-noise-Q050-P07, rgb-zh-noise-Q050-P08, rgb-zh-noise-Q050-P09, rgb-zh-noise-Q050-P10, rgb-zh-noise-Q050-P11, rgb-zh-noise-Q050-P12, rgb-zh-noise-Q050-P13, rgb-zh-noise-Q050-P14, rgb-zh-noise-Q050-P15, rgb-zh-noise-Q050-P16, rgb-zh-noise-Q050-P17, rgb-zh-noise-Q050-P18, rgb-zh-noise-Q050-P19, rgb-zh-noise-Q050-P20, rgb-zh-noise-Q050-P21, rgb-zh-noise-Q050-P22, rgb-zh-noise-Q050-P23

### rgb-int-001

**问题：** 2023年北京和上海高考出分时间

**标准答案：** 6月25日; 6月23日

**来源文档：** rgb-zh-noise-Q044-P00, rgb-zh-noise-Q044-P01, rgb-zh-noise-Q044-P02, rgb-zh-noise-Q044-P03, rgb-zh-noise-Q044-P04, rgb-zh-noise-Q044-P05, rgb-zh-noise-Q044-P06, rgb-zh-noise-Q044-P07, rgb-zh-noise-Q044-P08, rgb-zh-noise-Q044-P09, rgb-zh-noise-Q044-P14, rgb-zh-noise-Q044-P16, rgb-zh-noise-Q044-P17, rgb-zh-noise-Q044-P18, rgb-zh-noise-Q044-P19, rgb-zh-noise-Q044-P20, rgb-zh-noise-Q044-P21, rgb-zh-noise-Q044-P22, rgb-zh-int-Q001-P18, rgb-zh-int-Q001-P19, rgb-zh-int-Q001-P20, rgb-zh-int-Q001-P21, rgb-zh-int-Q001-P22, rgb-zh-int-Q001-P23, rgb-zh-int-Q001-P24, rgb-zh-int-Q001-P25, rgb-zh-int-Q001-P26, rgb-zh-int-Q001-P27, rgb-zh-int-Q001-P28

### rgb-int-002

**问题：** 2022年澳网男单和女单冠军分别是谁？

**标准答案：** 纳达尔; 巴蒂

**来源文档：** rgb-zh-int-Q002-P00, rgb-zh-int-Q002-P01, rgb-zh-int-Q002-P02, rgb-zh-int-Q002-P03, rgb-zh-int-Q002-P04, rgb-zh-int-Q002-P05, rgb-zh-int-Q002-P06, rgb-zh-int-Q002-P07, rgb-zh-int-Q002-P08, rgb-zh-int-Q002-P09, rgb-zh-int-Q002-P10, rgb-zh-int-Q002-P11, rgb-zh-int-Q002-P12, rgb-zh-int-Q002-P13, rgb-zh-int-Q002-P14, rgb-zh-int-Q002-P15, rgb-zh-int-Q002-P16, rgb-zh-int-Q002-P17, rgb-zh-int-Q002-P18, rgb-zh-int-Q002-P19, rgb-zh-int-Q002-P20, rgb-zh-int-Q002-P21, rgb-zh-int-Q002-P22, rgb-zh-int-Q002-P23, rgb-zh-int-Q002-P24, rgb-zh-int-Q002-P25, rgb-zh-int-Q002-P26, rgb-zh-int-Q002-P27, rgb-zh-int-Q002-P28, rgb-zh-int-Q002-P29, rgb-zh-int-Q002-P30, rgb-zh-int-Q002-P31, rgb-zh-int-Q002-P32, rgb-zh-int-Q002-P33, rgb-zh-int-Q002-P34, rgb-zh-int-Q002-P35, rgb-zh-int-Q002-P36, rgb-zh-int-Q002-P37

### rgb-int-003

**问题：** 2022春运的开始和结束时间是什么时候？

**标准答案：** 1月17日; 2月25日

**来源文档：** rgb-zh-int-Q003-P00, rgb-zh-int-Q003-P01, rgb-zh-int-Q003-P02, rgb-zh-int-Q003-P03, rgb-zh-int-Q003-P04, rgb-zh-int-Q003-P05, rgb-zh-int-Q003-P06, rgb-zh-int-Q003-P07, rgb-zh-int-Q003-P08

### rgb-int-004

**问题：** 《流浪地球2》的主演

**标准答案：** 吴京; 刘德华; 李雪健

**来源文档：** rgb-zh-int-Q004-P00, rgb-zh-int-Q004-P01, rgb-zh-int-Q004-P02, rgb-zh-int-Q004-P03, rgb-zh-int-Q004-P05, rgb-zh-int-Q004-P07, rgb-zh-int-Q004-P08, rgb-zh-int-Q004-P09, rgb-zh-int-Q004-P10

### rgb-int-005

**问题：** 2022年和2023年超级碗冠军是谁

**标准答案：** 洛杉矶公羊队; 堪萨斯城酋长

**来源文档：** rgb-zh-int-Q005-P00, rgb-zh-int-Q005-P01, rgb-zh-int-Q005-P02, rgb-zh-int-Q005-P03, rgb-zh-int-Q005-P04, rgb-zh-int-Q005-P05, rgb-zh-int-Q005-P06, rgb-zh-int-Q005-P07, rgb-zh-int-Q005-P08, rgb-zh-int-Q005-P09

### rgb-int-006

**问题：** 2021-2022赛季欧冠和欧联杯冠军分别是谁？

**标准答案：** 皇家马德里; 法兰克福

**来源文档：** rgb-zh-noise-Q027-P00, rgb-zh-noise-Q027-P01, rgb-zh-noise-Q027-P02, rgb-zh-noise-Q027-P03, rgb-zh-noise-Q027-P04, rgb-zh-noise-Q027-P05, rgb-zh-noise-Q027-P06, rgb-zh-noise-Q027-P07, rgb-zh-noise-Q027-P08, rgb-zh-noise-Q027-P09, rgb-zh-noise-Q027-P10, rgb-zh-noise-Q027-P11, rgb-zh-noise-Q027-P12, rgb-zh-int-Q006-P13, rgb-zh-int-Q006-P14, rgb-zh-int-Q006-P15, rgb-zh-int-Q006-P16, rgb-zh-int-Q006-P17, rgb-zh-int-Q006-P18, rgb-zh-int-Q006-P19, rgb-zh-int-Q006-P20

### rgb-int-007

**问题：** 卡塔尔世界杯德国队和法国队在哪个组

**标准答案：** E组; D组

**来源文档：** rgb-zh-int-Q007-P00, rgb-zh-int-Q007-P01, rgb-zh-int-Q007-P02, rgb-zh-int-Q007-P03, rgb-zh-int-Q007-P04, rgb-zh-int-Q007-P05, rgb-zh-int-Q007-P06, rgb-zh-int-Q007-P07, rgb-zh-int-Q007-P08, rgb-zh-int-Q007-P09, rgb-zh-int-Q007-P10, rgb-zh-int-Q007-P11, rgb-zh-int-Q007-P12, rgb-zh-int-Q007-P13, rgb-zh-int-Q007-P14, rgb-zh-int-Q007-P15, rgb-zh-int-Q007-P16, rgb-zh-int-Q007-P17, rgb-zh-int-Q007-P18, rgb-zh-int-Q007-P19, rgb-zh-int-Q007-P20, rgb-zh-int-Q007-P21, rgb-zh-int-Q007-P22, rgb-zh-int-Q007-P23, rgb-zh-int-Q007-P24, rgb-zh-int-Q007-P25, rgb-zh-int-Q007-P26, rgb-zh-int-Q007-P27, rgb-zh-int-Q007-P28, rgb-zh-int-Q007-P29, rgb-zh-int-Q007-P30, rgb-zh-int-Q007-P31, rgb-zh-int-Q007-P32, rgb-zh-int-Q007-P33, rgb-zh-int-Q007-P34, rgb-zh-int-Q007-P35, rgb-zh-int-Q007-P36

### rgb-int-008

**问题：** 北京冬奥会的第一棒和最后一棒火炬手分别是谁？

**标准答案：** 罗致焕; 迪妮格尔·衣拉木江; 赵嘉文

**来源文档：** rgb-zh-noise-Q009-P00, rgb-zh-noise-Q009-P01, rgb-zh-noise-Q009-P02, rgb-zh-noise-Q009-P03, rgb-zh-noise-Q009-P04, rgb-zh-int-Q008-P05, rgb-zh-int-Q008-P07, rgb-zh-int-Q008-P08, rgb-zh-int-Q008-P09, rgb-zh-int-Q008-P10, rgb-zh-int-Q008-P11, rgb-zh-int-Q008-P12, rgb-zh-int-Q008-P13, rgb-zh-int-Q008-P14, rgb-zh-int-Q008-P15, rgb-zh-int-Q008-P16, rgb-zh-int-Q008-P17, rgb-zh-int-Q008-P18, rgb-zh-int-Q008-P19

### rgb-int-009

**问题：** 北京冬奥会美国和中国分别获得多少金牌？

**标准答案：** 8; 9

**来源文档：** rgb-zh-int-Q009-P00, rgb-zh-int-Q009-P01, rgb-zh-int-Q009-P02, rgb-zh-int-Q009-P03, rgb-zh-int-Q009-P04, rgb-zh-int-Q009-P05, rgb-zh-int-Q009-P06, rgb-zh-int-Q009-P07, rgb-zh-int-Q009-P08, rgb-zh-int-Q009-P09, rgb-zh-int-Q009-P10, rgb-zh-int-Q009-P11, rgb-zh-int-Q009-P12, rgb-zh-int-Q009-P13, rgb-zh-int-Q009-P14, rgb-zh-int-Q009-P15, rgb-zh-int-Q009-P16

### rgb-int-010

**问题：** 《好好说话》的主演有哪些？

**标准答案：** 陈晓; 王晓晨; 王耀庆; 曾黎

**来源文档：** rgb-zh-int-Q010-P00, rgb-zh-int-Q010-P01, rgb-zh-int-Q010-P02, rgb-zh-int-Q010-P03, rgb-zh-int-Q010-P04, rgb-zh-int-Q010-P05, rgb-zh-int-Q010-P06, rgb-zh-int-Q010-P07, rgb-zh-int-Q010-P08, rgb-zh-int-Q010-P09, rgb-zh-int-Q010-P10, rgb-zh-int-Q010-P11, rgb-zh-int-Q010-P12, rgb-zh-int-Q010-P13

### rgb-int-011

**问题：** 2023年全英羽毛球公开赛男单和女单冠军？

**标准答案：** 李诗沣; 安洗莹

**来源文档：** rgb-zh-int-Q011-P00, rgb-zh-int-Q011-P01, rgb-zh-int-Q011-P02, rgb-zh-int-Q011-P03, rgb-zh-int-Q011-P04, rgb-zh-int-Q011-P05, rgb-zh-int-Q011-P06, rgb-zh-int-Q011-P07, rgb-zh-int-Q011-P08, rgb-zh-int-Q011-P09, rgb-zh-int-Q011-P10

### rgb-int-012

**问题：** 2022年英特尔和英伟达全年营收

**标准答案：** 631亿美元; 269.74亿美元

**来源文档：** rgb-zh-int-Q012-P00, rgb-zh-int-Q012-P01, rgb-zh-int-Q012-P02, rgb-zh-int-Q012-P03, rgb-zh-int-Q012-P04, rgb-zh-int-Q012-P05, rgb-zh-int-Q012-P06, rgb-zh-int-Q012-P07

### rgb-int-013

**问题：** 速度与激情10内地和北美的上映时间

**标准答案：** 5月17日; 5月19日

**来源文档：** rgb-zh-int-Q013-P00, rgb-zh-int-Q013-P01, rgb-zh-int-Q013-P02, rgb-zh-int-Q013-P03, rgb-zh-int-Q013-P04, rgb-zh-int-Q013-P05, rgb-zh-int-Q013-P06, rgb-zh-int-Q013-P07

### rgb-int-014

**问题：** 2021年和2022年全国棉花产量

**标准答案：** 597.7万吨; ['573.09万吨', '573.1万吨']

**来源文档：** rgb-zh-int-Q014-P00, rgb-zh-int-Q014-P01, rgb-zh-int-Q014-P02, rgb-zh-int-Q014-P03, rgb-zh-int-Q014-P04, rgb-zh-int-Q014-P05, rgb-zh-int-Q014-P06, rgb-zh-int-Q014-P07, rgb-zh-int-Q014-P08, rgb-zh-int-Q014-P09, rgb-zh-int-Q014-P10, rgb-zh-int-Q014-P11, rgb-zh-int-Q014-P12, rgb-zh-int-Q014-P13, rgb-zh-int-Q014-P14

### rgb-int-015

**问题：** 2022年和2023年春运首日火车票分别的时间

**标准答案：** 1月3日; 12月24日

**来源文档：** rgb-zh-int-Q015-P00, rgb-zh-int-Q015-P01, rgb-zh-int-Q015-P02, rgb-zh-int-Q015-P03, rgb-zh-int-Q015-P04, rgb-zh-int-Q015-P05, rgb-zh-int-Q015-P06, rgb-zh-int-Q015-P07, rgb-zh-int-Q015-P08, rgb-zh-int-Q015-P09, rgb-zh-int-Q015-P10, rgb-zh-int-Q015-P11, rgb-zh-int-Q015-P12, rgb-zh-int-Q015-P13, rgb-zh-int-Q015-P14, rgb-zh-int-Q015-P15, rgb-zh-int-Q015-P16, rgb-zh-int-Q015-P17, rgb-zh-int-Q015-P18, rgb-zh-int-Q015-P19, rgb-zh-int-Q015-P20, rgb-zh-int-Q015-P21, rgb-zh-int-Q015-P22, rgb-zh-int-Q015-P23, rgb-zh-int-Q015-P24, rgb-zh-int-Q015-P25, rgb-zh-int-Q015-P26, rgb-zh-int-Q015-P27

### rgb-int-016

**问题：** 漫长的季节的主演

**标准答案：** 范伟; 秦昊; 陈明昊

**来源文档：** rgb-zh-int-Q016-P00, rgb-zh-int-Q016-P01, rgb-zh-int-Q016-P02, rgb-zh-int-Q016-P03, rgb-zh-int-Q016-P04

### rgb-int-017

**问题：** 谁是《天才基本法》主演？

**标准答案：** 雷佳音; 张子枫; 张新成

**来源文档：** rgb-zh-int-Q017-P00, rgb-zh-int-Q017-P01, rgb-zh-int-Q017-P02, rgb-zh-int-Q017-P03, rgb-zh-int-Q017-P04, rgb-zh-int-Q017-P05, rgb-zh-int-Q017-P06, rgb-zh-int-Q017-P07, rgb-zh-int-Q017-P08, rgb-zh-int-Q017-P09, rgb-zh-int-Q017-P10, rgb-zh-int-Q017-P11, rgb-zh-int-Q017-P12, rgb-zh-int-Q017-P13, rgb-zh-int-Q017-P14

### rgb-int-018

**问题：** 《心居》的主演有谁，导演是谁？

**标准答案：** 海清; 童瑶; 张颂文; 滕华涛

**来源文档：** rgb-zh-int-Q018-P00, rgb-zh-int-Q018-P01, rgb-zh-int-Q018-P02, rgb-zh-int-Q018-P03, rgb-zh-int-Q018-P04, rgb-zh-int-Q018-P05, rgb-zh-int-Q018-P06, rgb-zh-int-Q018-P07, rgb-zh-int-Q018-P09, rgb-zh-int-Q018-P10, rgb-zh-int-Q018-P11, rgb-zh-int-Q018-P12, rgb-zh-int-Q018-P13, rgb-zh-int-Q018-P14, rgb-zh-int-Q018-P15, rgb-zh-int-Q018-P16, rgb-zh-int-Q018-P17, rgb-zh-int-Q018-P19, rgb-zh-int-Q018-P20, rgb-zh-int-Q018-P21, rgb-zh-int-Q018-P22, rgb-zh-int-Q018-P23, rgb-zh-int-Q018-P24, rgb-zh-int-Q018-P25, rgb-zh-int-Q018-P26, rgb-zh-int-Q018-P28

### rgb-int-019

**问题：** 上海和北京2021年的GDP分别是多少？

**标准答案：** 43214.85亿元; 40269.6亿元

**来源文档：** rgb-zh-int-Q019-P00, rgb-zh-int-Q019-P01, rgb-zh-int-Q019-P02, rgb-zh-int-Q019-P03, rgb-zh-int-Q019-P04, rgb-zh-int-Q019-P05, rgb-zh-int-Q019-P06

### rgb-int-020

**问题：** 谷歌和百度推出的类ChatGPT是什么？

**标准答案：** 文心一言; Bard

**来源文档：** rgb-zh-int-Q020-P00, rgb-zh-int-Q020-P01, rgb-zh-int-Q020-P02, rgb-zh-int-Q020-P03, rgb-zh-int-Q020-P04, rgb-zh-int-Q020-P05, rgb-zh-int-Q020-P06, rgb-zh-int-Q020-P07, rgb-zh-int-Q020-P08, rgb-zh-int-Q020-P09, rgb-zh-int-Q020-P10, rgb-zh-int-Q020-P11, rgb-zh-int-Q020-P12, rgb-zh-int-Q020-P13, rgb-zh-int-Q020-P14, rgb-zh-int-Q020-P15

### rgb-int-021

**问题：** C919商业首飞路线和航班号

**标准答案：** 上海; 北京; MU9191

**来源文档：** rgb-zh-noise-Q018-P00, rgb-zh-noise-Q018-P01, rgb-zh-noise-Q018-P02, rgb-zh-noise-Q018-P04, rgb-zh-int-Q021-P04, rgb-zh-int-Q021-P05, rgb-zh-int-Q021-P06, rgb-zh-int-Q021-P07

### rgb-int-022

**问题：** 谁是北京冬残奥会中国体育代表团旗手

**标准答案：** 郭雨洁; 汪之栋

**来源文档：** rgb-zh-int-Q022-P00, rgb-zh-int-Q022-P01, rgb-zh-int-Q022-P02, rgb-zh-int-Q022-P03, rgb-zh-int-Q022-P04, rgb-zh-int-Q022-P05, rgb-zh-int-Q022-P06, rgb-zh-int-Q022-P07

### rgb-int-023

**问题：** 2023前两季度中国GDP增长率

**标准答案：** 4.5%; 6.3%

**来源文档：** rgb-zh-int-Q023-P00, rgb-zh-int-Q023-P01, rgb-zh-int-Q023-P02, rgb-zh-int-Q023-P03, rgb-zh-int-Q023-P04, rgb-zh-int-Q023-P05, rgb-zh-int-Q023-P06, rgb-zh-int-Q023-P07, rgb-zh-int-Q023-P08

### rgb-int-024

**问题：** MU5735航班坠毁的时间和地点

**标准答案：** 梧州市藤县; 2022年3月21日

**来源文档：** rgb-zh-int-Q024-P00, rgb-zh-int-Q024-P01, rgb-zh-int-Q024-P02, rgb-zh-int-Q024-P03

### rgb-int-025

**问题：** 《炽道》的主演

**标准答案：** 金晨; 王安宇

**来源文档：** rgb-zh-int-Q025-P00, rgb-zh-int-Q025-P01, rgb-zh-int-Q025-P02, rgb-zh-int-Q025-P03, rgb-zh-int-Q025-P04, rgb-zh-int-Q025-P05

### rgb-int-026

**问题：** 《阿凡达：水之道》大陆和香港上映日期

**标准答案：** 12月16日; 12月14日

**来源文档：** rgb-zh-noise-Q030-P00, rgb-zh-noise-Q030-P01, rgb-zh-noise-Q030-P02, rgb-zh-noise-Q030-P03, rgb-zh-noise-Q030-P04, rgb-zh-noise-Q030-P05, rgb-zh-noise-Q030-P06, rgb-zh-noise-Q030-P07, rgb-zh-noise-Q030-P08, rgb-zh-noise-Q030-P09, rgb-zh-int-Q026-P10, rgb-zh-int-Q026-P11, rgb-zh-int-Q026-P12, rgb-zh-int-Q026-P13

### rgb-int-027

**问题：** 《护卫者》的主演是谁？

**标准答案：** 张丰毅; 王媛可; 王栎鑫

**来源文档：** rgb-zh-int-Q027-P00, rgb-zh-int-Q027-P01, rgb-zh-int-Q027-P02, rgb-zh-int-Q027-P03, rgb-zh-int-Q027-P04, rgb-zh-int-Q027-P05, rgb-zh-int-Q027-P06

### rgb-int-028

**问题：** 2023年马来西亚公开赛男女单打冠军

**标准答案：** 山口茜; 安赛龙

**来源文档：** rgb-zh-int-Q028-P00, rgb-zh-int-Q028-P01, rgb-zh-int-Q011-P04, rgb-zh-int-Q028-P03, rgb-zh-int-Q028-P04, rgb-zh-int-Q028-P05, rgb-zh-int-Q028-P06

### rgb-int-029

**问题：** 《瞬息全宇宙》获得了哪些奥斯卡奖项

**标准答案：** 最佳影片; 最佳导演; 最佳原创剧本; 最佳剪辑; ['最佳女主角', '最佳女演员']; 最佳男配角; 最佳女配角

**来源文档：** rgb-zh-int-Q029-P00, rgb-zh-int-Q029-P01, rgb-zh-int-Q029-P02, rgb-zh-int-Q029-P03, rgb-zh-int-Q029-P04, rgb-zh-int-Q029-P05, rgb-zh-int-Q029-P06, rgb-zh-int-Q029-P07, rgb-zh-int-Q029-P08, rgb-zh-int-Q029-P09, rgb-zh-int-Q029-P10, rgb-zh-int-Q029-P11, rgb-zh-int-Q029-P12, rgb-zh-int-Q029-P13, rgb-zh-int-Q029-P14, rgb-zh-int-Q029-P15, rgb-zh-int-Q029-P16, rgb-zh-int-Q029-P17, rgb-zh-int-Q029-P18, rgb-zh-int-Q029-P19, rgb-zh-int-Q029-P20, rgb-zh-int-Q029-P21, rgb-zh-int-Q029-P22, rgb-zh-int-Q029-P23

### rgb-int-030

**问题：** 第七届香港立法会议员宣誓仪式及首次会议的时间

**标准答案：** 1月3日; 1月12日

**来源文档：** rgb-zh-int-Q030-P00, rgb-zh-int-Q030-P01, rgb-zh-int-Q030-P02, rgb-zh-int-Q030-P03, rgb-zh-int-Q030-P04, rgb-zh-int-Q030-P05, rgb-zh-int-Q030-P06, rgb-zh-int-Q030-P07, rgb-zh-int-Q030-P08, rgb-zh-int-Q030-P09, rgb-zh-int-Q030-P10, rgb-zh-int-Q030-P11, rgb-zh-int-Q030-P12, rgb-zh-int-Q030-P13, rgb-zh-int-Q030-P14, rgb-zh-int-Q030-P15, rgb-zh-int-Q030-P16, rgb-zh-int-Q030-P17, rgb-zh-int-Q030-P18

### rgb-int-031

**问题：** 北京冬奥会女子和男子500米速度滑冰金牌分别是谁

**标准答案：** 高亭宇; 埃琳·杰克逊

**来源文档：** rgb-zh-noise-Q007-P23, rgb-zh-noise-Q007-P24, rgb-zh-noise-Q007-P25, rgb-zh-noise-Q007-P26, rgb-zh-noise-Q007-P27, rgb-zh-noise-Q007-P28, rgb-zh-noise-Q007-P29, rgb-zh-noise-Q007-P30, rgb-zh-int-Q031-P08

### rgb-int-032

**问题：** 《摇滚狂花》的主演有哪些？

**标准答案：** 姚晨; 常远; 庄达菲

**来源文档：** rgb-zh-int-Q032-P00, rgb-zh-int-Q032-P01, rgb-zh-int-Q032-P02, rgb-zh-int-Q032-P03, rgb-zh-int-Q032-P04, rgb-zh-int-Q032-P05, rgb-zh-int-Q032-P06, rgb-zh-int-Q032-P07, rgb-zh-int-Q032-P08, rgb-zh-int-Q032-P09, rgb-zh-int-Q032-P10, rgb-zh-int-Q032-P11, rgb-zh-int-Q032-P12, rgb-zh-int-Q032-P13, rgb-zh-int-Q032-P14

### rgb-int-033

**问题：** 深圳大学2022年和2023年分别录取了多少名本科生？

**标准答案：** 7436; 7286

**来源文档：** rgb-zh-int-Q033-P00, rgb-zh-int-Q033-P01, rgb-zh-int-Q033-P02, rgb-zh-int-Q033-P03

### rgb-int-034

**问题：** 陈凯歌少年时代上映时间及主演

**标准答案：** 刘昊然; 陈飞宇; 张雪迎; 文淇; 8月17日

**来源文档：** rgb-zh-int-Q034-P00, rgb-zh-int-Q034-P01, rgb-zh-int-Q034-P02, rgb-zh-int-Q034-P03, rgb-zh-int-Q034-P04, rgb-zh-int-Q034-P05, rgb-zh-int-Q034-P06, rgb-zh-int-Q034-P07, rgb-zh-int-Q034-P08

### rgb-int-035

**问题：** 北京冬奥会男子1500米速度滑冰和短道速滑中谁获得了金牌？

**标准答案：** 凯尔·内斯; 黄大宪

**来源文档：** rgb-zh-int-Q035-P00, rgb-zh-int-Q035-P01, rgb-zh-int-Q035-P02, rgb-zh-int-Q035-P03

### rgb-int-036

**问题：** 布林肯和耶伦访华时间

**标准答案：** 7月6日; 9日; 6月18日; 19日

**来源文档：** rgb-zh-int-Q036-P00, rgb-zh-int-Q036-P01, rgb-zh-int-Q036-P02, rgb-zh-int-Q036-P03, rgb-zh-int-Q036-P04, rgb-zh-int-Q036-P05, rgb-zh-int-Q036-P06

### rgb-int-037

**问题：** 2023年奥斯卡最佳女主角和最佳男主角分别是谁？

**标准答案：** 杨紫琼; ['布兰登·费舍', '布兰登·弗雷泽']

**来源文档：** rgb-zh-int-Q037-P00, rgb-zh-int-Q037-P01, rgb-zh-int-Q037-P02, rgb-zh-int-Q037-P03, rgb-zh-int-Q037-P04, rgb-zh-int-Q037-P05, rgb-zh-int-Q037-P06, rgb-zh-int-Q037-P07, rgb-zh-int-Q037-P08, rgb-zh-int-Q037-P09, rgb-zh-int-Q037-P10, rgb-zh-int-Q037-P11, rgb-zh-int-Q037-P12

### rgb-int-038

**问题：** 《李茂扮太子》是什么类型的电影？它的导演是谁？

**标准答案：** 喜剧; 高可; 杨晓明

**来源文档：** rgb-zh-int-Q038-P00, rgb-zh-int-Q038-P01, rgb-zh-int-Q038-P02, rgb-zh-int-Q038-P03, rgb-zh-int-Q038-P04, rgb-zh-int-Q038-P05, rgb-zh-int-Q038-P06, rgb-zh-int-Q038-P07, rgb-zh-int-Q038-P08, rgb-zh-int-Q038-P09, rgb-zh-int-Q038-P10, rgb-zh-int-Q038-P11, rgb-zh-int-Q038-P12, rgb-zh-int-Q038-P13, rgb-zh-int-Q038-P14, rgb-zh-int-Q038-P15, rgb-zh-int-Q038-P16, rgb-zh-int-Q038-P17, rgb-zh-int-Q038-P18, rgb-zh-int-Q038-P19, rgb-zh-int-Q038-P20

### rgb-int-039

**问题：** 2022年特斯拉和比亚迪交付量

**标准答案：** ['1313851', '131万']; ['187万', '186.35万']

**来源文档：** rgb-zh-int-Q039-P00, rgb-zh-int-Q039-P01, rgb-zh-int-Q039-P02, rgb-zh-int-Q039-P03, rgb-zh-int-Q039-P04, rgb-zh-int-Q039-P05, rgb-zh-int-Q039-P06, rgb-zh-int-Q039-P07, rgb-zh-int-Q039-P08, rgb-zh-int-Q039-P09, rgb-zh-int-Q039-P10, rgb-zh-int-Q039-P11, rgb-zh-int-Q039-P12, rgb-zh-int-Q039-P13

### rgb-int-040

**问题：** 邓伦逃税多少钱，被罚了多少钱

**标准答案：** 4765.82万; 1.06亿

**来源文档：** rgb-zh-int-Q040-P00, rgb-zh-int-Q040-P01, rgb-zh-int-Q040-P02, rgb-zh-int-Q040-P03, rgb-zh-int-Q040-P04, rgb-zh-int-Q040-P07, rgb-zh-int-Q040-P08, rgb-zh-int-Q040-P09, rgb-zh-int-Q040-P10

### rgb-int-041

**问题：** 2023年澳网男单和温单男单冠军是谁？

**标准答案：** 德约科维奇; 阿尔卡拉斯

**来源文档：** rgb-zh-int-Q041-P00, rgb-zh-int-Q041-P01, rgb-zh-int-Q041-P02, rgb-zh-int-Q041-P03, rgb-zh-int-Q041-P04, rgb-zh-int-Q041-P05, rgb-zh-int-Q041-P06, rgb-zh-int-Q041-P07, rgb-zh-int-Q041-P08, rgb-zh-int-Q041-P09, rgb-zh-int-Q041-P10, rgb-zh-int-Q041-P11, rgb-zh-int-Q041-P12, rgb-zh-int-Q041-P13, rgb-zh-int-Q041-P14, rgb-zh-int-Q041-P15, rgb-zh-int-Q041-P16, rgb-zh-int-Q041-P17, rgb-zh-int-Q041-P18, rgb-zh-int-Q041-P19, rgb-zh-int-Q041-P20, rgb-zh-int-Q041-P21

### rgb-int-042

**问题：** 花样滑冰女子和男子单人滑比赛金牌得主分别是谁？

**标准答案：** 谢尔巴科娃; 陈巍

**来源文档：** rgb-zh-int-Q042-P00, rgb-zh-int-Q042-P01, rgb-zh-int-Q042-P02, rgb-zh-int-Q042-P03, rgb-zh-int-Q042-P04, rgb-zh-int-Q042-P05, rgb-zh-int-Q042-P06, rgb-zh-int-Q042-P07, rgb-zh-int-Q042-P08, rgb-zh-int-Q042-P09, rgb-zh-int-Q042-P10, rgb-zh-int-Q042-P11, rgb-zh-int-Q042-P12, rgb-zh-int-Q042-P13, rgb-zh-int-Q042-P14, rgb-zh-int-Q042-P15, rgb-zh-int-Q042-P16, rgb-zh-int-Q042-P17, rgb-zh-int-Q042-P18, rgb-zh-int-Q042-P19, rgb-zh-int-Q042-P20, rgb-zh-int-Q042-P21, rgb-zh-int-Q042-P22

### rgb-int-043

**问题：** 2023年全国跳水冠军赛女子双人10米跳台和男子双人10米跳台冠军分别是谁？

**标准答案：** 全红婵; 陈芋汐; 练俊杰; 杨昊

**来源文档：** rgb-zh-int-Q043-P00, rgb-zh-int-Q043-P01, rgb-zh-int-Q043-P02, rgb-zh-int-Q043-P03, rgb-zh-int-Q043-P04, rgb-zh-int-Q043-P05, rgb-zh-int-Q043-P06, rgb-zh-int-Q043-P07, rgb-zh-int-Q043-P08, rgb-zh-int-Q043-P09, rgb-zh-int-Q043-P10, rgb-zh-int-Q043-P11, rgb-zh-int-Q043-P13, rgb-zh-int-Q043-P14, rgb-zh-int-Q043-P15, rgb-zh-int-Q043-P16, rgb-zh-int-Q043-P17, rgb-zh-int-Q043-P18, rgb-zh-int-Q043-P19, rgb-zh-int-Q043-P20, rgb-zh-int-Q043-P21, rgb-zh-int-Q043-P22, rgb-zh-int-Q043-P23, rgb-zh-int-Q043-P25, rgb-zh-int-Q043-P26

### rgb-int-044

**问题：** 上海和北京2023年新任市长是谁？

**标准答案：** 龚正; 殷勇

**来源文档：** rgb-zh-int-Q044-P00, rgb-zh-int-Q044-P01, rgb-zh-int-Q044-P02, rgb-zh-int-Q044-P03, rgb-zh-int-Q044-P04, rgb-zh-int-Q044-P05, rgb-zh-int-Q044-P06, rgb-zh-int-Q044-P07, rgb-zh-int-Q044-P08, rgb-zh-int-Q044-P09, rgb-zh-int-Q044-P11, rgb-zh-int-Q044-P12, rgb-zh-int-Q044-P13, rgb-zh-int-Q044-P15, rgb-zh-int-Q044-P16, rgb-zh-int-Q044-P17

### rgb-int-045

**问题：** 安倍晋三的国葬时间和地点？

**标准答案：** 9月27日; 日本武道馆

**来源文档：** rgb-zh-int-Q045-P00, rgb-zh-int-Q045-P01, rgb-zh-int-Q045-P02, rgb-zh-int-Q045-P03, rgb-zh-int-Q045-P04, rgb-zh-int-Q045-P05, rgb-zh-int-Q045-P06, rgb-zh-int-Q045-P07, rgb-zh-int-Q045-P08, rgb-zh-int-Q045-P09

### rgb-int-046

**问题：** 北京冬奥会和冬残奥会的开幕日期分别是什么时候?

**标准答案：** 2022年2月4日; 2022年3月4日

**来源文档：** rgb-zh-int-Q046-P00, rgb-zh-int-Q046-P01, rgb-zh-int-Q046-P02, rgb-zh-int-Q046-P03

### rgb-int-047

**问题：** 2022年谁当选台北市市长和高雄市市长？

**标准答案：** 蒋万安; 陈其迈

**来源文档：** rgb-zh-int-Q047-P00, rgb-zh-int-Q047-P01, rgb-zh-int-Q047-P02, rgb-zh-int-Q047-P03, rgb-zh-int-Q047-P04, rgb-zh-int-Q047-P05, rgb-zh-int-Q047-P07, rgb-zh-int-Q047-P08, rgb-zh-int-Q047-P09, rgb-zh-int-Q047-P10, rgb-zh-int-Q047-P11, rgb-zh-int-Q047-P12, rgb-zh-int-Q047-P13, rgb-zh-int-Q047-P14, rgb-zh-int-Q047-P15, rgb-zh-int-Q047-P16, rgb-zh-int-Q047-P17, rgb-zh-int-Q047-P18, rgb-zh-int-Q047-P19, rgb-zh-int-Q047-P20, rgb-zh-int-Q047-P21, rgb-zh-int-Q047-P22, rgb-zh-int-Q047-P23, rgb-zh-int-Q047-P24, rgb-zh-int-Q047-P25, rgb-zh-int-Q047-P26, rgb-zh-int-Q047-P27, rgb-zh-int-Q047-P28, rgb-zh-int-Q047-P29, rgb-zh-int-Q047-P30, rgb-zh-int-Q047-P31, rgb-zh-int-Q047-P32, rgb-zh-int-Q047-P33, rgb-zh-int-Q047-P34, rgb-zh-int-Q047-P35, rgb-zh-int-Q047-P36, rgb-zh-int-Q047-P37, rgb-zh-int-Q047-P38, rgb-zh-int-Q047-P39

### rgb-int-048

**问题：** 2022年和2023年春节档首日票房冠军

**标准答案：** 长津湖之水门桥; 流浪地球2

**来源文档：** rgb-zh-int-Q048-P00, rgb-zh-int-Q048-P01, rgb-zh-int-Q048-P02, rgb-zh-int-Q048-P03, rgb-zh-int-Q048-P04, rgb-zh-int-Q048-P05, rgb-zh-int-Q048-P06, rgb-zh-int-Q048-P07, rgb-zh-int-Q048-P08, rgb-zh-int-Q048-P09, rgb-zh-int-Q048-P10, rgb-zh-int-Q048-P11, rgb-zh-int-Q048-P12, rgb-zh-int-Q048-P13, rgb-zh-noise-Q036-P02, rgb-zh-int-Q048-P15, rgb-zh-int-Q048-P16, rgb-zh-int-Q048-P17, rgb-zh-int-Q048-P18, rgb-zh-int-Q048-P19, rgb-zh-int-Q048-P20, rgb-zh-int-Q048-P21, rgb-zh-int-Q048-P22, rgb-zh-int-Q048-P23, rgb-zh-int-Q048-P24, rgb-zh-int-Q048-P25

### rgb-int-049

**问题：** 电影《搜救》的导演和主演是谁

**标准答案：** 甄子丹; 罗志良

**来源文档：** rgb-zh-int-Q049-P00, rgb-zh-int-Q049-P01, rgb-zh-int-Q049-P02, rgb-zh-int-Q049-P03, rgb-zh-int-Q049-P04, rgb-zh-int-Q049-P05, rgb-zh-int-Q049-P06, rgb-zh-int-Q049-P07, rgb-zh-int-Q049-P08, rgb-zh-int-Q049-P09, rgb-zh-int-Q049-P10, rgb-zh-int-Q049-P11, rgb-zh-int-Q049-P12, rgb-zh-int-Q049-P13, rgb-zh-int-Q049-P14, rgb-zh-int-Q049-P15, rgb-zh-int-Q049-P16

### rgb-int-050

**问题：** 哪些中国斯诺克选手被终身禁赛

**标准答案：** 梁文博; 李行

**来源文档：** rgb-zh-int-Q050-P00, rgb-zh-int-Q050-P01, rgb-zh-int-Q050-P02, rgb-zh-int-Q050-P03, rgb-zh-int-Q050-P04, rgb-zh-int-Q050-P05, rgb-zh-int-Q050-P06, rgb-zh-int-Q050-P07

### rgb-neg-001

**问题：** 海底捞的新任首席执行官是谁？

**标准答案：** 杨利娟

**来源文档：** rgb-zh-noise-Q001-P01, rgb-zh-noise-Q001-P02, rgb-zh-noise-Q001-P03, rgb-zh-noise-Q001-P06, rgb-zh-noise-Q001-P07, rgb-zh-noise-Q001-P08, rgb-zh-noise-Q001-P11, rgb-zh-noise-Q001-P14, rgb-zh-noise-Q001-P15, rgb-zh-noise-Q001-P16, rgb-zh-noise-Q001-P18, rgb-zh-noise-Q001-P19

### rgb-neg-002

**问题：** 印度第三艘“歼敌者”级核潜艇下水的时间

**标准答案：** 2021年11月23日

**来源文档：** rgb-zh-noise-Q002-P00, rgb-zh-noise-Q002-P02, rgb-zh-noise-Q002-P04, rgb-zh-noise-Q002-P01

### rgb-neg-003

**问题：** 2022广州网球巡回赛U14组男单冠军是谁

**标准答案：** 王发

**来源文档：** rgb-zh-noise-Q003-P00, rgb-zh-noise-Q003-P03, rgb-zh-noise-Q003-P04, rgb-zh-noise-Q003-P05, rgb-zh-noise-Q003-P10, rgb-zh-noise-Q003-P13, rgb-zh-noise-Q003-P14, rgb-zh-noise-Q003-P18, rgb-zh-noise-Q003-P19, rgb-zh-noise-Q003-P20, rgb-zh-noise-Q003-P22, rgb-zh-noise-Q003-P23, rgb-zh-noise-Q003-P24

### rgb-neg-004

**问题：** 美国最高法院推翻了哪个堕胎判例

**标准答案：** 罗诉韦德案

**来源文档：** rgb-zh-noise-Q004-P00, rgb-zh-noise-Q004-P02, rgb-zh-noise-Q004-P03, rgb-zh-noise-Q004-P04, rgb-zh-noise-Q004-P06, rgb-zh-noise-Q004-P07, rgb-zh-noise-Q004-P10, rgb-zh-noise-Q004-P11, rgb-zh-noise-Q004-P13, rgb-zh-noise-Q004-P14, rgb-zh-noise-Q004-P15, rgb-zh-noise-Q004-P16

### rgb-neg-005

**问题：** 《七人乐队》的导演是谁？

**标准答案：** 洪金宝; 许鞍华; 谭家明; 袁和平; 杜琪峰; 林岭东; 徐克

**来源文档：** rgb-zh-noise-Q005-P01, rgb-zh-noise-Q005-P03, rgb-zh-noise-Q005-P00, rgb-zh-neg-Q005-P03, rgb-zh-neg-Q005-P04

### rgb-neg-006

**问题：** 神舟十三号飞船的成员有哪些

**标准答案：** 翟志刚; 王亚平; 叶光富

**来源文档：** rgb-zh-noise-Q006-P00, rgb-zh-noise-Q006-P01, rgb-zh-noise-Q006-P02, rgb-zh-noise-Q006-P03, rgb-zh-noise-Q006-P04, rgb-zh-noise-Q006-P05, rgb-zh-noise-Q006-P06, rgb-zh-noise-Q006-P07, rgb-zh-noise-Q006-P08

### rgb-neg-007

**问题：** 北京冬奥会男子500米速度滑冰金牌

**标准答案：** 高亭宇

**来源文档：** rgb-zh-noise-Q007-P01, rgb-zh-noise-Q007-P02, rgb-zh-noise-Q007-P03, rgb-zh-noise-Q007-P05, rgb-zh-noise-Q007-P06, rgb-zh-noise-Q007-P07, rgb-zh-noise-Q007-P08, rgb-zh-noise-Q007-P09, rgb-zh-noise-Q007-P10, rgb-zh-noise-Q007-P11, rgb-zh-noise-Q007-P13, rgb-zh-noise-Q007-P15, rgb-zh-noise-Q007-P16, rgb-zh-noise-Q007-P17, rgb-zh-noise-Q007-P18, rgb-zh-noise-Q007-P20, rgb-zh-noise-Q007-P22, rgb-zh-noise-Q007-P23, rgb-zh-noise-Q007-P24, rgb-zh-noise-Q007-P25, rgb-zh-noise-Q007-P27, rgb-zh-noise-Q007-P28, rgb-zh-noise-Q007-P29

### rgb-neg-008

**问题：** 《漫长的季节》的类型是什么？

**标准答案：** 悬疑

**来源文档：** rgb-zh-noise-Q008-P00, rgb-zh-noise-Q008-P01, rgb-zh-noise-Q008-P03, rgb-zh-noise-Q008-P04, rgb-zh-noise-Q008-P05, rgb-zh-noise-Q008-P07, rgb-zh-noise-Q008-P08, rgb-zh-noise-Q008-P09, rgb-zh-noise-Q008-P11, rgb-zh-noise-Q008-P13, rgb-zh-noise-Q008-P15, rgb-zh-noise-Q008-P16

### rgb-neg-009

**问题：** 谁是北京冬奥会第一棒火炬手

**标准答案：** 罗致焕

**来源文档：** rgb-zh-noise-Q009-P00, rgb-zh-noise-Q009-P01, rgb-zh-noise-Q009-P02, rgb-zh-noise-Q009-P03, rgb-zh-noise-Q009-P04

### rgb-neg-010

**问题：** 2023年国考实际参考人数

**标准答案：** 152.5万

**来源文档：** rgb-zh-noise-Q010-P00, rgb-zh-noise-Q010-P02, rgb-zh-noise-Q010-P04, rgb-zh-noise-Q010-P05, rgb-zh-noise-Q010-P06, rgb-zh-noise-Q010-P07, rgb-zh-noise-Q010-P08

### rgb-neg-011

**问题：** 2021年中国电影市场总票房是多少？

**标准答案：** 472.58亿元

**来源文档：** rgb-zh-noise-Q011-P01, rgb-zh-noise-Q011-P02, rgb-zh-noise-Q011-P03, rgb-zh-noise-Q011-P00, rgb-zh-neg-Q011-P04

### rgb-neg-012

**问题：** 黑石集团预测2022年美联储将加息几次

**标准答案：** ['4次', '四次']

**来源文档：** rgb-zh-noise-Q012-P00, rgb-zh-noise-Q012-P02, rgb-zh-noise-Q012-P03, rgb-zh-noise-Q012-P04, rgb-zh-noise-Q012-P05, rgb-zh-noise-Q012-P06, rgb-zh-noise-Q012-P07

### rgb-neg-013

**问题：** 2022春节档票房冠军是哪部电影

**标准答案：** 长津湖之水门桥

**来源文档：** rgb-zh-noise-Q013-P00, rgb-zh-noise-Q013-P02, rgb-zh-noise-Q013-P04, rgb-zh-noise-Q013-P03, rgb-zh-neg-Q013-P04

### rgb-neg-014

**问题：** 2022年上半年，西藏经济增长了多少？

**标准答案：** 4.8%

**来源文档：** rgb-zh-noise-Q014-P00, rgb-zh-neg-Q014-P01, rgb-zh-neg-Q014-P02, rgb-zh-neg-Q014-P03, rgb-zh-neg-Q014-P04

### rgb-neg-015

**问题：** 零壹空间是谁创立的？

**标准答案：** 舒畅

**来源文档：** rgb-zh-noise-Q015-P00, rgb-zh-noise-Q015-P01, rgb-zh-noise-Q015-P03, rgb-zh-noise-Q015-P04, rgb-zh-noise-Q015-P07, rgb-zh-noise-Q015-P08, rgb-zh-noise-Q015-P09, rgb-zh-noise-Q015-P10, rgb-zh-noise-Q015-P11, rgb-zh-noise-Q015-P12

### rgb-neg-016

**问题：** 众议院TikTok听证会的时间

**标准答案：** 3月23日

**来源文档：** rgb-zh-noise-Q016-P02, rgb-zh-noise-Q016-P03, rgb-zh-noise-Q016-P00, rgb-zh-noise-Q016-P01, rgb-zh-noise-Q016-P04, rgb-zh-noise-Q016-P05, rgb-zh-noise-Q016-P07

### rgb-neg-017

**问题：** 美国2021年GDP增长多少

**标准答案：** 5.7%

**来源文档：** rgb-zh-noise-Q017-P00, rgb-zh-noise-Q017-P02, rgb-zh-noise-Q017-P03, rgb-zh-noise-Q017-P04, rgb-zh-noise-Q017-P05

### rgb-neg-018

**问题：** C919商业首飞路线

**标准答案：** 上海; 北京

**来源文档：** rgb-zh-noise-Q018-P02, rgb-zh-noise-Q018-P04, rgb-zh-noise-Q018-P00, rgb-zh-noise-Q018-P03, rgb-zh-neg-Q018-P04

### rgb-neg-019

**问题：** 2023年1月3日恒指收盘点数

**标准答案：** 20145.29

**来源文档：** rgb-zh-noise-Q019-P00, rgb-zh-neg-Q019-P02, rgb-zh-neg-Q019-P03, rgb-zh-neg-Q019-P04

### rgb-neg-020

**问题：** 2023春运首日旅客发送量

**标准答案：** ['3473.6万人次', '3474万人次']

**来源文档：** rgb-zh-noise-Q020-P01, rgb-zh-noise-Q020-P00, rgb-zh-noise-Q020-P02, rgb-zh-noise-Q020-P03

### rgb-neg-021

**问题：** 2022年乒乓球团体世锦赛会在哪举行

**标准答案：** 成都

**来源文档：** rgb-zh-noise-Q021-P00, rgb-zh-noise-Q021-P01, rgb-zh-noise-Q021-P04, rgb-zh-noise-Q021-P03, rgb-zh-noise-Q021-P05

### rgb-neg-022

**问题：** 果果合唱团是谁创办的？

**标准答案：** 刘超

**来源文档：** rgb-zh-noise-Q022-P00, rgb-zh-noise-Q022-P01, rgb-zh-noise-Q022-P02, rgb-zh-noise-Q022-P03, rgb-zh-noise-Q022-P04, rgb-zh-noise-Q022-P05, rgb-zh-noise-Q022-P06, rgb-zh-noise-Q022-P10, rgb-zh-noise-Q022-P11, rgb-zh-noise-Q022-P13, rgb-zh-noise-Q022-P17, rgb-zh-noise-Q022-P18, rgb-zh-noise-Q022-P19

### rgb-neg-023

**问题：** 泸定地震造成多少人遇难？

**标准答案：** 93人

**来源文档：** rgb-zh-noise-Q023-P00, rgb-zh-noise-Q023-P01, rgb-zh-noise-Q023-P02, rgb-zh-noise-Q023-P03, rgb-zh-neg-Q023-P04

### rgb-neg-024

**问题：** 首趟RCEP班列的起点？

**标准答案：** 南宁

**来源文档：** rgb-zh-noise-Q024-P00, rgb-zh-noise-Q024-P01, rgb-zh-noise-Q024-P04, rgb-zh-neg-Q024-P03, rgb-zh-neg-Q024-P04

### rgb-neg-025

**问题：** 香港第六任行政长官选举结果？

**标准答案：** 李家超

**来源文档：** rgb-zh-noise-Q025-P00, rgb-zh-noise-Q025-P02, rgb-zh-noise-Q025-P03, rgb-zh-noise-Q025-P06, rgb-zh-noise-Q025-P07, rgb-zh-noise-Q025-P08, rgb-zh-noise-Q025-P12, rgb-zh-noise-Q025-P13, rgb-zh-noise-Q025-P16, rgb-zh-noise-Q025-P18, rgb-zh-noise-Q025-P21, rgb-zh-noise-Q025-P23

### rgb-neg-026

**问题：** 2022年G20峰会的时间？

**标准答案：** 11月15日; 16日

**来源文档：** rgb-zh-noise-Q026-P00, rgb-zh-noise-Q026-P01, rgb-zh-noise-Q026-P02, rgb-zh-noise-Q026-P03, rgb-zh-noise-Q026-P04, rgb-zh-noise-Q026-P05

### rgb-neg-027

**问题：** 2021-2022赛季欧冠冠军

**标准答案：** 皇家马德里

**来源文档：** rgb-zh-noise-Q027-P07, rgb-zh-noise-Q027-P08, rgb-zh-noise-Q027-P09, rgb-zh-noise-Q027-P11, rgb-zh-noise-Q027-P12

### rgb-neg-028

**问题：** 2022年百花奖最佳影片奖

**标准答案：** 长津湖

**来源文档：** rgb-zh-noise-Q028-P00, rgb-zh-noise-Q028-P02, rgb-zh-noise-Q028-P04, rgb-zh-noise-Q028-P08, rgb-zh-noise-Q028-P11, rgb-zh-noise-Q028-P12, rgb-zh-noise-Q028-P13, rgb-zh-noise-Q028-P14

### rgb-neg-029

**问题：** 2022年世界互联网大会在哪里举办？

**标准答案：** 乌镇

**来源文档：** rgb-zh-noise-Q029-P09, rgb-zh-noise-Q029-P10, rgb-zh-noise-Q029-P11, rgb-zh-noise-Q029-P13, rgb-zh-noise-Q029-P14, rgb-zh-noise-Q029-P16, rgb-zh-noise-Q029-P17, rgb-zh-noise-Q029-P18, rgb-zh-noise-Q029-P22, rgb-zh-noise-Q029-P24, rgb-zh-noise-Q029-P25

### rgb-neg-030

**问题：** 《阿凡达：水之道》国内上映日期

**标准答案：** 12月16日

**来源文档：** rgb-zh-noise-Q030-P00, rgb-zh-noise-Q030-P03, rgb-zh-noise-Q030-P04, rgb-zh-noise-Q030-P07, rgb-zh-noise-Q030-P08, rgb-zh-noise-Q030-P09

### rgb-neg-031

**问题：** 北京冬奥会吉祥物叫什么

**标准答案：** 冰墩墩

**来源文档：** rgb-zh-noise-Q031-P00, rgb-zh-noise-Q031-P01, rgb-zh-noise-Q031-P02, rgb-zh-noise-Q031-P03, rgb-zh-noise-Q031-P04, rgb-zh-noise-Q031-P05, rgb-zh-noise-Q031-P06, rgb-zh-noise-Q031-P07, rgb-zh-noise-Q031-P08, rgb-zh-noise-Q031-P09, rgb-zh-noise-Q031-P10, rgb-zh-noise-Q031-P11, rgb-zh-noise-Q031-P12, rgb-zh-noise-Q031-P13, rgb-zh-noise-Q031-P14, rgb-zh-noise-Q031-P15

### rgb-neg-032

**问题：** 神舟十四号的航天员有谁

**标准答案：** 陈冬; 刘洋; 蔡旭哲

**来源文档：** rgb-zh-noise-Q032-P00, rgb-zh-noise-Q032-P01, rgb-zh-noise-Q032-P02, rgb-zh-noise-Q032-P03, rgb-zh-noise-Q032-P04, rgb-zh-noise-Q032-P05, rgb-zh-noise-Q032-P06, rgb-zh-noise-Q032-P07, rgb-zh-noise-Q032-P08, rgb-zh-noise-Q032-P09, rgb-zh-noise-Q032-P10, rgb-zh-noise-Q032-P11, rgb-zh-noise-Q032-P12, rgb-zh-noise-Q032-P13

### rgb-neg-033

**问题：** 2022年APEC会议在哪里举行？

**标准答案：** 曼谷

**来源文档：** rgb-zh-noise-Q033-P02, rgb-zh-noise-Q033-P03, rgb-zh-noise-Q033-P04, rgb-zh-noise-Q033-P06, rgb-zh-noise-Q033-P11, rgb-zh-noise-Q033-P13, rgb-zh-noise-Q033-P14, rgb-zh-noise-Q033-P17, rgb-zh-noise-Q033-P18

### rgb-neg-034

**问题：** 欧元区2022年8月通胀率是多少？

**标准答案：** 9.1%

**来源文档：** rgb-zh-noise-Q034-P00, rgb-zh-noise-Q034-P02, rgb-zh-noise-Q034-P03, rgb-zh-noise-Q034-P04, rgb-zh-noise-Q034-P05

### rgb-neg-035

**问题：** 2022年冬奥会开幕式总导演是谁

**标准答案：** 张艺谋

**来源文档：** rgb-zh-noise-Q035-P00, rgb-zh-noise-Q035-P01, rgb-zh-noise-Q035-P02, rgb-zh-noise-Q035-P03, rgb-zh-noise-Q035-P04, rgb-zh-noise-Q035-P05, rgb-zh-noise-Q035-P06, rgb-zh-noise-Q035-P08, rgb-zh-noise-Q035-P09, rgb-zh-noise-Q035-P13, rgb-zh-noise-Q035-P14, rgb-zh-noise-Q035-P15, rgb-zh-noise-Q035-P16, rgb-zh-noise-Q035-P20, rgb-zh-noise-Q035-P22

### rgb-neg-036

**问题：** 2023年春节档票房最高的三部电影

**标准答案：** 满江红; 流浪地球2; 熊出没

**来源文档：** rgb-zh-noise-Q036-P01, rgb-zh-noise-Q036-P02, rgb-zh-noise-Q036-P04, rgb-zh-noise-Q036-P06, rgb-zh-neg-Q036-P04

### rgb-neg-037

**问题：** 浪姐4首播时间

**标准答案：** 5月5日

**来源文档：** rgb-zh-noise-Q037-P01, rgb-zh-noise-Q037-P02, rgb-zh-noise-Q037-P04, rgb-zh-noise-Q037-P05, rgb-zh-noise-Q037-P06

### rgb-neg-038

**问题：** iPhone SE 3的起售价是多少？

**标准答案：** 3499元

**来源文档：** rgb-zh-noise-Q038-P00, rgb-zh-noise-Q038-P01, rgb-zh-noise-Q038-P03, rgb-zh-noise-Q038-P04, rgb-zh-neg-Q038-P04

### rgb-neg-039

**问题：** 小米13系列手机发布时间？

**标准答案：** 12月11日

**来源文档：** rgb-zh-noise-Q039-P01, rgb-zh-noise-Q039-P02, rgb-zh-noise-Q039-P03, rgb-zh-noise-Q039-P04, rgb-zh-noise-Q039-P05

### rgb-neg-040

**问题：** 北京冬奥会澳大利亚运动员数量

**标准答案：** 44

**来源文档：** rgb-zh-neg-Q040-P00, rgb-zh-neg-Q040-P01, rgb-zh-neg-Q040-P02, rgb-zh-neg-Q040-P03, rgb-zh-neg-Q040-P04

### rgb-neg-041

**问题：** 俄罗斯瓦格纳是什么

**标准答案：** 私营军事

**来源文档：** rgb-zh-noise-Q041-P02, rgb-zh-noise-Q041-P00, rgb-zh-noise-Q041-P01, rgb-zh-neg-Q041-P03, rgb-zh-neg-Q041-P04

### rgb-neg-042

**问题：** 《炽道》的主演

**标准答案：** 金晨; 王安宇

**来源文档：** rgb-zh-noise-Q042-P00, rgb-zh-noise-Q042-P01, rgb-zh-noise-Q042-P02, rgb-zh-noise-Q042-P03, rgb-zh-noise-Q042-P04, rgb-zh-noise-Q042-P06, rgb-zh-noise-Q042-P09, rgb-zh-noise-Q042-P10, rgb-zh-noise-Q042-P11, rgb-zh-noise-Q042-P12, rgb-zh-noise-Q042-P13, rgb-zh-noise-Q042-P14, rgb-zh-noise-Q042-P15, rgb-zh-noise-Q042-P16

### rgb-neg-043

**问题：** 卡塔尔世界杯四强

**标准答案：** 阿根廷; 克罗地亚; 摩洛哥; 法国

**来源文档：** rgb-zh-noise-Q043-P00, rgb-zh-noise-Q043-P02, rgb-zh-noise-Q043-P03, rgb-zh-noise-Q043-P04, rgb-zh-noise-Q043-P06, rgb-zh-noise-Q043-P07, rgb-zh-noise-Q043-P08, rgb-zh-noise-Q043-P09

### rgb-neg-044

**问题：** 2023年北京市高考出分时间

**标准答案：** 6月25日

**来源文档：** rgb-zh-noise-Q044-P00, rgb-zh-noise-Q044-P01, rgb-zh-noise-Q044-P02, rgb-zh-noise-Q044-P04, rgb-zh-noise-Q044-P05, rgb-zh-noise-Q044-P06, rgb-zh-noise-Q044-P07, rgb-zh-noise-Q044-P12, rgb-zh-noise-Q044-P20, rgb-zh-noise-Q044-P22

### rgb-neg-045

**问题：** 2022年高考报名人数

**标准答案：** 1193万

**来源文档：** rgb-zh-noise-Q045-P00, rgb-zh-noise-Q045-P01, rgb-zh-noise-Q045-P03, rgb-zh-noise-Q045-P06, rgb-zh-noise-Q045-P07, rgb-zh-noise-Q045-P09, rgb-zh-noise-Q045-P10, rgb-zh-noise-Q045-P11, rgb-zh-noise-Q045-P12, rgb-zh-noise-Q045-P13

### rgb-neg-046

**问题：** 微软花了多少钱收购动视暴雪

**标准答案：** 687亿美元

**来源文档：** rgb-zh-noise-Q046-P00, rgb-zh-noise-Q046-P03, rgb-zh-noise-Q046-P04, rgb-zh-noise-Q046-P01, rgb-zh-noise-Q046-P02

### rgb-neg-047

**问题：** 中国第三艘航母名字

**标准答案：** 福建

**来源文档：** rgb-zh-noise-Q047-P00, rgb-zh-noise-Q047-P01, rgb-zh-noise-Q047-P05, rgb-zh-noise-Q047-P06, rgb-zh-noise-Q047-P09, rgb-zh-noise-Q047-P10, rgb-zh-noise-Q047-P11, rgb-zh-noise-Q047-P13, rgb-zh-noise-Q047-P17, rgb-zh-noise-Q047-P22, rgb-zh-noise-Q047-P23

### rgb-neg-048

**问题：** 汤臣倍健2022年上半年的营收为多少？

**标准答案：** 42.21亿元

**来源文档：** rgb-zh-noise-Q048-P00, rgb-zh-noise-Q048-P01, rgb-zh-noise-Q048-P02, rgb-zh-noise-Q048-P03, rgb-zh-noise-Q048-P04, rgb-zh-noise-Q048-P05, rgb-zh-noise-Q048-P06, rgb-zh-noise-Q048-P07, rgb-zh-noise-Q048-P08

### rgb-neg-049

**问题：** 浙江省第二届国际龙舟公开赛有多少支队伍参赛

**标准答案：** 32

**来源文档：** rgb-zh-noise-Q049-P00, rgb-zh-noise-Q049-P02, rgb-zh-noise-Q049-P03, rgb-zh-noise-Q049-P04, rgb-zh-neg-Q049-P04

### rgb-neg-050

**问题：** 北京2022年冬奥会口号是什么

**标准答案：** 一起向未来

**来源文档：** rgb-zh-noise-Q050-P02, rgb-zh-noise-Q050-P03, rgb-zh-noise-Q050-P04, rgb-zh-noise-Q050-P05, rgb-zh-noise-Q050-P06, rgb-zh-noise-Q050-P07, rgb-zh-noise-Q050-P08, rgb-zh-noise-Q050-P10, rgb-zh-noise-Q050-P11, rgb-zh-noise-Q050-P12, rgb-zh-noise-Q050-P13, rgb-zh-noise-Q050-P14, rgb-zh-noise-Q050-P15, rgb-zh-noise-Q050-P16, rgb-zh-noise-Q050-P18, rgb-zh-noise-Q050-P19, rgb-zh-noise-Q050-P20, rgb-zh-noise-Q050-P21, rgb-zh-noise-Q050-P22, rgb-zh-noise-Q050-P23

### rgb-fact-001

**问题：** 电影《饥饿游戏》的导演是谁

**标准答案：** ['盖瑞·罗斯', '加里·罗斯']

**来源文档：** rgb-zh-fact-Q001-P00, rgb-zh-fact-Q001-P01

### rgb-fact-002

**问题：** 东京奥运会开幕日期是什么时候

**标准答案：** 2021年7月23日

**来源文档：** rgb-zh-fact-Q002-P00, rgb-zh-fact-Q002-P01, rgb-zh-fact-Q002-P02, rgb-zh-fact-Q002-P03

### rgb-fact-003

**问题：** 2020赛季中超冠军是谁

**标准答案：** 江苏苏宁

**来源文档：** rgb-zh-fact-Q003-P00

### rgb-fact-004

**问题：** 印度的首都在哪

**标准答案：** 新德里

**来源文档：** rgb-zh-fact-Q004-P00, rgb-zh-fact-Q004-P01, rgb-zh-fact-Q004-P02, rgb-zh-fact-Q004-P03, rgb-zh-fact-Q004-P04, rgb-zh-fact-Q004-P05, rgb-zh-fact-Q004-P06, rgb-zh-fact-Q004-P07, rgb-zh-fact-Q004-P08

### rgb-fact-005

**问题：** 2019年金砖国家主席国是谁？

**标准答案：** 巴西

**来源文档：** rgb-zh-fact-Q005-P00, rgb-zh-fact-Q005-P01, rgb-zh-fact-Q005-P02, rgb-zh-fact-Q005-P03

### rgb-fact-006

**问题：** 2013年芦山地震的震级

**标准答案：** 7.0级

**来源文档：** rgb-zh-fact-Q006-P00, rgb-zh-fact-Q006-P01

### rgb-fact-007

**问题：** 《流浪地球》的导演

**标准答案：** 郭帆

**来源文档：** rgb-zh-fact-Q007-P00, rgb-zh-fact-Q007-P01, rgb-zh-fact-Q007-P02, rgb-zh-fact-Q007-P03, rgb-zh-fact-Q007-P04, rgb-zh-fact-Q007-P05, rgb-zh-fact-Q007-P06, rgb-zh-fact-Q007-P07, rgb-zh-fact-Q007-P08

### rgb-fact-008

**问题：** Minecraft是什么类型的游戏？

**标准答案：** 沙盒

**来源文档：** rgb-zh-fact-Q008-P00, rgb-zh-fact-Q008-P01, rgb-zh-fact-Q008-P02, rgb-zh-fact-Q008-P03

### rgb-fact-009

**问题：** 2000年奥运会在哪举办

**标准答案：** 澳大利亚; 悉尼

**来源文档：** rgb-zh-fact-Q009-P00

### rgb-fact-010

**问题：** 谁赢得了2020年美国总统选举？

**标准答案：** ['乔·拜登', '拜登']

**来源文档：** rgb-zh-fact-Q010-P00, rgb-zh-fact-Q010-P01, rgb-zh-fact-Q010-P02, rgb-zh-fact-Q010-P03

### rgb-fact-011

**问题：** 《泰囧》的导演是谁？

**标准答案：** 徐峥

**来源文档：** rgb-zh-fact-Q011-P00, rgb-zh-fact-Q011-P01, rgb-zh-fact-Q011-P02, rgb-zh-fact-Q011-P03, rgb-zh-fact-Q011-P04, rgb-zh-fact-Q011-P05

### rgb-fact-012

**问题：** 《小时代》的作者是谁？

**标准答案：** 郭敬明

**来源文档：** rgb-zh-fact-Q012-P00, rgb-zh-fact-Q012-P01, rgb-zh-fact-Q012-P02, rgb-zh-fact-Q012-P03, rgb-zh-fact-Q012-P04

### rgb-fact-013

**问题：** GPT-3的发布时间

**标准答案：** 2020年6月

**来源文档：** rgb-zh-fact-Q013-P00

### rgb-fact-014

**问题：** 曹缘是什么项目的

**标准答案：** 跳水

**来源文档：** rgb-zh-fact-Q014-P00, rgb-zh-fact-Q014-P01, rgb-zh-fact-Q014-P02, rgb-zh-fact-Q014-P03, rgb-zh-fact-Q014-P04, rgb-zh-fact-Q014-P05, rgb-zh-fact-Q014-P06, rgb-zh-fact-Q014-P07

### rgb-fact-015

**问题：** 2015赛季中超冠军是谁

**标准答案：** 广州恒大

**来源文档：** rgb-zh-fact-Q015-P00, rgb-zh-fact-Q015-P01, rgb-zh-fact-Q015-P02, rgb-zh-fact-Q015-P03

### rgb-fact-016

**问题：** 2008年奥运会是在哪举办的

**标准答案：** 北京

**来源文档：** rgb-zh-fact-Q016-P00, rgb-zh-fact-Q016-P01, rgb-zh-fact-Q016-P02, rgb-zh-fact-Q016-P03, rgb-zh-fact-Q016-P04

### rgb-fact-017

**问题：** 维多利亚女王去世时间

**标准答案：** 1901年1月22日

**来源文档：** rgb-zh-fact-Q017-P00

### rgb-fact-018

**问题：** 2016欧洲杯的举办国在哪

**标准答案：** 法国

**来源文档：** rgb-zh-fact-Q018-P00, rgb-zh-fact-Q018-P01, rgb-zh-fact-Q018-P02, rgb-zh-fact-Q018-P03, rgb-zh-fact-Q018-P04, rgb-zh-fact-Q018-P05, rgb-zh-fact-Q018-P06

### rgb-fact-019

**问题：** 《霸王别姬》的导演

**标准答案：** 陈凯歌

**来源文档：** rgb-zh-fact-Q019-P00, rgb-zh-fact-Q019-P01, rgb-zh-fact-Q019-P02, rgb-zh-fact-Q019-P03

### rgb-fact-020

**问题：** 2021年美国众议院议长是谁

**标准答案：** ['南希·佩洛西', '佩洛西']

**来源文档：** rgb-zh-fact-Q020-P00, rgb-zh-fact-Q020-P01

### rgb-fact-021

**问题：** 白宫在哪个城市

**标准答案：** 华盛顿

**来源文档：** rgb-zh-fact-Q021-P00, rgb-zh-fact-Q021-P01, rgb-zh-fact-Q021-P02, rgb-zh-fact-Q021-P03, rgb-zh-fact-Q021-P04

### rgb-fact-022

**问题：** 《哈利·波特》的作者是谁

**标准答案：** ['J·K·罗琳,J.K.罗琳', '罗琳']

**来源文档：** rgb-zh-fact-Q022-P00, rgb-zh-fact-Q022-P01, rgb-zh-fact-Q022-P02, rgb-zh-fact-Q022-P03, rgb-zh-fact-Q022-P04, rgb-zh-fact-Q022-P05, rgb-zh-fact-Q022-P06, rgb-zh-fact-Q022-P07, rgb-zh-fact-Q022-P08

### rgb-fact-023

**问题：** 《战狼2》中国版的导演是谁

**标准答案：** 吴京

**来源文档：** rgb-zh-fact-Q023-P00, rgb-zh-fact-Q023-P01, rgb-zh-fact-Q023-P02, rgb-zh-fact-Q023-P03, rgb-zh-fact-Q023-P04, rgb-zh-fact-Q023-P05, rgb-zh-fact-Q023-P06

### rgb-fact-024

**问题：** CBA2019-2020赛季总冠军

**标准答案：** 广东

**来源文档：** rgb-zh-fact-Q024-P00, rgb-zh-fact-Q024-P01, rgb-zh-fact-Q024-P02

### rgb-fact-025

**问题：** 《神奇女侠1984》的神奇女侠是谁演的

**标准答案：** 盖尔·加朵

**来源文档：** rgb-zh-fact-Q025-P00, rgb-zh-fact-Q025-P01

### rgb-fact-026

**问题：** 张继科是什么项目的

**标准答案：** 乒乓球

**来源文档：** rgb-zh-fact-Q026-P00, rgb-zh-fact-Q026-P01, rgb-zh-fact-Q026-P02, rgb-zh-fact-Q026-P03, rgb-zh-fact-Q026-P04

### rgb-fact-027

**问题：** 越南的首都在哪

**标准答案：** 河内

**来源文档：** rgb-zh-fact-Q027-P00, rgb-zh-fact-Q027-P01, rgb-zh-fact-Q027-P02, rgb-zh-fact-Q027-P03, rgb-zh-fact-Q027-P04

### rgb-fact-028

**问题：** 2018俄罗斯世界杯的冠军

**标准答案：** 法国

**来源文档：** rgb-zh-fact-Q028-P00, rgb-zh-fact-Q028-P01, rgb-zh-fact-Q028-P02, rgb-zh-fact-Q028-P03

### rgb-fact-029

**问题：** 《肖申克的救赎》的导演是谁

**标准答案：** 弗兰克·德拉邦特

**来源文档：** rgb-zh-fact-Q029-P00, rgb-zh-fact-Q029-P01

### rgb-fact-030

**问题：** 香港第六届立法会选举有多少个议席？

**标准答案：** 70

**来源文档：** rgb-zh-fact-Q030-P00, rgb-zh-fact-Q030-P01, rgb-zh-fact-Q030-P02

### rgb-fact-031

**问题：** 2020-2021赛季欧冠冠军

**标准答案：** 切尔西

**来源文档：** rgb-zh-fact-Q031-P00, rgb-zh-fact-Q031-P01, rgb-zh-fact-Q031-P02, rgb-zh-fact-Q031-P03, rgb-zh-fact-Q031-P04, rgb-zh-fact-Q031-P05

### rgb-fact-032

**问题：** 中国哪一年加入WTO的

**标准答案：** 2001年

**来源文档：** rgb-zh-fact-Q032-P00, rgb-zh-fact-Q032-P01, rgb-zh-fact-Q032-P02

### rgb-fact-033

**问题：** J-20战斗机研发国家

**标准答案：** 中国

**来源文档：** rgb-zh-fact-Q033-P00, rgb-zh-fact-Q033-P01, rgb-zh-fact-Q033-P02, rgb-zh-fact-Q033-P03, rgb-zh-fact-Q033-P04, rgb-zh-fact-Q033-P05

### rgb-fact-034

**问题：** 东盟有多少个成员国

**标准答案：** 10

**来源文档：** rgb-zh-fact-Q034-P00, rgb-zh-fact-Q034-P01, rgb-zh-fact-Q034-P02, rgb-zh-fact-Q034-P03, rgb-zh-fact-Q034-P04

### rgb-fact-035

**问题：** 《当幸福来敲门》的编剧是谁

**标准答案：** 斯蒂夫·康拉德

**来源文档：** rgb-zh-fact-Q035-P00

### rgb-fact-036

**问题：** 电影《阿凡达》的导演是谁

**标准答案：** ['詹姆斯·卡梅隆', '卡梅隆']

**来源文档：** rgb-zh-fact-Q036-P00, rgb-zh-fact-Q036-P01, rgb-zh-fact-Q036-P02

### rgb-fact-037

**问题：** 巴西的首都在哪

**标准答案：** 巴西利亚

**来源文档：** rgb-zh-fact-Q037-P00, rgb-zh-fact-Q037-P01, rgb-zh-fact-Q037-P02, rgb-zh-fact-Q037-P03, rgb-zh-fact-Q037-P04

### rgb-fact-038

**问题：** 中国2018年人口出生率

**标准答案：** 10.94‰

**来源文档：** rgb-zh-fact-Q038-P00, rgb-zh-fact-Q038-P01, rgb-zh-fact-Q038-P02

### rgb-fact-039

**问题：** 中国2019年人口出生率

**标准答案：** 10.48‰

**来源文档：** rgb-zh-fact-Q039-P00, rgb-zh-fact-Q039-P01, rgb-zh-fact-Q039-P02

### rgb-fact-040

**问题：** 香港第四任行政长官？

**标准答案：** 梁振英

**来源文档：** rgb-zh-fact-Q040-P00, rgb-zh-fact-Q040-P01, rgb-zh-fact-Q040-P02, rgb-zh-fact-Q040-P03, rgb-zh-fact-Q040-P04

### rgb-fact-041

**问题：** 《复仇者联盟4：终局之战》中国上映日期

**标准答案：** 2019年4月24日

**来源文档：** rgb-zh-fact-Q041-P00, rgb-zh-fact-Q041-P01

### rgb-fact-042

**问题：** 2018-2019赛季欧冠冠军

**标准答案：** 利物浦

**来源文档：** rgb-zh-fact-Q042-P00, rgb-zh-fact-Q042-P01, rgb-zh-fact-Q042-P02, rgb-zh-fact-Q042-P03

### rgb-fact-043

**问题：** 冰心的原名叫什么

**标准答案：** 谢婉莹

**来源文档：** rgb-zh-fact-Q043-P00, rgb-zh-fact-Q043-P01, rgb-zh-fact-Q043-P02, rgb-zh-fact-Q043-P03, rgb-zh-fact-Q043-P04

### rgb-fact-044

**问题：** 2010南非世界杯的冠军

**标准答案：** 西班牙

**来源文档：** rgb-zh-fact-Q044-P00, rgb-zh-fact-Q044-P01, rgb-zh-fact-Q044-P02, rgb-zh-fact-Q044-P03, rgb-zh-fact-Q044-P04, rgb-zh-fact-Q044-P05

### rgb-fact-045

**问题：** 谁暗杀了肯尼迪？

**标准答案：** ['李·哈维·奥斯瓦尔德', '李·奥斯瓦尔德', '李•哈维•奥斯瓦尔德']

**来源文档：** rgb-zh-fact-Q045-P00, rgb-zh-fact-Q045-P01

### rgb-fact-046

**问题：** 2020奥运会在哪举办

**标准答案：** 东京

**来源文档：** rgb-zh-fact-Q046-P00, rgb-zh-fact-Q046-P01, rgb-zh-fact-Q046-P02, rgb-zh-fact-Q046-P03, rgb-zh-fact-Q046-P04, rgb-zh-fact-Q046-P05, rgb-zh-fact-Q046-P06, rgb-zh-fact-Q046-P07, rgb-zh-fact-Q046-P08, rgb-zh-fact-Q046-P09

### rgb-fact-047

**问题：** 2018年女排世锦赛在哪举办

**标准答案：** 日本

**来源文档：** rgb-zh-fact-Q047-P00, rgb-zh-fact-Q047-P01, rgb-zh-fact-Q047-P02

### rgb-fact-048

**问题：** 2019年军运会在哪中国哪个城市举办

**标准答案：** 武汉

**来源文档：** rgb-zh-fact-Q048-P00, rgb-zh-fact-Q048-P01, rgb-zh-fact-Q048-P02, rgb-zh-fact-Q048-P03, rgb-zh-fact-Q048-P04, rgb-zh-fact-Q048-P05, rgb-zh-fact-Q048-P06

### rgb-fact-049

**问题：** 《小偷家族》的导演是谁

**标准答案：** 是枝裕和

**来源文档：** rgb-zh-fact-Q049-P00, rgb-zh-fact-Q049-P01, rgb-zh-fact-Q049-P02, rgb-zh-fact-Q049-P03, rgb-zh-fact-Q049-P04, rgb-zh-fact-Q049-P05, rgb-zh-fact-Q049-P06, rgb-zh-fact-Q049-P07, rgb-zh-fact-Q049-P08

### rgb-fact-050

**问题：** 2004年奥运会是在哪举办的

**标准答案：** 雅典

**来源文档：** rgb-zh-fact-Q050-P00, rgb-zh-fact-Q050-P01, rgb-zh-fact-Q050-P02, rgb-zh-fact-Q050-P03, rgb-zh-fact-Q050-P04, rgb-zh-fact-Q050-P05, rgb-zh-fact-Q050-P06, rgb-zh-fact-Q050-P07
