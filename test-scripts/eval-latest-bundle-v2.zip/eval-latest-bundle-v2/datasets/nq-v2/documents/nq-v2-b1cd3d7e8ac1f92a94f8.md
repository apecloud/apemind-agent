# Hebrew calendar

Hebrew calendar - Wikipedia

Hebrew calendar

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

Jewish calendar, showing Adar II between 1927 and 1948

| Today |

| Tuesday 9 January 2018 CE 22 Tevet AM 5778 [refresh] |

The Hebrew or Jewish calendar (הַלּוּחַ הָעִבְרִי‬, Ha-Luah ha-Ivri) is a lunisolar calendar used today predominantly for Jewish religious observances. It determines the dates for Jewish holidays and the appropriate public reading of Torah portions, yahrzeits (dates to commemorate the death of a relative), and daily Psalm readings, among many ceremonial uses. In Israel, it is used for religious purposes, provides a time frame for agriculture and is an official calendar for civil purposes, although the latter usage has been steadily declining in favor of the Gregorian calendar.

The present Hebrew calendar is the product of evolution, including a Babylonian influence. Until the Tannaitic period (approximately 10–220 CE), the calendar employed a new crescent moon, with an additional month normally added every two or three years to correct for the difference between twelve lunar months and the solar year. The year in which it was added was based on observation of natural agriculture-related events in Israel.[1] Through the Amoraic period (200–500 CE) and into the Geonic period, this system was gradually displaced by the mathematical rules used today. The principles and rules were fully codified by Maimonides in the Mishneh Torah in the 12th century. Maimonides' work also replaced counting "years since the destruction of the Temple" with the modern creation-era Anno Mundi.

The Hebrew lunar year is about eleven days shorter than the solar year and uses the 19-year Metonic cycle to bring it into line with the solar year, with the addition of an intercalary month every two or three years, for a total of seven times per 19 years. Even with this intercalation, the average Hebrew calendar year is longer by about 6 minutes and 40 seconds than the current mean tropical year, so that every 216 years the Hebrew calendar will fall a day behind the current mean tropical year; and about every 231 years it will fall a day behind the mean Gregorian calendar year.[citation needed]

The era used since the Middle Ages is the Anno Mundi epoch (Latin for "in the year of the world"; Hebrew: לבריאת העולם‬, "from the creation of the world"). As with Anno Domini (A.D. or AD), the words or abbreviation for Anno Mundi (A.M. or AM) for the era should properly precede the date rather than follow it.

AM 5778 began at sunset on 20 September 2017 and will end at sunset on 9 September 2018.[2]

Contents
 [hide] 

1 Components

1.1 Day and hours

1.2 Weeks

1.2.1 Names of weekdays

1.2.2 Days of week of holidays

1.3 Months

1.3.1 Importance of lunar months

1.3.2 Names of months

1.3.3 Leap months

1.3.4 Constellations

1.4 Years

1.4.1 Anno Mundi

1.4.2 Previous systems

1.4.3 New year

1.4.4 Leap years

1.4.5 Rosh Hashanah postponement rules

1.4.6 Deficient, regular, and complete years

1.4.7 Four gates

1.4.8 Holidays

2 History

2.1 Mishnaic period

2.2 Modern calendar

2.3 Usage in contemporary Israel

3 Other practices

3.1 Karaite calendar

3.2 Samaritan calendar

3.3 The Qumran calendar

3.4 Persian civil calendar

4 Astronomical calculations

4.1 Synodic month – the molad interval

4.2 Seasonal drift

4.3 Implications for Jewish ritual

4.4 Worked example

5 Rectifying the Hebrew calendar

6 Conversion between Jewish and civil calendars

7 See also

8 References

9 Bibliography

10 External links

10.1 Date converters

Components[edit]
Day and hours[edit]

Further information: Zmanim

The Jewish day is of no fixed length. The Jewish day is modeled on the reference to "...there was evening and there was morning..."[3] in the creation account in the first chapter of Genesis. Based on the classic rabbinic interpretation of this text, a day in the rabbinic Hebrew calendar runs from sunset (start of "the evening") to the next sunset.[4] In most populated parts of the world this is always approximately 24 standard hours, but, depending on the season of the year, it can be slightly less or slightly more. Halachically, a day ends and a new one starts when three stars are visible in the sky. The time between true sunset and the time when the three stars are visible (known as 'tzait ha'kochavim') is known as 'bein hashmashot', and there are differences of opinion as to which day it falls into for some uses. This may be relevant, for example, in determining the date of birth of a child born during that gap.

There is no clock in the Jewish scheme, so that the local civil clock is used. Though the civil clock, including the one in use in Israel, incorporates local adoptions of various conventions such as time zones, standard times and daylight saving, these have no place in the Jewish scheme. The civil clock is used only as a reference point – in expressions such as: "Shabbat starts at ...". The steady progression of sunset around the world and seasonal changes results in gradual civil time changes from one day to the next based on observable astronomical phenomena (the sunset) and not on man-made laws and conventions.

In Judaism, an hour is defined as 1/12 of the time from sunrise to sunset, so, during the winter, an hour can be much less than 60 minutes, and during the summer, it can be much more than 60 minutes. This proportional hour is known as a sha'ah z'manit (lit. a timely hour). A Jewish hour is divided into 1080 halakim (singular: helek) or parts. A part is 3⅓ seconds or 1/18 minute. The ultimate ancestor of the helek was a small Babylonian time period called a barleycorn, itself equal to 1/72 of a Babylonian time degree (1° of celestial rotation).[5] These measures are not generally used for everyday purposes.

Instead of the international date line convention, there are varying opinions as to where the day changes. One opinion uses the antimeridian of Jerusalem. (Jerusalem is 35°13' east of the prime meridian, so the antimeridian is at 144°47' W, passing through eastern Alaska.) Other opinions exist as well.[6][7] (See International date line in Judaism.)

The weekdays start with Sunday (day 1, or Yom Rishon) and proceed to Saturday (day 7), Shabbat. Since some calculations use division, a remainder of 0 signifies Saturday.

While calculations of days, months and years are based on fixed hours equal to 1/24 of a day, the beginning of each halachic day is based on the local time of sunset. The end of the Shabbat and other Jewish holidays is based on nightfall (Tzeth haKochabim) which occurs some amount of time, typically 42 to 72 minutes, after sunset. According to Maimonides, nightfall occurs when three medium-sized stars become visible after sunset. By the 17th century, this had become three-second-magnitude stars. The modern definition is when the center of the sun is 7° below the geometric (airless) horizon, somewhat later than civil twilight at 6°. The beginning of the daytime portion of each day is determined both by dawn and sunrise. Most halachic times are based on some combination of these four times and vary from day to day throughout the year and also vary significantly depending on location. The daytime hours are often divided into Sha'oth Zemaniyoth or "Halachic hours" by taking the time between sunrise and sunset or between dawn and nightfall and dividing it into 12 equal hours. The nighttime hours are similarly divided into 12 equal portions, albeit a different amount of time than the "hours" of the daytime. The earliest and latest times for Jewish services, the latest time to eat chametz on the day before Passover and many other rules are based on Sha'oth Zemaniyoth. For convenience, the modern day using Sha'oth Zemaniyoth is often discussed as if sunset were at 6:00 pm, sunrise at 6:00 am and each hour were equal to a fixed hour. For example, halachic noon may be after 1:00 pm in some areas during daylight saving time. Within the Mishnah, however, the numbering of the hours starts with the "first" hour after the start of the day.[8]

Weeks[edit]

Shavua [שבוע] is a weekly cycle of seven days, mirroring the seven-day period of the Book of Genesis in which the world is created. The names for the days of the week, like those in the creation account, are simply the day number within the week, with Shabbat being the seventh day. Each day of the week runs from sunset to the following sunset and is figured locally.

Names of weekdays[edit]

A bronze Shabbat candlestick holder made in British Mandate Palestine in the 1940s.

The Hebrew calendar follows a seven-day weekly cycle, which runs concurrently with but independently of the monthly and annual cycles. The names for the days of the week are simply the day number within the week. In Hebrew, these names may be abbreviated using the numerical value of the Hebrew letters, for example יום א׳‬ (Day 1, or Yom Rishon (יום ראשון‬)):

Yom Rishon – יום ראשון‬ (abbreviated יום א׳‬), meaning "first day" [corresponds to Sunday] (starting at preceding sunset of Saturday)

Yom Sheni – יום שני‬ (abbr. יום ב׳‬) meaning "second day" [corresponds to Monday]

Yom Shlishi – יום שלישי‬ (abbr. יום ג׳‬) meaning "third day" [corresponds to Tuesday]

Yom Reviʻi – יום רביעי‬ (abbr. יום ד׳‬) meaning "fourth day" [corresponds to Wednesday]

Yom Chamishi – יום חמישי‬ (abbr. יום ה׳‬) = "fifth day" [corresponds to Thursday]

Yom Shishi – יום ששי‬ (abbr. יום ו׳‬) meaning "sixth day" [corresponds to Friday]

Yom Shabbat – יום שבת‬ (abbr. יום ש׳‬), or more usually, simply Shabbat – שבת‬ meaning "rest day" [corresponds to Saturday]

Yom Shabbat (יום שבת‬) is also known as Yom Shabbat Kodesh – יום שבת קודש‬ meaning "holy rest day."

The names of the days of the week are modeled on the seven days mentioned in the creation story. For example, Genesis 1:5 "... And there was evening and there was morning, one day". One day (יוֹם אֶחָד‬) in Genesis 1:15 is translated in JPS as first day, and in some other contexts (including KJV) as day one. In subsequent verses, the Hebrew refers to the days using ordinal numbers, e.g., 'second day', 'third day', and so forth, but with the sixth and seventh days the Hebrew includes the definite article ("the").[9]

The rest day, Shabbat, has a special role in the Jewish weekly cycle as being a special and set apart day, where no work is done. There are many special rules that relate to Shabbat, discussed more fully in the Talmudic tractate Shabbat.

In (Talmudic) Hebrew, the word Shabbat (שַׁבָּת‬) can also mean "week",[10] so that in ritual liturgy a phrase like "Yom Reviʻi bəShabbat" means "the fourth day in the week".[11]

Days of week of holidays[edit]

Main article: Days of week on Hebrew calendar

The period from 1 Adar (or Adar II, in leap years) to 29 Marcheshvan contains all of the festivals specified in the Bible – Purim (14 Adar), Pesach (15 Nisan), Shavuot (6 Sivan), Rosh Hashanah (1 Tishrei), Yom Kippur (10 Tishrei), Sukkot (15 Tishrei), and Shemini Atzeret (22 Tishrei). This period is fixed, during which no adjustments are made.

| Purim | Passover (first day) | Shavuot (first day) | 17 Tammuz/ Tisha B'Av | Rosh Hashanah/ Sukkot/ Shmini Atzeret/ (first day) | Yom Kippur | Chanukah (first day) | 10 Tevet | Tu Bishvat |

| Thu | Sat | Sun | Sun* | Mon | Wed | Sun or Mon | Sun or Tue | Sat or Mon |

| Fri | Sun | Mon | Sun | Tue | Thu | Mon | Tue | Mon |

| Sun | Tue | Wed | Tue | Thu | Sat | Wed or Thu | Wed, Thu, or Fri | Tue, Wed, or Thu |

| Tue | Thu | Fri | Thu | Sat | Mon | Fri or Sat | Fri or Sun | Thu or Sat |

| *Postponed from Shabbat |

There are additional rules in the Hebrew calendar to prevent certain holidays from falling on certain days of the week. (See Rosh Hashanah postponement rules, below.) These rules are implemented by adding an extra day to Marcheshvan (making it 30 days long) or by removing one day from Kislev (making it 29 days long). Accordingly, a common Hebrew calendar year can have a length of 353, 354 or 355 days, while a leap Hebrew calendar year can have a length of 383, 384 or 385 days.

Months[edit]

The Hebrew calendar is a lunisolar calendar, meaning that months are based on lunar months, but years are based on solar years.[12] The calendar year features twelve lunar months of twenty-nine or thirty days, with an intercalary lunar month added periodically to synchronize the twelve lunar cycles with the longer solar year. (These extra months are added seven times every nineteen years. See Leap months, below.) The beginning of each Jewish lunar month is based on the appearance of the new moon.[13] Although originally the new lunar crescent had to be observed and certified by witnesses,[14] the moment of the true new moon is now approximated arithmetically as the molad, which is the mean new moon to a precision of one part.

The mean period of the lunar month (precisely, the synodic month) is very close to 29.5 days. Accordingly, the basic Hebrew calendar year is one of twelve lunar months alternating between 29 and 30 days:

| No. | Hebrew months | Length |

| 1 | Nisan | 30 |

| 2 | Iyar | 29 |

| 3 | Sivan | 30 |

| 4 | Tammuz | 29 |

| 5 | Av | 30 |

| 6 | Elul | 29 |

| 7 | Tishrei | 30 |

| 8 | Marcheshvan (or Cheshvan) | 29/30 |

| 9 | Kislev | 30/29 |

| 10 | Tevet | 29 |

| 11 | Shevat | 30 |

| 12 | Adar | 29 |

| Total | 353, 354 or 355 |

In leap years (such as 5774) an additional month, Adar I (30 days) is added after Shevat, while the regular Adar is referred to as "Adar II."

The insertion of the leap month mentioned above is based on the requirement that Passover—the festival celebrating the Exodus from Egypt, which took place in the spring—always occurs in the [northern hemisphere's] spring season. Since the adoption of a fixed calendar, intercalations in the Hebrew calendar have been assigned to fixed points in a 19-year cycle. Prior to this, the intercalation was determined empirically:

The year may be intercalated on three grounds: 'aviv [i.e.the ripeness of barley], fruits of trees, and the equinox. On two of these grounds it should be intercalated, but not on one of them alone.[15]

Importance of lunar months[edit]

From very early times, the Mesopotamian lunisolar calendar was in wide use by the countries of the western Asia region. The structure, which was also used by the Israelites, was based on lunar months with the intercalation of an additional month to bring the cycle closer to the solar cycle, although there is no evidence of a thirteenth month mentioned anywhere in the Hebrew Bible.[16]

Num 10:10 stresses the importance in Israelite religious observance of the new month (Hebrew: ראש חודש‬, Rosh Chodesh, "beginning of the month"): "... in your new moons, ye shall blow with the trumpets over your burnt-offerings..." Similarly in Num 28:11. "The beginning of the month" meant the appearance of a new moon, and in Exod 12:2. "This month is to you".

According to the Mishnah and Tosefta, in the Maccabean, Herodian, and Mishnaic periods, new months were determined by the sighting of a new crescent, with two eyewitnesses required to testify to the Sanhedrin to having seen the new lunar crescent at sunset.[17] The practice in the time of Gamaliel II (c. 100 CE) was for witnesses to select the appearance of the moon from a collection of drawings that depicted the crescent in a variety of orientations, only a few of which could be valid in any given month.[18] These observations were compared against calculations.[19]

At first the beginning of each Jewish month was signaled to the communities of Israel and beyond by fires lit on mountaintops, but after the Samaritans began to light false fires, messengers were sent.[20] The inability of the messengers to reach communities outside Israel before mid-month High Holy Days (Succot and Passover) led outlying communities to celebrate scriptural festivals for two days rather than one, observing the second feast-day of the Jewish diaspora because of uncertainty of whether the previous month ended after 29 or 30 days.[21]

In his work Mishneh Torah (1178), Maimonides included a chapter "Sanctification of the New Moon", in which he discusses the calendrical rules and their scriptural basis. He notes,

"By how much does the solar year exceed the lunar year? By approximately 11 days. Therefore, whenever this excess accumulates to about 30 days, or a little more or less, one month is added and the particular year is made to consist of 13 months, and this is the so-called embolismic (intercalated) year. For the year could not consist of twelve months plus so-and-so many days, since it is said: throughout the months of the year (Num 28:14), which implies that we should count the year by months and not by days."[22]

Names of months[edit]

Both the Syrian calendar, currently used in the Arabic-speaking countries of the Fertile crescent, and the modern Assyrian calendar share many of the names for months with the Hebrew calendar, such as Nisan, Iyyar, Tammuz, Ab, Elul, Tishri and Adar, indicating a common origin.[16] The origin is thought to be the Babylonian calendar.[16] The modern Turkish calendar includes the names Şubat (February), Nisan (April), Temmuz (July) and Eylul (September). The former name for October was Tesrin.

Biblical references to the pre-exilic calendar include ten months identified by number rather than by name. In parts of the Torah portion Noach ("Noah") (specifically, Gen 7:11, 8:3–4, 8:13–14) it is implied that the months are thirty days long.[23] There is also an indication that there were twelve months in the annual cycle (1 Kings 4:7, 1 Chronicles 27:1–15). Prior to the Babylonian exile, the names of only four months are referred to in the Tanakh:

Aviv – first month – literally "spring" (Exodus 12:2, 13:4, 23:15, 34:18, Deut. 16:1);

Ziv – second month – literally "light" (1 Kings 6:1, 6:37);

Ethanim – seventh month – literally "strong" in plural, perhaps referring to strong rains (1 Kings 8:2); and

Bul – eighth month (1 Kings 6:38).

All of these are believed to be Canaanite names.[24] These names are only mentioned in connection with the building of the First Temple. Håkan Ulfgard suggests that the use of what are rarely used Canaanite (or in the case of Ethanim perhaps Northwest-semitic) names indicates that "the author is consciously utilizing an archaizing terminology, thus giving the impression of an ancient story...".[25]

In a regular (kesidran) year, Marcheshvan has 29 days and Kislev has 30 days. However, because of the Rosh Hashanah postponement rules (see below) Kislev may lose a day to have 29 days, and the year is called a short (chaser) year, or Marcheshvan may acquire an additional day to have 30 days, and the year is called a full (maleh) year. The calendar rules have been designed to ensure that Rosh Hashanah does not fall on a Sunday, Wednesday or Friday. This is to ensure that Yom Kippur does not directly precede or follow Shabbat, which would create practical difficulties, and that Hoshana Rabbah is not on a Shabbat, in which case certain ceremonies would be lost for a year. Hebrew names and romanized transliteration may somewhat differ,[dubious – discuss] as they do for Marcheshvan/Cheshvan (חשוון‬) or Kislev (כסלו‬): the Hebrew words shown here are those commonly indicated, for example, in newspapers.[citation needed]

Hebrew names of the months with their Babylonian analogs

| # | Hebrew | Tiberian | Academy | Common/ Other | Length | Babylonian analog | Holidays/ Notable days | Notes |

| 1 | נִיסָן‬ | Nīsān | Nisan | Nissan | 30 days | Nisanu | Passover | Called Abib (Exodus 13:4, 23:15, 34:18, Deut. 16:1) and Nisan (Esther 3:7) in the Tanakh. |

| 2 | אִיָּר / אייר‬ | ʼIyyār | Iyyar | Iyar | 29 days | Ayaru | Pesach Sheni Lag B'Omer | Called Ziv in 1 Kings 6:1, 6:37. |

| 3 | סִיוָן / סיוון‬ | Sīwān | Sivan | Siwan | 30 days | Simanu | Shavuot |

| 4 | תַּמּוּז ‬ | Tammūz | Tammuz | Tamuz | 29 days | Dumuzu | Seventeenth of Tammuz | Named for the Babylonian god Dumuzi |

| 5 | אָב ‬ | ʼĀḇ | Av | Ab | 30 days | Abu | Tisha B'Av Tu B'Av |

| 6 | אֱלוּל ‬ | ʼĔlūl | Elul | 29 days | Ululu |

| 7 | תִּשׁרִי‬ | Tišrī | Tishri | Tishrei | 30 days | Tashritu | Rosh Hashanah Yom Kippur Sukkot Shemini Atzeret Simchat Torah | Called Ethanim in 1 Kings 8:2. First month of civil year. |

| 8 | מַרְחֶשְׁוָן / מרחשוון ‬ | Marḥešwān | Marẖeshvan | Marcheshvan Cheshvan Marẖeshwan | 29 or 30 days | Arakhsamna | Called Bul in 1 Kings 6:38. |

| 9 | כִּסְלֵו / כסליו‬ | Kislēw | Kislev | Kislev Chisleu Chislev | 29 or 30 days | Kislimu | Hanukkah |

| 10 | טֵבֵת ‬ | Ṭēḇēṯ | Tevet | Tebeth | 29 days | Tebetu | Tenth of Tevet |

| 11 | שְׁבָט ‬ | Šəḇāṭ | Shvat | Shevat Shebat Sebat | 30 days | Shabatu | Tu Bishvat |

| 12L* | אֲדָר א׳ ‬ | Adar I* | 30 days | *Only in Leap years. |

| 12 | אֲדָר / אֲדָר ב׳* ‬ | ʼĂḏār | Adar / Adar II* | 29 days | Adaru | Purim |

Leap months[edit]

The solar year is about eleven days longer than twelve lunar months. The Bible does not directly mention the addition of "embolismic" or intercalary months. However, without the insertion of embolismic months, Jewish festivals would gradually shift outside of the seasons required by the Torah. This has been ruled as implying a requirement for the insertion of embolismic months to reconcile the lunar cycles to the seasons, which are integral to solar yearly cycles.

When the observational form of the calendar was in use, whether or not an embolismic month was announced after the "last month" (Adar) depended on 'aviv [i.e., the ripeness of barley], fruits of trees, and the equinox. On two of these grounds it should be intercalated, but not on one of them alone.[15] It may be noted that in the Bible the name of the first month, Aviv, literally means "spring". Thus, if Adar was over and spring had not yet arrived, an additional month was observed.

Traditionally, for the Babylonian and Hebrew lunisolar calendars, the years 3, 6, 8, 11, 14, 17, and 19 are the long (13-month) years of the Metonic cycle. This cycle forms the basis of the Christian ecclesiastical calendar and the Hebrew calendar and is used for the computation of the date of Easter each year

During leap years Adar I (or Adar Aleph – "first Adar") is added before the regular Adar. Adar I is actually considered to be the extra month, and has 30 days. Adar II (or Adar Bet – "second Adar") is the "real" Adar, and has the usual 29 days. For this reason, holidays such as Purim are observed in Adar II, not Adar I.

Constellations[edit]

Main articles: Hebrew astronomy and Jewish views on astrology

Chronology was a chief consideration in the study of astronomy among the Jews; sacred time was based upon the cycles of the Sun and the Moon. The Talmud identified the twelve constellations of the zodiac with the twelve months of the Hebrew calendar. The correspondence of the constellations with their names in Hebrew and the months is as follows:

Aries – Taleh – Nisan

Taurus – Shor – Iyar

Gemini – Teomim – Sivan

Cancer – Sartan – Tammuz

Leo – Arye – Av

Virgo – Betulah – Elul

Libra – Moznayim – Tishrei

Scorpio – 'Akrab – Marcheshvan

Sagittarius – Keshet – Kislev

Capricorn – Gdi – Tevet

Aquarius – Dli – Shevat

Pisces – Dagim – Adar

Some scholars identified the 12 signs of the zodiac with the 12 sons of Jacob/twelve tribes of Israel.[26] It should be noted that the 12 lunar months of the Hebrew calendar are the normal months from new moon to new: the year normally contains twelve months averaging 29.52 days each. The discrepancy compared to the mean synodic month of 29.53 days is due to Adar I in a leap year always having thirty days. This means that the calendar year normally contains 354 days.

| Year 5778 since the creation of the world, according to the traditional count. |

| This year has 354 days, making it a regular (כסדרה) year. In 5778, Rosh Hashanah is on Thursday, while Passover is on Saturday. |

| According to the Machzor Katan, the 19-year (Metonic) cycle used to keep the Hebrew calendar aligned with the solar year: This year is the 2nd year of the 305th cycle. It is not a leap year. |

| According to the Machzor Gadol, a 28-year solar cycle used to calculate the date to recite Birkat Hachama, a blessing on the sun: This year is the 10th year of the 207th cycle. |

| According to the current reckoning of sabbatical (shmita) years: This year is the 3rd year of the cycle. It is a maaser ani year. |

Years[edit]

The Hebrew calendar year conventionally begins on Rosh Hashanah. However, other dates serve as the beginning of the year for different religious purposes.

There are three qualities that distinguish one year from another: whether it is a leap year or a common year, on which of four permissible days of the week the year begins, and whether it is a deficient, regular, or complete year. Mathematically, there are 24 (2×4×3) possible combinations, but only 14 of them are valid. Each of these patterns is called a keviyah (Hebrew קביעה for "a setting" or "an established thing"), and is encoded as a series of two or three Hebrew letters. See Four gates.

In Hebrew there are two common ways of writing the year number: with the thousands, called לפרט גדול‬ ("major era"), and without the thousands, called לפרט קטן‬ ("minor era"). Thus, the current year is written as ה'תשע"ח ‎(5778) using the "major era" and תשע"ח ‎(778) using the "minor era".

Anno Mundi[edit]

Further information: Anno Mundi

The Jewish calendar's reference point is traditionally held to be about one year before the Creation of the world.

In 1178 CE, Maimonides wrote in the Mishneh Torah, Sanctification of the Moon (11.16), that he had chosen the epoch from which calculations of all dates should be as "the third day of Nisan in this present year ... which is the year 4938 of the creation of the world" (March 22, 1178).[27] He included all the rules for the calculated calendar and their scriptural basis, including the modern epochal year in his work, and beginning formal usage of the anno mundi era. From the eleventh century, anno mundi dating became dominant throughout most of the world's Jewish communities.[28][29][page needed] Today, the rules detailed in Maimonides' calendrical code are those generally used by Jewish communities throughout the world.

Since the codification by Maimonides in 1178, the Jewish calendar has used the Anno Mundi epoch (Latin for "in the year of the world," abbreviated AM or A.M., Hebrew לבריאת העולם‬), sometimes referred to as the "Hebrew era", to distinguish it from other systems based on some computation of creation, such as the Byzantine calendar.

There is also reference in the Talmud to years since the creation based on the calculation in the Seder Olam Rabbah of Rabbi Jose ben Halafta in about 160 CE.[30] By his calculation, based on the Masoretic Text, Adam was created in 3760 BCE, later confirmed by the Muslim chronologist al-Biruni as 3448 years before the Seleucid era.[31] An example is the c. 8th century Baraita of Samuel.

According to rabbinic reckoning, the beginning of "year 1" is not Creation, but about one year before Creation, with the new moon of its first month (Tishrei) to be called molad tohu (the mean new moon of chaos or nothing). The Jewish calendar's epoch (reference date), 1 Tishrei AM 1, is equivalent to Monday, 7 October 3761 BC/BCE in the proleptic Julian calendar, the equivalent tabular date (same daylight period) and is about one year before the traditional Jewish date of Creation on 25 Elul AM 1, based upon the Seder Olam Rabbah.[32] Thus, adding 3760 before Rosh Hashanah or 3761 after to a Julian year number starting from 1 CE (AD 1) will yield the Hebrew year. For earlier years there may be a discrepancy [see: Missing years (Jewish calendar)].

The Seder Olam Rabbah also recognized the importance of the Jubilee and Sabbatical cycles as a long-term calendrical system, and attempted at various places to fit the Sabbatical and Jubilee years into its chronological scheme.

Occasionally, Anno Mundi is styled as Anno Hebraico (AH),[33] though this is subject to confusion with notation for the Islamic Hijri year.

Previous systems[edit]

Before the adoption of the current AM year numbering system, other systems were in use. In early times, the years were counted from some significant historic event. (e.g., 1 Kings 6:1) During the period of the monarchy, it was the widespread practice in western Asia to use era year numbers according to the accession year of the monarch of the country involved. This practice was also followed by the united kingdom of Israel (e.g., 1 Kings 14:25), kingdom of Judah (e.g., 2 Kings 18:13), kingdom of Israel (e.g., 2 Kings 17:6), Persia (e.g., Nehemiah 2:1) and others. Besides, the author of Kings coordinated dates in the two kingdoms by giving the accession year of a monarch in terms of the year of the monarch of the other kingdom, (e.g., 2 Kings 8:16) though some commentators note that these dates do not always synchronise.[34] Other era dating systems have been used at other times. For example, Jewish communities in the Babylonian diaspora counted the years from the first deportation from Israel, that of Jehoiachin in 597 BCE, (e.g., Ezekiel 1:1–2). The era year was then called "year of the captivity of Jehoiachin". (e.g., 2 Kings 25:27)

During the Hellenistic Maccabean period, Seleucid era counting was used, at least in the Greek-influenced area of Israel. The Books of the Maccabees used Seleucid era dating exclusively (e.g., 1 Maccabees 1:54, 6:20, 7:1, 9:3, 10:1). Josephus writing in the Roman period also used Seleucid era dating exclusively. During the Talmudic era, from the 1st to the 10th century, the center of world Judaism was in the Middle East, primarily in the Talmudic Academies of Iraq and Palestine. Jews in these regions used Seleucid era dating (also known as the "Era of Contracts").[28] The Avodah Zarah states:

Rav Aha b. Jacob then put this question: How do we know that our Era [of Documents] is connected with the Kingdom of Greece at all? Why not say that it is reckoned from the Exodus from Egypt, omitting the first thousand years and giving the years of the next thousand? In that case, the document is really post-dated!

Said Rav Nahman: In the Diaspora the Greek Era alone is used. He [the questioner] thought that Rav Nahman wanted to dispose of him anyhow, but when he went and studied it thoroughly he found that it is indeed taught [in a Baraita]: In the Diaspora the Greek Era alone is used.[35]

The use of the era of documents (i.e., Seleucid era) continued till the 16th century in the East, and was employed even in the 19th century among the Jews of Yemen.[36]

Occasionally in Talmudic writings, reference was made to other starting points for eras, such as destruction era dating,[36] being the number of years since the 70 CE destruction of the Second Temple. In the 8th and 9th centuries, as the center of Jewish life moved from Babylonia to Europe, counting using the Seleucid era "became meaningless".[28] There is indication that Jews of the Rhineland in the early Middle Ages used the "years after the destruction of the Temple" (e.g., Mainz Anonymous).

New year[edit]

A shofar made from a ram's horn is traditionally blown in observance of Rosh Hashanah, the beginning of the Jewish civic year.

Exodus 12:2 and Deut 16:1 set Aviv (now Nisan) as "the first of months":

this month shall be unto you the beginning of months; it shall be the first month of the year to you.

Nisan 1 is referred to as the ecclesiastical new year.

In ancient Israel, the start of the ecclesiastical new year for the counting of months and festivals (i.e., Nisan) was determined by reference to Passover. Passover is on 15 Nisan, (Leviticus 23:4–6) which corresponds to the full moon of Nisan. As Passover is a spring festival, it should fall on a full moon day around, and normally just after, the vernal (northward) equinox. If the twelfth full moon after the previous Passover is too early compared to the equinox, a leap month is inserted near the end of the previous year before the new year is set to begin. According to normative Judaism, the verses in Exodus 12:1–2 require that the months be determined by a proper court with the necessary authority to sanctify the months. Hence the court, not the astronomy, has the final decision.[37]

According to some Christian and Karaite sources, the tradition in ancient Israel was that 1 Nisan would not start until the barley is ripe, being the test for the onset of spring.[38] If the barley was not ripe, an intercalary month would be added before Nisan.

The day most commonly referred to as the "New Year" is 1 Tishrei, which actually begins in the seventh month of the ecclesiastical year. On that day the formal New Year for the counting of years (such as Shmita and Yovel), Rosh Hashanah ("head of the year") is observed. (see Ezekiel 40:1, which uses the phrase "beginning of the year".) This is the civil new year, and the date on which the year number advances. Certain agricultural practices are also marked from this date.[39]

In the 1st century, Josephus stated that while –

Moses...appointed Nisan...as the first month for the festivals...the commencement of the year for everything relating to divine worship, but for selling and buying and other ordinary affairs he preserved the ancient order [i. e. the year beginning with Tishrei]."[40]

Edwin Thiele has concluded that the ancient northern Kingdom of Israel counted years using the ecclesiastical new year starting on 1 Aviv (Nisan), while the southern Kingdom of Judah counted years using the civil new year starting on 1 Tishrei.[34] The practice of the Kingdom of Israel was also that of Babylon,[41] as well as other countries of the region.[16] The practice of Judah is still followed.

In fact the Jewish calendar has a multiplicity of new years for different purposes. The use of these dates has been in use for a long time. The use of multiple starting dates for a year is comparable to different starting dates for civil "calendar years", "tax or fiscal years", "academic years", "religious cycles", etc. By the time of the redaction of the Mishnah, Rosh Hashanah 1:1 (c. 200 CE), jurists had identified four new-year dates:

The 1st of Nisan is the new year for kings and feasts; the 1st of Elul is the new year for the tithe of cattle... the 1st of Tishri is the new year for years, of the years of release and jubilee years, for the planting and for vegetables; and the 1st of Shevat is the new year for trees-so the school of Shammai; and the school of Hillel say: On the 15th thereof.[42]

The month of Elul is the new year for counting animal tithes (ma'aser behemah). Tu Bishvat ("the 15th of Shevat") marks the new year for trees (and agricultural tithes).

For the dates of the Jewish New Year see Jewish and Israeli holidays 2000–2050 or calculate using the section "Conversion between Jewish and civil calendars".

Leap years[edit]

The Jewish calendar is based on the Metonic cycle of 19 years, of which 12 are common (non-leap) years of 12 months and 7 are leap years of 13 months. To determine whether a Jewish year is a leap year, one must find its position in the 19-year Metonic cycle. This position is calculated by dividing the Jewish year number by 19 and finding the remainder. For example, the Jewish year 5778 divided by 19 results in a remainder of 2, indicating that it is year 2 of the Metonic cycle. Since there is no year 0, a remainder of 0 indicates that the year is year 19 of the cycle.[43]

Years 3, 6, 8, 11, 14, 17, and 19 of the Metonic cycle are leap years. To assist in remembering this sequence, some people use the mnemonic Hebrew word GUCHADZaT "גוחאדז"ט"‬, where the Hebrew letters gimel-vav-het aleph-dalet-zayin-tet are used as Hebrew numerals equivalent to 3, 6, 8, 1, 4, 7, 9. The keviyah records whether the year is leap or common: פ for peshuta (פשוטה), meaning simple and indicating a common year, and מ indicating a leap year (me'uberet, מעוברת).[44]

Another memory aid notes that intervals of the major scale follow the same pattern as do Jewish leap years, with do corresponding to year 19 (or 0): a whole step in the scale corresponds to two common years between consecutive leap years, and a half step to one common year between two leap years. This connection with the major scale is more plain in the context of 19 equal temperament: counting the tonic as 0, the notes of the major scale in 19 equal temperament are numbers 0 (or 19), 3, 6, 8, 11, 14, 17, the same numbers as the leap years in the Hebrew calendar.

A simple rule for determining whether a year is a leap year has been given above. However, there is another rule which not only tells whether the year is leap but also gives the fraction of a month by which the calendar is behind the seasons, useful for agricultural purposes. To determine whether year n of the calendar is a leap year, find the remainder on dividing [(7 × n) + 1] by 19. If the remainder is 6 or less it is a leap year; if it is 7 or more it is not. For example, the remainder on dividing [(7 × 5778) + 1] by 19 is 15, so the year 5778 is not a leap year. The remainder on dividing [(7 × 5779) + 1] by 19 is 3, so the year 5779 is a leap year.[45] This works because as there are seven leap years in nineteen years the difference between the solar and lunar years increases by 7/19-month per year. When the difference goes above 18/19-month this signifies a leap year, and the difference is reduced by one month.

Rosh Hashanah postponement rules[edit]

| Day of week | Number of days |

| Monday | 353 | 355 | 383 | 385 |

| Tuesday | 354 | 384 |

| Thursday | 354 | 355 | 383 | 385 |

| Saturday | 353 | 355 | 383 | 385 |

To calculate the day on which Rosh Hashanah of a given year will fall, it is necessary first to calculate the expected molad (moment of lunar conjunction or new moon) of Tishrei in that year, and then to apply a set of rules to determine whether the first day of the year must be postponed. The molad can be calculated by multiplying the number of months that will have elapsed since some (preceding) molad whose weekday is known by the mean length of a (synodic) lunar month, which is 29 days, 12 hours, and 793 parts (there are 1080 "parts" in an hour, so that one part is equal to 3​1⁄3 seconds). The very first molad, the molad tohu, fell on Sunday evening at 11.11​1⁄3, or in Jewish terms Day 2, 5 hours, and 204 parts.

In calculating the number of months that will have passed since the known molad that one uses as the starting point, one must remember to include any leap month(s) that falls within the elapsed interval, according to the cycle of leap years. A 19-year cycle of 235 synodic months has 991 weeks 2 days 16 hours 595 parts, a common year of 12 synodic months has 50 weeks 4 days 8 hours 876 parts, while a leap year of 13 synodic months has 54 weeks 5 days 21 hours 589 parts.

The two months whose numbers of days may be adjusted, Marcheshvan and Kislev, are the eighth and ninth months of the Hebrew year, whereas Tishrei is the seventh month (in the traditional counting of the months, even though it is the first month of a new calendar year). Any adjustments needed to postpone Rosh Hashanah must be made to the adjustable months in the year that precedes the year of which the Rosh Hashanah will be the first day.

Just four potential conditions are considered to determine whether the date of Rosh Hashanah must be postponed. These are called the Rosh Hashanah postponement rules, or deḥiyyot:[46][47][48][49][50]

If the molad occurs at or later than noon, Rosh Hashanah is postponed a day. This is called deḥiyyah molad zaken (literally, "old birth", i.e., late new moon).

If the molad occurs on a Sunday, Wednesday, or Friday, Rosh Hashanah is postponed a day. If the application of deḥiyyah molad zaken would place Rosh Hashanah on one of these days, then it must be postponed a second day. This is called deḥiyyah lo ADU, an acronym that means "not [weekday] one, four, or six."

The first of these rules (deḥiyyah molad zaken) is referred to in the Talmud.[19] Nowadays, molad zaken is used as a device to prevent the molad falling on the second day of the month.[51] The second rule, (deḥiyyah lo ADU), is applied for religious reasons.

Another two rules are applied much less frequently and serve to prevent impermissible year lengths. Their names are Hebrew acronyms that refer to the ways they are calculated:

If the molad in a common year falls on a Tuesday after 9 hours and 204 parts, Rosh Hashanah is postponed to Thursday. This is deḥiyyah GaTaRaD, where the acronym stands for "3 [Tuesday], 9, 204."

If the molad following a leap year falls on a Monday, more than 15 hours and 589 parts after the Hebrew day began (for calculation purposes, this is taken to be 6 pm Sunday), Rosh Hashanah is postponed to Tuesday. This is deḥiyyah BeTUTeKaPoT, where the acronym stands for "2 [Monday], 15, 589."

At the innovation of the sages, the calendar was arranged to ensure that Yom Kippur would not fall on a Friday or Sunday, and Hoshana Rabbah would not fall on Shabbat.[52] These rules have been instituted because Shabbat restrictions also apply to Yom Kippur, so that if Yom Kippur were to fall on Friday, it would not be possible to make necessary preparations for Shabbat (such as candle lighting). Similarly, if Yom Kippur fell on a Sunday, it would not be possible to make preparations for Yom Kippur because the preceding day is Shabbat.[53] Additionally, the laws of Shabbat override those of Hoshana Rabbah, so that if Hoshana Rabbah were to fall on Shabbat certain rituals that are a part of the Hoshana Rabbah service (such as carrying willows, which is a form of work) could not be performed.[54]

To prevent Yom Kippur (10 Tishrei) from falling on a Friday or Sunday, Rosh Hashanah (1 Tishrei) cannot fall on Wednesday or Friday. Likewise, to prevent Hoshana Rabbah (21 Tishrei) from falling on a Saturday, Rosh Hashanah cannot fall on a Sunday. This leaves only four days on which Rosh Hashanah can fall: Monday, Tuesday, Thursday, and Saturday, which are referred to as the "four gates". Each day is associated with a number (its order in the week, beginning with Sunday as day 1). Numbers in Hebrew have been traditionally denominated by Hebrew letters. Thus the keviyah uses the letters ה ,ג ,ב and ז (representing 2, 3, 5, and 7, for Monday, Tuesday, Thursday, and Saturday) to denote the starting day of the year.

Deficient, regular, and complete years[edit]

The postponement of the year is compensated for by adding a day to the second month or removing one from the third month. A Jewish common year can only have 353, 354, or 355 days. A leap year is always 30 days longer, and so can have 383, 384, or 385 days.

A chaserah year (Hebrew for "deficient" or "incomplete") is 353 or 383 days long. Both Cheshvan and Kislev have 29 days. The Hebrew letter ח "het" is used in the keviyah.

A kesidrah year ("regular" or "in-order") is 354 or 384 days long. Cheshvan has 29 days while Kislev has 30 days. The Hebrew letter כ "kaf" is used in the keviyah.

A shlemah year ("complete" or "perfect", also "abundant") is 355 or 385 days long. Both Cheshvan and Kislev have 30 days. The Hebrew letter ש "shin" is used in the keviyah.

Whether a year is deficient, regular, or complete is determined by the time between two adjacent Rosh Hashanah observances and the leap year. While the keviyah is sufficient to describe a year, a variant specifies the day of the week for the first day of Pesach (Passover) in lieu of the year length.

A Metonic cycle equates to 235 lunar months in each 19-year cycle. This gives an average of 6939 days, 16 hours, and 595 parts for each cycle. But due to the Rosh Hashanah postponement rules (preceding section) a cycle of 19 Jewish years can be either 6939, 6940, 6941, or 6942 days in duration. Since none of these values is evenly divisible by seven, the Jewish calendar repeats exactly only following 36,288 Metonic cycles, or 689,472 Jewish years. There is a near-repetition every 247 years, except for an excess of about 50 minutes (905 parts).

Four gates[edit]

The annual calendar of a numbered Hebrew year, displayed as 12 or 13 months partitioned into weeks, can be determined by consulting the table of Four gates, whose inputs are the year's position in the 19-year cycle and its molad Tishrei. The resulting type (keviyah) of the desired year in the body of the table is a triple consisting of two numbers and a letter (written left-to-right in English). The left number of each triple is the day of the week of 1 Tishrei, Rosh Hashanah (2 3 5 7); the letter indicates whether that year is deficient (D), regular (R), or complete (C), the number of days in Chesvan and Kislev; while the right number of each triple is the day of the week of 15 Nisan, the first day of Passover or Pesach (1 3 5 7), within the same Hebrew year (next Julian/Gregorian year). The keviyah in Hebrew letters are written right-to-left, so their days of the week are reversed, the right number for 1 Tishrei and the left for 15 Nisan. The year within the 19-year cycle alone determines whether that year has one or two Adars.[55][56][57][58][59]

This table numbers the days of the week and hours for the limits of molad Tishrei in the Hebrew manner for calendrical calculations, that is, both begin at 6 pm, thus 7d 18h 0p is noon Saturday. The years of a 19-year cycle are organized into four groups: common years after a leap year but before a common year (1 4 9 12 15); common years between two leap years (7 18); common years after a common year but before a leap year (2 5 10 13 16); and leap years (3 6 8 11 14 17 19), all between common years. The oldest surviving table of Four gates was written by Saadia Gaon (892–942). It is so named because it identifies the four allowable days of the week on which 1 Tishrei can occur.

Comparing the days of the week of molad Tishrei with those in the keviyah shows that during 39% of years 1 Tishrei is not postponed beyond the day of the week of its molad Tishrei, 47% are postponed one day, and 14% are postponed two days. This table also identifies the seven types of common years and seven types of leap years. Most are represented in any 19-year cycle, except one or two may be in neighboring cycles. The most likely type of year is 5R7 in 18.1% of years, whereas the least likely is 5C1 in 3.3% of years. The day of the week of 15 Nisan is later than that of 1 Tishrei by one, two or three days for common years and three, four or five days for leap years in deficient, regular or complete years, respectively.

Four gates

| molad Tishrei ≥ | Year of 19-year cycle |

| 1 4 9 12 15 | 7 18 | 2 5 10 13 16 | 3 6 8 11 14 17 19 |

| 7d 18h 0p | 2D3 בחג | 2D5 בחה |

| 1d 9h 204p |

| 1d 20h 491p | 2C5 בשה | 2C7 בשז |

| 2d 15h 589p |

| 2d 18h 0p | 3R5 גכה | 3R7 גכז |

| 3d 9h 204p | 5R7 הכז |

| 3d 18h 0p | 5D1 החא |

| 4d 11h 695p |

| 5d 9h 204p | 5C1 השא | 5C3 השג |

| 5d 18h 0p |

| 6d 0h 408p | 7D1 זחא | 7D3 זחג |

| 6d 9h 204p |

| 6d 20h 491p | 7C3 זשג | 7C5 זשה |

Holidays[edit]

See Jewish and Israeli holidays 2000–2050

History[edit]

| Part of a series on the |

| History of Israel |

| Ancient Israel and Judah |

| Natufian culture Prehistory Canaan Israelites United monarchy Northern Kingdom Kingdom of Judah Babylonian rule |

| Second Temple period (530 BC–AD 70) |

| Persian rule Hellenistic period Hasmonean dynasty Herodian dynasty Kingdom Tetrarchy Roman Judea |

| Middle Ages (70–1517) |

| Roman Palaestina Byzantine Palaestina Prima Secunda Revolt against Constantius Gallus Samaritan revolts Revolt against Heraclius Caliphates Filastin Urdunn Crusades Ayyubid dynasty Mamluk Sultanate |

| Modern history (1517–1948) |

| Ottoman rule Eyalet Mutasarrifate Old Yishuv Zionism OETA British mandate |

| State of Israel (1948–present) |

| Independence Timeline Years Arab–Israeli conflict Start-up Nation |

| History of the Land of Israel by topic |

| Judaism Jerusalem Zionism Jewish leaders Jewish warfare Nationality |

| Related |

| Jewish history Hebrew calendar Archaeology Museums |

| Israel portal |

| v t e |

Mishnaic period[edit]

The Trumpeting Place inscription, a stone (2.43×1 m) with Hebrew inscription "To the Trumpeting Place" is believed to be a part of the Second Temple.

The Tanakh contains several commandments related to the keeping of the calendar and the lunar cycle, and records changes that have taken place to the Hebrew calendar.

It has been noted that the procedures described in the Mishnah and Tosefta are all plausible procedures for regulating an empirical lunar calendar.[60] Fire-signals, for example, or smoke-signals, are known from the pre-exilic Lachish ostraca.[61] Furthermore, the Mishnah contains laws that reflect the uncertainties of an empirical calendar. Mishnah Sanhedrin, for example, holds that when one witness holds that an event took place on a certain day of the month, and another that the same event took place on the following day, their testimony can be held to agree, since the length of the preceding month was uncertain.[62] Another Mishnah takes it for granted that it cannot be known in advance whether a year's lease is for twelve or thirteen months.[63] Hence it is a reasonable conclusion that the Mishnaic calendar was actually used in the Mishnaic period.

The accuracy of the Mishnah's claim that the Mishnaic calendar was also used in the late Second Temple period is less certain. One scholar has noted that there are no laws from Second Temple period sources that indicate any doubts about the length of a month or of a year. This led him to propose that the priests must have had some form of computed calendar or calendrical rules that allowed them to know in advance whether a month would have 30 or 29 days, and whether a year would have 12 or 13 months.[64]

Modern calendar[edit]

The Arch of Titus depicting the objects from the Temple being carried through Rome.

Between 70 and 1178 CE, the observation-based calendar was gradually replaced by a mathematically calculated one.[65] Except for the epoch year number, the calendar rules reached their current form by the beginning of the 9th century, as described by the Persian Muslim astronomer al-Khwarizmi (c. 780–850 CE) in 823.[66][67]

One notable difference between the calendar of that era and the modern form was the date of the epoch (the fixed reference point at the beginning of year 1), which at that time was one year later than the epoch of the modern calendar.

Most of the present rules of the calendar were in place by 823, according to a treatise by al-Khwarizmi. Al-Khwarizmi's study of the Jewish calendar, Risāla fi istikhrāj taʾrīkh al-yahūd "Extraction of the Jewish Era" describes the 19-year intercalation cycle, the rules for determining on what day of the week the first day of the month Tishrī shall fall, the interval between the Jewish era (creation of Adam) and the Seleucid era, and the rules for determining the mean longitude of the sun and the moon using the Jewish calendar.[66][67] Not all the rules were in place by 835.[68]

In 921, Aaron ben Meïr proposed changes to the calendar. Though the proposals were rejected, they indicate that all of the rules of the modern calendar (except for the epoch) were in place before that date. In 1000, the Muslim chronologist al-Biruni described all of the modern rules of the Hebrew calendar, except that he specified three different epochs used by various Jewish communities being one, two, or three years later than the modern epoch.[31]

There is a tradition, first mentioned by Hai Gaon (died 1038 CE), that Hillel b. R. Yehuda "in the year 670 of the Seleucid era" (i.e., 358–359 CE) was responsible for the new calculated calendar with a fixed intercalation cycle. Later writers, such as Nachmanides, explained Hai Gaon's words to mean that the entire computed calendar was due to Hillel b. Yehuda in response to persecution of Jews. Maimonides, in the 12th century, stated that the Mishnaic calendar was used "until the days of Abaye and Rava", who flourished c. 320–350 CE, and that the change came when "the land of Israel was destroyed, and no permanent court was left." Taken together, these two traditions suggest that Hillel b. Yehuda (whom they identify with the mid-4th-century Jewish patriarch Ioulos, attested in a letter of the Emperor Julian,[69] and the Jewish patriarch Ellel, mentioned by Epiphanius[70]) instituted the computed Hebrew calendar because of persecution. H. Graetz[71] linked the introduction of the computed calendar to a sharp repression following a failed Jewish insurrection that occurred during the rule of the Christian emperor Constantius and Gallus. A later writer, S. Lieberman, argued[72] instead that the introduction of the fixed calendar was due to measures taken by Christian Roman authorities to prevent the Jewish patriarch from sending calendrical messengers.

Both the tradition that Hillel b. Yehuda instituted the complete computed calendar, and the theory that the computed calendar was introduced due to repression or persecution, have been questioned.[73][74][75] Furthermore, two Jewish dates during post-Talmudic times (specifically in 506 and 776) are impossible under the rules of the modern calendar, indicating that its arithmetic rules were developed in Babylonia during the times of the Geonim (7th to 8th centuries).[76] The Babylonian rules required the delay of the first day of Tishrei when the new moon occurred after noon.[citation needed]

The Talmuds do, however, indicate at least the beginnings of a transition from a purely empirical to a computed calendar. According to a statement attributed to Yose, an Amora who lived during the second half of the 3rd century, the feast of Purim, 14 Adar, could not fall on a Sabbath nor a Monday, lest 10 Tishrei (Yom Kippur) fall on a Friday or a Sunday.[77] This indicates that, by the time of the redaction of the Jerusalem Talmud (c. 400 CE), there were a fixed number of days in all months from Adar to Elul, also implying that the extra month was already a second Adar added before the regular Adar. In another passage, a sage is reported to have counseled "those who make the computations" not to set the first day of Tishrei or the Day of the Willow on the sabbath.[78] This indicates that there was a group who "made computations" and were in a position to control, to some extent, the day of the week on which Rosh Hashanah would fall.

Usage in contemporary Israel[edit]

Early Zionist pioneers were impressed by the fact that the calendar preserved by Jews over many centuries in far-flung diasporas, as a matter of religious ritual, was geared to the climate of their original country: the Jewish New Year marks the transition from the dry season to the rainy one, and major Jewish holidays such as Sukkot, Passover, and Shavuot correspond to major points of the country's agricultural year such as planting and harvest.

Accordingly, in the early 20th century the Hebrew calendar was re-interpreted as an agricultural rather than religious calendar.

After the creation of the State of Israel, the Hebrew calendar became one of the official calendars of Israel, along with the Gregorian calendar. Holidays and commemorations not derived from previous Jewish tradition were to be fixed according to the Hebrew calendar date. For example, the Israeli Independence Day falls on 5 Iyar, Jerusalem Reunification Day on 28 Iyar, and the Holocaust Commemoration Day on 27 Nisan.

Nevertheless, since the 1950s usage of the Hebrew calendar has steadily declined, in favor of the Gregorian calendar. At present, Israelis—except for the religiously observant—conduct their private and public life according to the Gregorian calendar, although the Hebrew calendar is still widely acknowledged, appearing in public venues such as banks (where it is legal for use on cheques and other documents, though only rarely do people make use of this option) and on the mastheads of newspapers.

The Jewish New Year (Rosh Hashanah) is a two-day public holiday in Israel. However, since the 1980s an increasing number of secular Israelis celebrate the Gregorian New Year (usually known as "Silvester Night"—"ליל סילבסטר") on the night between 31 December and 1 January. Prominent rabbis have on several occasions sharply denounced this practice, but with no noticeable effect on the secularist celebrants.[79]

Wall calendars commonly used in Israel are hybrids. Most are organised according to Gregorian rather than Jewish months, but begin in September, when the Jewish New Year usually falls, and provide the Jewish date in small characters.

Other practices[edit]

Outside of Rabbinic Judaism, evidence shows a diversity of practice.

Karaite calendar[edit]

Karaites use the lunar month and the solar year, but the Karaite calendar differs from the current Rabbinic calendar in a number of ways. The Karaite calendar is identical to the Rabbinic calendar used before the Sanhedrin changed the Rabbinic calendar from the lunar, observation based, calendar to the current, mathematically based, calendar used in Rabbinic Judaism today.

In the lunar Karaite calendar, the beginning of each month, the Rosh Chodesh, can be calculated, but is confirmed by the observation in Israel of the first sightings of the new moon.[80] This may result in an occasional variation of a maximum of one day, depending on the inability to observe the new moon. The day is usually "picked up" in the next month.

The addition of the leap month (Adar II) is determined by observing in Israel the ripening of barley at a specific stage (defined by Karaite tradition) (called aviv),[81] rather than using the calculated and fixed calendar of rabbinic Judaism. Occasionally this results in Karaites being one month ahead of other Jews using the calculated rabbinic calendar. The "lost" month would be "picked up" in the next cycle when Karaites would observe a leap month while other Jews would not.

Furthermore, the seasonal drift of the rabbinic calendar is avoided, resulting in the years affected by the drift starting one month earlier in the Karaite calendar.

Also, the four rules of postponement of the rabbinic calendar are not applied, since they are not mentioned in the Tanakh. This can affect the dates observed for all the Jewish holidays in a particular year by one or two days.

In the Middle Ages many Karaite Jews outside Israel followed the calculated rabbinic calendar, because it was not possible to retrieve accurate aviv barley data from the land of Israel. However, since the establishment of the State of Israel, and especially since the Six Day War, the Karaite Jews that have made aliyah can now again use the observational calendar.

Samaritan calendar[edit]

The Samaritan community's calendar also relies on lunar months and solar years. Calculation of the Samaritan calendar has historically been a secret reserved to the priestly family alone,[82] and was based on observations of the new crescent moon. More recently, a 20th-century Samaritan High Priest transferred the calculation to a computer algorithm. The current High Priest confirms the results twice a year, and then distributes calendars to the community.[83]

The epoch of the Samaritan calendar is year of the entry of the Children of Israel into the Land of Israel with Joshua. The month of Passover is the first month in the Samaritan calendar, but the year number increments in the sixth month. Like in the Rabbinic calendar, there are seven leap years within each 19 year cycle. However, the Rabbinic and Samaritan calendars' cycles are not synchronized, so Samaritan festivals—notionally the same as the Rabbinic festivals of Torah origin—are frequently one month off from the date according to the Rabbinic calendar. Additionally, as in the Karaite calendar, the Samaritan calendar does not apply the four rules of postponement, since they are not mentioned in the Tanakh. This can affect the dates observed for all the Jewish holidays in a particular year by one or two days.[82][83]

The Qumran calendar[edit]

See also: Enoch calendar and Qumran calendrical texts

Many of the Dead Sea (Qumran) Scrolls have references to a unique calendar, used by the people there, who are often assumed to be Essenes.

The year of this calendar used the ideal Mesopotamian calendar of twelve 30-day months, to which were added 4 days at the equinoxes and solstices (cardinal points), making a total of 364 days.

There was some ambiguity as to whether the cardinal days were at the beginning of the months or at the end, but the clearest calendar attestations give a year of four seasons, each having three months of 30, 30, and 31 days with the cardinal day the extra day at the end, for a total of 91 days, or exactly 13 weeks. Each season started on the 4th day of the week (Wednesday), every year. (Ben-Dov, Head of All Years, pp. 16–17)

With only 364 days, it is clear that the calendar would after a few years be very noticeably different from the actual seasons, but there is nothing to indicate what was done about this problem. Various suggestions have been made by scholars. One is that nothing was done and the calendar was allowed to change with respect to the seasons. Another suggestion is that changes were made irregularly, only when the seasonal anomaly was too great to be ignored any longer. (Ben-Dov, Head of All Years, pp. 19–20)

The writings often discuss the moon, but the calendar was not based on the movement of the moon any more than indications of the phases of the moon on a modern western calendar indicate that that is a lunar calendar.

Persian civil calendar[edit]

Calendrical evidence for the postexilic Persian period is found in papyri from the Jewish colony at Elephantine, in Egypt. These documents show that the Jewish community of Elephantine used the Egyptian and Babylonian calendars.[84][85]

The Sardica paschal table shows that the Jewish community of some eastern city, possibly Antioch, used a calendrical scheme that kept Nisan 14 within the limits of the Julian month of March.[86] Some of the dates in the document are clearly corrupt, but they can be emended to make the sixteen years in the table consistent with a regular intercalation scheme. Peter, the bishop of Alexandria (early 4th century CE), mentions that the Jews of his city "hold their Passover according to the course of the moon in the month of Phamenoth, or according to the intercalary month every third year in the month of Pharmuthi",[87] suggesting a fairly consistent intercalation scheme that kept Nisan 14 approximately between Phamenoth 10 (March 6 in the 4th century CE) and Pharmuthi 10 (April 5). Jewish funerary inscriptions from Zoar, south of the Dead Sea, dated from the 3rd to the 5th century, indicate that when years were intercalated, the intercalary month was at least sometimes a repeated month of Adar. The inscriptions, however, reveal no clear pattern of regular intercalations, nor do they indicate any consistent rule for determining the start of the lunar month.[88]

In 1178, Maimonides included all the rules for the calculated calendar and their scriptural basis, including the modern epochal year in his work, Mishneh Torah. Today, the rules detailed in Maimonides' code are those generally used by Jewish communities throughout the world.

Astronomical calculations[edit]
Synodic month – the molad interval[edit]

A "new moon" (astronomically called a lunar conjunction and, in Hebrew, a molad) is the moment at which the sun and moon are aligned horizontally with respect to a north-south line (technically, they have the same ecliptical longitude). The period between two new moons is a synodic month. The actual length of a synodic month varies from about 29 days 6 hours and 30 minutes (29.27 days) to about 29 days and 20 hours (29.83 days), a variation range of about 13 hours and 30 minutes. Accordingly, for convenience, a long-term average length, identical to the mean synodic month of ancient times (also called the molad interval) is used. The molad interval is  days, or 29 days, 12 hours, and 793 "parts" (1 "part" = 1/18 minute; 3 "parts" = 10 seconds) (i.e., 29.530594 days), and is the same value determined by the Babylonians in their System B about 300 BCE[89] and was adopted by the Greek astronomer Hipparchus in the 2nd century BCE and by the Alexandrian astronomer Ptolemy in the Almagest four centuries later (who cited Hipparchus as his source). Its remarkable accuracy (less than one second from the true value) is thought to have been achieved using records of lunar eclipses from the 8th to 5th centuries BCE.[90]

This value is as close to the correct value of 29.530589 days as it is possible for a value to come that is rounded off to whole "parts". The discrepancy makes the molad interval about 0.6 seconds too long. Put another way, if the molad is taken as the time of mean conjunction at some reference meridian, then this reference meridian is drifting slowly eastward. If this drift of the reference meridian is traced back to the mid-4th century, the traditional date of the introduction of the fixed calendar, then it is found to correspond to a longitude midway between the Nile and the end of the Euphrates. The modern molad moments match the mean solar times of the lunar conjunction moments near the meridian of Kandahar, Afghanistan, more than 30° east of Jerusalem.

Furthermore, the discrepancy between the molad interval and the mean synodic month is accumulating at an accelerating rate, since the mean synodic month is progressively shortening due to gravitational tidal effects. Measured on a strictly uniform time scale, such as that provided by an atomic clock, the mean synodic month is becoming gradually longer, but since the tides slow Earth's rotation rate even more, the mean synodic month is becoming gradually shorter in terms of mean solar time.

Seasonal drift[edit]

The mean year of the current mathematically based Hebrew calendar is 365 days 5 hours 55 minutes and 25+25/57 seconds (365.2468 days) – computed as the molad/monthly interval of 29.530594 days × 235 months in a 19-year metonic cycle ÷ 19 years per cycle. In relation to the Gregorian calendar, the mean Gregorian calendar year is 365 days 5 hours 49 minutes and 12 seconds (365.2425 days), and the drift of the Hebrew calendar in relation to it is about a day every 231 years.

Implications for Jewish ritual[edit]

This figure, in a detail of a medieval Hebrew calendar, reminded Jews of the palm branch (Lulav), the myrtle twigs, the willow branches, and the citron (Etrog) to be held in the hand and to be brought to the synagogue during the holiday of sukkot, near the end of the autumn holiday season.

Although the molad of Tishrei is the only molad moment that is not ritually announced, it is actually the only one that is relevant to the Hebrew calendar, for it determines the provisional date of Rosh Hashanah, subject to the Rosh Hashanah postponement rules. The other monthly molad moments are announced for mystical reasons. With the moladot on average almost 100 minutes late, this means that the molad of Tishrei lands one day later than it ought to in (100 minutes) ÷ (1440 minutes per day) = 5 of 72 years or nearly 7% of years.

Therefore, the seemingly small drift of the moladot is already significant enough to affect the date of Rosh Hashanah, which then cascades to many other dates in the calendar year and sometimes, due to the Rosh Hashanah postponement rules, also interacts with the dates of the prior or next year. The molad drift could be corrected by using a progressively shorter molad interval that corresponds to the actual mean lunar conjunction interval at the original molad reference meridian. Furthermore, the molad interval determines the calendar mean year, so using a progressively shorter molad interval would help correct the excessive length of the Hebrew calendar mean year, as well as helping it to "hold onto" the northward equinox for the maximum duration.

When the 19-year intercalary cycle was finalised in the 4th century, the earliest Passover (in year 16 of the cycle) coincided with the northward equinox, which means that Passover fell near the first full moon after the northward equinox, or that the northward equinox landed within one lunation before 16 days after the molad of Nisan. This is still the case in about 80% of years; but, in about 20% of years, Passover is a month late by these criteria (as it was in AM 5765 and 5768, the 8th and 11th years of the 19-year cycle = Gregorian 2005 and 2008 CE). Presently, this occurs after the "premature" insertion of a leap month in years 8, 11, and 19 of each 19-year cycle, which causes the northward equinox to land on exceptionally early Hebrew dates in such years. This problem will get worse over time, and so beginning in AM 5817 (2057 CE), year 3 of each 19-year cycle will also be a month late. If the calendar is not amended, then Passover will start to land on or after the summer solstice around AM 16652 (12892 CE). (The exact year when this will begin to occur depends on uncertainties in the future tidal slowing of the Earth rotation rate, and on the accuracy of predictions of precession and Earth axial tilt.)

The seriousness of the spring equinox drift is widely discounted on the grounds that Passover will remain in the spring season for many millennia, and the text of the Torah is generally not interpreted as having specified tight calendrical limits. Of course, the Hebrew calendar also drifts with respect to the autumn equinox, and at least part of the harvest festival of Sukkot is already more than a month after the equinox in years 1, 9, and 12 of each 19-year cycle; beginning in AM 5818 (2057 CE), this will also be the case in year 4. (These are the same year numbers as were mentioned for the spring season in the previous paragraph, except that they get incremented at Rosh Hashanah.) This progressively increases the probability that Sukkot will be cold and wet, making it uncomfortable or impractical to dwell in the traditional succah during Sukkot. The first winter seasonal prayer for rain is not recited until Shemini Atzeret, after the end of Sukkot, yet it is becoming increasingly likely that the rainy season in Israel will start before the end of Sukkot.

No equinox or solstice will ever be more than a day or so away from its mean date according to the solar calendar, while nineteen Jewish years average 6939d 16h 33m 03​1⁄3s compared to the 6939d 14h 26m 15s of nineteen mean tropical years.[91] This discrepancy has mounted up to six days, which is why the earliest Passover currently falls on 26 March (as in AM 5773 / 2013 CE).

Worked example[edit]

Given the length of the year, the length of each month is fixed as described above, so the real problem in determining the calendar for a year is determining the number of days in the year. In the modern calendar, this is determined in the following manner.[92]

The day of Rosh Hashanah and the length of the year are determined by the time and the day of the week of the Tishrei molad, that is, the moment of the average conjunction. Given the Tishrei molad of a certain year, the length of the year is determined as follows:

First, one must determine whether each year is an ordinary or leap year by its position in the 19-year Metonic cycle. Years 3, 6, 8, 11, 14, 17, and 19 are leap years.

Secondly, one must determine the number of days between the starting Tishrei molad (TM1) and the Tishrei molad of the next year (TM2). For calendar descriptions in general the day begins at 6 p.m., but for the purpose of determining Rosh Hashanah, a molad occurring on or after noon is treated as belonging to the next day (the first deḥiyyah).[93] All months are calculated as 29d, 12h, 44m, 3​1⁄3s long (MonLen). Therefore, in an ordinary year TM2 occurs 12 × MonLen days after TM1. This is usually 354 calendar days after TM1, but if TM1 is on or after 3:11:20 a.m. and before noon, it will be 355 days. Similarly, in a leap year, TM2 occurs 13 × MonLen days after TM1. This is usually 384 days after TM1, but if TM1 is on or after noon and before 2:27:16​2⁄3 p.m., TM2 will be only 383 days after TM1. In the same way, from TM2 one calculates TM3. Thus the four natural year lengths are 354, 355, 383, and 384 days.

However, because of the holiday rules, Rosh Hashanah cannot fall on a Sunday, Wednesday, or Friday, so if TM2 is one of those days, Rosh Hashanah in year 2 is postponed by adding one day to year 1 (the second deḥiyyah). To compensate, one day is subtracted from year 2. It is to allow for these adjustments that the system allows 385-day years (long leap) and 353-day years (short ordinary) besides the four natural year lengths.

But how can year 1 be lengthened if it is already a long ordinary year of 355 days or year 2 be shortened if it is a short leap year of 383 days? That is why the third and fourth deḥiyyahs are needed.

If year 1 is already a long ordinary year of 355 days, there will be a problem if TM1 is on a Tuesday,[94] as that means TM2 falls on a Sunday and will have to be postponed, creating a 356-day year. In this case, Rosh Hashanah in year 1 is postponed from Tuesday (the third deḥiyyah). As it cannot be postponed to Wednesday, it is postponed to Thursday, and year 1 ends up with 354 days.

On the other hand, if year 2 is already a short year of 383 days, there will be a problem if TM2 is on a Wednesday.[95] because Rosh Hashanah in year 2 will have to be postponed from Wednesday to Thursday and this will cause year 2 to be only 382 days long. In this case, year 2 is extended by one day by postponing Rosh Hashanah in year 3 from Monday to Tuesday (the fourth deḥiyyah), and year 2 will have 383 days.

Rectifying the Hebrew calendar[edit]

The attribution of the fixed arithmetic Hebrew calendar solely to Hillel II has, however, been questioned by a few authors, such as Sasha Stern, who claim that the calendar rules developed gradually over several centuries.[60]

Given the importance in Jewish ritual of establishing the accurate timing of monthly and annual times, some futurist writers and researchers have considered whether a "corrected" system of establishing the Hebrew date is required. The mean year of the current mathematically based Hebrew calendar has "drifted" an average of 7–8 days late relative to the equinox relationship that it originally had. It is not possible, however, for any individual Hebrew date to be a week or more "late", because Hebrew months always begin within a day or two of the molad moment. What happens instead is that the traditional Hebrew calendar "prematurely" inserts a leap month one year before it "should have been" inserted, where "prematurely" means that the insertion causes the spring equinox to land more than 30 days before the latest acceptable moment, thus causing the calendar to run "one month late" until the time when the leap month "should have been" inserted prior to the following spring. This presently happens in 4 years out of every 19-year cycle (years 3, 8, 11, and 19), implying that the Hebrew calendar currently runs "one month late" more than 21% of the time.

Dr. Irv Bromberg has proposed a 353-year cycle of 4366 months, which would include 130 leap months, along with use of a progressively shorter molad interval, which would keep an amended fixed arithmetic Hebrew calendar from drifting for more than seven millennia.[96] It takes about 3​1⁄2 centuries for the spring equinox to drift an average of ​1⁄19th of a molad interval earlier in the Hebrew calendar. That is a very important time unit, because it can be cancelled by simply truncating a 19-year cycle to 11 years, omitting 8 years including three leap years from the sequence. That is the essential feature of the 353-year leap cycle ((9 × 19) + 11 + (9 × 19) = 353 years).

Religious questions abound about how such a system might be implemented and administered throughout the diverse aspects of the world Jewish community.[97]

Conversion between Jewish and civil calendars[edit]

The list below gives a time which can be used to determine the day the Jewish ecclesiastical (spring) year starts over a period of nineteen years:

20:18  Monday, 31 March 2014
05:07  Saturday, 21 March 2015
02:40  Friday, 8 April 2016
11:28  Tuesday, 28 March 2017
20:17  Saturday, 17 March 2018
17:50  Friday, 5 April 2019
02:38  Wednesday, 25 March 2020
11:27  Sunday, 14 March 2021
09:00  Saturday, 2 April 2022
17:49 Wednesday, 22 March 2023
15:21  Tuesday, 9 April 2024
00:10  Sunday, 30 March 2025
08:59  Thursday, 19 March 2026
06:31  Wednesday, 7 April 2027
15:20  Sunday, 26 March 2028
00:09  Friday, 16 March 2029
21:41  Wednesday, 3 April 2030
06:30  Monday, 24 March 2031
15:19  Friday, 12 March 2032

Every nineteen years this time is 2 days, 16 hours, 33 1/18 minutes later in the week. That is either the same or the previous day in the civil calendar, depending on whether the difference in the day of the week is three or two days. If 29 February is included fewer than five times in the nineteen – year period the date will be later by the number of days which corresponds to the difference between the actual number of insertions and five. If the year is due to start on Sunday, it actually begins on the following Tuesday if the following year is due to start on Friday morning. If due to start on Monday, Wednesday or Friday it actually begins on the following day. If due to start on Saturday, it actually begins on the following day if the previous year was due to begin on Monday morning.

The table below lists, for a Jewish year commencing on 23 March, the civil date of the first day of each month. If the year does not begin on 23 March, each month's first day will differ from the date shown by the number of days that the start of the year differs from 23 March. The correct column is the one which shows the correct starting date for the following year in the last row. If 29 February falls within a Jewish month the first day of later months will be a day earlier than shown.

| Jewish month | Civil date of first day of Jewish month |

| Length of year | 353 days | 354 days | 355 days | 383 days | 384 days | 385 days |

| First | 23 March | 23 March | 23 March | 23 March | 23 March | 23 March |

| Second | 22 April | 22 April | 22 April | 22 April | 22 April | 22 April |

| Third | 21 May | 21 May | 21 May | 21 May | 21 May | 21 May |

| Fourth | 20 June | 20 June | 20 June | 20 June | 20 June | 20 June |

| Fifth | 19 July | 19 July | 19 July | 19 July | 19 July | 19 July |

| Sixth | 18 August | 18 August | 18 August | 18 August | 18 August | 18 August |

| Seventh | 16 September | 16 September | 16 September | 16 September | 16 September | 16 September |

| Eighth | 16 October | 16 October | 16 October | 16 October | 16 October | 16 October |

| Ninth | 14 November | 14 November | 15 November | 14 November | 14 November | 15 November |

| Tenth | 13 December | 14 December | 15 December | 13 December | 14 December | 15 December |

| Eleventh | 11 January | 12 January | 13 January | 11 January | 12 January | 13 January |

| Added month | 10 February | 11 February | 12 February |

| Twelfth | 10 February | 11 February | 12 February | 12 March | 13 March | 14 March |

| First | 11 March | 12 March | 13 March | 10 April | 11 April | 12 April |

For long period calculations, dates should be reduced to the Julian calendar and converted back to the civil calendar at the end of the calculation. The civil calendar used here (Exigian) is correct to one day in 44,000 years and omits the leap day in centennial years which do not give remainder 200 or 700 when divided by 900.[98] It is identical to the Gregorian calendar between 15 October 1582 CE and 28 February 2400 CE (both dates inclusive).

To find how many days the civil calendar is ahead of the Julian in any year from 301 BCE (the calendar is proleptic [assumed] up to 1582 CE) add 300 to the year, multiply the hundreds by 7, divide by 9 and subtract 4. Ignore any fraction of a day. When the difference between the calendars changes the calculated value applies on and from March 1 (civil date) for conversions to Julian. For earlier dates reduce the calculated value by one. For conversions to the civil date the calculated value applies on and from February 29 (Julian date). Again, for earlier dates reduce the calculated value by one. The difference is applied to the calendar one is converting into. A negative value indicates that the Julian date is ahead of the civil date. In this case it is important to remember that when calculating the civil equivalent of February 29 (Julian), February 29 is discounted. Thus if the calculated value is −4 the civil equivalent of this date is February 24. Before 1 CE use astronomical years rather than years BCE. The astronomical year is (year BCE) – 1.

Up to the 4th century CE, these tables give the day of the Jewish month to within a day or so and the number of the month to within a month or so. From the 4th century, the number of the month is given exactly and from the 9th century the day of the month is given exactly as well.

In the Julian calendar, every 76 years the Jewish year is due to start 5h 47 14/18m earlier, and 3d 18h 12 4/18m later in the week.

Example calculation

On what civil date does the eighth month begin in CE 20874-5?

20874=2026+(248x76). In (248x76) Julian years the Jewish year is due to start (248x3d 18h 12 4/18m) later in the week, which is 932d 2h 31 2/18m or 1d 2h 31 2/18m later after removing complete weeks. Allowing for the current difference of thirteen days between the civil and Julian calendars, the Julian date is 13+(248x0d 5h 47 4/18m) earlier, which is 72d 21h 28 16/18m earlier. Convert back to the civil calendar by applying the formula.

20874+300=21174
211x7=1477
1477/9=164 remainder 1
164-4=160.
160d-72d 21h 28 16/18m=87d 2h 31 2/18m.

So, in 20874 CE, the Jewish year is due to begin 87d 2h 31 2/18m later than in 2026 CE and 1d 2h 31 2/18m later in the week. In 20874 CE, therefore, the Jewish year is due to begin at 11.30 3/18 A.M. on Friday, 14 June. Because of the displacements, it actually begins on Saturday, 15 June. Odd months have 30 days and even months 29, so the starting dates are 2, 15 July; 3, 13 August; 4, 12 September; 5, 11 October; 6, 10 November; 7, 9 December, and 8, 8 January.

The rules are based on the theory that Maimonides explains in his book "Rabbinical Astronomy"[99] – no allowance is made for the secular (centennial) decrease of ½ second in the length of the mean tropical year and the increase of about four yards in the distance between the earth and the moon resulting from tidal friction because astronomy was not sufficiently developed in the 12th century (when Maimonides wrote his book) to detect this.

See also[edit]

Judaism portal

Assyrian calendar

Babylonian calendar

Biblical and Talmudic units of measurement

Chol HaMoed, the intermediate days during Passover and Sukkot.

Chronology of the Bible

Counting of the Omer

Islamic calendar

Jewish and Israeli holidays 2000–2050

Lag BaOmer, 33rd day of counting the Omer.

References[edit]

Jump up ^ Specifically, the ripening of the barley crop; the age of the kids, lambs, and doves; the ripeness of the fruit trees; and the relation of the date to the tekufah (seasons). See the Talmud, Sanhedrin 11b

Jump up ^ "Tishrei, 5777". Chabad.org. Retrieved September 13, 2015.

Jump up ^ Gen 1:5, Gen 1:8, Gen 1:13, Gen 1:19, Gen 1:23, Gen 1:31 and Gen 2.2.

Jump up ^ Kurzweil, Arthur (9 February 2011). "The Torah For Dummies". John Wiley & Sons – via Google Books. 

Jump up ^ Otto Neugebauer, "The astronomy of Maimonides and its sources", Hebrew Union College Annual 23 (1949) 322–363.

Jump up ^ See Willie Roth's essay The International Date Line and Halacha.

Jump up ^ "Appendix II: Baal HaMaor's Interpretation of 20b and its Relevance to the Dateline" in Talmud Bavli, Schottenstein Edition, Tractate Rosh HaShanah, Mesorah Publications Ltd. ("ArtScroll") 1999, where "20b" refers to the 20th page 2nd folio of the tractate.

Jump up ^ See, for example, Berachot chapter 1, Mishnah 2.

Jump up ^ See Genesis 1:8, 1:13, 1:19, 1:23, 1:31 and 2.2.

Jump up ^ For example, according to Morfix מילון מורפיקס, Morfix Dictionary, which is based upon Prof. Yaakov Choeka's Rav Milim dictionary. But the word meaning a non-Talmudic week is שָׁבוּע (shavuʻa), according to the same "מילון מורפיקס".

Jump up ^ For example, when referring to the daily psalm recited in the morning prayer (Shacharit).

Jump up ^ In contrast, the Gregorian calendar is a pure solar calendar, while the Islamic calendar is a pure lunar calendar.

Jump up ^ Under the fixed, calculated calendar, this is only loosely true. Because the calculations are based on mean lunar months, not observed ones–and because of the Rosh Hashanah postponement rules—a given month may not begin on the same day as its astronomical conjunction. See Bromberg, Dr. Irv (August 5, 2010). "Moon and the Molad of the Hebrew Calendar". utoronto.ca. Retrieved December 16, 2012. 

Jump up ^ This practice continues to be used in Karaite Judaism as well as in the Islamic calendar.

^ Jump up to: a b Tosefta Sanhedrin 2.2, Herbert Danby, Trans., Tractate Sanhedrin Mishnah and Tosefta, Society for Promoting Christian Knowledge, London and New York, 1919, p. 31. Also quoted in Sacha Stern, Calendar and Community: A History of the Jewish Calendar Second Century BCE-Tenth Century CE, Oxford University Press, 2001, p. 70.

^ Jump up to: a b c d Ancient Israel: Its Life and Institutions (1961) by Roland De Vaux, John McHugh, Publisher: McGraw–Hill, ISBN 978-0-8028-4278-7, p.179

Jump up ^ M. Rosh Hashanah 1.7

Jump up ^ M. Rosh Hashanah 2.6–8

^ Jump up to: a b b. Rosh Hashanah 20b: "This is what Abba the father of R. Simlai meant: 'We calculate the new moon's birth. If it is born before midday, then certainly it will have been seen shortly before sunset. If it was not born before midday, certainly it will not have been seen shortly before sunset.' What is the practical value of this remark? R. Ashi said: Confuting the witnesses." I. Epstein, Ed., The Babylonian Talmud Seder Mo'ed, Soncino Press, London, 1938, p. 85.

Jump up ^ M. Rosh Hashanah 2.2

Jump up ^ b. Betzah 4b

Jump up ^ Sanctification of the New Moon. Archived 2010-06-21 at the Wayback Machine. Translated from the Hebrew by Solomon Gandz; supplemented, introduced, and edited by Julian Obermann; with an astronomical commentary by Otto Neugebauer. Yale Judaica Series, Volume 11, New Haven: Yale University Press, 1956

Jump up ^ Gen 7:11 says "... on the seventeenth day of the second month—on that day all the springs of the great deep burst forth..." and 8:3–4 says "...At the end of the hundred and fifty days the water had gone down, (4) and on the seventeenth day of the seventh month the ark came to rest on the mountains of Ararat..." There is an interval of 5 months and 150 days, making each month 30 days long.

Jump up ^ Hachlili, Rachel (2013). Ancient Synagogues – Archaeology and Art: New Discoveries and Current Research. Brill. p. 342. ISBN 978-9004257733. 

Jump up ^ Ulfgard, Håkan (1998). The Story of Sukkot : the Setting, Shaping and Sequel of the Biblical Feast of Tabernacles. Mohr Siebeck. p. 99. ISBN 3-16-147017-6. 

Jump up ^ (12 Signs, 12 Sons: Astrology in the Bible, David Womack, Harper & Row, San Francisco 1978, pg 43)

Jump up ^ Solomon, Gandz (1947–1948). "Date of the Composition of Maimonides' Code". Proceedings of the American Academy for Jewish Research, Vol. 17, pp. 1–7. doi:10.2307/3622160. JSTOR 3622160. Retrieved March 14, 2013.

^ Jump up to: a b c Chronology of the Old Testament, Dr. Floyd Nolen Jones "When the center of Jewish life moved from Babylonia to Europe during the 8th and 9th centuries CE, calculations from the Seleucid era became meaningless. Over those centuries, it was replaced by that of the anno mundi era of the Seder Olam. From the 11th century, anno mundi dating became dominant throughout most of the world's Jewish communities."

Jump up ^ Alden A. Mosshammer. The Easter Computus and the Origins of the Christian Era. 

Jump up ^ p.107, Kantor

^ Jump up to: a b See The Remaining Signs of Past Centuries.

Jump up ^ A minority opinion places Creation on 25 Adar AM 1, six months earlier, or six months after the modern epoch.

Jump up ^ Fisher Saller, Carol; Harper, Russell David, eds. (2010). "9.34: Eras". The Chicago Manual of Style (16th ed.). Chicago: Univiversity of Chicago Press. ISBN 978-0-226-10420-1. 

^ Jump up to: a b Edwin Thiele, The Mysterious Numbers of the Hebrew Kings, (1st ed.; New York: Macmillan, 1951; 2d ed.; Grand Rapids: Eerdmans, 1965; 3rd ed.; Grand Rapids: Zondervan/Kregel, 1983). ISBN 0-8254-3825-X, 9780825438257

Jump up ^ Adsole, Atenebris. "Babylonian Talmud: 'Abodah Zarah 10". www.come-and-hear.com. 

^ Jump up to: a b Avodah Zarah, tractate 9 Footnote: "The Eras in use among Jews in Talmudic Times are: (a) ERA OF CONTRACTS [H] dating from the year 380 before the Destruction of the Second Temple (312–1 BCE) when, at the Battle of Gaza, Seleucus Nicator, one of the followers of Alexander the Great, gained dominion over Palestine. It is also termed Seleucid or Greek Era [H]. Its designation as Alexandrian Era connecting it with Alexander the Great (Maim. Yad, Gerushin 1, 27) is an anachronism, since Alexander died in 323 BCE—eleven years before this Era began (v. E. Mahler, Handbuch der judischen Chronologie, p. 145). This Era, which is first mentioned in Mac. I, 10, and was used by notaries or scribes for dating all civil contracts, was generally in vogue in eastern countries till the 16th cent, and was employed even in the 19th cent, among the Jews of Yemen, in South Arabia (Eben Saphir, Lyck, 1866, p. 62b). (b) THE ERA OF THE DESTRUCTION (of the Second Temple) [H] the year 1 of which corresponds to 381 of the Seleucid Era, and 69–70 of the Christian Era. This Era was mainly employed by the Rabbis and was in use in Palestine for several centuries, and even in the later Middle Ages documents were dated by it. One of the recently discovered Genizah documents bears the date 13 Tammuz 987 after the Destruction of the Temple—i.e., 917 C.E. (Op. cit. p. 152, also Marmorstein ZDMG, Vol. VI, p. 640). The difference between the two Eras as far as the tens and units are concerned is thus 20. If therefore a Tanna, say in the year 156 Era of Dest. (225 CE), while remembering, naturally, the century, is uncertain about the tens and units, he should ask the notary what year it is according to his—Seleucid—era. He will get the answer 536 (156 + 380), on adding 20 to which he would get 556, the last two figures giving him the year [1] 56 of the Era of Destruction."

Jump up ^ Scherman, Nosson (2005). Artscroll Chumash. 

Jump up ^ The barley had to be "eared out" (ripe) in order to have a wave-sheaf offering of the first fruits according to the Law. Jones, Stephen (1996). Secrets of Time. 

Jump up ^ See Maaser Rishon, Maaser Sheni, Maaser Ani.

Jump up ^ Josephus, Antiquities 1.81, Loeb Classical Library, 1930.

Jump up ^ The Chronology of the Old Testament, 16th ed., Floyd Nolan Jones, ISBN 978-0-89051-416-0, pp. 118–123

Jump up ^ M. Rosh Hashanah 1, in Herbert Danby, trans., The Mishnah, Oxford University Press, 1933, p. 188.

Jump up ^ See also Golden number.

Jump up ^ "The Jewish Calendar: A Closer Look". Judaism 101. Retrieved 25 March 2011. 

Jump up ^ Dershowitz, Nachum; Reingold, Edward M. (December 2007). Calendrical Calculations (Third ed.). Cambridge University Press. p. 91. 

Jump up ^ R. Avraham bar Chiya ha-nasi. Sefer ha-Ibbur (part 2, chapters 9,10). 

Jump up ^ Tur, O.C. (section 428). 

Jump up ^ Rambam. Hilchos Kiddush ha-Chodesh (chapters 6,7,8). 

Jump up ^ W. M. Feldman (1965). "Chapter 17: The Fixed Calendar". Rabbinical Mathematics and Astronomy (2nd ed.). Hermon Press. 

Jump up ^ Hugo Mandelbaum (1986). "Introduction: Elements of the Calendar Calculations". In Arthur Spier. The Comprehensive Hebrew Calendar (3rd ed.). 

Jump up ^ Landau, Remy. "Hebrew Calendar Science and Myth: 'The Debatable Dehiyah Molad Zaquen'". Retrieved 7 February 2015. 

Jump up ^ This is the reason given by most halachic authorities, based on the Talmud, Rosh Hashanah 20b and Sukkah 43b. Maimonides (Mishneh Torah, Kiddush Hachodesh 7:7), however, writes that the arrangement was made (possible days alternating with impossible ones) in order to average out the difference between the mean and true lunar conjunctions.

Jump up ^ The Talmud (Rosh Hashanah 20b) puts it differently: over two consecutive days of full Shabbat restrictions, vegetables would wilt (since they can't be cooked), and unburied corpses would putrefy.

Jump up ^ Yerushalmi, Sukkah 54b.

Jump up ^ Bushwick, Nathan (1989). Understanding the Jewish Calendar. New York/Jerusalem: Moznaim. pp. 95–97. ISBN 0-940118-17-3. 

Jump up ^ Poznanski, Samuel (1910). "Calendar (Jewish)". In Hastings, James. Encyclopædia of Religion and Ethics. 3. Edinburgh: T. & T. Clark. p. 121. 

Jump up ^ Resnikoff, Louis A. (1943). "Jewish Calendar Calculations". Scripta Mathematica. 9: 276. 

Jump up ^ In the Four gates sources (keviyot cited here are in Hebrew in sources): Bushwick forgot to include 5D for leap years. Poznanski forgot to include 5D for a limit in his table although he did include it in his text as 5D1; for leap years he incorrectly listed 5C7 instead of the correct 5C3. Resnikoff's table is correct.

Jump up ^ Robert Schram, Kalendariographische und Chronologische Tafeln, 1908, pp. XXIII-XXVI, 190–238. Schram gives the type of Hebrew year for all years 1–6149 AM (−3760 – 2388 Julian/Gregorian) in a main table (3946+) and its adjunct (1+, 1742+) on pages 191–234 in the form 2d, 2a, 3r, 5r, 5a, 7d, 7a for common years and 2D, 2A, 3R, 5D, 5A, 7D, 7A for leap years. The type of year 1 AM, 2a, is on page 200 at the far right.

^ Jump up to: a b Sacha Stern, Calendar and Community, Oxford University Press, 2001, pp. 162ff.

Jump up ^ James B. Pritchard, ed., The Ancient Near East: An Anthology of Texts and Pictures, Vol. 1, Princeton University Press, p. 213.

Jump up ^ M. Sanhedrin 5.3: "If one testifies, 'on the second of the month, and the other, 'on the third of the month:' their evidence is valid, for one may have been aware of the intercalation of the month and the other may not have been aware of it. But if one says, 'on the third', and the other 'on the fifth', their evidence is invalid."

Jump up ^ M. Baba Metzia 8.8.

Jump up ^ Solomon Gandz, "The origin of the Two New Moon Days", Jewish Quarterly Review (New Series), v. 40, 1949–50. Reprinted in Shlomo Sternberg, ed., Studies in Hebrew Astronomy and Mathematics by Solomon Gandz, KTAV, New York, 1970, pp. 72–73.

Jump up ^ Sacha Stern, Calendar and Community.

^ Jump up to: a b E.S. Kennedy, "Al-Khwarizmi on the Jewish calendar", Scripta Mathematica 27 (1964) 55–59.

^ Jump up to: a b "al-Khwarizmi", Dictionary of Scientific Biography, VII: 362, 365.

Jump up ^ Stern, Sacha. Calendar and Community: A History of the Jewish Calendar Second Century BCE-Tenth Century CE. Oxford, 2001. ISBN 9780198270348. 

Jump up ^ Julian, Letter 25, in John Duncombe, Select Works of the Emperor Julian and some Pieces of the Sophist Libanius, Vol. 2, Cadell, London, 1784, pp. 57–62.

Jump up ^ Epiphanius, Adversus Haereses 30.4.1, in Frank Williams, trans., The Panarion of Epiphanius of Salamis Book I (Sections 1–46), Leiden, E. J.Brill, 1987, p. 122.

Jump up ^ H. Graetz, Popular History of the Jews, (A. B. Rhine, trans.,) Hebrew Publishing Company, New York, 1919, Vol. II, pp. 410–411. Quoted in Sacha Stern, Calendar and Community, p. 216.

Jump up ^ S Lieberman, "Palestine in the 3rd and 4th Centuries", Jewish Quarterly Review, New Series 36, pp. 329–370(1946). Quoted in Sacha Stern, Calendar and Community, pp. 216–217.

Jump up ^ Sacha Stern, Calendar and Community: A History of the Jewish Calendar Second Century BCE-Tenth Century CE, Oxford University Press, 2001. In particular section 5.1.1, discussion of the "Persecution theory."

Jump up ^ Samuel Poznanski, "Ben Meir and the Origin of the Jewish Calendar", Jewish Quarterly Review, Original Series, Vol. 10, pp. 152–161(1898).

Jump up ^ "While it is not unreasonable to attribute to Hillel II the fixing of the regular order of intercalations, his full share in the present fixed calendar is doubtful." Entry "Calendar", Encyclopedia Judaica, Keter, Jerusalem, 1971.

Jump up ^ Samuel Poznanski, "Calendar (Jewish)", Encyclopaedia of Religion and Ethics, vol. 3.

Jump up ^ Yerushalmi Megillah 70b.

Jump up ^ Yerushalmi Sukkah 54b.

Jump up ^ David Lev (23 December 2012). "Rabbinate: New Year's Eve Parties 'Not Kosher'". Arutz Sheva. Retrieved 30 November 2013. 

Jump up ^ "Karaite Korner - New Moon and the Hebrew Month". www.karaite-korner.org. 

Jump up ^ "Aviv Barley in the Biblical Calendar - Nehemia's Wall". 24 February 2016. 

^ Jump up to: a b "The Samaritan Calendar" (PDF). www.thesamaritanupdate.com. 2008. Retrieved 28 December 2017. 

^ Jump up to: a b Benyamim, Tzedaka. "Calendar". www.israelite-samaritans.com. Retrieved 28 December 2017. 

Jump up ^ Sacha Stern, "The Babylonian Calendar at Elephantine", Zeitschrift für Papyrologie und Epigraphik 130, 159–171(2000).

Jump up ^ Lester L. Grabbe, A History of the Jews and Judaism in the Second Temple Period, Volume 1: Yehud: A History of the Persian Province of Judah, T&T Clark, London, 2004, p. 186.

Jump up ^ Eduard Schwartz, Christliche und jüdische Ostertafeln, (Abhandlungen der königlichen Gesellschaft der Wissenschaften zu Göttingen. Philologisch-Historische Klasse. Neue Folge, Band viii, Berlin, 1905.

Jump up ^ Peter of Alexandria, quoted in the Chronicon Paschale. Corpus Scriptorum Historiae Byzantinae, Chronicon Paschale Vol. 1, Weber, Bonn, 1832, p. 7

Jump up ^ Sacha Stern, Calendar and Community, pp. 87–97, 146–153.

Jump up ^ Neugebauer, Astronomical cuneiform texts, Vol 1, pp 271–273

Jump up ^ G. J. Toomer, Hipparchus' Empirical Basis for his Lunar Mean Motions, Centaurus, Vol 24, 1980, pp. 97–109

Jump up ^ Weinberg, I., Astronomical Aspects of the Jewish Calendar, Monthly Notes of the Astronomical Society of South Africa, Vol. 15, p. 86; available at [1]

Jump up ^ The following description is based on the article "Calendar" in Encyclopaedia Judaica (Jerusalem: Ketter, 1972). It is an explanatory description, not a procedural one, in particular explaining what is going on with the third and fourth deḥiyyot

Jump up ^ So for example if the Tishrei molad is calculated as occurring from noon on Wednesday (the 18th hour of the fourth day) up until noon on Thursday, Rosh Hashanah falls on a Thursday, which of course starts Wednesday at sunset wherever one happens to be.

Jump up ^ This will happen if TM1 is on or after 3:11:20 a.m. and before noon on a Tuesday. If TM1 is Monday, Thursday or Saturday, Rosh Hashanah in year 2 does not need to be postponed. If TM1 is Sunday, Wednesday or Friday, Rosh Hashanah in year 1 is postponed, so year 1 is not the maximum length.

Jump up ^ TM2 will be between noon and 2:27:16​2⁄3 p.m. on Tuesday, and TM3 will be between 9:32:43​1⁄3 and noon on Monday.

Jump up ^ Bromberg, Irv. "The Rectified Hebrew Calendar". Retrieved 2011-05-13. 

Jump up ^ "Committee concerning the fixing of the Calendar - The Sanhedrin English". www.thesanhedrin.org. 

Jump up ^ Cassidy, Simon. "Re: How long is a year..EXACTLY? East Carolina University Calendar discussion List CALNDR-L". 25 October 1996. Retrieved 7 February 2015. 

Jump up ^ Feldman, W M. Rabbinical Mathematics and Astronomy:Judaic Studies Library; no. SHP 4. New York, 1978. ISBN 978-0872030268. 

Bibliography[edit]

al-Biruni. The Chronology of Ancient Nations, Chapter VII. tr. C. Edward Sachau. London, 1879.

Ari Belenkiy. "A Unique Feature of the Jewish Calendar – Dehiyot". Culture and Cosmos 6 (2002) 3–22.

Jonathan Ben-Dov. Head of All Years: Astronomy and Calendars at Qumran in their Ancient Context. Leiden: Brill, 2008.

Bonnie Blackburn and Leofranc Holford-Strevens. The Oxford Companion to the Year: An Exploration of Calendar Customs and Time-reckoning. Oxford University Press; USA, 2000.

Sherrard Beaumont Burnaby. Elements of the Jewish and Muhammadan Calendars. George Bell and Sons, London, 1901.

Nathan Bushwick. Understanding the Jewish Calendar. Moznaim, New York/Jerusalem, 1989. ISBN 0-940118-17-3

William Moses Feldman. Rabbinical Mathematics and Astronomy, 3rd edition, Sepher-Hermon Press, New York, 1978.

Eduard Mahler, Handbuch der jüdischen Chronologie. Buchhandlung Gustav Fock, Leipzig, 1916.

Helen R. Jacobus. 'Zodiac Calendars in the Dead Sea Scrolls and Their Reception: Ancient Astronomy and Astrology in Early Judaism.' Leiden: Brill, 2014. ISBN 9789004284050

Otto Neugebauer. Ethiopic astronomy and computus. Österreichische Akademie der Wissenschaften, philosophisch-historische Klasse, Sitzungsberichte 347. Vienna, 1979.

The Code of Maimonides (Mishneh Torah), Book Three, Treatise Eight: Sanctification of the New Moon. Translated by Solomon Gandz. Yale Judaica Series Volume XI, Yale University Press, New Haven, Conn., 1956.

Samuel Poznanski. "Calendar (Jewish)". Encyclopædia of Religion and Ethics. T. & T. Clark, Edinburgh, 1910, vol. 3, pp. 117–124.

Edward M. Reingold and Nachum Dershowitz. Calendrical Calculations: The Millennium Edition. Cambridge University Press; 2 edition (2001). ISBN 0-521-77752-6

723–730.

Louis A. Resnikoff. "Jewish Calendar Calculations", Scripta Mathematica 9 (1943) 191–195, 274–277.

Eduard Schwartz, Christliche und jüdische Ostertafeln (Abhandlungen der königlichen Gesellschaft der Wissenschaften zu Göttingen. Philologisch-Historische Klasse. Neue Folge, Band viii), Berlin, 1905.

Arthur Spier. The Comprehensive Hebrew Calendar: Twentieth to the Twenty-Second Century 5660–5860/1900–2100. Feldheim Publishers, Jerusalem/New York, 1986.

Sacha Stern, Calendar and Community: A History of the Jewish Calendar 2nd Century BCE to 10th Century CE. Oxford University Press, 2001. ISBN 9780198270348.

Ernest Wiesenberg. "Appendix: Addenda and Corrigenda to Treatise VIII". The Code of Maimonides (Mishneh Torah), Book Three: The Book of Seasons. Yale Judaica Series Volume XIV, Yale University Press, New Haven, Conn., 1961. pp. 557–602.

Francis Henry Woods. "Calendar (Hebrew)", Encyclopædia of Religion and Ethics. T. & T. Clark, Edinburgh, 1910, vol. 3, pp. 108–109.

External links[edit]

| This article's use of external links may not follow Wikipedia's policies or guidelines. Please improve this article by removing excessive or inappropriate external links, and converting useful links where appropriate into footnote references. (February 2012) (Learn how and when to remove this template message) |

Perpetual Hebrew / Civil Calendar

The Jewish Controversy about Calendar Postponements

Jewish Calendar with Zmanim – Halachic times and date converter chabad.org

Jewish calendar scientific explanation at the NASA web site

Karaite Holidays Karaite website

Hebrew Calendar Dates and Holydays (Diaspora or Israel) for both the Traditional and the Rectified calendars

Hebrew – Gregorian Calendar with options

Bet Ha Bracha Hebrew Calendar

Hebrew Calendar Science and Myths

Chelm.org's explanation of the Jewish calendar

Jewish Calendar with Halachic times date converter and daf yomi yeshiva.co

Date converters[edit]

Jewish Holidays Online – List of all Jewish holidays for the current year (or any given year).

Molad – Jewish Calendar with Zmanim and holidays for Mobiles.

Jewish Calendar for many platforms

Kaluach – Hebrew/civil calendars

Hebcal Hebrew Date Converter

Sample VB.Net and Javascript code to convert the Hebrew Date to the Gregorian Date at the Wayback Machine (archived November 25, 2007)

Jewish / Civil Date Converter

Software program that converts Hebrew dates to the civil calendar and vice versa

Gregorian-Mayan–Julian–Islamic-Persian-Hebrew Calendar Converter

Kalendis Calendar Calculator

Firefox Add-ons. Hebrew Calendar

Lisp calendar calculator which accompanies Dershowitz & Reingold's Calendrical Calculations 3rd ed. Click "Ancillary materials" tab.

Hebrew/Gregorian converter, including a full Hebrew calendar.

Hebrew/Gregorian Calendar converter, including a full Jewish Calendar.

| [show] v t e Calendars |

| Systems | Lunar Lunisolar Solar |

| In wide use | Astronomical Bengali Chinese Ethiopian Gregorian Hebrew Hindu Iranian Islamic ISO Unix time |

| Akan Armenian Assyrian Bahá'í (Badí‘) Balinese pawukon Balinese saka Berber Buddhist Burmese Chinese Coptic Gaelic Germanic Heathen Georgian Hebrew Hindu or Indian Vikram Samvat Saka Igbo Iranian Jalali (medieval) Hijri (modern) Zoroastrian Islamic Fasli Tabular Jain Japanese Javanese Korean Juche Kurdish Lithuanian Malayalam Mongolian Melanau Nanakshahi Nepal Sambat Nisg̱a'a Oromo Romanian Somali Sesotho Slavic Slavic Native Faith Tamil Thai lunar solar Tibetan Vietnamese Xhosa Yoruba |

| Types | Runic Mesoamerican Long Count Calendar round |

| Christian variants | Julian Revised Liturgical year Eastern Orthodox Saints |

| Historical | Attic Aztec Tonalpohualli Xiuhpohualli Babylonian Bulgar Byzantine Celtic Cham Culāsakaraj Egyptian Florentine French Republican Germanic Greek Hindu Inca Macedonian Maya Haab' Tzolk'in Muisca Pentecontad Pisan Rapa Nui Roman calendar Rumi Soviet Swedish Turkmen |

| By specialty | Holocene (anthropological) Proleptic Gregorian / Proleptic Julian (historiographical) Darian (Martian) Dreamspell (New Age) Discordian / Pataphysical (surreal) |

| Proposals | Calendar reform Hanke–Henry Permanent International Fixed Pax Positivist Symmetry454 Tranquility World New Earth Time |

| Fictional | Discworld Greyhawk Middle-earth Stardate Star Wars (Galactic Standard Calendar) |

| Displays and applications | Electronic Perpetual Wall |

| Terminology | Era Epoch Regnal name Regnal year Year zero |

| Systems | Ab urbe condita Anno Domini/Common Era Anno Mundi Assyrian Before Present Chinese Imperial Chinese Minguo Human Era Japanese Korean Seleucid Spanish Yugas Satya Treta Dvapara Kali Vietnamese |

| List of calendars |

| [show] v t e Jews and Judaism |

| Outline of Judaism Index of Jewish history-related articles |

| History | Timeline Israelites Origins of Judaism Ancient Israel and Judah Second Temple period Rabbinic Judaism Middle Ages Haskalah Zionism |

| Population | Assimilation Diaspora Ashkenazi Sephardi Mizrahi Languages Hebrew Lists of Jews Persecution Antisemitism |

| Philosophy | Beliefs Mitzvah Chosen people Conversion Eschatology Messiah Ethics God Halakha Kabbalah Land of Israel Who is a Jew? |

| Schisms | Religious movements Orthodox Haredi Hasidic Conservative Reform Karaite relations Secularism |

| Literature | Tanakh Torah Nevi'im Ketuvim Rabbinic Mishnah Talmud Midrash Kabbalah texts Zohar Shulchan Aruch Siddur Hebrew literature |

| Culture | Calendar Holidays Cuisine Kashrut Education Leadership Rabbi Marriage Music Names Politics Prayer Synagogue Symbolism |

| Studies | Ashkenazi intelligence Genetics Jew (word) Jewish Virtual Library Relations with other Abrahamic religions Christianity Islam |

| Category: Jews and Judaism Judaism portal Judaism – Wikipedia book |

| [show] v t e Jewish and Israeli holidays and observances |

| Shabbat | Shabbat |

| High Holy Days | Rosh Hashanah Fast of Gedalia Ten Days of Repentance Yom Kippur |

| Shavuot |

| Sukkot Hoshana Rabbah Shemini Atzeret Simchat Torah |

| Yom tov sheni shel galuyot Chol HaMoed Isru chag |

| Rosh Chodesh Hanukkah Tenth of Tevet Tu BiShvat Fast of Esther Purim Purim Katan Counting of the Omer Lag BaOmer 17th of Tammuz The Three Weeks The Nine Days Tisha B'Av Tu B'Av Rosh Hashanah LaBehema |

| Holidays / memorial days of the State of Israel | Yom HaAtzmaut (Independence Day) Yom HaZikaron (Memorial Day) Yom HaShoah (Holocaust Remembrance Day) Yom Yerushalayim (Jerusalem Day) Yom HaAliyah (Aliyah Day) |

| Ethnic minority holidays | Mimouna Seharane Sigd |

| Hebrew calendar months | Tishrei Cheshvan Kislev Tevet Shevat Adar and Adar Sheni Nisan Iyar Sivan Tammuz Av Elul |

| Jewish and Israeli holidays 2000–2050 |

| [show] v t e Time in religion and mythology |

| Time and fate deities Eternity Eschatology Golden Age Divination Prophecy Calendar Fate |

| [show] v t e Chronology |

| Key topics | Archaeology Astronomy Geology History Paleontology Time |

| Calendar eras | Human Era Ab urbe condita Anno Domini / Common Era Anno Mundi Byzantine era Seleucid era Spanish era Before Present Hijri Egyptian Sothic cycle Hindu units of time (Yuga) Mesoamerican Long Count Short Count Tzolk'in Haab' |

| Regnal year | Canon of Kings Lists of kings Limmu |

| Era names | Chinese Japanese Korean Vietnamese |

| Pre-Julian / Julian | Pre-Julian Roman Original Julian Proleptic Julian Revised Julian |

| Gregorian | Gregorian Proleptic Gregorian Old Style and New Style dates Adoption of the Gregorian calendar Dual dating |

| Astronomical | Lunisolar Solar Lunar Astronomical year numbering |

| Others | Chinese sexagenary cycle Geologic Calendar Hebrew Iranian Islamic ISO week date Mesoamerican Maya Aztec Winter count (Plains Indians) |

| Astronomic time | Cosmic Calendar Ephemeris Galactic year Metonic cycle Milankovitch cycles |

| Concepts | Deep time Geological history of Earth Geological time units |

| Standards | Global Standard Stratigraphic Age (GSSA) Global Boundary Stratotype Section and Point (GSSP) |

| Methods | Chronostratigraphy Geochronology Isotope geochemistry Law of superposition Luminescence dating Samarium–neodymium dating |

| Absolute dating | Amino acid racemisation Archaeomagnetic dating Dendrochronology Ice core Incremental dating Lichenometry Paleomagnetism Radiometric dating Radiocarbon Uranium–lead Potassium–argon Tephrochronology Luminescence dating Thermoluminescence dating |

| Relative dating | Fluorine absorption Nitrogen dating Obsidian hydration Seriation Stratigraphy |

| Genetic methods | Molecular clock |

| Linguistic methods | Glottochronology |

| Related topics | Chronicle New Chronology Periodization Synchronoptic view Timeline Year zero Circa Floruit Terminus post quem ASPRO chronology |

| Portal |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Hebrew_calendar&oldid=819021002"

Categories:

Hebrew calendar

Lunisolar calendars

Hidden categories:

Webarchive template wayback links

All articles with unsourced statements

Articles with unsourced statements from November 2016

All accuracy disputes

Articles with disputed statements from August 2015

Articles with unsourced statements from August 2015

Wikipedia articles needing page number citations from February 2016

Articles with unsourced statements from April 2008

Wikipedia external links cleanup from February 2012

Wikipedia spam cleanup from February 2012

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikimedia Commons

			Languages

Afrikaans

Alemannisch

العربية

Asturianu

Azərbaycanca

বাংলা

Беларуская

Беларуская (тарашкевіца)‎

Български

Bosanski

Brezhoneg

Català

Cebuano

Čeština

Cymraeg

Dansk

Deutsch

Eesti

Ελληνικά

Español

Esperanto

Euskara

فارسی

Français

Frysk

Furlan

Galego

한국어

Հայերեն

Hrvatski

Ido

Bahasa Indonesia

Interlingua

Íslenska

Italiano

עברית

Basa Jawa

ಕನ್ನಡ

ქართული

Қазақша

Ladino

Latina

Latviešu

Lietuvių

Magyar

Македонски

მარგალური

مصرى

Bahasa Melayu

Nederlands

日本語

Nordfriisk

Norsk

Norsk nynorsk

Occitan

پنجابی

Polski

Português

Română

Русский

Scots

සිංහල

Simple English

Slovenčina

Ślůnski

Српски / srpski

Srpskohrvatski / српскохрватски

Basa Sunda

Suomi

Svenska

Tagalog

தமிழ்

ไทย

Türkçe

Українська

اردو

Tiếng Việt

ייִדיש

粵語

Zazaki

中文

Edit links

 This page was last edited on 6 January 2018, at 23:15.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews