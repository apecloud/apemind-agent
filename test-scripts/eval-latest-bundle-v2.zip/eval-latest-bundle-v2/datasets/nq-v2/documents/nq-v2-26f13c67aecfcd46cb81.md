# Geocentric model

Geocentric model - Wikipedia

Geocentric model

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

"Geocentric" redirects here. For orbits around Earth, see Geocentric orbit.

Figure of the heavenly bodies — An illustration of the Ptolemaic geocentric system by Portuguese cosmographer and cartographer Bartolomeu Velho, 1568 (Bibliothèque Nationale, Paris)

In astronomy, the geocentric model (also known as geocentrism, or the Ptolemaic system) is a superseded description of the universe with Earth at the center. Under the geocentric model, the Sun, Moon, stars, and planets all orbited Earth.[1] The geocentric model served as the predominant description of the cosmos in many ancient civilizations, such as those of Aristotle and Ptolemy.

Two observations supported the idea that Earth was the center of the Universe. First, from the view on Earth, the Sun appears to revolve around Earth once per day. While the Moon and the planets have their own motions, they also appear to revolve around Earth about once per day. The stars appeared to be on a celestial sphere, rotating once each day along an axis through the north and south geographic poles of Earth.[2] Second, Earth does not seem to move from the perspective of an Earth-bound observer; it appears to be solid, stable, and unmoving.

Ancient Greek, ancient Roman and medieval philosophers usually combined the geocentric model with a spherical Earth. It is not the same as the older flat Earth model implied in some mythology.[n 1][n 2][5] The ancient Jewish Babylonian uranography pictured a flat Earth with a dome-shaped, rigid canopy called the firmament placed over it (רקיע- rāqîa').[n 3][n 4][n 5][n 6][n 7][n 8] However, the ancient Greeks believed that the motions of the planets were circular and not elliptical, a view that was not challenged in Western culture until the 17th century through the synthesis of theories by Copernicus and Kepler.

The astronomical predictions of Ptolemy's geocentric model were used to prepare astrological and astronomical charts for over 1500 years. The geocentric model held sway into the early modern age, but from the late 16th century onward, it was gradually superseded by the Heliocentric model of Copernicus, Galileo and Kepler. There was much resistance to the transition between these two theories. Christian theologians were reluctant to reject a theory that agreed with Bible passages (e.g. "Sun, stand you still upon Gibeon", Joshua 10:12). Others felt a new, unknown theory could not subvert an accepted consensus for geocentrism.

Contents
 [hide] 

1 Ancient Greece

2 Ptolemaic model

2.1 Ptolemaic system

2.2 Islamic astronomy and geocentrism

3 Geocentrism and rival systems

3.1 Copernican system

4 Gravitation

5 Relativity

6 Religious and contemporary adherence to geocentrism

6.1 Historical positions of the Roman Catholic hierarchy

6.2 Orthodox Judaism

6.3 Islam

7 Planetariums

8 See also

9 Notes

10 References

11 Bibliography

12 External links

Ancient Greece[edit]

Illustration of Anaximander's models of the universe. On the left, summer; on the right, winter.

The geocentric model entered Greek astronomy and philosophy at an early point; it can be found in pre-Socratic philosophy. In the 6th century BC, Anaximander proposed a cosmology with Earth shaped like a section of a pillar (a cylinder), held aloft at the center of everything. The Sun, Moon, and planets were holes in invisible wheels surrounding Earth; through the holes, humans could see concealed fire. About the same time, Pythagoras thought that the Earth was a sphere (in accordance with observations of eclipses), but not at the center; they believed that it was in motion around an unseen fire. Later these views were combined, so most educated Greeks from the 4th century BC on thought that the Earth was a sphere at the center of the universe.[12]

In the 4th century BC, two influential Greek philosophers, Plato and his student Aristotle, wrote works based on the geocentric model. According to Plato, the Earth was a sphere, stationary at the center of the universe. The stars and planets were carried around the Earth on spheres or circles, arranged in the order (outwards from the center): Moon, Sun, Venus, Mercury, Mars, Jupiter, Saturn, fixed stars, with the fixed stars located on the celestial sphere. In his "Myth of Er", a section of the Republic, Plato describes the cosmos as the Spindle of Necessity, attended by the Sirens and turned by the three Fates. Eudoxus of Cnidus, who worked with Plato, developed a less mythical, more mathematical explanation of the planets' motion based on Plato's dictum stating that all phenomena in the heavens can be explained with uniform circular motion. Aristotle elaborated on Eudoxus' system.

In the fully developed Aristotelian system, the spherical Earth is at the center of the universe, and all other heavenly bodies are attached to 47–55 transparent, rotating spheres surrounding the Earth, all concentric with it. (The number is so high because several spheres are needed for each planet.) These spheres, known as crystalline spheres, all moved at different uniform speeds to create the revolution of bodies around the Earth. They were composed of an incorruptible substance called aether. Aristotle believed that the moon was in the innermost sphere and therefore touches the realm of Earth, causing the dark spots (macula) and the ability to go through lunar phases. He further described his system by explaining the natural tendencies of the terrestrial elements: Earth, water, fire, air, as well as celestial aether. His system held that Earth was the heaviest element, with the strongest movement towards the center, thus water formed a layer surrounding the sphere of Earth. The tendency of air and fire, on the other hand, was to move upwards, away from the center, with fire being lighter than air. Beyond the layer of fire, were the solid spheres of aether in which the celestial bodies were embedded. They, themselves, were also entirely composed of aether.

Adherence to the geocentric model stemmed largely from several important observations. First of all, if the Earth did move, then one ought to be able to observe the shifting of the fixed stars due to stellar parallax. In short, if the Earth was moving, the shapes of the constellations should change considerably over the course of a year. If they did not appear to move, the stars are either much farther away than the Sun and the planets than previously conceived, making their motion undetectable, or in reality they are not moving at all. Because the stars were actually much further away than Greek astronomers postulated (making movement extremely subtle), stellar parallax was not detected until the 19th century. Therefore, the Greeks chose the simpler of the two explanations. Another observation used in favor of the geocentric model at the time was the apparent consistency of Venus' luminosity, which implies that it is usually about the same distance from Earth, which in turn is more consistent with geocentrism than heliocentrism. In reality, that is because the loss of light caused by Venus' phases compensates for the increase in apparent size caused by its varying distance from Earth. Objectors to heliocentrism noted that terrestrial bodies naturally tend to come to rest as near as possible to the center of the Earth. Further barring the opportunity to fall closer the center, terrestrial bodies tend not to move unless forced by an outside object, or transformed to a different element by heat or moisture.

Atmospheric explanations for many phenomena were preferred because the Eudoxan–Aristotelian model based on perfectly concentric spheres was not intended to explain changes in the brightness of the planets due to a change in distance.[13] Eventually, perfectly concentric spheres were abandoned as it was impossible to develop a sufficiently accurate model under that ideal. However, while providing for similar explanations, the later deferent and epicycle model was flexible enough to accommodate observations for many centuries.

Ptolemaic model[edit]

The basic elements of Ptolemaic astronomy, showing a planet on an epicycle with an eccentric deferent and an equant point. The Green shaded area is the celestial sphere which the planet occupies.

Although the basic tenets of Greek geocentrism were established by the time of Aristotle, the details of his system did not become standard. The Ptolemaic system, developed by the Hellenistic astronomer Claudius Ptolemaeus in the 2nd century AD finally standardised geocentrism. His main astronomical work, the Almagest, was the culmination of centuries of work by Hellenic, Hellenistic and Babylonian astronomers. For over a millennium European and Islamic astronomers assumed it was the correct cosmological model. Because of its influence, people sometimes wrongly think the Ptolemaic system is identical with the geocentric model.

Ptolemy argued that the Earth was a sphere in the center of the universe, from the simple observation that half the stars were above the horizon and half were below the horizon at any time (stars on rotating stellar sphere), and the assumption that the stars were all at some modest distance from the center of the universe. If the Earth was substantially displaced from the center, this division into visible and invisible stars would not be equal.[n 9]

Ptolemaic system[edit]

Pages from 1550 Annotazione on Sacrobosco's Tractatus de Sphaera, showing the Ptolemaic system.

In the Ptolemaic system, each planet is moved by a system of two spheres: one called its deferent; the other, its epicycle. The deferent is a circle whose center point, called the eccentric and marked in the diagram with an X, is removed from the Earth. The original purpose of the eccentric was to account for the difference in length of the seasons (northern autumn was about five days shorter than spring during this time period) by placing the Earth away from the center of rotation of the rest of the universe. Another sphere, the epicycle, is embedded inside the deferent sphere and is represented by the smaller dotted line to the right. A given planet then moves around the epicycle at the same time the epicycle moves along the path marked by the deferent. These combined movements cause the given planet to move closer to and further away from the Earth at different points in its orbit, and explained the observation that planets slowed down, stopped, and moved backward in retrograde motion, and then again reversed to resume normal, or prograde, motion.

The deferent-and-epicycle model had been used by Greek astronomers for centuries along with the idea of the eccentric (a deferent which is slightly off-center from the Earth), which was even older. In the illustration, the center of the deferent is not the Earth but the spot marked X, making it eccentric (from the Greek ἐκ ec- meaning "from," and κέντρον kentron meaning "center"), from which the spot takes its name. Unfortunately, the system that was available in Ptolemy's time did not quite match observations, even though it was considerably improved over Hipparchus' system. Most noticeably the size of a planet's retrograde loop (especially that of Mars) would be smaller, and sometimes larger, than expected, resulting in positional errors of as much as 30 degrees. To alleviate the problem, Ptolemy developed the equant. The equant was a point near the center of a planet's orbit which, if you were to stand there and watch, the center of the planet's epicycle would always appear to move at uniform speed; all other locations would see non-uniform speed, like on the Earth. By using an equant, Ptolemy claimed to keep motion which was uniform and circular, although it departed from the Platonic ideal of uniform circular motion. The resultant system, which eventually came to be widely accepted in the west, seems unwieldy to modern astronomers; each planet required an epicycle revolving on a deferent, offset by an equant which was different for each planet. It predicted various celestial motions, including the beginning and end of retrograde motion, to within a maximum error of 10 degrees, considerably better than without the equant.

The model with epicycles is in fact a very good model of an elliptical orbit with low eccentricity. The well known ellipse shape does not appear to a noticeable extent when the eccentricity is less than 5%, but the offset distance of the "center" (in fact the focus occupied by the sun) is very noticeable even with low eccentricities as possessed by the planets.

To summarize, Ptolemy devised a system that was compatible with Aristotelian philosophy and managed to track actual observations and predict future movement mostly to within the limits of the next 1000 years of observations. The observed motions and his mechanisms for explaining them include:

The Ptolemaic System

| Object(s) | Observation | Modeling mechanism |

| Stars | Motion of entire sky E to W in ~24 hrs ("first motion") | Stars: Daily motion E to W of sphere of stars, carrying all other spheres with it; normally ignored; other spheres have additional motions |

| Sun | Motion yearly W to E along ecliptic | Motion of Sun's sphere W to E in year |

| Sun | Non-uniform rate along ecliptic (uneven seasons) | Eccentric orbit (Sun's deferent center off Earth) |

| Moon | Monthly motion W to E compared to stars | Monthly W to E motion of Moon's sphere |

| The 5 planets | General motion W to E through zodiac | Motion of deferents W to E; period set by observation of planet going around the ecliptic |

| Planets | Retrograde motion | Motion of epicycle in same direction as deferent. Period of epicycle is time between retrograde motions (synodic period). |

| Planets | Variations in speed through the zodiac | Eccentric per planet |

| Planets | Variations in retrograde timing | Equants per planet (Copernicus used a pair of epicycles instead) |

| Planets | Size of deferents, epicycles | Only ratio between radius of deferent and associated epicycle determined; absolute distances not determined in theory |

| Interior planets | Average greatest elongations of 23° (Mercury) and 46° (Venus) | Size of epicycles set by these angles, proportional to distances |

| Interior planets | Limited to movement near the Sun | Center their deferent centers along the Sun–Earth line |

| Exterior planets | Retrograde only at opposition, when brightest | Radii of epicycles aligned to Sun–Earth line |

The geocentric model was eventually replaced by the heliocentric model. The earliest heliocentric model, Copernican heliocentrism, could remove Ptolemy's epicycles because the retrograde motion could be seen to be the result of the combination of Earth and planet movement and speeds. Copernicus felt strongly that equants were a violation of Aristotelian purity, and proved that replacement of the equant with a pair of new epicycles was entirely equivalent. Astronomers often continued using the equants instead of the epicycles because the former was easier to calculate, and gave the same result.

It has been determined, in fact, that the Copernican, Ptolemaic and even the Tychonic models provided identical results to identical inputs. They are computationally equivalent. It wasn't until Kepler demonstrated a physical observation that could show that the physical sun is directly involved in determining an orbit that a new model was required.

The Ptolemaic order of spheres from Earth outward is:[15]

Moon

Mercury

Venus

Sun

Mars

Jupiter

Saturn

Fixed Stars

Primum Mobile ("First Moved")

Ptolemy did not invent or work out this order, which aligns with the ancient Seven Heavens religious cosmology common to the major Eurasian religious traditions. It also follows the decreasing orbital periods of the moon, sun, planets and stars.

Islamic astronomy and geocentrism[edit]

Main articles: Maragheh observatory, Astronomy in medieval Islam, and Islamic cosmology

Muslim astronomers generally accepted the Ptolemaic system and the geocentric model,[16] but by the 10th century texts appeared regularly whose subject matter was doubts concerning Ptolemy (shukūk).[17] Several Muslim scholars questioned the Earth's apparent immobility[18][19] and centrality within the universe.[20] Some Muslim astronomers believed that the Earth rotates around its axis, such as Abu Sa'id al-Sijzi (d. circa 1020).[21][22] According to al-Biruni, Sijzi invented an astrolabe called al-zūraqī based on a belief held by some of his contemporaries "that the motion we see is due to the Earth's movement and not to that of the sky."[22][23] The prevalence of this view is further confirmed by a reference from the 13th century which states:

According to the geometers [or engineers] (muhandisīn), the Earth is in constant circular motion, and what appears to be the motion of the heavens is actually due to the motion of the Earth and not the stars.[22]

Early in the 11th century Alhazen wrote a scathing critique of Ptolemy's model in his Doubts on Ptolemy (c. 1028), which some have interpreted to imply he was criticizing Ptolemy's geocentrism,[24] but most agree that he was actually criticizing the details of Ptolemy's model rather than his geocentrism.[25]

In the 12th century, Arzachel departed from the ancient Greek idea of uniform circular motions by hypothesizing that the planet Mercury moves in an elliptic orbit,[26][27] while Alpetragius proposed a planetary model that abandoned the equant, epicycle and eccentric mechanisms,[28] though this resulted in a system that was mathematically less accurate.[29] Alpetragius also declared the Ptolemaic system as an imaginary model that was successful at predicting planetary positions but not real or physical. His alternative system spread through most of Europe during the 13th century.[30]

Fakhr al-Din al-Razi (1149–1209), in dealing with his conception of physics and the physical world in his Matalib, rejects the Aristotelian and Avicennian notion of the Earth's centrality within the universe, but instead argues that there are "a thousand thousand worlds (alfa alfi 'awalim) beyond this world such that each one of those worlds be bigger and more massive than this world as well as having the like of what this world has." To support his theological argument, he cites the Qur'anic verse, "All praise belongs to God, Lord of the Worlds," emphasizing the term "Worlds."[20]

The "Maragha Revolution" refers to the Maragha school's revolution against Ptolemaic astronomy. The "Maragha school" was an astronomical tradition beginning in the Maragha observatory and continuing with astronomers from the Damascus mosque and Samarkand observatory. Like their Andalusian predecessors, the Maragha astronomers attempted to solve the equant problem (the circle around whose circumference a planet or the center of an epicycle was conceived to move uniformly) and produce alternative configurations to the Ptolemaic model without abandoning geocentrism. They were more successful than their Andalusian predecessors in producing non-Ptolemaic configurations which eliminated the equant and eccentrics, were more accurate than the Ptolemaic model in numerically predicting planetary positions, and were in better agreement with empirical observations.[31] The most important of the Maragha astronomers included Mo'ayyeduddin Urdi (d. 1266), Nasīr al-Dīn al-Tūsī (1201–1274), Qutb al-Din al-Shirazi (1236–1311), Ibn al-Shatir (1304–1375), Ali Qushji (c. 1474), Al-Birjandi (d. 1525), and Shams al-Din al-Khafri (d. 1550).[32] Ibn al-Shatir, the Damascene astronomer (1304–1375 AD) working at the Umayyad Mosque, wrote a major book entitled Kitab Nihayat al-Sul fi Tashih al-Usul (A Final Inquiry Concerning the Rectification of Planetary Theory) on a theory which departs largely from the Ptolemaic system known at that time. In his book, Ibn al-Shatir, an Arab astronomer of the fourteenth century, E. S. Kennedy wrote "what is of most interest, however, is that Ibn al-Shatir's lunar theory, except for trivial differences in parameters, is identical with that of Copernicus (1473–1543 AD)." The discovery that the models of Ibn al-Shatir are mathematically identical to those of Copernicus suggests the possible transmission of these models to Europe.[33] At the Maragha and Samarkand observatories, the Earth's rotation was discussed by al-Tusi and Ali Qushji (b. 1403); the arguments and evidence they used resemble those used by Copernicus to support the Earth's motion.[18][19]

However, the Maragha school never made the paradigm shift to heliocentrism.[34] The influence of the Maragha school on Copernicus remains speculative, since there is no documentary evidence to prove it. The possibility that Copernicus independently developed the Tusi couple remains open, since no researcher has yet demonstrated that he knew about Tusi's work or that of the Maragha school.[34][35]

Geocentrism and rival systems[edit]

| The examples and perspective in this article may not include all significant viewpoints. Please improve the article or discuss the issue. (June 2015) (Learn how and when to remove this template message) |

This drawing from an Icelandic manuscript dated around 1750 illustrates the geocentric model.

Not all Greeks agreed with the geocentric model. The Pythagorean system has already been mentioned; some Pythagoreans believed the Earth to be one of several planets going around a central fire.[36] Hicetas and Ecphantus, two Pythagoreans of the 5th century BC, and Heraclides Ponticus in the 4th century BC, believed that the Earth rotated on its axis but remained at the center of the universe.[37] Such a system still qualifies as geocentric. It was revived in the Middle Ages by Jean Buridan. Heraclides Ponticus was once thought to have proposed that both Venus and Mercury went around the Sun rather than the Earth, but this is no longer accepted.[38] Martianus Capella definitely put Mercury and Venus in orbit around the Sun.[39] Aristarchus of Samos was the most radical. He wrote a work, which has not survived, on heliocentrism, saying that the Sun was at the center of the universe, while the Earth and other planets revolved around it.[40] His theory was not popular, and he had one named follower, Seleucus of Seleucia.[41]

Copernican system[edit]

Main article: Copernican heliocentrism

In 1543, the geocentric system met its first serious challenge with the publication of Copernicus' De revolutionibus orbium coelestium (On the Revolutions of the Heavenly Spheres), which posited that the Earth and the other planets instead revolved around the Sun. The geocentric system was still held for many years afterwards, as at the time the Copernican system did not offer better predictions than the geocentric system, and it posed problems for both natural philosophy and scripture. The Copernican system was no more accurate than Ptolemy's system, because it still used circular orbits. This was not altered until Johannes Kepler postulated that they were elliptical (Kepler's first law of planetary motion).

With the invention of the telescope in 1609, observations made by Galileo Galilei (such as that Jupiter has moons) called into question some of the tenets of geocentrism but did not seriously threaten it. Because he observed dark "spots" on the moon, craters, he remarked that the moon was not a perfect celestial body as had been previously conceived. This was the first time someone could see imperfections on a celestial body that was supposed to be composed of perfect aether. As such, because the moon's imperfections could now be related to those seen on Earth, one could argue that neither was unique: rather, they were both just celestial bodies made from Earth-like material. Galileo could also see the moons of Jupiter, which he dedicated to Cosimo II de' Medici, and stated that they orbited around Jupiter, not Earth.[42] This was a significant claim as it would mean not only that not everything revolved around Earth as stated in the Ptolemaic model, but also showed a secondary celestial body could orbit a moving celestial body, strengthening the heliocentric argument that a moving Earth could retain the Moon.[43] Galileo's observations were verified by other astronomers of the time period who quickly adopted use of the telescope, including Christoph Scheiner, Johannes Kepler, and Giovan Paulo Lembo.[44]

Phases of Venus

In December 1610, Galileo Galilei used his telescope to observe that Venus showed all phases, just like the Moon. He thought that while this observation was incompatible with the Ptolemaic system, it was a natural consequence of the heliocentric system.

However, Ptolemy placed Venus' deferent and epicycle entirely inside the sphere of the Sun (between the Sun and Mercury), but this was arbitrary; he could just as easily have swapped Venus and Mercury and put them on the other side of the Sun, or made any other arrangement of Venus and Mercury, as long as they were always near a line running from the Earth through the Sun, such as placing the center of the Venus epicycle near the Sun. In this case, if the Sun is the source of all the light, under the Ptolemaic system:

If Venus is between Earth and the Sun, the phase of Venus must always be crescent or all dark.

If Venus is beyond the Sun, the phase of Venus must always be gibbous or full.

But Galileo saw Venus at first small and full, and later large and crescent.

In this depiction of the Tychonic system, the objects on blue orbits (the moon and the sun) revolve around the Earth. The objects on orange orbits (Mercury, Venus, Mars, Jupiter, and Saturn) revolve around the sun. Around all is a sphere of stars, which rotates.

This showed that with a Ptolemaic cosmology, the Venus epicycle can be neither completely inside nor completely outside of the orbit of the Sun. As a result, Ptolemaics abandoned the idea that the epicycle of Venus was completely inside the Sun, and later 17th century competition between astronomical cosmologies focused on variations of Tycho Brahe's Tychonic system (in which the Earth was still at the center of the universe, and around it revolved the Sun, but all other planets revolved around the Sun in one massive set of epicycles), or variations on the Copernican system.

Gravitation[edit]

Johannes Kepler analysed Tycho Brahe's famously accurate observations and afterwards constructed his three laws in 1609 and 1619, based on a heliocentric view where the planets move in elliptical paths. Using these laws, he was the first astronomer to successfully predict a transit of Venus (for the year 1631). The change from circular orbits to elliptical planetary paths dramatically improved the accuracy of celestial observations and predictions. Because the heliocentric model by Copernicus was no more accurate than Ptolemy's system, new observations were needed to persuade those who still held on to the geocentric model. However, Kepler's laws based on Brahe's data became a problem which geocentrists could not easily overcome.

In 1687, Isaac Newton stated the law of universal gravitation, described earlier as a hypothesis by Robert Hooke and others. His main achievement was to mathematically derive Kepler's laws of planetary motion from the law of gravitation, thus helping to prove the latter. This introduced gravitation as the force that both kept the Earth and planets moving through the heavens and also kept the air from flying away. The theory of gravity allowed scientists to construct a plausible heliocentric model for the solar system quickly. In his Principia, Newton explained his system of how gravity, previously thought of as an occult force (that is, an unexplained force), directed the movements of celestial bodies, and kept our solar system in its working order. His descriptions of centripetal force[45] were a breakthrough in scientific thought which used the newly developed differential calculus, and finally replaced the previous schools of scientific thought, i.e. those of Aristotle and Ptolemy. However, the process was gradual.

Several empirical tests of Newton's theory, explaining the longer period of oscillation of a pendulum at the equator and the differing size of a degree of latitude, gradually became available over the period 1673–1738. In addition, stellar aberration was observed by Robert Hooke in 1674 and tested in a series of observations by Jean Picard over ten years finishing in 1680. However, it was not explained until 1729 when James Bradley provided an approximate explanation in terms of the Earth's revolution about the sun.

In 1838, astronomer Friedrich Wilhelm Bessel measured the parallax of the star 61 Cygni successfully, and disproved Ptolemy's claim that parallax motion did not exist. This finally confirmed the assumptions made by Copernicus, provided accurate, dependable scientific observations, and displayed truly how far away stars were from Earth.

A geocentric frame is useful for many everyday activities and most laboratory experiments, but is a less appropriate choice for solar-system mechanics and space travel. While a heliocentric frame is most useful in those cases, galactic and extra-galactic astronomy is easier if the sun is treated as neither stationary nor the center of the universe, but rotating around the center of our galaxy, and in turn our galaxy is also not at rest in the cosmic background.

Relativity[edit]

Albert Einstein and Leopold Infeld wrote in The Evolution of Physics (1938): "Can we formulate physical laws so that they are valid for all CS (=coordinate systems), not only those moving uniformly, but also those moving quite arbitrarily, relative to each other? If this can be done, our difficulties will be over. We shall then be able to apply the laws of nature to any CS. The struggle, so violent in the early days of science, between the views of Ptolemy and Copernicus would then be quite meaningless. Either CS could be used with equal justification. The two sentences, 'the sun is at rest and the Earth moves', or 'the sun moves and the Earth is at rest', would simply mean two different conventions concerning two different CS. Could we build a real relativistic physics valid in all CS; a physics in which there would be no place for absolute, but only for relative, motion? This is indeed possible!"[46]

Despite giving more respectability to the geocentric view than Newtonian physics does,[47] relativity is not geocentric. Rather, relativity states that the Sun, the Earth, the Moon, Jupiter, or any other point for that matter could be chosen as a center of the solar system with equal validity.[48] For this reason Robert Sungenis, a modern geocentrist, spent much of Volume I of his book Galileo Was Wrong: The Church Was Right critiquing and trying to unravel the Special and General theories of Relativity.[49]

Relativity agrees with Newtonian predictions that regardless of whether the Sun or the Earth are chosen arbitrarily as the center of the coordinate system describing the solar system, the paths of the planets form (roughly) ellipses with respect to the Sun, not the Earth. With respect to the average reference frame of the fixed stars, the planets do indeed move around the Sun, which due to its much larger mass, moves far less than its own diameter and the gravity of which is dominant in determining the orbits of the planets. (In other words, the center of mass of the solar system is near the center of the Sun.) The Earth and Moon are much closer to being a binary planet; the center of mass around which they both rotate is still inside the Earth, but is about 4,624 km (2,873 mi) or 72.6% of the Earth's radius away from the centre of the Earth (thus closer to the surface than the center).[citation needed]

What the principle of relativity points out is that correct mathematical calculations can be made regardless of the reference frame chosen, and these will all agree with each other as to the predictions of actual motions of bodies with respect to each other. It is not necessary to choose the object in the solar system with the largest gravitational field as the center of the coordinate system in order to predict the motions of planetary bodies, though doing so may make calculations easier to perform or interpret. A geocentric coordinate system can be more convenient when dealing only with bodies mostly influenced by the gravity of the Earth (such as artificial satellites and the Moon), or when calculating what the sky will look like when viewed from Earth (as opposed to an imaginary observer looking down on the entire solar system, where a different coordinate system might be more convenient).

Religious and contemporary adherence to geocentrism[edit]

Map of the Square and Stationary Earth, by Orlando Ferguson (1893)

The Ptolemaic model of the solar system held sway into the early modern age; from the late 16th century onward it was gradually replaced as the consensus description by the heliocentric model. Geocentrism as a separate religious belief, however, never completely died out. In the United States between 1870 and 1920, for example, various members of the Lutheran Church–Missouri Synod published articles disparaging Copernican astronomy, and geocentrism was widely taught within the synod during that period.[50] However, in the 1902 Theological Quarterly, A. L. Graebner claimed that the synod had no doctrinal position on geocentrism, heliocentrism, or any scientific model, unless it were to contradict Scripture. He stated that any possible declarations of geocentrists within the synod did not set the position of the church body as a whole.[51]

Articles arguing that geocentrism was the biblical perspective appeared in some early creation science newsletters pointing to some passages in the Bible, which, when taken literally, indicate that the daily apparent motions of the Sun and the Moon are due to their actual motions around the Earth rather than due to the rotation of the Earth about its axis. For example, in Joshua 10:12, the Sun and Moon are said to stop in the sky, and in Psalms the world is described as immobile.[52] Psalms 93:1 says in part "the world is established, firm and secure".) Contemporary advocates for such religious beliefs include Robert Sungenis (president of Bellarmine Theological Forum and author of the 2006 book Galileo Was Wrong).[53] These people subscribe to the view that a plain reading of the Bible contains an accurate account of the manner in which the universe was created and requires a geocentric worldview. Modern geocentrism is pseudoscientific,[54] and most contemporary creationist organizations reject such perspectives.[n 10]

After all, Copernicanism was the first major victory of science over religion, so it's inevitable that some folks would think that everything that's wrong with the world began there.

— Steven Dutch of the University of Wisconsin–Madison[56]

Morris Berman quotes a 2006 survey that show currently some 20% of the U.S. population believe that the sun goes around the Earth (geocentricism) rather than the Earth goes around the sun (heliocentricism), while a further 9% claimed not to know.[57] Polls conducted by Gallup in the 1990s found that 16% of Germans, 18% of Americans and 19% of Britons hold that the Sun revolves around the Earth.[58] A study conducted in 2005 by Jon D. Miller of Northwestern University, an expert in the public understanding of science and technology,[59] found that about 20%, or one in five, of American adults believe that the Sun orbits the Earth.[60] According to 2011 VTSIOM poll, 32% of Russians believe that the Sun orbits the Earth.[61]

Historical positions of the Roman Catholic hierarchy[edit]

The famous Galileo affair pitted the geocentric model against the claims of Galileo. In regards to the theological basis for such an argument, two Popes addressed the question of whether the use of phenomenological language would compel one to admit an error in Scripture. Both taught that it would not. Pope Leo XIII (1878–1903) wrote:

we have to contend against those who, making an evil use of physical science, minutely scrutinize the Sacred Book in order to detect the writers in a mistake, and to take occasion to vilify its contents. ... There can never, indeed, be any real discrepancy between the theologian and the physicist, as long as each confines himself within his own lines, and both are careful, as St. Augustine warns us, "not to make rash assertions, or to assert what is not known as known". If dissension should arise between them, here is the rule also laid down by St. Augustine, for the theologian: "Whatever they can really demonstrate to be true of physical nature, we must show to be capable of reconciliation with our Scriptures; and whatever they assert in their treatises which is contrary to these Scriptures of ours, that is to Catholic faith, we must either prove it as well as we can to be entirely false, or at all events we must, without the smallest hesitation, believe it to be so." To understand how just is the rule here formulated we must remember, first, that the sacred writers, or to speak more accurately, the Holy Ghost "Who spoke by them, did not intend to teach men these things (that is to say, the essential nature of the things of the visible universe), things in no way profitable unto salvation." Hence they did not seek to penetrate the secrets of nature, but rather described and dealt with things in more or less figurative language, or in terms which were commonly used at the time, and which in many instances are in daily use at this day, even by the most eminent men of science. Ordinary speech primarily and properly describes what comes under the senses; and somewhat in the same way the sacred writers-as the Angelic Doctor also reminds us – "went by what sensibly appeared", or put down what God, speaking to men, signified, in the way men could understand and were accustomed to.

— Providentissimus Deus 18

Maurice Finocchiaro, author of a book on the Galileo affair, notes that this is "a view of the relationship between biblical interpretation and scientific investigation that corresponds to the one advanced by Galileo in the "Letter to the Grand Duchess Christina".[62] Pope Pius XII (1939–1958) repeated his predecessor's teaching:

The first and greatest care of Leo XIII was to set forth the teaching on the truth of the Sacred Books and to defend it from attack. Hence with grave words did he proclaim that there is no error whatsoever if the sacred writer, speaking of things of the physical order "went by what sensibly appeared" as the Angelic Doctor says, speaking either "in figurative language, or in terms which were commonly used at the time, and which in many instances are in daily use at this day, even among the most eminent men of science". For "the sacred writers, or to speak more accurately – the words are St. Augustine's – the Holy Spirit, Who spoke by them, did not intend to teach men these things – that is the essential nature of the things of the universe – things in no way profitable to salvation"; which principle "will apply to cognate sciences, and especially to history", that is, by refuting, "in a somewhat similar way the fallacies of the adversaries and defending the historical truth of Sacred Scripture from their attacks".

— Divino afflante Spiritu, 3

In 1664, Pope Alexander VII republished the Index Librorum Prohibitorum (List of Prohibited Books) and attached the various decrees connected with those books, including those concerned with heliocentrism. He stated in a Papal Bull that his purpose in doing so was that "the succession of things done from the beginning might be made known [quo rei ab initio gestae series innotescat]".[63]

The position of the curia evolved slowly over the centuries towards permitting the heliocentric view. In 1757, during the papacy of Benedict XIV, the Congregation of the Index withdrew the decree which prohibited all books teaching the Earth's motion, although the Dialogue and a few other books continued to be explicitly included. In 1820, the Congregation of the Holy Office, with the pope's approval, decreed that Catholic astronomer Giuseppe Settele was allowed to treat the Earth's motion as an established fact and removed any obstacle for Catholics to hold to the motion of the Earth:

The Assessor of the Holy Office has referred the request of Giuseppe Settele, Professor of Optics and Astronomy at La Sapienza University, regarding permission to publish his work Elements of Astronomy in which he espouses the common opinion of the astronomers of our time regarding the Earth’s daily and yearly motions, to His Holiness through Divine Providence, Pope Pius VII. Previously, His Holiness had referred this request to the Supreme Sacred Congregation and concurrently to the consideration of the Most Eminent and Most Reverend General Cardinal Inquisitor. His Holiness has decreed that no obstacles exist for those who sustain Copernicus' affirmation regarding the Earth's movement in the manner in which it is affirmed today, even by Catholic authors. He has, moreover, suggested the insertion of several notations into this work, aimed at demonstrating that the above mentioned affirmation [of Copernicus], as it has come to be understood, does not present any difficulties; difficulties that existed in times past, prior to the subsequent astronomical observations that have now occurred. [Pope Pius VII] has also recommended that the implementation [of these decisions] be given to the Cardinal Secretary of the Supreme Sacred Congregation and Master of the Sacred Apostolic Palace. He is now appointed the task of bringing to an end any concerns and criticisms regarding the printing of this book, and, at the same time, ensuring that in the future, regarding the publication of such works, permission is sought from the Cardinal Vicar whose signature will not be given without the authorization of the Superior of his Order.[64]

In 1822, the Congregation of the Holy Office removed the prohibition on the publication of books treating of the Earth's motion in accordance with modern astronomy and Pope Pius VII ratified the decision:

The most excellent [cardinals] have decreed that there must be no denial, by the present or by future Masters of the Sacred Apostolic Palace, of permission to print and to publish works which treat of the mobility of the Earth and of the immobility of the sun, according to the common opinion of modern astronomers, as long as there are no other contrary indications, on the basis of the decrees of the Sacred Congregation of the Index of 1757 and of this Supreme [Holy Office] of 1820; and that those who would show themselves to be reluctant or would disobey, should be forced under punishments at the choice of [this] Sacred Congregation, with derogation of [their] claimed privileges, where necessary.[65]

The 1835 edition of the Catholic Index of Prohibited Books for the first time omits the Dialogue from the list.[62] In his 1921 papal encyclical, In praeclara summorum, Pope Benedict XV stated that, "though this Earth on which we live may not be the center of the universe as at one time was thought, it was the scene of the original happiness of our first ancestors, witness of their unhappy fall, as too of the Redemption of mankind through the Passion and Death of Jesus Christ".[66] In 1965 the Second Vatican Council stated that, "Consequently, we cannot but deplore certain habits of mind, which are sometimes found too among Christians, which do not sufficiently attend to the rightful independence of science and which, from the arguments and controversies they spark, lead many minds to conclude that faith and science are mutually opposed."[67] The footnote on this statement is to Msgr. Pio Paschini's, Vita e opere di Galileo Galilei, 2 volumes, Vatican Press (1964). Pope John Paul II regretted the treatment which Galileo received, in a speech to the Pontifical Academy of Sciences in 1992. The Pope declared the incident to be based on a "tragic mutual miscomprehension". He further stated:

Cardinal Poupard has also reminded us that the sentence of 1633 was not irreformable, and that the debate which had not ceased to evolve thereafter, was closed in 1820 with the imprimatur given to the work of Canon Settele. ... The error of the theologians of the time, when they maintained the centrality of the Earth, was to think that our understanding of the physical world's structure was, in some way, imposed by the literal sense of Sacred Scripture. Let us recall the celebrated saying attributed to Baronius "Spiritui Sancto mentem fuisse nos docere quomodo ad coelum eatur, non quomodo coelum gradiatur". In fact, the Bible does not concern itself with the details of the physical world, the understanding of which is the competence of human experience and reasoning. There exist two realms of knowledge, one which has its source in Revelation and one which reason can discover by its own power. To the latter belong especially the experimental sciences and philosophy. The distinction between the two realms of knowledge ought not to be understood as opposition.[68]

Orthodox Judaism[edit]

A few Orthodox Jewish leaders maintain a geocentric model of the universe based on the aforementioned Biblical verses and an interpretation of Maimonides to the effect that he ruled that the Earth is orbited by the sun.[69][70] The Lubavitcher Rebbe also explained that geocentrism is defensible based on the theory of Relativity, which establishes that "when two bodies in space are in motion relative to one another, ... science declares with absolute certainty that from the scientific point of view both possibilities are equally valid, namely that the Earth revolves around the sun, or the sun revolves around the Earth", although he also went on to refer to people who believed in geocentrism as "remaining in the world of Copernicus".[71]

The Zohar implies: "The entire world and those upon it, spin round in a circle like a ball", both those at the bottom of the ball and those at the top. All God's creatures, wherever they live on the different parts of the ball, look different (in color, in their features) because the air is different in each place, but they stand erect as all other human beings.

Therefore, there are places in the world where, when some have light, others have darkness; when some have day, others have night.

While geocentrism is important in Maimonides' calendar calculations,[72] the great majority of Jewish religious scholars, who accept the divinity of the Bible and accept many of his rulings as legally binding, do not believe that the Bible or Maimonides command a belief in geocentrism.[70][73]

Islam[edit]

Prominent cases of modern geocentrism in Islam are very isolated. Very few individuals promoted a geocentric view of the universe. One of them was Ahmed Raza Khan Barelvi, a Sunni scholar of Indian subcontinent. He rejected the heliocentric model and wrote a book[74] that explains the movement of the sun, moon and other planets around the Earth. The Grand Mufti of Saudi Arabia from 1993 to 1999, Ibn Baz also promoted the geocentric view between 1966 and 1985.

Planetariums[edit]

The geocentric (Ptolemaic) model of the solar system is still of interest to planetarium makers, as, for technical reasons, a Ptolemaic-type motion for the planet light apparatus has some advantages over a Copernican-type motion.[75] The celestial sphere, still used for teaching purposes and sometimes for navigation, is also based on a geocentric system[76] which in effect ignores parallax. However this effect is negligible at the scale of accuracy that applies to a planetarium.

See also[edit]

Astronomy portal

Cosmology portal

Celestial spheres

Firmament

Flat Earth

Religious cosmology

Sphere of fire

Notes[edit]

Jump up ^ The Egyptian universe was substantially similar to the Babylonian universe; it was pictured as a rectangular box with a north-south orientation and with a slightly concave surface, with Egypt in the center. A good idea of the similarly primitive state of Hebrew astronomy can be gained from Biblical writings, such as the Genesis creation story and the various Psalms that extol the firmament, the stars, the sun, and the earth. The Hebrews saw the earth as an almost flat surface consisting of a solid and a liquid part, and the sky as the realm of light in which heavenly bodies move. The earth rested on cornerstones and could not be moved except by Jehovah (as in an earthquake). According to the Hebrews, the sun and the moon were only a short distance from one another[3]

Jump up ^ The picture of the universe in Talmudic texts has the Earth in the center of creation with heaven as a hemisphere spread over it. The Earth is usually described as a disk encircled by water. Interestingly, cosmological and metaphysical speculations were not to be cultivated in public nor were they to be committed to writing. Rather, they were considered as "secrets of the Torah not to be passed on to all and sundry" (Ketubot 112a). While study of God's creation was not prohibited, speculations about "what is above, what is beneath, what is before, and what is after" (Mishnah Hagigah: 2) were restricted to the intellectual elite.[4]

Jump up ^ "firmament – The division made by God, according to the P account of creation, to restrain the cosmic water and form the sky (Genesis 1:6–8). Hebrew cosmology pictured a flat earth, over which was a dome-shaped firmament, supported above the earth by mountains, and surrounded by waters. Holes or sluices (windows, Gen. 7: 11) allowed the water to fall as rain. The firmament was the heavens in which God set the sun (Psalms 19:4) and the stars (Genesis 1:4) on the fourth day of the creation. There was more water under the earth (Genesis 1:7) and during the Flood the two great oceans joined up and covered the earth; sheol was at the bottom of the earth (Isa. 14: 9; Num. 16: 30)."[6]

Jump up ^ The cosmographical structure assumed by this text is the ancient, traditional flat earth model that was common throughout the Near East and that persisted in Jewish tradition because of its place in the religiously authoritative biblical materials.[7]

Jump up ^ “The term "firmament" (רקיע- rāqîa') denotes the atmosphere between the heavenly realm and the earth (Gen. 1:6–7, 20) where the celestial bodies move (Gen. 1:14–17). It can also be used as a synonym for "heaven" (Gen. 1:8; Ps. 19:2). This "firmament is part of the heavenly structure whether it is the equivalent of 'heaven/sky' or is what separates it from the earth. ... The ancient Israelites also used more descriptive terms for how God created the celestial realm, and based on the collection of these more specific and illustrative terms, I would propose that they had two basic ideas of the composition of the heavenly realm. First is the idea that the heavenly realm was imagined as a vast cosmic canopy. The verb used to describe metaphorically how God stretched out this canopy over earth is הטנ (nātāh) 'stretch out', or 'spread'. 'I made the earth, and created humankind upon it; it was my hands that stretched out the heavens, and I commanded all their host (Isa. 45:12).' In the Bible this verb is used to describe the stretching out (pitching) of a tent. Since the texts that mention the stretching out of the sky are typically drawing on creation imagery, it seems that the figure intends to suggest that the heavens are Yahweh's cosmic tent. One can imagine ancient Israelites gazing up to the stars and comparing the canopy of the sky to the roofs of the tents under which they lived. In fact, if one were to look up at the ceiling of a dark tent with small holes in the roof during the daytime, the roof, with the sunlight shining through the holes, would look very much like the night sky with all its stars. The second image of the material composition of the heavenly realm involves a firm substance. The term רקיע (răqîa'), typically translated 'firmament', indicates the expanse above the earth. The root רקע means 'stamp out' or 'forge'. The idea of a solid, forged surface fits well with Ezekiel 1 where God's throne rests upon the רקיע (răqîa'). According to Genesis 1, the רקיע(rāqîa') is the sphere of the celestial bodies (Gen. 1:6–8, 14–17; cf. ben Sira 43:8). It may be that some imagined the עיקר to be a firm substance on which the celestial bodies rode during their daily journeys across the sky."[8]

Jump up ^ In the course of the Second Temple Period Jews, and eventually Christians, began to describe the universe in new terms. The model of the universe inherited form the Hebrew Bible and the Ancient Near East of a flat earth completely surrounded by water with a heavenly realm of the gods arching above from horizon to horizon became obsolete. In the past the heavenly realm was for gods only. It was the place where all events on earth were determined by the gods, and their decisions were irrevocable. The gulf between the gods and humans could not have been greater. The evolution of Jewish cosmography in the course of the Second Temple Period followed developments in Hellenistic astronomy.[9]

Jump up ^ What is described in Genesis 1:1 to 2:3 was the commonly accepted structure of the universe from at least late in the second millennium BCE to the fourth or third century BCE. It represents a coherent model for the experiences of the people of Mesopotamia through that period. It reflects a world-view that made sense of water coming from the sky and the ground as well as the regular apparent movements of the stars, sun, moon, and planets. There is a clear understanding of the restrictions on breeding between different species of animals and of the way in which human beings had gained control over what were, by then, domestic animals. There is also recognition of the ability of humans to change the environment in which they lived. This same understanding occurred also in the great creation stories of Mesopotamia; these stories formed the basis for the Jewish theological reflections of the Hebrew Scriptures concerning the creation of the world. The Jewish priests and theologians who constructed the narrative took accepted ideas about the structure of the world and reflected theologically on them in the light of their experience and faith. There was never any clash between Jewish and Babylonian people about the structure of the world, but only about who was responsible for it and its ultimate theological meaning. The envisaged structure is simple: Earth was seen as being situated in the middle of a great volume of water, with water both above and below Earth. A great dome was thought to be set above Earth (like an inverted glass bowl), maintaining the water above Earth in its place. Earth was pictured as resting on foundations that go down into the deep. These foundations secured the stability of the land as something that is not floating on the water and so could not be tossed about by wind and wave. The waters surrounding Earth were thought to have been gathered together in their place. The stars, sun, moon, and planets moved in their allotted paths across the great dome above Earth, with their movements defining the months, seasons, and year.[10]

Jump up ^ From Myth to Cosmos: The earliest speculations about the origin and nature of the world took the form of religious myths. Almost all ancient cultures developed cosmological stories to explain the basic features of the cosmos: Earth and its inhabitants, sky, sea, sun, moon, and stars. For example, for the Babylonians, the creation of the universe was seen as born from a primeval pair of human-like gods. In early Egyptian cosmology, eclipses were explained as the moon being swallowed temporarily by a sow or as the sun being attacked by a serpent. For the early Hebrews, whose account is preserved in the biblical book of Genesis, a single God created the universe in stages within the relatively recent past. Such pre-scientific cosmologies tended to assume a flat Earth, a finite past, ongoing active interference by deities or spirits in the cosmic order, and stars and planets (visible to the naked eye only as points of light) that were different in nature from Earth.[11]

Jump up ^ This argument is given in Book I, Chapter 5, of the Almagest.[14]

Jump up ^ Donald B. DeYoung, for example, states that "Similar terminology is often used today when we speak of the sun's rising and setting, even though the earth, not the sun, is doing the moving. Bible writers used the 'language of appearance,' just as people always have. Without it, the intended message would be awkward at best and probably not understood clearly. When the Bible touches on scientific subjects, it is entirely accurate."[55]

References[edit]

Jump up ^ Lawson, Russell M. (2004). Science in the Ancient World: An Encyclopedia. ABC-CLIO. pp. 29–30. ISBN 1851095349. 

Jump up ^ Kuhn 1957, pp. 5–20.

Jump up ^ Abetti, Giorgio (2012). "Cosmology". Encyclopedia Americana (Online ed.). Grolier. 

Jump up ^ Tirosh-Samuelson, Hava (2003). "Topic Overview: Judaism". In van Huyssteen, J. Wentzel Vrede. Encyclopedia of Science and Religion. 2. New York: Macmillan Reference USA. pp. 477–83. 

Jump up ^ Gandz, Solomon (1953). "The distribution of land and sea on the Earth's surface according to Hebrew sources". Proceedings of the American Academy for Jewish Research. 22: 23–53. Like the Midrash and the Talmud, the Targum does not think of a globe of the spherical earth, around which the sun revolves in 24 hours, but of a flat disk of the earth, above which the sun completes its semicircle in an average of 12 hours. 

Jump up ^ Browning, W. R. F. (1997). "firmament". Dictionary of the Bible (Oxford Reference Online ed.). Oxford University Press. 

Jump up ^ Wright, J. Edward (2000). The Early History Of Heaven. Oxford University Press. p. 155. 

Jump up ^ Wright 2000, pp. 55–6

Jump up ^ Wright 2000, p. 201

Jump up ^ Selley, Richard C.; Cocks, L. Robin M.; Plimer, Ian R., eds. (2005). "Biblical Geology". Encyclopedia of Geology. 1. Amsterdam: Elsevier. p. 253 – via Gale Virtual Reference Library. 

Jump up ^ Applebaum, Wilbur (2009). "Astronomy and Cosmology: Cosmology". In Lerner, K. Lee; Lerner, Brenda Wilmoth. Scientific Thought: In Context. 1. Detroit: Gale. pp. 20–31 – via Gale Virtual Reference Library. 

Jump up ^ Fraser, Craig G. (2006). The Cosmos: A Historical Perspective. p. 14. 

Jump up ^ Hetherington, Norriss S. (2006). Planetary Motions: A Historical Perspective. p. 28. 

Jump up ^ Crowe 1990, pp. 60–2

Jump up ^ Goldstein, Bernard R. (1967). "The Arabic version of Ptolemy's planetary hypothesis". Transactions of the American Philosophical Society. 57 (pt. 4): 6. JSTOR 1006040. 

Jump up ^ A. I. Sabra, "Configuring the Universe: Aporetic, Problem Solving, and Kinematic Modeling as Themes of Arabic Astronomy," Perspectives on Science 6.3 (1998): 288–330, at pp. 317–18:

All Islamic astronomers from Thabit ibn Qurra in the ninth century to Ibn al-Shatir in the fourteenth, and all natural philosophers from al-Kindi to Averroes and later, are known to have accepted ... the Greek picture of the world as consisting of two spheres of which one, the celestial sphere ... concentrically envelops the other.

Jump up ^ Hoskin, Michael (1999-03-18). The Cambridge Concise History of Astronomy. Cambridge University Press. p. 60. ISBN 9780521576000. 

^ Jump up to: a b Ragep, F. Jamil (2001). "Tusi and Copernicus: The Earth's motion in context". Science in Context. Cambridge University Press. 14 (1-2): 145–163. doi:10.1017/s0269889701000060. 

^ Jump up to: a b Ragep, F. Jamil (2001). "Freeing astronomy from philosophy: An aspect of Islamic influence on science". Osiris. 2nd Series. 16 (Science in Theistic Contexts: Cognitive Dimensions): 49–64, 66–71. doi:10.1086/649338. 

^ Jump up to: a b Setia, Adi (2004). "Fakhr Al-Din Al-Razi on physics and the nature of the physical world: A preliminary survey". Islam & Science. 2. 

Jump up ^ Alessandro Bausani (1973). "Cosmology and Religion in Islam". Scientia/Rivista di Scienza. 108 (67): 762. 

^ Jump up to: a b c Young, M. J. L., ed. (2006-11-02). Religion, Learning and Science in the 'Abbasid Period. Cambridge University Press. p. 413. ISBN 9780521028875. 

Jump up ^ Nasr, Seyyed Hossein (1993-01-01). An Introduction to Islamic Cosmological Doctrines. SUNY Press. p. 135. ISBN 9781438414195. 

Jump up ^ Qadir (1989), p. 5–10.

Jump up ^ Nicolaus Copernicus, Stanford Encyclopedia of Philosophy (2004).

Jump up ^ Rufus, W. C. (May 1939). "The influence of Islamic astronomy in Europe and the far east". Popular Astronomy. Vol. 47 no. 5. pp. 233–8. Bibcode:1939PA.....47..233R. 

Jump up ^ Hartner, Willy (1955). "The Mercury horoscope of Marcantonio Michiel of Venice". Vistas in Astronomy. 1: 118–22. Bibcode:1955VA......1...84H. doi:10.1016/0083-6656(55)90016-7. 

Jump up ^ Goldstein, Bernard R. (1972). "Theory and observation in medieval astronomy". Isis. 63 (1): 41. doi:10.1086/350839. 

Jump up ^ "Ptolemaic Astronomy, Islamic Planetary Theory, and Copernicus's Debt to the Maragha School". Science and Its Times. Thomson Gale. 2006. 

Jump up ^ Samsó, Julio (1970–80). "Al-Bitruji Al-Ishbili, Abu Ishaq". Dictionary of Scientific Biography. New York: Charles Scribner's Sons. ISBN 0-684-10114-9. 

Jump up ^ Saliba, George (1994). A History of Arabic Astronomy: Planetary Theories During the Golden Age of Islam. New York University Press. pp. 233–234, 240. ISBN 0814780237. 

Jump up ^ Dallal, Ahmad (1999). "Science, Medicine and Technology". In Esposito, John. The Oxford History of Islam. New York: Oxford University Press. p. 171. 

Jump up ^ Guessoum, N. (June 2008). "Copernicus and Ibn Al-Shatir: Does the Copernican revolution have Islamic roots?". The Observatory. 128: 231–9. Bibcode:2008Obs...128..231G. 

^ Jump up to: a b Huff, Toby E. (2003). The Rise of Early Modern Science: Islam, China and the West. Cambridge University Press. p. 58. ISBN 9780521529945. 

Jump up ^ Kirmani, M. Zaki; Singh, Nagendra Kr (2005). Encyclopaedia of Islamic Science and Scientists: A-H. Global Vision. ISBN 9788182200586. 

Jump up ^ Johansen, K. F.; Rosenmeier, H. (1998). A History of Ancient Philosophy: From the Beginnings to Augustine. p. 43. 

Jump up ^ Sarton, George (1953). Ancient Science Through the Golden Age of Greece. p. 290. 

Jump up ^ Eastwood, B. S. (1992-11-01). "Heraclides and heliocentrism – Texts diagrams and interpretations". Journal for the History of Astronomy. 23: 233. Bibcode:1992JHA....23..233E. 

Jump up ^ Lindberg, David C. (2010). The Beginnings of Western Science: The European Scientific Tradition in Philosophical, Religious, and Institutional Context, Prehistory to A.D. 1450 (2nd ed.). University of Chicago Press. p. 197. ISBN 9780226482040. 

Jump up ^ Lawson 2004, p. 19

Jump up ^ Russell, Bertrand (2013) [1945]. A History of Western Philosophy. Routledge. p. 215. ISBN 9781134343676. 

Jump up ^ Finocchiaro, Maurice A. (2008). The Essential Galileo. Indianapolis, IL: Hackett. p. 49. 

Jump up ^ "Galileo and the Telescope". Commonwealth Scientific and Industrial Research Organisation. Retrieved 17 October 2014. 

Jump up ^ Lattis, James L. (1995). Between Copernicus and Galileo: Christoph Clavius and the Collapse of Ptolemaic Cosmology, University of Chicago Press, pgs 186-190

Jump up ^ Densmore, Dana, ed. (2004). Selections from Newton's Principia. Green Lion Press. p. 12. 

Jump up ^ Einstein, Albert (1938). The Evolution of Physics (1966 ed.). New York: Simon & Schuster. p. 212. ISBN 0-671-20156-5. 

Jump up ^ Hoyle, Fred (1973). Nicolaus Copernicus: An Essay On His Life and Work. New York: Harper and Row. p. 87. ISBN 0-06-011971-3. 

Jump up ^ Hoyle, Fred (1973). Nicolaus Copernicus: An Essay On His Life and Work. London: Heineman Educational Books Ltd. p. 1. ISBN 0-435-54425-X. 

Jump up ^ Sungenis, Robert (2007). Galileo Was Wrong: The Church Was Right. Vol I. State Line, PA: Catholic Apologetics International Publishing. p. 50. ISBN 978-0-9779640-5-5. 

Jump up ^ Babinski, E. T., ed. (1995). "Excerpts from Frank Zindler's 'Report from the center of the universe' and 'Turtles all the way down'". TalkOrigins Archive. Retrieved 2013-12-01. 

Jump up ^ Graebner, A. L. (1902). "Science and the church". Theological Quarterly. St. Louis, MO: Lutheran Synod of Missouri, Ohio and other states, Concordia Publishing. 6: 37–45. 

Jump up ^ Numbers, Ronald L. (1993). The Creationists: The Evolution of Scientific Creationism. University of California Press. p. 237. ISBN 0520083938. 

Jump up ^ Sefton, Dru (2006-03-30). "In this world view, the sun revolves around the earth". Times-News. Hendersonville, NC. p. 5A. 

Jump up ^ Modern Geocentrism: A Case Study of Pseudoscience in Astronomy

Jump up ^ DeYoung, Donald B. (1997-11-05). "Astronomy and the Bible: Selected questions and answers excerpted from the book". Answers in Genesis. Retrieved 2013-12-01. 

Jump up ^ Geocentrism lives

Jump up ^ Berman, Morris (2006). Dark Ages America: The Final Phase of Empire. W.W. Norton & Company. ISBN 9780393058666. 

Jump up ^ Crabtree, Steve (1999-07-06). "New Poll Gauges Americans' General Knowledge Levels". Gallup. 

Jump up ^ "Jon D. Miller". Northwestern University website. Retrieved 2007-07-19. 

Jump up ^ Dean, Cornelia (2005-08-30). "Scientific savvy? In U.S., not much". New York Times. Retrieved 2007-07-19. 

Jump up ^ 'СОЛНЦЕ – СПУТНИК ЗЕМЛИ', ИЛИ РЕЙТИНГ НАУЧНЫХ ЗАБЛУЖДЕНИЙ РОССИЯН ['Sun-earth', or rating scientific fallacies of Russians] (in Russian) (Пресс-выпуск №1684 [Press release no. 1684]), ВЦИОМ [All-Russian Center for the Study of Public Opinion], 2011-02-08. 

^ Jump up to: a b Finocchiaro, Maurice A. (1989). The Galileo Affair: A Documentary History. Berkeley: University of California Press. p. 307. ISBN 9780520066625. 

Jump up ^ Index librorum prohibitorum Alexandri VII (in Latin). Rome: Ex typographia Reurendae Camerae Apostolicae. 1664. p. v. 

Jump up ^ "Interdisciplinary Encyclopedia of Religion and Science". 

Jump up ^ Fantoli, Annibale (1996). Galileo: For Copernicanism and For the Church. University of Notre Dame. p. 475. ISBN 0268010323. 

Jump up ^ "In Praeclara Summorum: Encyclical of Pope Benedict XV on Dante to Professors and Students of Literature and Learning in the Catholic World". Rome. 1921-04-30. § 4. Archived from the original on 2014-11-09. 

Jump up ^ "Pastoral Constitution on the Church in the Modern World 'Gaudium Et Spes' Promulgated by His Holiness, Pope Paul IV on December 7, 1965". § 36. Archived from the original on April 11, 2011. 

Jump up ^ Pope John Paul II (1992-11-04). "Faith can never conflict with reason". L'Osservatore Romano. 44 (1264).  (Published English translation).

Jump up ^ Nussbaum, Alexander (2007-12-19). "Orthodox Jews & science: An empirical study of their attitudes toward evolution, the fossil record, and modern geology". Skeptic Magazine. Retrieved 2008-12-18. 

^ Jump up to: a b Nussbaum, Alexander (January–April 2002). "Creationism and geocentrism among Orthodox Jewish scientists". Reports of the National Center for Science Education: 38–43. 

Jump up ^ Schneersohn, Menachem Mendel; Gotfryd, Arnie (2003). Mind over Matter: The Lubavitcher Rebbe on Science, Technology and Medicine. Shamir. pp. 76ff.; cf. xvi-xvii, 69, 100–1, 171–2, 408ff. ISBN 9789652930804. 

Jump up ^ "Sefer Zemanim: Kiddush HaChodesh: Chapter 11". Mishneh Torah. Translated by Touger, Eliyahu. Chabad-Lubavitch Media Center. Halacha 13–14. 

Jump up ^ Rabinowitz, Avi (1987). "EgoCentrism and GeoCentrism; Human Significance and Existential Despair; Bible and Science; Fundamentalism and Skepticalism". Science & Religion. Retrieved 2013-12-01.  Published in Branover, Herman; Attia, Ilana Coven, eds. (1994). Science in the Light of Torah: A B'Or Ha'Torah Reader. Jason Aronson. ISBN 9781568210346. 

Jump up ^ "Fauz e Mubeen Dar Radd e Harkat e Zamin". 

Jump up ^ Hort, William Jillard (1822). A General View of the Sciences and Arts. p. 182. 

Jump up ^ Kaler, James B. (2002). The Ever-changing Sky: A Guide to the Celestial Sphere. p. 25. 

Bibliography[edit]

Crowe, Michael J. (1990). Theories of the World from Antiquity to the Copernican Revolution. Mineola, NY: Dover Publications. ISBN 0486261735. 

Dreyer, J.L.E. (1953). A History of Astronomy from Thales to Kepler. New York: Dover Publications. 

Evans, James (1998). The History and Practice of Ancient Astronomy. New York: Oxford University Press. 

Grant, Edward (1984-01-01). "In Defense of the Earth's Centrality and Immobility: Scholastic Reaction to Copernicanism in the Seventeenth Century". Transactions of the American Philosophical Society. New Series. 74 (4): 1–69. doi:10.2307/1006444. ISSN 0065-9746. JSTOR 1006444. 

Heath, Thomas (1913). Aristarchus of Samos. Oxford: Clarendon Press. 

Hoyle, Fred (1973). Nicolaus Copernicus. 

Koestler, Arthur (1986) [1959]. The Sleepwalkers: A History of Man's Changing Vision of the Universe. Penguin Books. ISBN 014055212X.  1990 reprint: ISBN 0140192468.

Kuhn, Thomas S. (1957). The Copernican Revolution. Cambridge: Harvard University Press. ISBN 0674171039. 

Linton, Christopher M. (2004). From Eudoxus to Einstein—A History of Mathematical Astronomy. Cambridge: Cambridge University Press. ISBN 9780521827508. 

Walker, Christopher, ed. (1996). Astronomy Before the Telescope. London: British Museum Press. ISBN 0714117463. 

External links[edit]

Another demonstration of the complexity of observed orbits when assuming a geocentric model of the solar system

Geocentric Perspective animation of the Solar System in 150AD

Ptolemy’s system of astronomy

The Galileo Project – Ptolemaic System

| [hide] v t e Ancient Greek astronomy |

| Astronomers | Aglaonice Agrippa Anaximander Andronicus Apollonius Aratus Aristarchus Aristyllus Attalus Autolycus Bion Callippus Cleomedes Cleostratus Conon Eratosthenes Euctemon Eudoxus Geminus Heraclides Hicetas Hipparchus Hippocrates of Chios Hypsicles Menelaus Meton Oenopides Philip of Opus Philolaus Posidonius Ptolemy Pytheas Seleucus Sosigenes of Alexandria Sosigenes the Peripatetic Strabo Thales Theodosius Theon of Alexandria Theon of Smyrna Timocharis |

| Works | Almagest (Ptolemy) On Sizes and Distances (Hipparchus) On the Sizes and Distances (Aristarchus) On the Heavens (Aristotle) |

| Instruments | Antikythera mechanism Armillary sphere Astrolabe Dioptra Equatorial ring Gnomon Mural instrument Triquetrum |

| Concepts | Callippic cycle Celestial spheres Circle of latitude Counter-Earth Deferent and epicycle Equant Geocentrism Heliocentrism Hipparchic cycle Metonic cycle Octaeteris Solstice Spherical Earth Sublunary sphere Zodiac |

| Influences | Babylonian astronomy Egyptian astronomy |

| Influenced | Medieval European science Indian astronomy Medieval Islamic astronomy |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Geocentric_model&oldid=836095452"

Categories:

Ancient Greek astronomy

Celestial coordinate system

Obsolete scientific theories

Scientific modeling

Early scientific cosmologies

Copernican Revolution

Hidden categories:

CS1 uses Russian-language script (ru)

CS1 Russian-language sources (ru)

CS1 Latin-language sources (la)

CS1: Julian–Gregorian uncertainty

Articles needing more viewpoints from June 2015

All articles with unsourced statements

Articles with unsourced statements from July 2017

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikimedia Commons

			Languages

Afrikaans

العربية

Asturianu

Azərbaycanca

বাংলা

Башҡортса

Беларуская

Български

བོད་ཡིག

Català

Čeština

Dansk

Deutsch

Eesti

Ελληνικά

Español

Esperanto

Euskara

فارسی

Français

Frysk

Gaeilge

Galego

한국어

Հայերեն

हिन्दी

Hrvatski

Bahasa Indonesia

Íslenska

Italiano

עברית

ქართული

Қазақша

Кыргызча

Latviešu

Lëtzebuergesch

Lietuvių

Magyar

മലയാളം

मराठी

Nederlands

Nedersaksies

日本語

Norsk

Norsk nynorsk

Occitan

Polski

Português

Română

Русский

Scots

Simple English

Slovenčina

Српски / srpski

Srpskohrvatski / српскохрватски

Suomi

Svenska

Tagalog

ไทย

Türkçe

Українська

اردو

Tiếng Việt

粵語

中文
				56 more

Edit links

 This page was last edited on 12 April 2018, at 17:16.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews