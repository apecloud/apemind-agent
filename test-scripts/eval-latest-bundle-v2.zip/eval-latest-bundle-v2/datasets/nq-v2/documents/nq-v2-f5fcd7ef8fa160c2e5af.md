# Stay (Shakespears Sister song)

Stay (Shakespears Sister song) - Wikipedia

Stay (Shakespears Sister song)

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| "Stay" |

| Single by Shakespears Sister |

| from the album Hormonally Yours |

| B-side | "The Trouble with Andre" |

| Released | 13 January 1992 (1992-01-13) |

| Format | CD single, 7" single, cassette |

| Recorded | 1991 |

| Genre | Pop, alternative,[1] gothic rock |

| Length | 3:50 (album version) 3:45 (7" edit) |

| Label | London |

| Songwriter(s) | Siobhan Fahey, Marcella Detroit and David A. Stewart |

| Producer(s) | Shakespears Sister, Alan Moulder, Chris Thomas |

| Shakespears Sister singles chronology |

| "Goodbye Cruel World" (1991) | "Stay" (1992) | "I Don't Care" (1992) |

| "Goodbye Cruel World" (1991) | "Stay" (1992) | "I Don't Care" (1992) |

"Stay" is a song by UK-based pop act Shakespears Sister, released by London Records in January 1992 as the second single from their album Hormonally Yours. Upon release, the single became a global smash hit becoming the duo's first and only No. 1 single in numerous territories, including the UK, where it topped the UK Singles Chart for eight consecutive weeks;[2] the longest UK No. 1 reign for any all-female band, and was the fourth biggest selling single of 1992. The single also held the No. 1 position in band member Siobhan Fahey's birthplace, Ireland, for six weeks, and it was a transatlantic hit reaching No. 4 on the Billboard Hot 100 in the US.[3]

At the 1993 Brit Awards "Stay" won the award for British Video of the Year.[4] In November 2010, The X Factor contestant Cher Lloyd performed the song on series 7 of the show. Following this, the original version re-entered the UK, Ireland and the European Hot 100 Singles charts. The song originally sold 490,000 copies in the UK by the end of 1992 which was a year that saw low single sales, as of February 2012 it has sold over 600,000 copies[5] (the threshold for a Platinum certification in the UK). As well as being used on The X Factor, the song has also been featured on Britain's Got Talent, Dancing on Ice, Strictly Come Dancing, The Voice UK, The Voice of Ireland and The X Factor New Zealand.

"Stay" was the only Shakespears Sister song that featured Siobhan Fahey less prominently on vocals than Marcella Detroit, with Detroit singing the verses and lead chorus and Fahey singing the song's dramatic bridge. Detroit is noted for singing in whistle register before the last chorus of the song, going up to a high F (F6). The piano, synth and bass guitar were performed by Ian Maidman, and the drums by Steve Ferrera, both musicians whose contributions featured throughout the 'Hormonally Yours' album.

Contents
 [hide] 

1 Critical reception

2 Music video

2.1 Background and development

2.2 Synopsis

3 Track listing

4 Charts and certifications

4.1 Weekly charts

4.2 Year-end charts

4.3 Certifications

5 Covers

6 In popular culture

7 References

8 External links

Critical reception[edit]

Billboard wrote about the song: "British female duo scored a No. 1 pop smash throughout Europe and the U.K. with this complex modern-pop tune. Vocal tradeoff between Marcella Detroit and former member of Bananarama Siobhan Fahey is both intense and dramatic."[6]

Music video[edit]
Background and development[edit]

Sophie Muller directed the promo video for the single, the concept of which was inspired by the film Cat Women of the Moon.[7] The video featured Detroit and Fahey fighting over a comatose man (played by Dave Evans, former boyfriend of Fahey's Bananarama bandmate Keren Woodward).[8]

The video won Best Video at the 1993 Music Week Awards and Brit Awards, and was the subject of a spoof by comedians French & Saunders. The epic promo was featured in the Top 100 Music Videos of all time by Channel 4.[9]

Synopsis[edit]

In some rare versions the beginning quotes a variation of the opening of William Shakespeare's Macbeth: The original quote of the play ("When shall we three meet again") is changed to "When shall we two meet again", referring to the story told in the video.[10] The video starts with a view of a calm night sky. A shooting star passes over a full moon and the song begins. The camera pans back into a hospital room. Detroit is seen tending to her lover, played by Evans, who is in a coma and on the verge of death, while singing to him not to leave her. At the bridge of the song, a portal opens and the angel of death, played by Fahey, appears at the top of a staircase, wearing a sparkling catsuit. She dances around in front of a bright light whilst mocking Detroit with a verse that she cannot save her lover and the best she can hope for is to return safely to her own world. Detroit tries her best to wake the man up, while Death slowly makes her way down the stairs to claim his soul. The two women begin fighting over the man, making it literally and figuratively a fight between life (Detroit) and death (Fahey). During their struggle, the man finally wakes up, he and Detroit embrace while Death, having failed to seduce him into her realm, walks away in disgust and goes back up the staircase to the light, presumably being the stairway to Heaven.[11]

Track listing[edit]

| UK CD single[12] "Stay" – 3:48 "Stay" (LP version) – 3:50 "The Trouble with Andre" – 4:44 "Excerpts from Hormonally Yours" – 6:02 US CD single "Stay" – 3:48 "Remember My Name" – 3:36 "Excerpts from Hormonally Yours" – 2:33 | 7" single / UK cassette single "Stay" – 3:48 "The Trouble with Andre" – 4:44 US cassette single "Stay" – 3:48 "Excerpts from Hormonally Yours" – 2:34 "The Trouble with Andre" – 4:44 |

Charts and certifications[edit]

| Chart (1992) | Peak position |

| Australia (ARIA)[13] | 3 |

| Austria (Ö3 Austria Top 40)[14] | 4 |

| Belgium (Ultratop 50 Flanders)[15] | 9 |

| Canada Top Singles (RPM)[16] | 4 |

| France (SNEP)[17] | 40 |

| Germany (Media Control AG)[18] | 3 |

| Ireland (IRMA)[19] | 1 |

| Netherlands (Dutch Top 40)[20] | 28 |

| New Zealand (RIANZ)[21] | 5 |

| Norway (VG-lista)[22] | 6 |

| Sweden (Sverigetopplistan)[23] | 1 |

| Switzerland (Schweizer Hitparade)[24] | 2 |

| UK Singles (Official Charts Company)[3] | 1 |

| US Billboard Hot 100[25] | 4 |

| US Modern Rock Tracks (Billboard)[25] | 25 |

| US Rhythmic Top 40 (Billboard)[25] | 28 |

| US Top 40 Mainstream (Billboard)[25] | 18 |

| Chart (2010) | Peak position |

| European Hot 100 Singles[26] | 38 |

| Ireland (IRMA)[27] | 10 |

| Scotland (Official Charts Company)[28] | 11 |

| UK Singles (Official Charts Company)[29] | 12 |

| Chart (1992) | Position |

| Australia (ARIA)[30] | 21 |

| New Zealand (Recorded Music NZ)[31] | 42 |

| UK Singles Chart[citation needed] | 4 |

| US Billboard Hot 100[32] | 45 |

Certifications[edit]

| Region | Certification | Certified units/Sales |

| Australia (ARIA)[30] | Gold | 35,000^ |

| United Kingdom (BPI)[33] | Gold | 400,000[34] |

| United States (RIAA)[35] | Gold | 500,000[36] |

| ^shipments figures based on certification alone |

Covers[edit]

Cher Lloyd performed the song on the Halloween episode of The X Factor series 7 in 2010. The Shakespears Sister original re-entered the UK Singles Chart at No.12 and the Irish Singles Chart at No.10.

Il Divo recorded a version of the song for their 2011 album, Wicked Game.

Delta Goodrem recorded a version of the song as a B-side for her 2014 single cover version of "Love... Thy Will Be Done".

Blutengel recorded a version on their 2004 album Demon Kiss, and 2015 album Omen.

Sweetbox recorded a version on their 2002 album Jade.

Cradle of Filth recorded a version on their 2006 album Thornography.

Ane Brun recorded a version on her 2017 album Leave Me Breathless.

In popular culture[edit]

Featured in the 2000s paranormal television series Ghost Whisperer, season 4, episode 13 ("Body of Water").

References[edit]

Jump up ^ "The Quietus - Reviews - Shakespears Sister". 

Jump up ^ Roberts, David (2006). British Hit Singles & Albums (19th ed.). London: Guinness World Records Limited. pp. 537–9. ISBN 1-904994-10-5. 

^ Jump up to: a b "Charstats - Shakespear's Sister". chartstats.com. Archived from the original on 10 January 2013. Retrieved 2012-12-03. 

Jump up ^ "1993". Brits.co.uk. 1993-02-16. Retrieved 2014-03-30. 

Jump up ^ "Shakespears Sister's Stay turns 20". 

Jump up ^ "Billboard: Single Reviews" (PDF). Billboard. Retrieved 24 January 2018. 

Jump up ^ "Marcy & Siobhan about STAY". YouTube. 2008-06-07. Retrieved 2014-03-30. 

Jump up ^ [1] Archived 11 March 2007 at the Wayback Machine.

Jump up ^ "Explore". Channel 4. Retrieved 2014-03-30. 

Jump up ^ "Shakespears Sister 'Stay'". YouTube. 2006-11-30. Retrieved 2014-05-09. 

Jump up ^ "Shakespears Sister 'Stay'". YouTube. 2009-11-11. Retrieved 2014-03-30. 

Jump up ^ "Siobhan Fahey - Bad Blood - Discogs". Discogs.com. Retrieved 2012-12-01. 

Jump up ^ "Australian Charts > Shakespears Sister - Stay". australian-charts.com. Retrieved 2012-12-03. 

Jump up ^ "Austrian Charts > Shakespears Sister - Stay". austrian-charts.at. Retrieved 2012-12-03. 

Jump up ^ "Ultratop.be – Shakespears Sister – Stay" (in Dutch). Ultratop 50.

Jump up ^ Canadian Top Singles

Jump up ^ "French Charts > Shakespears Sister - Stay". lescharts.com. Retrieved 2012-12-03. 

Jump up ^ "GER Charts > Shakespears Sister". charts.de. Retrieved 2012-12-07. 

Jump up ^ "Rish Charts > Shakespears Sister". irishcharts.de. Retrieved 2012-12-03. 

Jump up ^ "Dutch Charts > Shakespears Sister - Stay". dutchcharts.nl. Retrieved 2012-12-03. 

Jump up ^ "New Zealand Charts > Shakespears Sister - Stay". charts.org.nz. Retrieved 2012-12-03. 

Jump up ^ "Norwegian Charts > Shakespears Sister - Stay". norwegiancharts.com. Retrieved 2012-12-03. 

Jump up ^ "Swedish Charts > Shakespears Sister - Stay". swedishcharts.com. Retrieved 2012-12-03. 

Jump up ^ "Swiss Charts > Shakespears Sister - Stay". hitparade.ch. Retrieved 2012-12-03. 

^ Jump up to: a b c d "Shakespear's Siter - Allmusic discography". allmusic. Retrieved 2012-12-03. 

Jump up ^ "European Hot 100". billboard. Retrieved 2012-12-03. 

Jump up ^ "Chart Track: Week 43, 2010". Irish Singles Chart.

Jump up ^ "Official Scottish Singles Sales Chart Top 100". Official Charts Company.

Jump up ^ "Official Singles Chart Top 100". Official Charts Company.

^ Jump up to: a b Ryan, Gavin (2011). Australia's Music Charts 1988-2010. Mt. Martha, VIC, Australia: Moonlight Publishing. 

Jump up ^ "End of Year Charts 1992". Recorded Music NZ. Retrieved 3 December 2017. 

Jump up ^ "Billboard Top 100 - 1992". Archived from the original on 17 January 2010. Retrieved 2010-07-30. 

Jump up ^ "British single certifications – Shakespears Sister – Stay". British Phonographic Industry.  Enter Stay in the search field and then press Enter.

Jump up ^ "BPI Awards Search". Archived from the original on 11 May 2011. Retrieved 2012-12-03. 

Jump up ^ "American single certifications – Shakespears Sister – Stay". Recording Industry Association of America.  If necessary, click Advanced, then click Format, then select Single, then click SEARCH

Jump up ^ "SEARCHRIAA – Gold & Platinum: Shakespears Sister". Recording Industry Association of America. Archived from the original on 26 June 2007. Retrieved 2012-12-03. 

External links[edit]

Lyrics of this song at MetroLyrics

| Preceded by "Goodnight Girl" by Wet Wet Wet | UK number one single 22 February 1992 (eight weeks) | Succeeded by "Deeply Dippy" by Right Said Fred |

| [hide] v t e Shakespears Sister |

| Siobhan Fahey Marcella Detroit |

| Studio albums | Sacred Heart Hormonally Yours #3 Songs from the Red Room Cosmic Dancer |

| Compilation albums | The Best of Shakespear's Sister Long Live the Queens! Rarities Remixes |

| Live albums | Live 1992 |

| Extended plays | The Red Room Sessions The Other Side... Demos and Rarities The Other Side... Demos and Rarities Part II The Other Side... Demos and Rarities Part III The Working Demos |

| Singles | "Break My Heart (You Really)" / "Heroine" "You're History" "Run Silent" "Dirty Mind" "Goodbye Cruel World" "Stay" "I Don't Care" "Hello (Turn Your Radio On)" "My 16th Apology" "I Can Drive" "Bitter Pill" "Pulsatron" "Bad Blood "It's a Trip" |

| Video albums | Sacred Heart Hormonally Yours S.F.T.R.R: Videos |

| Related articles | Discography |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Stay_(Shakespears_Sister_song)&oldid=835765476"

Categories:

1992 singles

Irish Singles Chart number-one singles

Number-one singles in Sweden

UK Singles Chart number-one singles

Music videos directed by Sophie Muller

Shakespears Sister songs

Song recordings produced by Alan Moulder

Songs written by Siobhan Fahey

Songs written by Marcella Detroit

Songs written by David A. Stewart

1992 songs

London Records singles

Song recordings produced by Chris Thomas (record producer)

1990s ballads

Pop ballads

Hidden categories:

Webarchive template wayback links

Use dmy dates from April 2012

Use British English from April 2012

Articles with hAudio microformats

Singlechart usages for Flanders

Singlechart usages for Ireland

Singlechart called without artist

Singlechart called without song

Singlechart usages for Scotland

Singlechart usages for UK

All articles with unsourced statements

Articles with unsourced statements from October 2013

Certification Table Entry usages for Australia

Certification Table Entry usages for United Kingdom

Certification Table Entry usages for United States

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Español

Polski

Edit links

 This page was last edited on 10 April 2018, at 16:48.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews