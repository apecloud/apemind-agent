# Order of the British Empire

Order of the British Empire - Wikipedia

Order of the British Empire

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

"GBE", "KBE", "DBE", "CBE", "OBE", and "MBE" redirect here. For other uses, see GBE (disambiguation), KBE (disambiguation), DBE (disambiguation), CBE (disambiguation), OBE (disambiguation), and MBE (disambiguation).

| Most Excellent Order of the British Empire |

| CBE neck decoration (in civil division) |

| Awarded by the sovereign of the United Kingdom |

| Type | Order of chivalry |

| Established | 1917 |

| Motto | For God and the Empire |

| Eligibility | British nationals, or anyone who has made a significant achievement for the United Kingdom |

| Awarded for | Prominent national or regional achievements[1] |

| Status | Currently constituted |

| Sovereign | Queen Elizabeth II |

| Grand Master | Prince Philip, Duke of Edinburgh |

| Grades | Knight/Dame Grand Cross (GBE) Knight/Dame Commander (KBE/DBE) Commander (CBE) Officer (OBE) Member (MBE) |

| Former grades | Medal of the Order of the British Empire for Gallantry Medal of the Order of the British Empire for Meritorious Service |

| Precedence |

| Next (higher) | Royal Victorian Order |

| Next (lower) | Varies, depending on rank |

| Military ribbon Civil ribbon |

MBE as awarded in 1918

Grand Cross star of the Order of the British Empire

Close-up of an MBE from 1945 showing the "For God and the Empire"

Lieutenant General Sir Robert Fulton, KBE

The Most Excellent Order of the British Empire is a British order of chivalry, rewarding contributions to the arts and sciences, work with charitable and welfare organisations, and public service outside the Civil service.[2] It was established on 4 June 1917 by King George V, and comprises five classes across both civil and military divisions, the most senior two of which make the recipient either a knight if male or dame if female.[3] There is also the related British Empire Medal, whose recipients are affiliated with, but not members of, the order.

Recommendations for appointments to the Order of the British Empire were at first made on the nomination of the United Kingdom, the self-governing Dominions of the Empire (later Commonwealth) and the Viceroy of India. Nominations continue today from Commonwealth countries that participate in recommending British (Imperial) honours. Most Commonwealth countries, such as India, Pakistan, Nigeria and Canada ceased recommendations for appointments to the Order of the British Empire when they created their own honours.[4]

Contents
 [hide] 

1 Current classes

2 Styles and honorary knighthoods

3 History

4 Composition

5 Gallantry

6 Vestments and accoutrements

7 Chapel

8 Precedence and privileges

9 Current Knights and Dames Grand Cross

9.1 Knights and Dames Grand Cross

9.2 Honorary

10 Recommendations by Commonwealth countries

11 Criticism

12 See also

13 References

13.1 Citations

13.2 Sources

14 Further reading

15 External links

Current classes[edit]

The five classes of appointment to the Order are, in descending order of precedence:

Knight Grand Cross or Dame Grand Cross of the Most Excellent Order of the British Empire (GBE)[a]

Knight Commander or Dame Commander of the Most Excellent Order of the British Empire (KBE or DBE)

Commander of the Most Excellent Order of the British Empire (CBE)

Officer of the Most Excellent Order of the British Empire (OBE)

Member of the Most Excellent Order of the British Empire (MBE)

Styles and honorary knighthoods[edit]

The senior two ranks of Knight or Dame Grand Cross, and Knight or Dame Commander, entitle their members to use the title of Sir for men and Dame for women before their forename. Most members are citizens of the United Kingdom or the Commonwealth realms that use the Imperial system of honours and awards.

Honorary knighthoods are appointed to citizens of nations where the Queen is not head of state, and may permit use of post-nominal letters but not the title of Sir or Dame. Occasionally, honorary appointees are, incorrectly, referred to as Sir or Dame – Bob Geldof, for example. Honorary appointees who later become a citizen of a Commonwealth realm can convert their appointment from honorary to substantive, then enjoy all privileges of membership of the order, including use of the title of Sir and Dame for the senior two ranks of the Order. An example is Irish broadcaster Terry Wogan, who was appointed an honorary Knight Commander of the Order in 2005, and on successful application for British citizenship, held alongside his Irish citizenship, was made a substantive member and subsequently styled as Sir Terry Wogan.[5][6]

History[edit]

King George V founded the Order to fill gaps in the British honours system:

The Orders of the Garter, Thistle, and of St Patrick honoured royals, peers, statesmen, and eminent military commanders;

The Order of the Bath honoured senior military officers and civil servants;

The Order of St Michael and St George honoured diplomats and colonial officials;

The Order of the Star of India and the Order of the Indian Empire honoured Indian rulers and British and Indian officials of the British Indian Empire; and

The Royal Victorian Order, in the personal gift of the monarch, honoured those who had personally served the royal family.

In particular, King George V wished to create an Order to honour many thousands of those who had served in a variety of non-combatant roles during the First World War. When first established, the Order had only one division. However, in 1918, soon after its foundation, it was formally divided into Military and Civil Divisions.[7] The Order's motto is For God and the Empire.[2]

At the foundation of the Order, the 'Medal of the Order of the British Empire' was instituted, to serve as a lower award granting recipients affiliation but not membership. In 1922, this was renamed the 'British Empire Medal' (BEM). It stopped being awarded by the United Kingdom as part of the 1993 reforms to the honours system, but was again awarded beginning in 2012, starting with 293 BEMs awarded for Queen Elizabeth II's Diamond Jubilee.[8] In addition, the BEM is awarded by the Cook Islands and by some other Commonwealth nations. In 2004, a report entitled "A Matter of Honour: Reforming Our Honours System" by a Commons committee recommended to phase out the Order of the British Empire, as its title was "now considered to be unacceptable, being thought to embody values that are no longer shared by many of the country's population".[9]

Composition[edit]

The British monarch is Sovereign of the Order, and appoints all other members of the Order (by convention, on the advice of the governments of the United Kingdom and some Commonwealth realms). The next most senior member is the Grand Master, of whom there have been three: Prince Edward, the Prince of Wales (1917–1936); Queen Mary (1936–1953); and the current Grand Master, the Duke of Edinburgh (since 1953).

The Order is limited to 300 Knights and Dames Grand Cross, 845 Knights and Dames Commander, and 8,960 Commanders. There are no limits applied to the total number of members of the fourth and fifth classes, but no more than 858 Officers and 1,464 Members may be appointed per year. Foreign appointees, as honorary members, do not contribute to the numbers restricted to the Order as full members do. Although the Order of the British Empire has by far the highest number of members of the British Orders of Chivalry, with over 100,000 living members worldwide, there are fewer appointments to knighthoods than in other orders.[2]

Though men can be knighted separately from an order of chivalry, women cannot, and so the rank of Knight/Dame Commander of the Order is the lowest rank of damehood, and second-lowest of knighthood (above Knights Bachelor). Because of this, an appointment as Dame Commander is made in circumstances in which a man would be created a Knight Bachelor. For example, by convention, female judges of the High Court of Justice are created Dames Commander after appointment, while male judges become Knights Bachelor.

The Order has six officials: the Prelate; the Dean; the Secretary; the Registrar; the King of Arms; and the Usher. The Bishop of London, a senior bishop in the Church of England, serves as the Order's Prelate. The Dean of St Paul's is ex officio the Dean of the Order. The Order's King of Arms is not a member of the College of Arms, as are many other heraldic officers. The Usher of the Order is known as the Gentleman Usher of the Purple Rod; he does not – unlike his Order of the Garter equivalent, the Gentleman Usher of the Black Rod – perform any duties related to the House of Lords.

From time to time, individuals are appointed to a higher grade within the Order, thereby ceasing usage of the junior post-nominal letters.

Gallantry[edit]

The institution of the Order of the British Empire in 1917 was for meritorious service but from the beginning some appointments and some promotions were for acts of gallantry. There were an increased number of cases in the Second World War for service personnel and civilians including the merchant marine, police and emergency services and civil defense mostly MBEs but a small number of CBEs and OBEs. Such awards were for gallantry that did not reach the standard of the George Medal, but, as an Order, were listed before it on the Order of Wear. Awards for meritorious service usually appear without a citation but there were often citations for gallantry awards, some detailed and graphic.[10] From 14 January 1958, these awards were designated Commander, Officer or Member of the Order of the British Empire for Gallantry.[11]

Any individual made a member of the Order for gallantry could wear an emblem of two crossed silver oak leaves on the same riband, ribbon or bow as the badge. It could not be awarded posthumously, and was replaced in 1974 with the Queen's Gallantry Medal (QGM). If recipients of the Order of the British Empire for Gallantry received promotion within the Order, whether for gallantry or otherwise, they continued to wear also the insignia of the lower grade with the oak leaves.[12] However, they only used the post-nominal letters of the higher grade.

Vestments and accoutrements[edit]

Members of the Order wear elaborate vestments on important occasions (such as quadrennial services and coronations), which vary by rank (the designs underwent major changes in 1937):

The mantle, worn by only Knights and Dames Grand Cross, was originally made of yellow satin lined with blue silk, but is now made of rose pink satin lined with pearl-grey silk. On the left side is a representation of the star (see below).

The collar, also worn by only Knights and Dames Grand Cross, is made of gold. It consists of six medallions depicting the Royal Arms, alternating with six medallions depicting the Royal and Imperial Cypher of George V (GRI, which stands for "Georgius Rex Imperator"). The medallions are linked with gold cables depicting lions and crowns.

Knight/Dame Grand Cross insignia

Mantle worn by Knights and Dames Grand Cross (GBE)

Close-up of the star on the mantle

Collar and star of a Knight or Dame Grand Cross of the Order of the British Empire

Badge as awarded to a female Member of the Order

On certain "collar days" designated by the Sovereign, members attending formal events may wear the Order's collar over their military uniform, formal day dress, or evening wear. When collars are worn (either on collar days or on formal occasions such as coronations), the badge is suspended from the collar. Collars are returned upon the death of their owners, but other insignia may be retained.

At less important occasions, simpler insignia are used:

The star is an eight-pointed silver star used by only Knights and Dames Grand Cross and Knights and Dames Commander. It is worn pinned to the left breast. Varying in size depending on class, it bears a crimson ring with the motto of the Order inscribed. Within the ring, a figure of Britannia was originally shown. Since 1937, however, the effigies of George V and Mary of Teck have been shown instead.

The badge is the only insignia used by all members of the Order. Until 1937, it was suspended on a purple ribbon, with a red central stripe for the military division; since then, the ribbon has been rose-pink with pearl-grey edges, with the addition of a pearl-grey central stripe for the military division. Knights and Dames Grand Cross wear it on a riband or sash, passing from the right shoulder to the left hip. Knights Commander and male Commanders wear the badge from a ribbon around the neck; male Officers and Members wear the badge from a ribbon on the left chest; all females other than Dames Grand Cross wear it from a bow on the left shoulder. The badge is in the form of a cross patonce (having the arms growing broader and floriated toward the end), the obverse of which bears the same field as the star (that is, either Britannia or George V and Queen Mary); the reverse bears George V's Royal and Imperial Cypher. Both are within a ring bearing the motto of the Order. The size of the badges varies according to rank: the higher classes have slightly larger badges. The badges of Knights and Dames Grand Cross, Knights and Dames Commander and Commanders are enamelled with pale blue crosses and crimson rings; those of Officers are plain gold; those of Members are plain silver.

The British Empire Medal is made of silver. On the obverse is an image of Britannia surrounded by the motto, with the words "For Meritorious Service" at the bottom; on the reverse is George V's Imperial and Royal Cypher, with the words "Instituted by King George V" at the bottom. The name of the recipient is engraved on the rim. This medal is nicknamed 'the Gong', and comes in both a full-sized and miniature versions – the latter for formal white-tie and informal black-tie occasions.

A lapel pin for everyday wear was first announced at the end of December 2006, and is available to recipients of all levels of the Order, as well as to holders of the British Empire Medal. The pin design is not unique to any level. The pin features the badge of the Order, enclosed in a circle of ribbon of its colours of pink and grey. Lapel pins must be purchased separately by a member of the Order.[13] The creation of such a pin was recommended in Sir Hayden Phillips' review of the honours system in 2004.[14]

| Order of the British Empire ribbon bars |

| Civil | Military |

| 1917–1935 |

| Since 1936 |

Chapel[edit]

Chapel of the Order in the crypt of St Paul's Cathedral

The chapel of the Order is in the far eastern end of the crypt of St Paul's Cathedral, but it holds its great services upstairs in the main body of the Cathedral. (The Cathedral also serves as the home of the chapel of The Most Distinguished Order of St Michael and St George.) Religious services for the whole Order are held every four years; new Knights and Dames Grand Cross are installed at these services. The chapel was dedicated in 1960.

Precedence and privileges[edit]

Knights Grand Cross and Knights Commander prefix Sir, and Dames Grand Cross and Dames Commander prefix Dame, to their forenames.[b] Wives of Knights may prefix Lady to their surnames, but no equivalent privilege exists for husbands of Knights or spouses of Dames. Such forms are not used by peers and princes, except when the names of the former are written out in their fullest forms. Male clergy of the Church of England or the Church of Scotland do not use the title Sir as they do not receive the accolade (i.e., they are not dubbed "knight" with a sword), although they do append the post-nominal letters: dames do not receive the accolade, and therefore female clergy are free to use the title Dame.

Knights and Dames Grand Cross use the post-nominal, GBE; Knights Commander, KBE; Dames Commander, DBE; Commanders, CBE; Officers, OBE; and Members, MBE. The post-nominal for the British Empire Medal is BEM.

Members of all classes of the Order are assigned positions in the order of precedence. Wives of male members of all classes also feature on the order of precedence, as do sons, daughters and daughters-in-law of Knights Grand Cross and Knights Commander; relatives of Ladies of the Order, however, are not assigned any special precedence. As a general rule, individuals can derive precedence from their fathers or husbands, but not from their mothers or wives (see order of precedence in England and Wales for the exact positions).

Knights, Dames and Commanders may display the circlet of the Order on the coat of arms, with the badge of the Order suspended from it.[c]

Knights and Dames Grand Cross are also entitled to be granted heraldic supporters. They may, furthermore, encircle their arms with a depiction of the circlet (a circle bearing the motto) and the collar; the former is shown either outside or on top of the latter. Knights and Dames Commander and Commanders may display the circlet, but not the collar, surrounding their arms. The badge is depicted suspended from the collar or circlet.

Current Knights and Dames Grand Cross[edit]

Sovereign: Queen Elizabeth II

Grand Master: Prince Philip, Duke of Edinburgh

King of Arms: Lieutenant General Sir Robert Fulton, KBE

Knights and Dames Grand Cross[edit]

This list is incomplete; you can help by expanding it.

Military ranks listed denotes the awarded being in the military division.

| Military rank | Name | Post-nominals | Year appointed |

| Admiral of the Fleet | The Duke of Edinburgh | KG KT OM GCVO ONZ GBE AK QSO GCL CC CMM PC CD ADC(P) | 1953 |

| Air Chief Marshal | Sir Peter Le Cheminant | GBE KCB DFC* | 1978 |

| General | Sir Hugh Beach | GBE KCB MC | 1985 |

| General | Sir Frank Kitson | GBE KCB MC* DL | 1985 |

| Sir Sze Yuen Chung | GBE GBM | 1989 |

| Sir Thomas Eichelbaum | GBE PC QC | 1989 |

| Air Chief Marshal | Sir David Harcourt-Smith | GBE KCB DFC | 1989 |

| Field Marshal | The Lord Vincent of Coleshill | GBE KCB DSO | 1990 |

| Sir Alexander Graham | GBE | 1990 |

| Air Chief Marshal | Sir Patrick Hine | GCB GBE | 1991 |

| Sir Brian Jenkins | GBE | 1991 |

| Sir Francis McWilliams | GBE | 1992 |

| Air Chief Marshal | Sir Anthony Skingsley | GBE KCB | 1992 |

| Admiral | Sir Kenneth Eaton | GBE KCB | 1994 |

| Air Chief Marshal | Sir Bill Wratten | GBE CB AFC | 1998 |

| The Lord Rothschild | OM GBE | 1998 |

| Sir Stephen Brown | GBE | 1999 |

| Air Chief Marshal | Sir Anthony Bagnall | GBE KCB | 2002 |

| Sir Michael Sydney Perry | GBE | 2002 |

| Sir Ronnie Flanagan | GBE QPM | 2002 |

| Sir Cyril Taylor | GBE | 2004 |

| The Baroness Butler-Sloss | GBE PC | 2005 |

| Sir David Cooksey | GBE | 2007 |

| General | Sir Timothy Granville-Chapman | GBE KCB | 2011 |

| The Lord King of Lothbury | KG GBE | 2011 |

| The Earl of Selborne | GBE DL | 2011 |

| Sir John Parker | GBE | 2012 |

| The Baroness Hayman | GBE PC | 2012 |

| Sir Keith Mills | GBE DL | 2013 |

| Sir Alan Budd | GBE | 2013 |

| Sir John Bell | GBE FRS | 2015 |

| Air Chief Marshal | Sir Stuart Peach | GBE KCB ADC DL | 2016 |

| Sir Ian Wood | GBE | 2016 |

| Sir Cyril Chantler | GBE | 2017 |

| Sir Michael Rawlins | GBE | 2017 |

| Sir David Weatherall | GBE FRS | 2017 |

| Sir Keith Peters | GBE | 2018 |

Honorary[edit]

| Name | Post-nominal | Country | Year appointed |

| George J. Mitchell | GBE | United States | 1999 |

| Ratan Tata | GBE | India | 2014 |

Recommendations by Commonwealth countries[edit]

Recommendations for appointments to the Order of the British Empire continue to be made by some Commonwealth realms. In 2016, Antigua and Barbuda, Bahamas, Barbados, Belize, Grenada, Papua New Guinea, Saint Christopher and Nevis, Saint Lucia, Solomon Islands, and Tuvalu all included Order of the British Empire awards in their New Year and/or Queen's Birthday honours lists.[15][16] Since the Second World War, most Commonwealth realms have established their own national system of honours and awards and have created their own unique orders, decorations and medals. Canada seldom made recommendations for appointments to the Order of the British Empire except for the Second World War and Korea but continued to recommend gallantry awards for both military and civilians until the creation of the Order of Canada.[17] Australia continued to recommend the Order of the British Empire until the 1989 Queen's Birthday Honours, nearly 15 years after the creation of the Order of Australia.[18]

Criticism[edit]

See also: List of people who have declined a British honour

The Order has attracted some criticism for its naming having connection with the idea of the now-extinct British Empire.[19] Benjamin Zephaniah, a British Jamaican poet, publicly rejected appointment as an Officer in 2003 because, he asserted, it reminded him of "thousands of years of brutality". He also said that "It reminds me of how my foremothers were raped and my forefathers brutalised".[20]

In 2004, a House of Commons Select Committee recommended changing the name of the award to the Order of British Excellence, and changing the rank of Commander to Companion; as the former was said to have a "militaristic ring".[19][21]

A notable person to decline the offer of membership was the author C. S. Lewis (1898–1963), who had been named on the last list of honours by George VI in December 1951. Despite being a monarchist, he declined so as to avoid association with any political issues.[22][23]

The members of The Beatles were appointed as Members in 1965. John Lennon justified the comparative merits of his investiture by comparing military membership in the Order: "Lots of people who complained about us receiving the MBE [status] received theirs for heroism in the war – for killing people ... We received ours for entertaining other people. I'd say we deserve ours more". Lennon later returned his MBE insignia on 25 November 1969, as part of his ongoing peace protests.[24] Other criticism centres on the claim that many recipients of the Order are being rewarded with honours for simply doing their jobs; critics claim that the Civil Service and Judiciary receive far more orders and honours than leaders of other professions.[19]

Chin Peng, long-time leader of the Malayan Communist Party, was appointed as an Officer for his share in fighting against the Japanese during World War II, in close co-operation with the British commando Force 136. His membership was withdrawn by the British government (and became undesirable for Chin Peng himself) when the Communist leader headed his party's guerrilla insurgency against the British in the Malayan Emergency after the War.[25]

See also[edit]

Orders, decorations, and medals of the United Kingdom – the British honours system

List of Knights Grand Cross of the Order of the British Empire

List of Dames Grand Cross of the Order of the British Empire

List of honorary British knights and dames

United Kingdom order of precedence

Honours Committee

References[edit]
Citations[edit]

Jump up ^ It is commonly written without "of the Most Excellent Order" and other words not implied by the post-nominals.

Jump up ^ Never surnames – thus Sir Antony Sher may be shortened to Sir Antony, but not to Sir Sher

Jump up ^ In the image provided, the recipient has also been received into the Venerable Order of Saint John, and so that badge is shown also, on the black ribbon to the right.

Sources[edit]

Jump up ^ "Guide to the Honours". BBC News. BBC. 10 June 2015. Retrieved 25 May 2016. 

^ Jump up to: a b c "Order of the British Empire". The Official Website of the British Monarchy. The Royal Household. Archived from the original on 27 March 2010. Retrieved 24 August 2009. 

Jump up ^ "No. 30250". The London Gazette (2nd supplement). 24 August 1917. pp. 8791–8999. 

Jump up ^ The last Canadian recommendation for the Order of the British Empire was a MBE for gallantry gazetted in 1966, a year before the creation of the Order of Canada. The Australian Honours System unilaterally created in 1975 did not achieve bi-partisan support until 1992 when Australian federal and state governments agreed to cease Australian recommendations for British honours. The last Australian recommended Order of the British Empire appointments were in the 1989 Queen’s Birthday Honours.

Jump up ^ "No. 57855". The London Gazette (1st supplement). 31 December 2005. p. 26. 

Jump up ^ "Radio's Wogan becomes Sir Terry". BBC News. BBC. 6 December 2005. Retrieved 7 February 2009. 

Jump up ^ "No. 31084". The London Gazette. 27 December 1918. p. 15135. 

Jump up ^ "Birthday Honours: 'Working class' British Empire Medal revived". BBC News. BBC. 16 June 2012. Retrieved 20 June 2012. 

Jump up ^ "A Matter of Honour: Reforming Our Honours System" (pdf). House of Commons Public Administration Select Committee. Parliament.uk. 13 July 2004. Retrieved 15 January 2016. 

Jump up ^ British gallantry awards by P E Abbott and JMA Tamplin, 1981, Nimrod Dix & Co, London, ISBN 0-902633-74-0, chapters 35 to 38.

Jump up ^ "No. 41285". The London Gazette (Supplement). 14 January 1958. p. 365. 

Jump up ^ "No. 56878". The London Gazette (Supplement). 17 March 2003. p. 3353. 

Jump up ^ "Emblem for honours (Archived 4 April 2012)". The National Archives. DirectGov (UK). Archived from the original on 4 April 2012. Retrieved 26 July 2014. 

Jump up ^ "BEM Recipients Entitled to New Emblem". The Berwickshire News. 12 November 2008. Retrieved 26 July 2014. 

Jump up ^ London Gazette 61450, Thu, 31 December 2015, p. N40

Jump up ^ London Gazette 61608, Sat 11 June 2016, p. B40

Jump up ^ However, there were awards of the related British Empire Medal for Gallantry, whose recipients are affiliated with, but not members of the Order of the British Empire, after the creation of the Order of Canada. see https://www.thegazette.co.uk/London/issue/44630/page/1

Jump up ^ London Gazette 51778, Sat, 17 June 1989, p. 45

^ Jump up to: a b c A reformed Honours system, Select Committee on Public Administration, 7 July 2004, Retrieved 13 May 2012

Jump up ^ Mills, Merope (27 November 2003). "Rasta poet publicly rejects his OBE". The Guardian. Retrieved 31 July 2015. 

Jump up ^ "Honours system outdated, say MPs", BBC News, 13 July 2004, Retrieved 28 February 2007

Jump up ^ "Chronology of the Life of C.S. Lewis". Archived from the original on 6 February 2012. 

Jump up ^ C.S., Lewis (1994). W. H. Lewis, Walter Hooper, ed. Letters of C.S. Lewis. New York: Mariner Books. p. 528. ISBN 0-15-650871-0. 

Jump up ^ Brian Roylance; George Harrison; John Lennon; Paul McCartney; Ringo Starr (2000). The Beatles Anthology. Chronicle Books. p. 183. ISBN 0-8118-2684-8. 

Jump up ^ Dead or Alive,(subscription required) TIME Magazine, 12 May 1952

Further reading[edit]

Galloway, Peter (1996). The Order of the British Empire. Central Chancery of the Orders of Knighthood. ISBN 0-907605-65-6. 

Hood, Frederic (1967). The Chapel of the Most Excellent Order of the British Empire, with a foreword by Prince Philip.

"Knighthood and Chivalry" (1911). Encyclopædia Britannica, 11th ed., London: Cambridge University Press.

External links[edit]

| Wikimedia Commons has media related to Order of the British Empire. |

Order of the British Empire – official website of the British Monarchy

The Honours system – UK Government

Queen's Birthday and New Year honours – The London Gazette, lists recipients of honours

"The Most Excellent Order of the British Empire" (2002) – Cambridge University Heraldic and Genealogical Society

"Order of Precedence in England and Wales", Velde, F. R. (2003) – Heraldica.org

Search recommendations for the Order of the British Empire on the UK National Archives' website

The Chapel of the Most Excellent Order of the British Empire – OBE Chapel Exterior detail – jpg image, IanMcGrawPhotos.co.uk

| [show] v t e Orders, decorations, and medals of the United Kingdom |

| Current | Garter Thistle Bath Merit St Michael and St George Royal Victorian Distinguished Service British Empire Imperial Service Companions of Honour St John |

| Dormant | St Patrick Royal Guelphic Crown of India Star of India Indian Empire Indian Merit British India Burma |

| Other | Royal Victorian Chain Hereditary peerage Life peerage Privy Counsellor Baronet Knight Bachelor Aide-de-camp (ADC) Honours of other Commonwealth realms |

| Level 1 | Victoria Cross (VC) George Cross (GC) |

| Level 2A | Distinguished Service Order (DSO) Conspicuous Gallantry Cross (CGC) Royal Red Cross Class I (RRC) |

| Level 2B | George Medal (GM) Queen's Police Medal, for Gallantry (QPM) Queen's Fire Service Medal, for Gallantry (QFSM) |

| Level 3A | Distinguished Service Cross (DSC) Military Cross (MC) Distinguished Flying Cross (DFC) Air Force Cross (AFC) Royal Red Cross Class II (ARRC) |

| Level 3B | Constabulary Medal (Ireland) Sea Gallantry Medal (SGM) Queen's Gallantry Medal (QGM) Royal Victorian Medal (RVM) British Empire Medal (BEM) Queen's Police Medal, for Distinguished Service (QPM) Queen's Fire Service Medal, for Distinguished Service (QFSM) Queen's Ambulance Service Medal (QAM) Queen's Volunteer Reserves Medal (QVRM) Polar Medal (PM) Imperial Service Medal (ISM) Overseas Territories Police Medal (CPM) Merchant Navy Medal for Meritorious Service |

| Level 4 | Mentioned in Despatches Queen's Commendation for Bravery Queen's Commendation for Bravery in the Air Queen's Commendation for Valuable Service |

| Other | Badge of Honour |

| Level 1 | Indian Order of Merit (First Class) (IOM) Albert Medal (1st class) (AM) Edward Medal (1st class) (EM) Empire Gallantry Medal (EGM) |

| Level 2A | Indian Order of Merit (Second Class) (IOM) Distinguished Conduct Medal (DCM) Conspicuous Gallantry Medal (CGM) Conspicuous Gallantry Medal (Flying) (CGM) |

| Level 2B | Albert Medal (2nd class) (AM) Edward Medal (2nd class) (EM) Union of South Africa King's Medal for Bravery, Gold |

| Level 3A | Order of British India (First Class) (OBI) Order of British India (Second Class) (OBI) Indian Order of Merit (Third Class) (IOM) Royal West African Frontier Force Distinguished Conduct Medal King's African Rifles Distinguished Conduct Medal Indian Distinguished Service Medal (IDSM) Distinguished Service Medal (DSM) Military Medal (MM) Distinguished Flying Medal (DFM) Air Force Medal (AFM) Burma Gallantry Medal (BGM) |

| Level 3B | Union of South Africa Queen's Medal for Bravery (Silver) Kaisar-i-Hind Medal (Gold, Silver, Bronze) Indian Police Medal, for Gallantry Ceylon Police Medal, for Gallantry Sierra Leone Police Medal, for Gallantry Sierra Leone Fire Brigades Medal, for Gallantry Colonial Police Medal, for Gallantry (CPM) Canada Medal (CM) Queen's Medal for Chiefs Indian Police Medal, for Meritorious Service Ceylon Police Medal, for Merit Sierra Leone Police Medal, for Meritorious Service Sierra Leone Fire Brigades Medal, for Meritorious Service |

| Level 4 | King's/Queen's Commendation for Brave Conduct King's/Queen's Commendation for Valuable Service in the Air |

| Royal Family Orders (personal mementos) | King George IV Victoria and Albert King Edward VII King George V King George VI Queen Elizabeth II |

| See also British campaign medals Revocations Orders, decorations and medals |

| [show] v t e Former decorations of Australia |

| Australian Honours Order of Precedence prior to 6 October 1992 |

| Most Honourable Order of the Bath | Knight/Dame Grand Cross of the Order of the Bath (GCB) Knight/Dame Commander of the Order of the Bath (KCB/DCB) Companion of the Order of the Bath (CB) |

| Most Distinguished Order of St Michael and St George | Knight/Dame Grand Cross of the Order of St Michael and St George (GCMG) Knight/Dame Commander of the Order of St Michael and St George (KCMG/DCMG) Companion of the Order of St Michael and St George (CMG) |

| Most Excellent Order of the British Empire | / Knight/Dame Grand Cross of the Order of the British Empire (GBE) / Knight/Dame Commander of the Order of the British Empire (KBE/DBE) / Commander of the Order of the British Empire (CBE) / Officer of the Order of the British Empire (OBE) / Member of the Order of the British Empire (MBE) |

| Imperial Service Order | Companion of the Imperial Service Order (ISO) |

| Order of the Companions of Honour | Companion of the Order of the Companions of Honour (CH) |

| Miscellaneous | Hereditary peer Life peer Baronet Knight Bachelor |

| In the face of the enemy | Victoria Cross (VC) Distinguished Service Order (DSO) Distinguished Conduct Medal (DCM) Conspicuous Gallantry Medal (CGM) Conspicuous Gallantry Medal (Flying) (CGM) Military Cross (MC) Distinguished Flying Cross (DFC) Military Medal (MM) Distinguished Flying Medal (DFM) Mentioned in dispatches |

| Not the face of the enemy | Air Force Cross (AFC) Air Force Medal (AFM) Queen's Commendation for Brave Conduct |

| In the face of the enemy | Distinguished Service Cross (DSC) Distinguished Service Medal (DSM) |

| Not the face of the enemy | Queen's Police Medal for Distinguished Service (QPM) Queen's Fire Service Medal for Distinguished Service (QFSM) |

| Civil bravery decorations | George Cross (GC) Albert Medal, First Class (AM) Albert Medal, First Class (Sea) (AM) Albert Medal, Second Class (AM) Albert Medal, Second Class (Sea) (AM) George Medal (GM) Queen's Police Medal for Gallantry (QPM) Queen's Fire Service Medal for Gallantry (QFSM) Sea Gallantry Medal (SGM) Queen's Gallantry Medal (QGM) Edward Medal (EM) Queen's Commendation for Brave Conduct |

| Nursing service | Member of the Royal Red Cross (RRC) Associate of the Royal Red Cross (ARRC) |

| Meritorious service | / British Empire Medal (BEM) Queen's Commendation for Valuable Service |

| Authority control | WorldCat Identities VIAF: 157543990 LCCN: nr90010472 NLA: 35400351 |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Order_of_the_British_Empire&oldid=819028920"

Categories:

Order of the British Empire

Orders of knighthood of the United Kingdom

1917 establishments in the United Kingdom

Orders of knighthood awarded to heads of state, consorts and sovereign family members

British honours system

Hidden categories:

Pages containing London Gazette template with parameter supp set to y

Pages containing links to subscription-only content

EngvarB from February 2017

Use dmy dates from February 2017

Pages using deprecated image syntax

Articles containing Latin-language text

Incomplete lists from March 2015

Wikipedia articles with VIAF identifiers

Wikipedia articles with LCCN identifiers

Wikipedia articles with NLA identifiers

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikimedia Commons

			Languages

Afrikaans

العربية

Asturianu

Azərbaycanca

বাংলা

Беларуская

Български

Boarisch

Català

Čeština

Cymraeg

Dansk

Deutsch

Eesti

Ελληνικά

Español

Esperanto

فارسی

Français

Galego

한국어

हिन्दी

Hrvatski

Bahasa Indonesia

Italiano

עברית

Latviešu

Lëtzebuergesch

Lietuvių

Magyar

Македонски

مصرى

Bahasa Melayu

Nederlands

日本語

Norsk

Norsk nynorsk

Occitan

Polski

Português

Română

Русский

Scots

Shqip

Simple English

Slovenčina

Slovenščina

Suomi

Svenska

ไทย

Türkçe

Українська

中文

Edit links

 This page was last edited on 7 January 2018, at 00:19.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews