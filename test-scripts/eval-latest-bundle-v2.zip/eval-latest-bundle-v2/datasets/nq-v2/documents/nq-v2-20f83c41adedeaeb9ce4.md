# Where Is the Love?

Where Is the Love? - Wikipedia

Where Is the Love?

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

This article is about the Black Eyed Peas song. For the Roberta Flack and Donny Hathaway song, see Where Is the Love. For the Hanson song, see Where's the Love.

| "Where Is the Love?" |

| Single by The Black Eyed Peas |

| from the album Elephunk |

| B-side | "Somethin' for That Ass" "What's Goin Down" |

| Released | June 16, 2003 |

| Format | CD single |

| Recorded | December 26, 2001–March 3, 2003 |

| Genre | Conscious hip hop pop[2] soul[3] |

| Length | 8:29 (2003 album version) 4:34 (single version/2004 album version) 3:51 (radio edit) |

| Label | A&M will.i.am Interscope |

| Songwriter(s) | will.i.am apl.de.ap Taboo Justin Timberlake Printz Board Michael Fratantuno George Pajon |

| Producer(s) | will.i.am Ron Fair |

| The Black Eyed Peas singles chronology |

| "Request + Line" (2001) | "Where Is the Love?" (2003) | "Shut Up" (2003) |

| "Request + Line" (2001) | "Where Is the Love?" (2003) | "Shut Up" (2003) |

| Music video |

| "Where Is the Love?" on YouTube |

"Where Is the Love?" is a song by American hip hop group The Black Eyed Peas. It was released in June 2003 as the lead single from their third album, Elephunk. The song was written by will.i.am, apl.de.ap, Taboo, Justin Timberlake, Printz Board, Michael Fratantuno and George Pajon. The track features vocals from Timberlake, although he is not officially credited on the single release. It was the band's first song to feature singer Fergie as an official member.

"Where Is the Love?" saw success on radio airplay charts,[4] peaked at number eight on the US Billboard Hot 100, and topped the charts in Australia, Ireland and the United Kingdom. It became the biggest-selling single of 2003 in the latter country. The band and Timberlake received two nominations, Record of the Year and Best Rap/Sung Collaboration, for "Where Is the Love?" at the 46th Grammy Awards.[5]

Contents
 [hide] 

1 Background

2 Composition

3 Reception

4 Music video

5 Covers

6 Formats and track listings

7 Personnel

8 Charts and certifications

8.1 Weekly charts

8.2 Year-end charts

8.3 Decade-end charts

8.4 Certifications

9 2016 version

9.1 Music video

9.2 Track listing

9.3 Personnel

9.4 Charts

9.5 2016 Spanish/English version

10 References

11 External links

Background[edit]

Following the commercial failures of their previous albums and singles, there was doubt over whether The Black Eyed Peas would continue to record together. A&R executive Ron Fair approached them and suggested a crossover to a more mainstream pop sound. will.i.am in particular resisted the idea for fear that they would be seen as sellouts. However, after discussions and some writing sessions, the idea was pursued.[6]

Shortly after Christmas 2001, will.i.am created a loop and a guitar part that he liked. apl.de.ap and Taboo also heard the track and were able to write similar lyrics over it. Justin Timberlake was introduced to the group by Taboo, and got a chance to hear the track that will.i.am created. Impressed with the music, Timberlake helped write and sing the chorus.

Timberlake was in the midst of promotion of his debut solo album, Justified, and his label Jive Records was concerned about possible overexposure. The Black Eyed Peas were worried about this, as getting some assistance from an established pop star like Timberlake had been the original point of this song. A compromise was reached eventually in which Jive gave clearance for the vocals of Timberlake to be released on the song, but he does not appear in the song's music video nor is he officially credited on the song as an artist. By 2008, the single had sold 954,000 digital copies.[7]

Composition[edit]

Timberlake co-wrote the song and provided vocals.

The song was written by will.i.am, apl.de.ap, Taboo, Justin Timberlake, Ron Fair, Printz Board, George Pajon, Fiona Davies M. Fratantuno, and J. Curtis, and co-produced by will.i.am and Ron Fair. In this song, The Black Eyed Peas lament on various worldwide problems. Many issues are discussed, which include but are not limited to terrorism, US government hypocrisy, racism, gang crime, pollution, war, and intolerance

Reception[edit]

The song was rewarded with nominations at the 46th Grammy Awards in 2004 for Record of the Year and Best Rap/Sung Collaboration.

The song was the biggest selling single of 2003 in the UK. It was also the 25th best-selling single of the 2000s (decade) in the UK.[8]

On May 12, 2013, after 10 years since the song's release, the song re-entered the official UK singles charts at 40, eventually peaking at 35.

Music video[edit]

The music video for "Where Is the Love?" was shot in East Los Angeles and features The Black Eyed Peas and various other people, including various young children, asking the world where the love really is. In the video, will.i.am and Taboo act as a soul music road duo who use music to tell people what is wrong with the world, Fergie appears as a peacemaker who places stickers with question marks on them all over the place to ask people where the love is in the world, and apl.de.ap is a criminal who is arrested for using criminal offences to tell people the truth. Justin Timberlake does not appear in the video, although several different people are seen mouthing the chorus as he sings it.

The video is similar to a 2002 British television advertisement for T-Mobile, in which a face of a young baby is presented in various forms around a large city, much like the question mark in this video. The Bon Jovi music video "Have a Nice Day" is also similar to both the advertisement and this video. The video features gameplay footage of the graphically explicit and controversial video game Postal 2, in which a group of young children are playing the game. This suggests that violence in the media and entertainment industry affects the morals of children.

Covers[edit]

British pop band Busted did a rock version of the song, which features on their live album, A Ticket for Everyone.

The Voice UK contestant Frances Wood sang the song at her audition and chose will.i.am to be her mentor.

Japanese pop singer Sho Sakurai of Arashi re-wrote the rap lyrics in Japanese language and performed his cover version at his solo concert in 2006.

At the Mnet Asian Music Awards (commonly abbreviated as MAMA) promotional held in Singapore in 2011, will.i.am apl.de.ap performed the song with friend and collaborator, K-pop vocalist and rapper CL of 2NE1 performing Taboo and Fergie's part.

The X Factor Israel contestant Inbal Bibi sang the song at the live shows and received positive reviews.

Ariana Grande joined the Black Eyed Peas for a cover of the version at Grande's 2017 One Love Manchester concert.

Gwen Stefani performed the song at Hyundai Genesis G70 launch event in Seoul, South Korea on September 15, 2017.

Formats and track listings[edit]

CD single

"Where Is the Love?" – 4:35

Personnel[edit]

Arranged by Ron Fair

Writers – will.i.am, Justin Timberlake, Taboo, apl.de.ap, Printz Board, Michael Fratantuno, George Pajon, Jr.

Producers – will.i.am, Ron Fair

Charts and certifications[edit]

| Chart (2003–04) | Peak position |

| Australia (ARIA)[9] | 1 |

| Austria (Ö3 Austria Top 40)[10] | 1 |

| Belgium (Ultratop 50 Flanders)[11] | 1 |

| Belgium (Ultratop 50 Wallonia)[12] | 19 |

| Canada (Canadian Hot 100)[13] | 5 |

| Denmark (Tracklisten)[14] | 1 |

| Europe (European Hot 100 Singles)[15] | 1 |

| France (SNEP)[16] | 16 |

| Germany (Official German Charts)[17] | 1 |

| Hungary (Single Top 40)[18] | 3 |

| Hungary (Dance Top 40)[19] | 10 |

| Ireland (IRMA)[20] | 1 |

| Italy (FIMI)[21] | 3 |

| Netherlands (Dutch Top 40)[22] | 1 |

| New Zealand (Recorded Music NZ)[23] | 1 |

| Norway (VG-lista)[24] | 1 |

| Poland (Polish Singles Chart)[25] | 1 |

| Romania (Romanian Top 100)[26] | 1 |

| Scotland (Official Charts Company)[27] | 1 |

| Spain (PROMUSICAE)[28] | 2 |

| Sweden (Sverigetopplistan)[29] | 1 |

| Switzerland (Schweizer Hitparade)[30] | 1 |

| UK Singles (Official Charts Company)[31] | 1 |

| US Billboard Hot 100[32] | 8 |

| US Adult Top 40 (Billboard)[33] | 16 |

| US Dance Club Songs (Billboard)[34] | 7 |

| US Hot R&B/Hip-Hop Songs (Billboard)[35] | 22 |

| US Hot Rap Songs (Billboard)[36] | 19 |

| US Mainstream Top 40 (Billboard)[37] | 1 |

| US Rhythmic (Billboard)[38] | 1 |

| Chart (2013) | Peak position |

| UK Singles (Official Charts Company)[39] | 35 |

| Chart (2017) | Peak position |

| United Kingdom (Official Charts Company)[40] | 42 |

| Chart (2003) | Position |

| Australian Singles Chart[41] | 3 |

| Austrian Singles Chart[42] | 10 |

| Belgian (Flanders) Singles Chart[43] | 10 |

| Dutch Top 40[44] | 4 |

| French Singles Chart[45] | 78 |

| German Singles Chart[46] | 4 |

| Irish Singles Chart[47] | 2 |

| Italian Singles Chart[48] | 10 |

| New Zealand Singles Chart[49] | 2 |

| Swedish Singles Chart[50] | 7 |

| Swiss Singles Chart[51] | 2 |

| UK Singles Chart[52] | 1 |

| US Billboard Hot 100[53] | 26 |

Decade-end charts[edit]

| (2000–2009) | Position |

| German Singles Chart[54] | 89 |

| UK Singles Chart[8] | 25 |

Certifications[edit]

| Region | Certification | Certified units/Sales |

| Australia (ARIA)[55] | 4× Platinum | 280,000^ |

| Belgium (BEA)[56] | Gold | 25,000* |

| Germany (BVMI)[57] | Gold | 150,000^ |

| Italy (FIMI)[58] | Platinum | 50,000 |

| Norway (IFPI Norway)[59] | Platinum | 10,000* |

| New Zealand (RMNZ)[60] | Platinum | 10,000* |

| United Kingdom (BPI)[61] | 2× Platinum | 1,018,056[62] |

| United States (RIAA)[63] | Platinum | 1,000,000^ |

| *sales figures based on certification alone ^shipments figures based on certification alone sales+streaming figures based on certification alone |

| [show]Order of precedence |

| Preceded by "Evergreen"/"Anything Is Possible" by Will Young | Top selling single of the year (UK) 2003 | Succeeded by "Do They Know It's Christmas?" by Band Aid 20 |

| Preceded by "Ignition" by R. Kelly "Not Me, Not I" by Delta Goodrem | Australian ARIA Singles Chart number-one single August 24, 2003 – September 14, 2003 October 5, 2003 – October 12, 2003 | Succeeded by "White Flag" by Dido "Rise Up" by Australian Idol – The Final 12 |

| Preceded by "Breathe" by Blu Cantrell | Irish IRMA number-one single September 6, 2003 – November 1, 2003 | Succeeded by "Be Faithful" by Fatman Scoop featuring The Crooklyn Clan |

| Preceded by "Are You Ready for Love" by Elton John | UK Singles Chart number one single September 7, 2003 – October 18, 2003 | Succeeded by "Hole in the Head" by Sugababes |

| Preceded by "Hver dag" by Ufo Yepha | Danish number-one single September 12, 2003 – October 24, 2003 | Succeeded by "Guilty" by Blue |

| Preceded by "Never Leave You - Uh Oooh, Uh Oooh!" by Lumidee | Swiss number-one single September 21, 2003 – November 16, 2003 | Succeeded by "Aïcha" by Outlandish |

| Preceded by "Aïcha" by Outlandish | Dutch Top 40 number-one single September 27, 2003 – October 4, 2003 | Succeeded by "Anyplace, Anywhere, Anytime" by Nena and Kim Wilde |

| Preceded by "Wild at Heart" by David "Wild at Heart" by David "White Flag" by Dido | Norwegian VG-lista number-one single 41/2003 43/2003 45/2003 – 46/2003 | Succeeded by "Wild at Heart" by David "White Flag" by Dido "Hey Ya!" by Outkast |

| Preceded by "Never Leave You – Uh Oooh, Uh Oooh!" by Lumidee | Belgian (Flanders) number-one single October 4, 2003 – October 25, 2003 | Succeeded by "You Are the Reason" by Sarah & Koen Wauters |

| Preceded by "White Flag" by Dido | German number-one single October 10, 2003 – October 31, 2003 | Succeeded by "Schick mir 'nen Engel" by Overground |

| Preceded by "Never Leave You – Uh Oooh, Uh Oooh!" by Lumidee | Eurochart Hot 100 number-one single October 11, 2003 – November 22, 2003 | Succeeded by "Me Against the Music" by Britney Spears and Madonna |

| Preceded by "White Flag" by Dido | Ö3 Austria Top 40 number-one single October 26, 2003 – November 15, 2003 | Succeeded by "Schick mir 'nen Engel" by Overground |

| Preceded by "Aïcha" by Outlandish | Swedish number-one single November 5, 2003 | Succeeded by "Aïcha" by Outlandish |

2016 version[edit]

| "#WHERESTHELOVE" |

| Single by The Black Eyed Peas featuring The World |

| Released | August 31, 2016 |

| Format | Digital download |

| Length | 5:25 |

| Label | Interscope |

| Songwriter(s) | will.i.am apl.de.ap Taboo Justin Timberlake The Game ASAP Rocky DJ Khaled Giorgio Tuinfort |

| Producer(s) | will.i.am Giorgio Tuinfort |

| The Black Eyed Peas singles chronology |

| "Don't Stop the Party" (2011) | "#WHERESTHELOVE" (2016) | "Street Livin'" (2018) |

| "Don't Stop the Party" (2011) | "#WHERESTHELOVE" (2016) | "Street Livin'" (2018) |

| Music video |

| "#WHERESTHELOVE" on YouTube |

On August 31, 2016, a new version of the song titled "#WHERESTHELOVE" credited to "The Black Eyed Peas featuring The World" was made available for digital download exclusively on iTunes and released to other digital retailers later that day.[64] The song samples the original track but has additional music composition and features additional vocals from Justin Timberlake, Jamie Foxx, Ty Dolla $ign, Mary J. Blige, Diddy, Cassie, Andra Day, The Game, Tori Kelly, V. Bozeman, Jessie J, French Montana, DJ Khaled, Usher, Nicole Scherzinger, ASAP Rocky, Jaden Smith and a 40-member children's choir.[65] All proceeds from the song will go to will.i.am's non-profit foundation, i.am.angel. – the charity funds educational programs and college scholarships.[66] The Black Eyed Peas partnered with issues-driven media company ATTN and foundation education partner and leading geospatial company Esri for the single release campaign.[64]

Music video[edit]

An accompanying music video, directed by Michael Jurkovac, also premiered worldwide on Apple Music that same day and shows appearances by the featured vocalists and many celebrities including Connie Britton, Lance Bass, Rosario Dawson, Shailene Woodley, Taye Diggs, Kareem Abdul-Jabbar, Quincy Jones, Olivia Munn, Jhené Aiko, Krewella, Wiz Khalifa, Charlie Carver, Ian Harding, Max Carver, Daniel Sharman, Vanessa Hudgens, Carla Gugino, DJ Khaled, Ben Barnes, Nikki Reed, Bridgit Mendler, Jessica Szohr, Snoop Dogg, LL Cool J, Kris Jenner and Kendall Jenner. .[65][67][68][69]

Inspired by tragedies, like the attacks in Paris, and in Brussells and Orlando, and police shootings of Philando Castile and Alton Sterling, the Peas saw the relevance of the song and decided it was time to revive the track for a new generation.[70] Family members affected by gun violence including (Alton Sterling's aunt Sandra, Philando Castile's mother Valerie) and police officials (Dallas Police Chief David O. Brown, Officer Miguel Salcedo, and more appear in the video.

Track listing[edit]

Digital download[71]

"#WHERESTHELOVE" (featuring The World) – 5:25

Personnel[edit]

Credits adapted from the official press release.[64]

Produced by will.i.am and Giorgio Tuinfort

Instruments and Programming by Giorgio Tuinfort and will.i.am

Mixed by will.i.am and Joe Peluso

Mastered by Joe Bozzi

Written by will.i.am, apl.de.ap, Taboo, Justin Timberlake, The Game, ASAP Rocky, DJ Khaled and Giorgio Tuinfort

Instruments and Programming by Giorgio Tuinfort and will.i.am

Piano by Giorgio Tuinfort

First Violin by Ben Mathot, Inger van Vliet, Marleen Wester, Tseroeja van den Bos and Sofie van der Pol

Second Violin by Judith van Driel, Loes Dooren, Diewertje Wanders and Azra Dizdar

Alt Violin by Ian de Jong, Yanna Pelser, Bas Goossens

Cello by David Faber and Jascha Bordon

Bass by Hinse Mutter

Horns by Jenneke de Jonge

Trumpet by Printz Board

Orchestra Midi Programming by Franck van der Heijden

Orchestra Arrangement by Franck van der Heijden and Giorgio Tuinfort

Orchestra recorded and mixed by Paul Power

Vocals recorded by will.i.am and padraic kerin

Main and additional vocals by The Black Eyed Peas, Justin Timberlake, Jamie Foxx, Ty Dolla $ign, Mary J. Blige, Diddy, Cassie, Andra Day, The Game, Tori Kelly, V. Bozeman, Jessie J, French Montana, DJ Khaled, Usher, Nicole Scherzinger, ASAP Rocky, Jaden Smith and a 40-member children's choir.

Charts[edit]

| Chart (2016) | Peak position |

| Australia (ARIA)[72] | 15 |

| Australia Digital Track Chart (ARIA)[73] | 5 |

| Belgium (Ultratip Flanders)[74] | 12 |

| Belgium Urban (Ultratop Flanders)[75] | 15 |

| Belgium (Ultratip Wallonia)[76] | 6 |

| Canadian Digital Songs (Billboard)[77] | 21 |

| Euro Digital Songs (Billboard)[78] | 14 |

| Finland Download (Latauslista)[79] | 12 |

| France (SNEP)[80] | 26 |

| Germany (Official German Charts)[81] | 39 |

| Luxembourg Digital Songs (Billboard)[82] | 5 |

| Netherlands (Dutch Top 40 Tip)[83] | 28 |

| New Zealand Heatseekers (Recorded Music NZ)[84] | 3 |

| Scotland (Official Charts Company)[85] | 11 |

| Slovakia (Singles Digitál Top 100)[86] | 58 |

| Spain (PROMUSICAE)[87] | 14 |

| Switzerland (Schweizer Hitparade)[88] | 41 |

| UK Singles (Official Charts Company)[89] | 47 |

| UK Download (Official Charts Company)[90] | 11 |

| US Digital Songs (Billboard)[91] | 39 |

| US Pop Digital Songs (Billboard)[92] | 20 |

2016 Spanish/English version[edit]

The Black Eyed Peas also released a bilingual Spanish/English version of "#WHERESTHELOVE", titled "#DóndeEstáElAmor?" crediting The Black Eyed Peas featuring El Mundo. The version was premiered on November 7, 2016, during Premios de la Radio. The music video premiered days later, featuring a roster of Latin stars including Gerardo Ortiz, Milkman, Pepe Aguilar, Becky G, Fey, Paulina Rubio, Luis Coronel and many others.[93]

References[edit]

Jump up ^ "Review: Black Eyed Peas: Where Is The Love? - Culture and Youth Studies". 26 January 2014. Retrieved 21 August 2017. 

Jump up ^ "The Black Eyed Peas - Biography - Billboard". 

Jump up ^ "Where Is the Love? - The Black Eyed Peas,Justin Timberlake - Song Info - AllMusic". 

Jump up ^ "Road to the Grammys: The Making of Black Eyed Peas' 'Where Is the Love'". MTV News. March 2, 2004. Retrieved September 2, 2016. 

Jump up ^ "2004 Grammy Nominees". MTV. Archived from the original on May 2, 2015. Retrieved June 21, 2015. 

Jump up ^ Moss, Corey (2004-02-04). "Road To The Grammys: The Making Of Black Eyed Peas' 'Where Is The Love' - Music, Celebrity, Artist News". MTV. Retrieved 2012-01-12. 

Jump up ^ Grein, Paul (2009-04-08). "Week Ending April 5, 2009: A Prince Beats A King (Of Pop) | Chart Watch - Yahoo! Music". New.music.yahoo.com. Retrieved 2012-01-12. 

^ Jump up to: a b Radio 1 Chart of the Decade, as presented by DJ Nihal on December 29, 2009

Jump up ^ "Australian-charts.com – The Black Eyed Peas – Where Is The Love?". ARIA Top 50 Singles.

Jump up ^ "Austriancharts.at – The Black Eyed Peas – Where Is The Love?" (in German). Ö3 Austria Top 40.

Jump up ^ "Ultratop.be – The Black Eyed Peas – Where Is The Love?" (in Dutch). Ultratop 50.

Jump up ^ "Ultratop.be – The Black Eyed Peas – Where Is The Love?" (in French). Ultratop 50.

Jump up ^ "Black Eyed Peas Chart History (Canadian Hot 100)". Billboard.

Jump up ^ "Danishcharts.com – The Black Eyed Peas – Where Is The Love?". Tracklisten.

Jump up ^ "Black Eyed Peas – Chart history" European Hot 100 for Black Eyed Peas.

Jump up ^ "Lescharts.com – The Black Eyed Peas – Where Is The Love?" (in French). Les classement single.

Jump up ^ "Musicline.de – The Black Eyed Peas Single-Chartverfolgung" (in German). Media Control Charts. PhonoNet GmbH.

Jump up ^ "Archívum – Slágerlisták – MAHASZ" (in Hungarian). Single (track) Top 40 lista. Magyar Hanglemezkiadók Szövetsége.

Jump up ^ "Archívum – Slágerlisták – MAHASZ" (in Hungarian). Dance Top 40 lista. Magyar Hanglemezkiadók Szövetsége.

Jump up ^ "Chart Track: Week 36, 2003". Irish Singles Chart.

Jump up ^ "Italiancharts.com – The Black Eyed Peas – Where Is The Love?". Top Digital Download.

Jump up ^ "Nederlandse Top 40 – week 40, 2003" (in Dutch). Dutch Top 40

Jump up ^ "Charts.org.nz – The Black Eyed Peas – Where Is The Love?". Top 40 Singles.

Jump up ^ "Norwegiancharts.com – The Black Eyed Peas – Where Is The Love?". VG-lista.

Jump up ^ "Nielsen Music Control". Archived from the original on 2007-10-24. 

Jump up ^ Romanian Top 100: Editia 1, saptamina 5.01 - 11.01, 2004

Jump up ^ "Official Scottish Singles Sales Chart Top 100". Official Charts Company.

Jump up ^ "Spanishcharts.com – The Black Eyed Peas – Where Is The Love?" Canciones Top 50.

Jump up ^ "Swedishcharts.com – The Black Eyed Peas – Where Is The Love?". Singles Top 100.

Jump up ^ "Swisscharts.com – The Black Eyed Peas – Where Is The Love?". Swiss Singles Chart.

Jump up ^ "Official Singles Chart Top 100". Official Charts Company.

Jump up ^ "Black Eyed Peas Chart History (Hot 100)". Billboard.

Jump up ^ "Black Eyed Peas Chart History (Adult Pop Songs)". Billboard.

Jump up ^ "Black Eyed Peas Chart History (Dance Club Songs)". Billboard.

Jump up ^ "Black Eyed Peas Chart History (Hot R&B/Hip-Hop Songs)". Billboard.

Jump up ^ "Black Eyed Peas Chart History (Hot Rap Songs)". Billboard.

Jump up ^ "Black Eyed Peas Chart History (Pop Songs)". Billboard.

Jump up ^ "Black Eyed Peas Chart History (Rhythmic)". Billboard.

Jump up ^ "Black Eyed Peas: Artist Chart History". Official Charts Company.

Jump up ^ "Official Singles Chart Top 40". Official Charts Company. Retrieved 2017-06-10. 

Jump up ^ "2003 Australian Singles Chart". aria. Retrieved May 2, 2010. 

Jump up ^ "2003 Austrian Singles Chart" (in German). Austriancharts. Archived from the original on September 11, 2012. Retrieved May 2, 2010. 

Jump up ^ "2003 Belgian (Flanders) Singles Chart" (in Dutch). Ultratop. Retrieved May 2, 2010. 

Jump up ^ "Single top 100 over 2003" (PDF) (in Dutch). Top40. Retrieved May 2, 2010. 

Jump up ^ "2003 French Singles Chart" (in French). SNEP. Retrieved May 2, 2010. 

Jump up ^ "German Top 20 - The Chart Of 2003" (in German). ki.informatik.uni-wuerzburg.de. Retrieved July 13, 2014. 

Jump up ^ "2003 Irish Singles Chart". IRMA. Retrieved May 2, 2010. 

Jump up ^ "I singoli più venduti del 2003" (in Italian). Hit Parade Italia. Retrieved July 13, 2014. 

Jump up ^ "2003 New Zealand Singles Chart". Rianz. Archived from the original on July 22, 2010. Retrieved May 2, 2010. 

Jump up ^ "Årslista Singlar - År 2003" (in Swedish). hitlistan.se. Archived from the original on April 2, 2015. Retrieved July 13, 2014. 

Jump up ^ "2003 Swiss Singles Chart" (in German). Swisscharts. Retrieved May 2, 2010. 

Jump up ^ "2003 UK Singles Chart" (PDF). ChartsPlus. Retrieved May 2, 2010. 

Jump up ^ "Top 100 Songs of 2003 - Billboard Year End Charts". Bobborst. Bobborst. Retrieved 18 March 2016. 

Jump up ^ "Die ultimative Chart Show | Hits des neuen Jahrtausends | Download". RTL.de. Retrieved 2012-01-12. 

Jump up ^ "ARIA Charts – Accreditations – 2014 Singles". Australian Recording Industry Association. Retrieved January 23, 2015. 

Jump up ^ "Ultratop − Goud en Platina – 2003". Ultratop. Hung Medien. Retrieved January 23, 2015. 

Jump up ^ "Gold-/Platin-Datenbank (Black Eyed Peas; 'Where Is The Love?')" (in German). Bundesverband Musikindustrie. Retrieved January 23, 2015. 

Jump up ^ "Italian single certifications – Black Eyed Peas – Where Is The Love?" (in Italian). Federazione Industria Musicale Italiana. Retrieved September 18, 2017. 

Jump up ^ "Trofeer" (in Norwegian). Archived from the original on July 22, 2011. Retrieved January 23, 2015. 

Jump up ^ "The Official New Zealand Music Chart". 

Jump up ^ "British single certifications – Black Eyed Peas – Where Is The Love?". British Phonographic Industry. Retrieved January 23, 2015.  Enter Where Is The Love? in the search field and then press Enter.

Jump up ^ Copsey, Rob (September 19, 2017). "The UK's Official Chart 'millionaires' revealed". Official Charts Company. Retrieved October 16, 2017. 

Jump up ^ "American single certifications – Black Eyed Peas – Where Is The Love". Recording Industry Association of America. Retrieved January 23, 2015.  If necessary, click Advanced, then click Format, then select Single, then click SEARCH

^ Jump up to: a b c "Black Eyed Peas Reunite for "#WHERESTHELOVE" Launching Appeal to Stop Shootings and Violence". iamangelfoundation.org. September 1, 2016. Archived from the original on September 13, 2016. 

^ Jump up to: a b "Black Eyed Peas reunite to update 'Where Is The Love'". Entertainment Weekly. September 1, 2016. Retrieved September 1, 2016. 

Jump up ^ "Black Eyed Peas Reunite for Anti-Gun Violence Song". Billboard. August 31, 2016. Retrieved September 1, 2016. 

Jump up ^ "The Black Eyed Peas - #WHERESTHELOVE ft. The World". YouTube. Retrieved September 2, 2016. 

Jump up ^ "Black Eyed Peas remixe "Where Is The Love?" avec Justin Timberlake, Usher.." (in French). NJR. August 31, 2016. Retrieved August 31, 2016. 

Jump up ^ "#WHERESTHELOVE". www.wheresthelove.com. Retrieved 2016-12-26. 

Jump up ^ "Watch the All-Star Remake of Black Eyed Peas' '#WHERESTHELOVE'". Rap-Up. August 31, 2016. Retrieved September 1, 2016. 

Jump up ^ "#WHERESTHELOVE (feat. The World) - Single by The Black Eyed Peas on iTunes". Apple Inc. Retrieved August 31, 2016. 

Jump up ^ "[http://www.australian-charts.com/showitem.asp?interpret=The+Black+Eyed+Peas+feat.+The+World&titel=

Wheresthelove&cat=s Australian-charts.com – The Black Eyed Peas feat. The World – #Wheresthelove"]. ARIA Top 50 Singles. Retrieved September 10, 2016.

Jump up ^ "ARIA Australian Top 40 Digital Tracks - ARIA Charts". ARIA Charts. September 10, 2016. Archived from the original on September 13, 2016. 

Jump up ^ "[http://www.ultratop.be/nl/showitem.asp?interpret=The+Black+Eyed+Peas+feat.+The+World&titel=

Wheresthelove&cat=s Ultratop.be – The Black Eyed Peas feat. The World – #Wheresthelove"] (in Dutch). Ultratip. Retrieved October 1, 2016.

Jump up ^ "[http://www.ultratop.be/nl/showitem.asp?interpret=The+Black+Eyed+Peas+feat.+The+World&titel=

Wheresthelove&cat=s Ultratop.be – The Black Eyed Peas feat. The World – #Wheresthelove"] (in Dutch). Ultratop Urban. Retrieved September 17, 2016.

Jump up ^ "[http://www.ultratop.be/fr/showitem.asp?interpret=The+Black+Eyed+Peas+feat.+The+World&titel=

Wheresthelove&cat=s Ultratop.be – The Black Eyed Peas feat. The World – #Wheresthelove"] (in French). Ultratip. Retrieved October 1, 2016.

Jump up ^ "Hot Canadian Digital Songs: September 24, 2016". Billboard. Retrieved September 13, 2016. 

Jump up ^ "Euro Digital Songs: September 17, 2016". Billboard. Retrieved September 13, 2016.  (subscription required)

Jump up ^ "The Black Eyed Peas: #wheresthelove (Feat. The World)" (in Finnish). Musiikkituottajat – IFPI Finland. Retrieved September 14, 2016.

Jump up ^ "[http://www.lescharts.com/showitem.asp?interpret=The+Black+Eyed+Peas+feat.+The+World&titel=

Wheresthelove&cat=s Lescharts.com – The Black Eyed Peas feat. The World – #Wheresthelove"] (in French). Les classement single. Retrieved September 17, 2016.

Jump up ^ "Offizielle Deutsche Charts - Black Eyed Peas - Where Is The Love". Offiziellecharts.de. September 9, 2016. Retrieved September 13, 2016. 

Jump up ^ "Luxembourg Digital Songs: September 17, 2016". Billboard. Retrieved September 13, 2016.  (subscription required)

Jump up ^ "Tipparade-Iijst van week 37, 2016" (in Dutch). Dutch Top 40. September 10, 2016. Retrieved September 14, 2016. 

Jump up ^ "NZ Heatseekers Singles Chart". Recorded Music NZ. September 12, 2016. Retrieved September 9, 2016. 

Jump up ^ "Official Scottish Singles Sales Chart Top 100". Official Charts Company. Retrieved September 10, 2016.

Jump up ^ "SNS IFPI" (in Slovak). Hitparáda – Singles Digital Top 100 Oficiálna. IFPI Czech Republic. Note: insert 201636 into search. Retrieved September 12, 2016.

Jump up ^ "[http://www.spanishcharts.com/showitem.asp?interpret=The+Black+Eyed+Peas+feat.+The+World&titel=

Wheresthelove&cat=s Spanishcharts.com – The Black Eyed Peas feat. The World – #Wheresthelove"] Canciones Top 50. Retrieved September 16, 2016.

Jump up ^ "[http://www.swisscharts.com/showitem.asp?interpret=The+Black+Eyed+Peas+feat.+The+World&titel=

Wheresthelove&cat=s Swisscharts.com – The Black Eyed Peas feat. The World – #Wheresthelove"]. Swiss Singles Chart. Retrieved September 11, 2016.

Jump up ^ "Official Singles Chart Top 100". Official Charts Company. Retrieved September 10, 2016.

Jump up ^ "Official Singles Downloads Chart Top 100". Official Charts Company. Retrieved September 10, 2016.

Jump up ^ "Hot Digital Songs: September 24, 2016". Billboard. Retrieved September 13, 2016.  (subscription required)

Jump up ^ "Pop Digital Songs: September 24, 2016". Billboard. Retrieved September 13, 2016.  (subscription required)

Jump up ^ "Watch Black Eyed Peas' 'Donde Esta el Amor' Music Video Feat. Gerardo Ortiz, Becky G & More". Retrieved 21 August 2017. 

External links[edit]

Lyrics of this song at MetroLyrics

#WHERESTHELOVE ft. The World (2016) on YouTube

| [show] v t e The Black Eyed Peas |

| will.i.am apl.de.ap Taboo Fergie Kim Hill Dante Santiago DJ Motiv8 Mookie Mook Sierra Swan |

| Studio albums | Behind the Front Bridging the Gap Elephunk Monkey Business The E.N.D. The Beginning |

| Singles | "Fallin' Up/¿Que Dices?" "Joints & Jam" "Karma" "BEP Empire/Get Original "Weekends" "Request + Line" "Where Is the Love?" "Shut Up" "Hey Mama" "Let's Get It Started" "Don't Phunk with My Heart" "Don't Lie" "My Humps" "Pump It" "Boom Boom Pow" "I Gotta Feeling" "Meet Me Halfway" "Imma Be" "Rock That Body" "Missing You" "The Time (Dirty Bit)" "Just Can't Get Enough" "Don't Stop the Party" |

| Promotional singles | "Bebot" "Alive" "Do It Like This" "Light Up the Night" "Yesterday" |

| Featured singles | "Mas que Nada" |

| Compilation albums | Renegotiations: The Remixes The E.N.D. Summer 2010 Canadian Invasion Tour: Remix Collection |

| Video albums | Behind the Bridge to Elephunk Live from Sydney to Vegas |

| Tours | Monkey Business Tour Honda Civic Tour Black Blue & You Tour The E.N.D World Tour The Beginning Massive Stadium Tour |

| Related articles | Discography Atban Klann The Black Eyed Peas Experience Black Eyed Peas Present: Masters of the Sun ― The Zombie Chronicles |

| Book Category |

| [show] v t e Best-selling singles by year in the United Kingdom |

| 1952–1969 | 1952: "Auf Wiederseh'n Sweetheart" – Vera Lynn (UK) 1953: "I Believe" – Frankie Laine 1954: "Secret Love" – Doris Day 1955: "Rose Marie" – Slim Whitman 1956: "I'll Be Home" – Pat Boone 1957: "Diana" – Paul Anka 1958: "Jailhouse Rock" – Elvis Presley 1959: "Living Doll" – Cliff Richard (UK) 1960: "It's Now or Never" – Elvis Presley 1961: "Wooden Heart" – Elvis Presley 1962: "I Remember You" – Frank Ifield (UK) 1963: "She Loves You" – The Beatles (UK) 1964: "Can't Buy Me Love" – The Beatles (UK) 1965: "Tears" – Ken Dodd (UK) 1966: "Green, Green Grass of Home" – Tom Jones (UK) 1967: "Release Me" – Engelbert Humperdinck (UK) 1968: "Hey Jude" – The Beatles (UK) 1969: "Sugar, Sugar" – The Archies |

| 1970–1989 | 1970: "The Wonder of You" – Elvis Presley 1971: "My Sweet Lord" – George Harrison (UK) 1972: "Amazing Grace" – The Royal Scots Dragoon Guards Band (UK) 1973: "Tie a Yellow Ribbon Round the Ole Oak Tree" – Tony Orlando and Dawn 1974: "Tiger Feet" – Mud (UK) 1975: "Bye Bye Baby" – Bay City Rollers (UK) 1976: "Save Your Kisses for Me" – Brotherhood of Man (UK) 1977: "Mull of Kintyre" / "Girls' School" – Wings (UK) 1978: "Rivers of Babylon" / "Brown Girl in the Ring" – Boney M. 1979: "Bright Eyes" – Art Garfunkel 1980: "Don't Stand So Close to Me" – The Police (UK) 1981: "Don't You Want Me" – The Human League (UK) 1982: "Come On Eileen" – Dexys Midnight Runners (UK) 1983: "Karma Chameleon" – Culture Club (UK) 1984: "Do They Know It's Christmas?" – Band Aid (UK) 1985: "The Power of Love" – Jennifer Rush 1986: "Don't Leave Me This Way" – The Communards (UK) 1987: "Never Gonna Give You Up" – Rick Astley (UK) 1988: "Mistletoe and Wine" – Cliff Richard (UK) 1989: "Ride on Time" – Black Box |

| 1990–2009 | 1990: "Unchained Melody" – The Righteous Brothers 1991: "(Everything I Do) I Do It for You" – Bryan Adams 1992: "I Will Always Love You" – Whitney Houston 1993: "I'd Do Anything for Love (But I Won't Do That)" – Meat Loaf 1994: "Love Is All Around" – Wet Wet Wet (UK) 1995: "Unchained Melody" – Robson & Jerome (UK) 1996: "Killing Me Softly" – Fugees 1997: "Something About the Way You Look Tonight" / "Candle in the Wind 1997" – Elton John (UK) 1998: "Believe" – Cher 1999: "...Baby One More Time" – Britney Spears 2000: "Can We Fix It?" – Bob the Builder (UK) 2001: "It Wasn't Me" – Shaggy featuring Rikrok (UK) 2002: "Anything Is Possible" / "Evergreen" – Will Young (UK) 2003: "Where Is the Love?" – The Black Eyed Peas 2004: "Do They Know It's Christmas?" – Band Aid 20 (UK) 2005: "Is This the Way to Amarillo" – Tony Christie featuring Peter Kay (UK) 2006: "Crazy" – Gnarls Barkley 2007: "Bleeding Love" – Leona Lewis (UK) 2008: "Hallelujah" – Alexandra Burke (UK) 2009: "Poker Face" – Lady Gaga |

| 2010–present | 2010: "Love the Way You Lie" – Eminem featuring Rihanna 2011: "Someone Like You" – Adele (UK) 2012: "Somebody That I Used to Know" – Gotye featuring Kimbra 2013: "Blurred Lines" – Robin Thicke featuring T.I. & Pharrell Williams 2014: "Happy" – Pharrell Williams 2015: "Uptown Funk" – Mark Ronson (UK) featuring Bruno Mars 2016: "One Dance" – Drake featuring Wizkid and Kyla (UK) 2017: "Shape of You" - Ed Sheeran (UK) |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Where_Is_the_Love%3F&oldid=819481709"

Categories:

2000s ballads

2010s ballads

2003 singles

2003 songs

2016 singles

2016 songs

A&M Records singles

Anti-war songs

Billboard Mainstream Top 40 (Pop Songs) number-one singles

Charity singles

Dutch Top 40 number-one singles

European Hot 100 Singles number-one singles

Interscope Records singles

Irish Singles Chart number-one singles

Justin Timberlake songs

Number-one singles in Australia

Number-one singles in Austria

Number-one singles in Denmark

Number-one singles in Germany

Number-one singles in Norway

Number-one singles in Poland

Number-one singles in Romania

Number-one singles in Sweden

Number-one singles in Switzerland

UK Singles Chart number-one singles

Pop ballads

Protest songs

Rhythm and blues ballads

Song recordings produced by Ron Fair

Song recordings produced by will.i.am

Songs about the media

Songs against racism and xenophobia

Songs of the Iraq War

Songs written by apl.de.ap

Songs written by George Pajon

Songs written by Ron Fair

Songs written by Taboo (rapper)

Songs written by will.i.am

The Black Eyed Peas songs

Ultratop 50 Singles (Flanders) number-one singles

Hidden categories:

CS1 German-language sources (de)

CS1 Dutch-language sources (nl)

CS1 French-language sources (fr)

CS1 Italian-language sources (it)

CS1 Swedish-language sources (sv)

CS1 Norwegian-language sources (no)

Pages containing links to subscription-only content

Articles with hAudio microformats

Singlechart usages for Australia

Singlechart usages for Austria

Singlechart usages for Flanders

Singlechart usages for Wallonia

Singlechart usages for Canada

Singlechart called without song

Singlechart usages for Denmark

Singlechart usages for Billboardeuropeanhot100

Singlechart usages for France

Singlechart usages for Germany

Singlechart usages for Hungarytop10

Singlechart called without artist

Singlechart usages for Hungarydance

Singlechart usages for Ireland

Singlechart usages for Italy

Singlechart usages for Dutch40

Singlechart usages for New Zealand

Singlechart usages for Norway

Singlechart usages for Scotland

Singlechart usages for Spain

Singlechart usages for Sweden

Singlechart usages for Switzerland

Singlechart usages for UK

Singlechart usages for Billboardhot100

Singlechart usages for Billboardadultpopsongs

Singlechart usages for Billboarddanceclubplay

Singlechart usages for Billboardrandbhiphop

Singlechart usages for Billboardrapsongs

Singlechart usages for Billboardpopsongs

Singlechart usages for Billboardrhythmic

Singlechart usages for UKchartstats

Certification Table Entry usages for Australia

Certification Table Entry usages for Belgium

Certification Table Entry usages for Germany

Certification Table Entry usages for Italy

Certification Table Entry usages for Norway

Certification Table Entry usages for New Zealand

Certification Table Entry usages for United Kingdom

Certification Table Entry usages for United States

Singlechart making named ref

Singlechart usages for Flanders Tip

Singlechart usages for Flanders Urban

Singlechart usages for Wallonia Tip

Singlechart usages for Finnishdownload

Singlechart usages for Slovakdigital

Singlechart usages for UKdownload

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Deutsch

Eesti

Español

فارسی

Français

Bahasa Indonesia

Italiano

Lietuvių

Nederlands

Polski

Português

Русский

Slovenčina

Svenska

Türkçe

Tiếng Việt

Edit links

 This page was last edited on 9 January 2018, at 16:29.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews