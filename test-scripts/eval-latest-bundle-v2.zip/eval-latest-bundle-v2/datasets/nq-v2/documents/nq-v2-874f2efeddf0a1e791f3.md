# Kal Ho Naa Ho (song)

Kal Ho Naa Ho (song) - Wikipedia

Kal Ho Naa Ho (song)

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| "Kal Ho Naa Ho" |

| Single by Sonu Nigam |

| from the album Kal Ho Naa Ho soundtrack |

| Released | 27 September 2003 (India) |

| Genre | Romance |

| Length | 5:23 |

| Label | Sony Music |

| Songwriter(s) | Shankar-Ehsaan-Loy (music) Javed Akhtar (lyrics) |

| Producer(s) | Karan Johar |

| Audio sample |

| file help |

Kal Ho Naa Ho (Hindi: कल हो ना हो, English: Tomorrow May Never Come) is a Hindi song from the 2003 Hindi film Kal Ho Naa Ho directed by Nikhil Advani. The song is one of the most popular Hindi film songs all time. The song was composed by Shankar-Ehsaan-Loy with lyrics penned by Javed Akhtar and sung by Sonu Nigam. It quickly became popular upon release. There is also a sad version of the song in the film on which Sonu Nigam is joined by Alka Yagnik and Richa Sharma.

Sonu Nigam was busy when the song was to be recorded. Instead of opting for some other singer, Karan Johar decided to wait for a month before Sonu came back and recorded the song for the movie[1] The song was featured in Outlook's list of Bollywood's Timeless Melodies, making it the only contemporary selection on the list.[2]

Contents
 [hide] 

1 About the song

2 Legacy

3 Awards

4 References

About the song[edit]

The theme of the song was composed by Loy Mendonsa of the Shankar-Ehsaan-Loy trio[3] and Shankar Mahadevan arranged the groove.[4]

In a later interview in the documentary "Pancham unmixed", Shankar, Ehsaan and Loy revealed that the music of the segment "har pal yahaan" in the song was inspired by the music of R.D.Burman.[5]

Legacy[edit]

The song was featured in Outlook magazine's 20 Best Hindi Film Songs Ever list. The jury was composed of celebrities such as Gulzar, Hariharan, Javed Akhtar, Kumar Sanu and Shantanu Moitra. Each jury member was asked to nominate 10 favorites and the songs the winners were ranked according to the number of votes each song got. "Kal Ho Naa Ho" was ranked at 19 making it the only contemporary selection in the list.[6]

The track was featured in Hindustan Times's "Song of the Century" list, which described the song as "one of the most unforgettable tunes in recent times."[7]

Awards[edit]

National Film Award for Best Male Playback Singer - Sonu Nigam

IIFA Best Male Playback Award - Sonu Nigam

Filmfare Best Male Playback Award - Sonu Nigam

IIFA Best Lyricist Award - Javed Akhtar

Filmfare Best Lyricist Award - Javed Akhtar

References[edit]

Jump up ^ "I Don't Want to Sing 'Crap' in Bollywood: Sonu Nigam". 

Jump up ^ "Shankar Ehsaan Loy still making waves for Kal Ho Na Ho". Bollywood Hungama. Retrieved July 1, 2006. 

Jump up ^ "I have to compliment Himesh. If we have 2 hits a year, he has 20". Bollywood Hungama. Retrieved March 24, 2006. [permanent dead link]

Jump up ^ Rajeev, Masand. "To Catch a Star: Shankar, Ehsaan, Loy on music, masti". CNN IBN. Retrieved Mar 31, 2008. 

Jump up ^ Singh, Brahmanand S. "Pancham unmixed - a documentary about R.D.Burman".  Missing or empty |url= (help); |access-date= requires |url= (help)

Jump up ^ "20 Best Hindi Film Songs Ever". Outlook. Retrieved June 26, 2006. 

Jump up ^ "Songs of the Century - Hindustan Times". 2012-08-20. Archived from the original on 2012-08-04. Retrieved 2012-08-20. this song one of the most unforgettable tunes in recent times. 

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Kal_Ho_Naa_Ho_(song)&oldid=829528571"

Categories:

Indian songs

Hindi film songs

Songs with music by Shankar–Ehsaan–Loy

Songs with lyrics by Javed Akhtar

Sonu Nigam songs

Music videos featuring Shah Rukh Khan

Hidden categories:

All articles with dead external links

Articles with dead external links from May 2017

Articles with permanently dead external links

Pages using web citations with no URL

Pages using citations with accessdate and no URL

Articles with hAudio microformats

Articles containing Hindi-language text

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Bahasa Indonesia

Edit links

 This page was last edited on 9 March 2018, at 05:10.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews