# Sorry, Wrong Number

Sorry, Wrong Number - Wikipedia

Sorry, Wrong Number

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| Sorry, Wrong Number |

| Theatrical release poster |

| Directed by | Anatole Litvak |

| Produced by | Anatole Litvak Hal B. Wallis |

| Screenplay by | Lucille Fletcher |

| Based on | Sorry, Wrong Number 1943 the radio play by Lucille Fletcher |

| Starring | Barbara Stanwyck Burt Lancaster Ann Richards Wendell Corey |

| Music by | Franz Waxman |

| Cinematography | Sol Polito |

| Edited by | Warren Low |

| Production company | Hal Wallis Productions |

| Distributed by | Paramount Pictures |

| Release date | September 1, 1948 (1948-09-01) |

| Running time | 89 minutes |

| Country | United States |

| Language | English |

| Box office | $2,850,000 (US rentals)[1] |

Sorry, Wrong Number is a 1948 American thriller film noir directed by Anatole Litvak and starring Barbara Stanwyck and Burt Lancaster.[2] It tells the story of a woman who overhears a murder plot. The film was adapted by Lucille Fletcher from her 1943 radio play. It is one of the few pre-1950 Paramount Pictures films that remained in the studio's library (the rest are currently owned by Universal).[3]

Contents
 [hide] 

1 Plot

2 Cast

3 Production

4 Radio play

5 Adaptations

5.1 1950 Lux Radio Theatre Version

5.2 1946 TV Broadcast

5.3 1954 TV Broadcast

5.4 1958 Australian TV Version

5.5 1989 US TV Movie

5.6 1948 Radio Parody

6 Other media

7 See also

8 References

9 External links

9.1 Streaming audio

Plot[edit]

Leona Stevenson (Barbara Stanwyck) is the spoiled, bedridden daughter of wealthy businessman James Cotterell (Ed Begley). One day, while listening to what seems to be a crossed telephone connection, she hears two men planning a woman's murder. The call cuts off without Leona learning very much other than it is scheduled for 11:15 p.m., when a passing train will hide any sounds. She calls the telephone company and the police, but with few concrete details, they can do nothing. Complicating matters, her husband Henry (Lancaster) is overdue and their servants have the night off, leaving her all alone in a Manhattan apartment.

As she makes a number of phone calls trying to locate Henry, Leona inadvertently begins to piece together the mystery. The story is told mostly in flashbacks. When Leona reaches Henry's secretary, Elizabeth Jennings (Dorothy Neumann), she learns that he took an attractive Mrs. Lord to lunch and did not return to the office. Mrs. Lord turns out to be the former Sally Hunt (Ann Richards). Leona stole then-drug-store-employee Henry from Sally, and married him against her father's wishes. Sally is now the wife of Fred Lord (Leif Erickson), a lawyer in the district attorney's office. From overheard conversations, she learned that her husband was close to resolving an investigation that involves Henry somehow. Sally became so concerned that she followed her husband and two associates to a mysterious meeting in a seemingly abandoned house on Staten Island. The house, according to a "no trespassing" sign, belongs to a W. Evans. Sally arranged to meet Henry for lunch, but before she could warn him, he left the table and did not return. Later, Sally calls Leona with more news. The house on Staten Island has burned down, and three men, including someone named Morano (William Conrad), have been arrested. Waldo Evans (Harold Vermilyea), however, has escaped.

Leona then receives a message from Henry stating he has gone out of town on business he had forgotten about and will not be back until Sunday.

Leona next gets in touch with Dr. Alexander (Wendell Corey), a specialist she had come to New York to see regarding her lifelong heart troubles. Alexander reveals that he gave Henry her prognosis 10 days before, something that Henry kept from her. Henry had married Leona without being aware of her health problems. He first found out when she had a heart attack after they quarreled about his attempt to get a job on his own, rather than being a do-nothing vice president in his father-in-law's business. (James Cotterell, however, sabotaged his job interview.) Her attacks became more and more frequent, until she finally took to her bed about a year ago. Alexander, however, diagnosed Leona's problems as purely psychosomatic; nothing is wrong with her physically.

Leona has got into hysterics and phones a hospital, asking to hire a nurse for the night. The receptionist tells her that they are short staffed and she can only have a nurse if the doctor feels it isn't an emergency. She thinks it is only 11:00pm but discovers her clock has stopped, sending her into worse hysterics.

Then Leona receives a telephone call from Waldo Evans, a chemist working for her father. He reluctantly discloses that Henry recruited him to steal valuable chemicals from the Cotterell drug company to sell to Morano. Later, Henry decided to bypass Morano when Evans was transferred to the New Jersey plant. Morano, however, showed up with two thugs and intimidated Henry into signing an IOU for $200,000 for his lost profits, due in three months. When Henry protested that he did not have that much money, Morano pointed out that Leona must have a large insurance policy. However, with Morano now in custody, Evans stresses that Henry no longer has to raise the now-overdue sum. Waldo leaves Leona with a telephone number to call to locate Henry, but when she calls the number she discovers to her horror that it is for the city morgue.

When Henry finally calls from a train station in New Haven, Connecticut, Leona gives him Evans' message. Seeing that it is only minutes from 11:15, he pleads with her to go to the balcony and scream for help, but she protests that she cannot, though she can hear somebody downstairs. When the intruder enters her bedroom, she begs for her life, then screams. The intruder strangles and kills Leona. Unaware of the policemen about to apprehend him, Henry frantically calls back, only to have a man answer, "Sorry, wrong number."

Cast[edit]

Barbara Stanwyck as Leona Stevenson

Burt Lancaster as Henry J. Stevenson

Ann Richards as Sally Hunt Lord

Wendell Corey as Dr. Philip Salvador

Harold Vermilyea as Waldo Evans

Ed Begley as James Cotterell

Leif Erickson as Fred Lord

William Conrad as Morano

John Bromfield as Joe - Detective

Jimmy Hunt as Peter Lord

Dorothy Neumann as Elizabeth Ramsey

Paul Fierro as Harpootlian

Bill Cartledge as Page Boy (uncredited)

Holmes Herbert as Wilkins Mineral (uncredited)

Production[edit]

Sorry, Wrong Number conforms to many of the conventions of film noir. The movie plays in real time, with many flashbacks to flesh out the story. Stanwyck's bedroom window overlooks the night skyline of Manhattan. The film is shot very dark, with looming shadows and a circling camera used to maintain a high level of suspense.[4]

Hollywood's Production Code Administration initially objected to elements of Fletcher's screenplay, including its depiction of drug trafficking, and the script was significantly revised to win approval.[5]

For her role in the film, Stanwyck was nominated for the Academy Award for Best Actress.

Radio play[edit]

Lucille Fletcher's play originally aired on the Suspense radio program on May 25, 1943, essentially a one-woman show with Agnes Moorehead as Mrs. Stevenson. The play was reprised seven times, each starring Moorehead. The final broadcast was on February 14, 1960.

Orson Welles called Sorry, Wrong Number "the greatest single radio script ever written".[6]

In 2015, the May 25, 1943 broadcast was deemed "culturally, historically, or aesthetically significant" by the Library of Congress and selected for inclusion in the National Recording Registry.

Adaptations[edit]
1950 Lux Radio Theatre Version[edit]

Another radio version – an adaptation of the film – was broadcast January 9, 1950, on Lux Radio Theatre. Barbara Stanwyck recreated her screen role

1946 TV Broadcast[edit]

Sorry, Wrong Number was made into a television play broadcast on station WCBW-TV (now WCBS-TV) in New York on January 30, 1946, starring Mildred Natwick and G. Swayne Gordon.[7]

1954 TV Broadcast[edit]

A second live teleplay was broadcast on November 4, 1954, as the fourth episode of the CBS anthology series Climax!, starring Lillian Bronson, adapted by Fletcher herself, with music provided by her then-husband, Bernard Herrmann.[8]

1958 Australian TV Version[edit]

A version was produced for Australian television in 1958 starring Georgie Sterling.[9][10] Sterling had performed in the play on radio in 1948.[11]

1989 US TV Movie[edit]

Another television version aired in 1989, starring Loni Anderson, Patrick Macnee and Hal Holbrook. It was directed by Tony Wharmby and adapted by Ann Louise Bardach.[12]

1948 Radio Parody[edit]

On 17 October 1948, Stanwyck did a parody of Sorry, Wrong Number on The Jack Benny Program.[13]

Other media[edit]

Clips from Sorry, Wrong Number were used for the 1982 comedy-mystery Dead Men Don't Wear Plaid, the 1991 thriller Dead Again and the 2014 action-thriller Jack Ryan: Shadow Recruit. The latter two films were directed by Kenneth Branagh.

See also[edit]

List of films featuring home invasions

Real time

References[edit]

Jump up ^ "Top Grossers of 1948", Variety 5 January 1949 p 46

Jump up ^ "The 100 Best Film Noirs of All Time". Paste. August 9, 2015. Retrieved August 9, 2015. 

Jump up ^ Sorry, Wrong Number (1948) on IMDb.

Jump up ^ Eifert, Steve. Sorry, Wrong Number, film analysis and review, Film Noir of the Week, June 29, 2008. Accessed: July 12, 2013.

Jump up ^ Passafiume, Andrea. Turner Classic Movies, Sorry, Wrong Number, film article, "The Big Idea Behind Sorry, Wrong Number". Accessed: July 12, 2013.

Jump up ^ "The Hitch-Hiker". The Mercury Summer Theatre on the Air, June 21, 1946, (at 1:00), at the Internet Archive. Retrieved 2014-08-04. 

Jump up ^ Sorry, Wrong Number (1946) on IMDb.

Jump up ^ Sorry, Wrong Number (1954) on IMDb.

Jump up ^ Sorry, Wrong Number (1958) on IMDb

Jump up ^ "Western heroes revolt". The Australian Women's Weekly. 26, (2). Australia, Australia. 18 June 1958. p. 13. Retrieved 22 May 2016 – via National Library of Australia. 

Jump up ^ "NEW FEATURE FOR 2AD". The Armidale Express And New England General Advertiser (3488). New South Wales, Australia. 10 May 1948. p. 2. Retrieved 22 May 2016 – via National Library of Australia. 

Jump up ^ Sorry, Wrong Number (1989) on IMDb.

Jump up ^ Benny, Jack. The Old Time Radio Network, at the OTR.Network Library web site, December 8, 2011. Accessed: July 12, 2013.

External links[edit]

Sorry, Wrong Number at the American Film Institute Catalog

Sorry, Wrong Number on IMDb

Sorry, Wrong Number at AllMovie

Sorry, Wrong Number at the TCM Movie Database

Sorry, Wrong Number film trailer on YouTube

Streaming audio[edit]

Suspense and Lux Radio Theater broadcasts of Sorry, Wrong Number

Sorry, Wrong Number on Lux Radio Theater: January 9, 1950. Starring Barbara Stanwyck and Burt Lancaster.

| [hide] v t e Films directed by Anatole Litvak |

| Dolly Gets Ahead (1930) Calais-Dover (1931) No More Love (1931) The Song of Night (1932) Tell Me Tonight (1932) Sleeping Car (1933) Mayerling (1936) The Woman I Love (1937) Tovarich (1937) The Amazing Dr. Clitterhouse (1938) The Sisters (1938) Confessions of a Nazi Spy (1939) Castle on the Hudson (1940) All This, and Heaven Too (1940) City for Conquest (1940) Out of the Fog (1941) Blues in the Night (1941) This Above All (1942) The Long Night (1947) Sorry, Wrong Number (1948) The Snake Pit (1948) Decision Before Dawn (1951) Act of Love (1953) The Deep Blue Sea (1955) Anastasia (1956) Mayerling (1957) The Journey (1959) Goodbye Again (1961) Five Miles to Midnight (1962) The Night of the Generals (1967) The Lady in the Car with Glasses and a Gun (1970) |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Sorry,_Wrong_Number&oldid=821809130"

Categories:

1948 films

English-language films

1943 plays

1946 television plays

1940s psychological thriller films

American films

American black-and-white films

American thriller films

Film noir

Films scored by Franz Waxman

Films based on radio series

Films directed by Anatole Litvak

Films produced by Hal B. Wallis

Films set in New York City

Paramount Pictures films

Telephony in popular culture

United States National Recording Registry recordings

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Català

Deutsch

فارسی

Français

Italiano

עברית

Nederlands

日本語

Português

Русский

Suomi

Svenska

Türkçe

Українська

Edit links

 This page was last edited on 22 January 2018, at 19:30.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews