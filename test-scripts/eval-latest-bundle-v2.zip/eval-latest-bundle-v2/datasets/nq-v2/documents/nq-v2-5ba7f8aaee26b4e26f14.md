# List of extinct animals of the British Isles

List of extinct animals of the British Isles - Wikipedia

List of extinct animals of the British Isles

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| This article needs additional citations for verification. Please help improve this article by adding citations to reliable sources. Unsourced material may be challenged and removed. (May 2013) (Learn how and when to remove this template message) |

See also: List of endangered species of the British Isles

This is a list of extinct animals of the British Isles. Only a small number of these are globally extinct, most famously the Irish elk, great auk and woolly mammoth. Most of the remainder survive to some extent outside the islands. The list includes introduced species only in cases where they were able to form self-sustaining colonies for a time. Only species extinct since Great Britain was separated from mainland Europe are included. The date beside each species is the last date when a specimen was observed in the wild or, where this is not known, the approximate date of extinction. The list is complete for mammals, reptiles, freshwater fish and amphibians.

Contents
 [hide] 

1 Mammals[1]

2 Birds

3 Fish

4 Amphibians

5 Reptiles

6 Insects

6.1 Beetles

6.2 Bees, wasps and ants

6.3 Flies

6.4 Butterflies and moths

6.5 Dragonflies and damselflies

6.6 Caddisflies

7 Crustaceans

7.1 Molluscs

7.1.1 Land snails

8 Reintroduction and re-establishment

9 See also

10 References

11 Further reading

Mammals[1][edit]

Arctic lemming – c. 8000 BC

Arctic fox - c. (unknown)

†Eurasian aurochs – c. 1000 BC

Barbary macaque - c. 30,000 BC

†Cave bear – c. 15,000 BC

Coypu – 1978 (nonnative)

Elk Alces alces

Eurasian beaver – 1526 (reintroduced)

Eurasian brown bear – c. 1000 AD

Eurasian lynx – c. AD 400

Grey whale – c. 598 BC

Eurasian wolf – AD 1680 in Britain, AD 1786 in Ireland

†Irish elk – c. 6000 BC

Narrow-headed vole – c. 8000 BC

Steppe pika – c. 8000 BC

Root vole – c. 1500 BC

Saiga antelope – c. 10,000 BC

Steppe lemming – c. 8000 BC

†Tarpan – c. 7000 BC

Walrus – c. 1000 BC (Occasional Visitor) [2]

Wild Boar – c. 1400 (Reintroduced) [3]

Wisent – c. 3000 BC

Wolverine – c. 6000 BC

†Woolly mammoth – c. 10,000 BC

†Woolly rhinoceros – c. 10,000 BC

†Cave lion – c. 10,000 BC

†Scimitar cat - c. 30,000 BC[4]

†Cave hyena - c. 11,000 BC

†European jaguar - c. (unknown)

†European Ice Age leopard - c. 24,000 BC

†European gazelle - c. (unknown)

Birds[edit]

Fea's petrel – Iron Age

Dalmatian pelican – c. 1000 BC

Eurasian spoonbill – 15th century (re-established)

Little egret – late medieval period (re-established)

Osprey – 1916 (re-established)

White-tailed eagle – 1916 (reintroduced)

Western marsh harrier – late 19th century (re-established)

Northern goshawk – late 19th century (possibly reintroduced)

Western capercaillie – 1780s (reintroduced)

Great bustard – 19th century (reintroduced)

Common crane – late medieval period (now re-established)

Pied avocet – 19th century (re-established)

Kentish plover – 20th century (last breeding record 1979)[5]

†Great auk – 1844

White stork – 1416

Red-backed shrike – 1989 (as a regular breeding bird)

Wryneck (as a regular breeding bird)

Fish[edit]

†Houting

Burbot

Amphibians[edit]

Agile frog – c. 1000 AD

Moor frog – c. 1000 AD

European tree frog – 1986

Reptiles[edit]

European pond terrapin – ≤ 3000 BC

Insects[edit]
Beetles[edit]

Agonum sahlbergi (ground beetle) – 1914

Blue stag beetle – 19th century

Graphoderus bilineatus (water beetle) – 1906

Harpalus honestus (ground beetle) – 1905

Horned dung beetle – 1957

Ochthebius aeneus (water beetle) – 1913

Platydema violaceum (tenebrionid) – 1957

Rhantus aberratus (water beetle) – 1904

Scybalicus oblongiusculus (ground beetle) – 1926

Teretrius fabricii (histerid) – 1907

Bees, wasps and ants[edit]

Andrena polita (mining bee) – 1934

Bombus pomorum, apple bumblebee – 1864[6]

Bombus cullumanus, Cullum's bumblebee – 1941[6]

Eucera tuberculata (mining bee) – 1941

Halictus maculatus (mining bee) – 1930

Mellinus crabroneus (digger wasp) – c. 1950

Odynerus reniformis (mason wasp) – 1915

Odynerus simillimus (mason wasp) – 1905

Short-haired bumblebee – 1989[6]

Flies[edit]

Merodon clavipes

Butterflies and moths[edit]

General reference: Waring et al., 2009.[7]

Aporia crataegi, black-veined white – 1925

Borkhausenia minutella – 1950

Conformist (moth) –

Euclemensia woodiella (moth) – 1829

Flame brocade (moth) – 1919

Frosted yellow (moth) – 1914

Gypsy moth – 1907; reappeared 1995[8]

Isle of Wight wave (moth) – 1931

Large chequered skipper – c. 1989 (non-native, Channel Islands)

Large copper – 1865

Many-lined (moth) – 1875

Map – c. 1914 (non-native)

Mazarine blue – 1906

Orache moth – 1915

Reed tussock (moth) – 1875

Scarce black arches (moth) – 1898 (transitory resident)

Speckled beauty (moth) – 1898

Union rustic (moth) – 1919

Viper's bugloss (moth) –1969[9]

Dragonflies and damselflies[edit]

Norfolk damselfly – 1957

Orange-spotted emerald (dragonfly) – 1957

Caddisflies[edit]

Hydropsyche bulgaromanorum (caddis fly) – 1926

Hydropsyche exocellata (caddis fly) – 1901

Crustaceans[edit]

Artemia salina (brine shrimp) – after 1758[10][11]

Molluscs[edit]
Land snails[edit]

Fruticicola fruticum

Cernuella neglecta

† – Species is extinct worldwide

Reintroduction and re-establishment[edit]

Main article: Species reintroduction § United Kingdom

The white-tailed eagle has been successfully re-established on the west coast of Scotland.[12] Having clung on in parts of Wales[13], Red kites have been successfully re-established in parts of England and Scotland.[14] Ongoing projects involve both these species: the corncrake into parts of England and Scotland, and the great bustard on Salisbury Plain.

European beavers have been reintroduced to parts of Scotland, and there are plans to bring them back to other parts of Britain. A five-year trial reintroduction at Knapdale in Argyll started in 2009 and concluded in 2014.[15] A few hundred beavers live wild in the Tay river basin, as a result of escapes from a wildlife park.[16] A similar reintroduction trial is being undertaken on the River Otter in Devon, England.[17] In 2016, beavers were recognised as a British native species, and will be protected under law.[18]

In 2008, moose were released into a fenced reserve on the Alladale Estate in the Highlands of Scotland. Reindeer were re-established in 1952; approximately 150–170 reindeer live around the Cairngorms region in Scotland.

In 1998, MAFF, now known as DEFRA released a report concerning the presence of two populations of wild boar living freely in the UK[19]. These boar are thought to have escaped from wildlife parks, zoos and from farms where they are farmed for their meat, and gone on to establish breeding populations[20][21].

The northern clade pool frog was reintroduced from Swedish stock in 2005, to a single site in Norfolk, England, following detailed research to prove that it had been native prior to its extinction around 1993.

The large blue butterfly has been successfully re-established from Swedish stock at a number of sites, but few of these are open-access. There are also several successful cases of the establishment of new populations of heath fritillary.

There have been calls for the reintroduction of the lynx, brown bear and grey wolf to the UK.[22]

See also[edit]

List of mammals of the British Isles

Extinct animals from the Isle of Man

List of extinct animals of Europe

Introduced species of the British Isles

References[edit]

Jump up ^ Yalden, Derek (1999), History of British Mammals, London: T. & A.D. Poyser Ltd., ISBN 0-85661-110-7 

Jump up ^ http://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-21647421

Jump up ^ https://www.britishwildboar.org.uk/index.htm?britain.htm

Jump up ^ "The lost beasts that roamed Britain during the ice age". BBC. July 22, 2015. Retrieved 29 August 2017. 

Jump up ^ Bill Teale (2016-09-17). "Birdwatch: Rare appearance from Kentish plover". Yorkshire Post. Retrieved 26 May 2017. 

^ Jump up to: a b c Bumblebee superfacts, BugLife, retrieved January 23, 2013 

Jump up ^ Waring, P.; et al. (2009), Field Guide to the Moths of Great Britain and Ireland, Hook, Hampshire: British Wildlife Publishing, ISBN 0953139999 ; UK Moths, Ian Kimber https://ukmoths.org.uk/, retrieved January 23, 2013  Missing or empty |title= (help)

Jump up ^ Tilbury, Christine (March 2007), Gypsy Moth Advisory Note (PDF), Forest Research: Tree Health Division, retrieved 6 February 2014 

Jump up ^ "Viper's Bugloss Hadena irregularis – UK Moths", UK Moths, Ian Kimber, retrieved January 23, 2013 

Jump up ^ Gilbert Van Stappen (1996), "Artemia", in Patrick Lavens & Patrick Sorgeloos, Manual on the Production and Use of Live Food for Aquaculture, FAO Fisheries Technical Paper, 361, Rome: Food and Agriculture Organization, pp. 79–106, ISBN 978-92-5-103934-2 

Jump up ^ Geoffrey Fryer (2006), "The brine shrimp's tale: a topsy turvy evolutionary fable" (PDF), Biological Journal of the Linnean Society, 88 (3): 377–382, doi:10.1111/j.1095-8312.2006.00623.x 

Jump up ^ George Monbiot. "15 species that should be brought back to rewild Britain". the Guardian. Retrieved 20 December 2015. 

Jump up ^ "RSPB: Redkite Conservation". 

Jump up ^ "The RSPB: Red kite". The RSPB. Retrieved 20 December 2015. 

Jump up ^ "Commissioned Report No. 685 The Scottish Beaver Trial: Ecological monitoring of the European beaver Castor fiber and other riparian mammals 2009-2014, final report" (PDF). Retrieved 18 December 2016. 

Jump up ^ "Tay Beavers Origin". Scottish Wild Beavers. Retrieved 20 December 2015. 

Jump up ^ http://www.devonwildlifetrust.org/river-otter-beavers

Jump up ^ https://www.theguardian.com/environment/2016/nov/24/beavers-native-protected-species-status-reintroduction-scotland

Jump up ^ "Feral wild boar in England Status, impact and management A report on behalf of Defra European Wildlife Division" (PDF). National Archives. Department for Environment, Food and Rural Affairs. Archived from the original on 1 January 2007. Retrieved 26 October 2017. CS1 maint: BOT: original-url status unknown (link)

Jump up ^ "Feral wild boar in England Status, impact and management A report on behalf of Defra European Wildlife Division" (PDF). Archived from the original on 1 January 2007. Retrieved 26 October 2017. CS1 maint: BOT: original-url status unknown (link)

Jump up ^ "Wild Boar". The British Association for Shooting and Conservation. BASC. Retrieved 26 October 2017. 

Jump up ^ "Call for lynx and wolf reintroduction". BBC News. 15 July 2015. Retrieved 20 December 2015. 

| This article needs additional citations for verification. Please help improve this article by adding citations to reliable sources. Unsourced material may be challenged and removed. (August 2009) (Learn how and when to remove this template message) |

Further reading[edit]

A Short History of the British Mammal Fauna (archived)

The History of British Birds

Buglife on bumblebees

Joint Nature Conservation Committee – Invertebrates extinct in the last 100 yearsvvnoljv;sfolzdfbionszfibkn sfn k;l

						Retrieved from "https://en.wikipedia.org/w/index.php?title=List_of_extinct_animals_of_the_British_Isles&oldid=832106142"

Categories:

Lists of extinct animals by region

Extinct animals of Europe

Lists of British animals

British Isles-related lists

Hidden categories:

Pages with citations lacking titles

Pages with citations having bare URLs

CS1 maint: BOT: original-url status unknown

Articles needing additional references from May 2013

All articles needing additional references

Articles needing additional references from August 2009

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Add links

 This page was last edited on 23 March 2018, at 21:50.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews