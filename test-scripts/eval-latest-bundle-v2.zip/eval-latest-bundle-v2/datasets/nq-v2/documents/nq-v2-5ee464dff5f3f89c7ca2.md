# Death Row Records

Death Row Records - Wikipedia

			Death Row Records

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| Death Row Records |

| Parent company | Time Warner, Interscope (former) |

| Founded | 1991; 26 years ago (1991) |

| Founder | Dr. Dre The D.O.C. Suge Knight Michael “Harry-O” Harris |

| Status | Inactive |

| Genre | Hip hop, R&B, gangsta rap |

| Country of origin | United States |

| Location | Los Angeles, California |

Death Row Records (formerly Tha Row Records) was an American record company founded in 1991 by Dr. Dre, Suge Knight, The D.O.C., and Michael “Harry-O” Harris. Many West Coast artists were on the label, such as: Dr. Dre, Snoop Dogg, Tupac Shakur, The Outlawz, MC Hammer, Young Soldierz, Sam Sneed, Michel'le, Jewell, RBX, The Lady of Rage, Danny Boy, DJ Quik, O.F.T.B., LBC Crew, and the rap group Tha Dogg Pound consisting of Kurupt, Daz Dillinger, Nate Dogg, Soopafly, and many others. Death Row Records was making $100,000,000 a year, but by 1996; most of the aforementioned artists departed from the label after the death of 2Pac. The company filed for bankruptcy in 2006 and on January 15, 2009, was auctioned to entertainment development company WIDEawake Entertainment Group, Inc. for $18,000,000[1][2]

Contents
 [hide] 

1 History

1.1 The Chronic and Ruthless Records feud

1.2 Doggystyle

1.3 Signing Tupac and Suge Knight's rise

1.4 Bad Boy feud and Dr. Dre's departure

1.5 M.C. Hammer's involvement and departure

1.6 Tupac Shakur's murder and Suge Knight's incarceration

1.7 2nd generation exodus

1.8 Chapter 11 Bankruptcy

1.9 From WIDEawake acquisition to E1

2 Former Artists

3 Releases

4 See also

5 References

6 Further reading

7 External links

History[edit]

Main article: Ruthless Records

In the late-1980s, producer Dr. Dre was a member of N.W.A, signed to friend Eazy E's Ruthless Records. As head of production at the label, Dre produced a large number of Ruthless projects, many of them successful; feeling the pressures of having to produce so many acts and feeling he was underpaid, Dr. Dre became frustrated with Ruthless Records.[3] After the departure of Ice Cube in 1989 over financial disagreements with N.W.A. manager Jerry Heller,[4] Suge Knight and fellow Ruthless artist, The D.O.C. went over the books with a lawyer. Convinced that Heller was dishonest, they approached Dr. Dre about forming a label with them, away from Heller and Eazy-E.[5] Allegedly using strong-arm tactics, Knight was able to procure contracts from Eazy-E for The D.O.C., Dr. Dre and Ruthless singer, Michel'le.[6]

Knight approached Vanilla Ice, using management connections with Mario "Chocolate" Johnson, claiming Johnson had produced the song "Ice Ice Baby", and had not received royalties for it.[7] After consulting with Alex Roberts, who sources suggest was Suge Knight's connection to the underworld, Knight and two bodyguards arrived at The Palm in West Hollywood, where Van Winkle was eating. After shoving Van Winkle's bodyguards aside, Knight sat down in front of Van Winkle, staring at him before asking "How you doin'?"[7] Similar incidents were repeated on several occasions, including alleged attempts to lure Vanilla Ice into a van filled with Bloods and Crips, before Knight showed up at Vanilla Ice's hotel suite on the fifteenth floor of the Bel Age Hotel, accompanied by Johnson and a member of the Oakland Raiders. According to Vanilla Ice, Knight took him out on the balcony by himself, and implied he would throw Vanilla Ice off unless he signed the rights to the song over to Knight; Van Winkle's money helped fund Death Row.[7] At one time, Death Row was located at the intersection of Wilshire Blvd. and San Vicente Blvd.[8] Knight was seen on several occasions leaving Alex Roberts' home in Malibu. Knight approached Michael "Harry-O" Harris, a businessman imprisoned on drug and attempted murder charges. Through David Kenner, an attorney handling Harris's appeal, Harry-O set up Godfather, a parent company for the newly christened Death Row.[9]

The Chronic and Ruthless Records feud[edit]

Main article: The Chronic

With the help of Kenner, Knight began signing young, inner-city California-based artists and arranged for Death Row Records to handle the soundtrack for the 1992 film, Deep Cover. The single, "Deep Cover", established Dr. Dre as a solo artist and a young Snoop "Doggy" Dogg as his protégé. Work soon began on The Chronic, Dr. Dre's debut solo album, which heavily featured Snoop and the rest of the label's core roster.

The album went on to sell 5,700,000 records in the US,[10] establishing the West Coast in the hip-hop industry and popularizing the distinctive style of G-Funk.[11]

Doggystyle[edit]

Main article: Doggystyle (album)

After finding solo success, Dr. Dre began crafting Snoop Dogg's debut album Doggystyle; the process took two years. Snoop's debut was released in 1993 due to public demand and high pressure from retailers. Though unfinished,[12] it outperformed The Chronic at Quadruple Platinum,[13] and garnered similarly glowing reviews.[14] Soon after the release of the album, Snoop Dogg was charged with murder,[15] fueling the debate that politicians C. Delores Tucker and then-Vice Presidential candidate Dan Quayle sparked by denouncing gangsta rap as against American values, encouraging violence towards police officers, and degrading to Black women.

Signing Tupac and Suge Knight's rise[edit]

| This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (May 2015) (Learn how and when to remove this template message) |

By 1995, the label began to flood with Suge Knight's cronies—friends and gang members fresh out of jail, as well as off-duty LAPD officers later implicated in the Rampart scandal working as security. Emboldened, Knight began taking more control of the label and further sought the spotlight, while Dr. Dre receded into the background, shying away from the violent atmosphere and Suge Knight's newfound volatility. Tucker's pressure to conform extended to a joint proposal by herself and a Warner executive to set up a record label with Knight to put out content-controlled hip-hop music, which Knight billed as a breach of contract,[9] resulting in a switch in distribution from Time Warner to Interscope. At The Source Awards in 1995, the Death Row roster's performance garnered a poor reception from the mainly East Coast audience; Knight also made comments pertaining to Bad Boy CEO Puff Daddy, sparking friction between the two labels (and, soon after, the two entire coasts). Knight soon signed 2Pac,and Lord Autopz of Ruthless Criminalz while 2Pac was incarcerated on a sexual abuse conviction, after agreeing to post 2Pac's bail. At the same time, a rift between Michael and Lydia Harris and Suge and David Kenner began to grow, with the latter pair denying Harris'.involvement in the company and refusing to take his phone calls.

Bad Boy feud and Dr. Dre's departure[edit]

2Pac began work on his Death Row album, kicking off his tenure by insulting The Notorious B.I.G., Junior M.A.F.I.A. and Puff Daddy (the founder of Bad Boy Records), whom he accused of setting him up to be robbed and shot earlier that year, as well as Busta Rhymes, Mobb Deep, Jay-Z, A Tribe Called Quest, De La Soul, The Fugees and Nas. Tha Dogg Pound's debut album, Dogg Food, continued the label's streak of commercial successes; its members – rappers Kurupt and Daz Dillinger – then joined Snoop in ridiculing New York rappers with their single "New York, New York", featuring Snoop Dogg. The video, set in New York City, New York, was also heightened when the set was fired upon in a drive-by. After the shooting, Snoop Dogg and Tha Dogg Pound filmed scenes kicking down a building in New York. The single provoked a response called '"L.A., L.A." by East Coast rappers Capone-N-Noreaga, Tragedy Khadafi, and Mobb Deep.

Another report was that Sam Sneed was beaten in one of the label's meetings by a group of Death Row affiliates, led by Suge Knight and 2Pac. According to Daz Dillinger, the reason this happened was that Sam Sneed had too many East Coast rappers in his Lady Heroin music video.[16] Disillusioned with the direction of Death Row, artists RBX and The D.O.C. chose to leave, after which Suge Knight exercised tighter control over the rest of the roster.[9] Dogg Food was not produced by Dr. Dre but was mixed by Dr. Dre, a further testament to Dre's dwindling involvement with his own record label. Dr. Dre also grew tired of Knight's violence within the label, although he contributed toward two tracks on 2Pac's All Eyez on Me. The rest of the tracks on the album, however, were mostly produced by Daz Dillinger and Johnny J, despite Dr. Dre being nominally titled as Executive Producer. Shakur's behavior reportedly became erratic as he continued his verbal wars with The Notorious B.I.G., Bad Boy Records, Puff Daddy, Mobb Deep, and Prodigy, including many violent confrontations with many of those rappers at some points. In 1996, due to the infighting, Dr. Dre left Death Row Records to found Aftermath; which provoked 2Pac to turn against Dr. Dre.

M.C. Hammer's involvement and departure[edit]

Suge Knight's relationship with MC Hammer dates back to 1988. With the success of Hammer's 1994 album, The Funky Headhunter (featuring Tha Dogg Pound), Hammer signed with Death Row in 1995, along with Snoop Dogg and his close friend, 2Pac.[17] The label did not release the album of M.C. Hammer's music (titled Too Tight), although he did release versions of some tracks on his next album.[18][19] However, Hammer did record tracks with Shakur and others, most notably the song "Too Late Playa" (along with Big Daddy Kane and Danny Boy).[20][21] After the death of 2Pac in 1996, MC Hammer left Death Row Records.[22][23]

Tupac Shakur's murder and Suge Knight's incarceration[edit]

Main article: Murder of Tupac Shakur

Formerly a united front of artists, Death Row's roster fractured into separate camps. Daz, now head producer, worked on Snoop Dogg's second album Tha Doggfather, which featured Bad Azz and Techniec of his LBC Crew, Warren G and Nate Dogg of his group 213 and Tha Dogg Pound. 2Pac shut himself into the studio with Hurt-M-Badd and Big "D", crafting The Don Killuminati: The 7 Day Theory - unlike All Eyez on Me, it was devoid of high-profile Death Row guest appearances, instead showcasing The Outlawz and Bad Azz. Suge Knight was now barely reachable by his staff, and employees were assaulted as punishment for not following orders.[12]

During a trip to Las Vegas, Nevada for a Mike Tyson boxing match, 2Pac was interviewed on the possibility of Death Row East, an East Coast branch of Death Row. It was also during this time, that Alex Roberts and David Kenner had been seen at Suge Knight's Vegas Club 662 in discussion about the possibility of having Roberts' New York underworld connections help pave the way for Death Row East. Though names from Big Daddy Kane and The Wu-Tang Clan to Eric B. and K-Solo were mentioned, the label would never be formed; On September 7, 1996, Suge Knight and 2Pac were caught on surveillance camera at the MGM Grand Hotel in Las Vegas attacking gang member Orlando Anderson who was a Southside Compton, California Crip. Later that night, 2Pac was shot four times in a drive-by shooting in the back seat of Suge Knight's BMW 750iL waiting at a red traffic light at crossroads; en route to Knight's Las Vegas Club 662;[24][25] despite living six days in critical condition, 2Pac died September 13, 1996.

Shakur's "The Don Killuminati: 7 Day Theory" was released in November 1996, just one week before Snoop Dogg's "Tha Doggfather". Both albums achieved Platinum sales. Suge Knight was convicted of parole violation and sentenced to nine years in prison, causing Interscope to drop their distribution deal with the label.[26] Suge Knight's control over the label diminished, as Nate Dogg was able to leave, followed by Snoop Dogg and Kurupt. After the release of her solo album The Lady of Rage left. Daz Dillinger departed in 1999 but produced for Big C-Style, he later formed Dogg Pound Records. Kurupt returned to the label in 2002 upon Suge Knight's release from prison.[27]

2nd generation exodus[edit]

Maintaining artistic control from behind bars, Suge Knight launched smear campaigns against his former artists, most notably Snoop Dogg.[citation needed] The label supported itself with releases pulled from vaults—most successfully various posthumous 2Pac albums, along with Dr. Dre and Snoop Dogg re-releases and then-unreleased compilation records such as Suge Knight Represents: Chronic 2000 and Snoop Dogg: Dead Man Walkin. He signed new talent, including Crooked I who had been lighting up the Californian underground with his rhyming ability, particularly the Wake Up Show with Sway & King Tech. Suge Knight also signed Left Eye. He also appointed Cold 187um head producer, to oversee the 2Pac album Until the End of Time and Tha Dogg Pound 's 2002.

Despite bad blood, Kurupt would again sign with Suge Knight in exchange for the position of Vice President, which sparked a feud between himself and Daz Dillinger and Snoop Dogg. He began work on Against tha Grain; his verbal feud with his former partners continued from 2002 to 2005.[28] Left Eye signed with Death Row after finishing her solo deal with Arista who released her 1st album Supernova in 2001. Lopez joined to record a 2nd solo album under the pseudonym N.I.N.A. (New Identity Not Applicable) she was also working on TLC's new album 3D. N.I.N.A. was cancelled after her death in April 2002. The album was leaked online in 2011.

After promoting his new talent from prison, directing a campaign against his former artists and exacerbating the conflict between Daz Dillinger and Kurupt,[29] Suge had still yet to release any albums by his new artists. After Kurupt's 2nd departure, Against tha Grain was released; soon after, citing dissatisfaction with serving 5 years on the label and seeing no release,[30] Rapper Crooked I left Death Row, eventually filing a gag order on Knight to prevent him from interfering with him finding a new deal.[31] Petey Pablo, who had signed in 2005 and started the never-released album Same Eyez on Me,[32] left along with rapper Tha Realest[33] in 2006.

Chapter 11 Bankruptcy[edit]

On April 4, 2006 both Death Row Records and Suge Knight simultaneously filed for Chapter 11 Bank protection following the appointment of a Receiver to acquire and auction off assets of both Death Row Records and Suge Knight in the civil case filed by Lydia Harris against Suge Knight. Among those listed as unsecured creditors to Death Row include the Harris', the Internal Revenue Service ($6,900,000), Koch Records ($3,400,000), Interscope Records ($2,500,000) and a number of artists previously signed to the label. Suge Knight would eventually lose control of Death Row Records and his personal assets when Chapter 11 Trustees took over both cases.

From WIDEawake acquisition to E1[edit]

On January 15, 2009, Death Row was successfully auctioned to entertainment development company WIDEawake for $18 million USD. On January 25, 2009, an auction was held for everything found in the Death Row office after it filed for bankruptcy. Of note was the Death Row electric chair which went for $2500 USD.[34]

Since the acquisition, the company has continued to release material from its vast archives of materials acquired in the sale. Noteworthy releases include previously unreleased material from such artists as Snoop Dogg, Kurupt, Danny Boy, Crooked I, Sam Sneed, LBC Crew and O.F.T.B. Since the acquisition of the material, Money Mafia-Death Row, under the management of WIDEawake, has made many positive steps towards improving the image of Death Row by making good on its promise to make royalty payments to many of the artists, producers, and songwriters with commercially released material under the label. On "Record Store Day" April 18, 2012, the label has issued a free Death Row "Record Store Day" CD sampler which included music from Lord Autopz, Petey Pablo and Danny Boy

"The Chronic Re-Lit" was released on September 1, 2009. The album contained the original The Chronic album re-mastered and 7 bonus songs from the vault by Snoop Doggy Dogg, CPO, Kurupt, Jewell, and more; plus a DVD containing music videos, a rare Dr. Dre interview, a Dr. Dre and Snoop Dogg mini movie, and rare 1992 television commercials for the original The Chronic release.[35][36]

"Snoop Doggy Dogg – Death Row The Lost Sessions Vol 1"[37] was released October 13, 2009 and contains 15 previously unreleased tracks with 4 being produced by Dr. Dre.

"Death Row The Ultimate Collection"[38] was released on November 24 and was a special box set containing 3 audio CDs (1 greatest hits disc and 2 discs of unreleased content), 1 DVD of music videos which includes the unreleased Dr. Dre music video "Puffin' On Blunts" and a limited edition Death Row T-shirt. The set boasts over 20 unreleased tracks from the likes of: Snoop Doggy Dogg, Tha Dogg Pound, The Lady of Rage,Lord Autopz and Petey Pablo. During this period, there was a specific distribution venture between E1 and Wideawake Death Row LLC.

On 10 December 2012, New Solutions Financial Corp., the Canadian company that owned WIDEawake Death Row, had gone bankrupt and sold both the label and catalog to a publicly held company[39] In 2013, E1 purchased the rights to the Death Row catalog. The Group invested £175 million in content rights and television programmes in the year (2012: £135.8 million) and £4.2 million (6 million $) to purchase the music library assets of Death Row.[40]

Former Artists[edit]

Dr. Dre (1991-1996)

The D.O.C (1991-1994)

Michel'le (1991-1999); (2002-2003)

Snoop Dogg (1991-1997)

Tha Dogg Pound (1991-1997)

Lady of Rage (1991-1997)

2Pac (1995-1996)

Outlawz (1995-1999)

213 (group) (1991-1997)

RBX (1991-1994)

Nate Dogg (1991-1997)

MC Hammer (1995-1996)

Kurupt (1991-1997) (2002-2005)

Daz Dillinger (1991-1999)

Lisa "Left Eye" Lopes (2002)

Crooked I (1999-2004)

SKG (2001)

Tha Realest (1996-2001)

YGD Tha Top Dogg (1997-2000)

Danny Boy (1994-1999); (2002-2003)

Sam Sneed (1993-1997)

Yaki Kadafi of The Outlawz (1995-1996)

Jewell (1992-1999)

O.F.T.B. (1994-1998)

J-Flexx (1994-1997)

Petey Pablo (2005-2006)

Sunny red (2003-2006

Soopafly (1994-1997)

2nd II None (1994-1998)

Prince Ital Joe (1995-1998)

LBC Crew (1995-1997)

O.G. Big Tray Dee (1994-1997)

Bad Azz (1995-1997)

Lil' C-Style (1994-1998)

Techniec (1994-1997)

Young Swoop G (1994-2001)

Nanci Fletcher (1993-1996)

DJ Quik (1994-1996)

C.P.O. Boss Hogg (1991-1998)

Above the Law (1999-2001)

Young Soldierz (1994-1998)

Big Pimpin' Delemond (1994-1999)

Butch Cassidy (1996-1998)

V.K. (1999)

Dobbie (1998-1999)

Eastwood (2002-2005)

Big C-Style (1998-2001)

6 Feet Deep

B.G.O.T.I.

Chocolate (1991-1993)

Chocolate Bandit (1996-1999)

Mr. 2-3 (1991-1993)

Sean 'Barney' Thomas

Slip Capone (1993-1998)

Lil' Malik a.k.a. Lil' Hershey Loc

Fatal-n-Felony (1995-1996)

The Gang (1996-1997)

Twang

GP The Beast

Scarlo

El Dorado (1998-1999)

The Ralatives (1998-2000)

Hurt-M-Badd

Spider Loc (2002- 2004)

Gangxsta Ridd

Dresta

Mac Shawn

LA Nash

Scrilla

Warlord

Capricorn

O.Y.G Redrum781

Gangsta Girl

Dorasel

Gail Gotti

Releases[edit]

Main article: Death Row Records discography

| Year | Album information |

| 1992 | Dr. Dre – The Chronic Released: December 15, 1992 Chart positions: No.3 Billboard RIAA certification: 3x Platinum[41] Singles: "Fuck Wit Dre Day", "Let Me Ride", "Nuthin' but a 'G' Thang" |

| 1993 | Snoop Doggy Dogg – Doggystyle Released: November 23, 1993 Chart positions: No.1 Billboard RIAA certification: 4x Platinum Singles: "Who Am I (What's My Name)", "Gin and Juice", "Doggy Dogg World" |

| 1994 | Above the Rim Released: March 22, 1994 Chart positions: No.2 Billboard RIAA certification: 2x Platinum Singles: "Regulate", "Anything", "Afro Puffs", "Part-Time Lover" |

| Murder Was The Case Released: October 15, 1994 Chart positions: No.1 Billboard RIAA certification: 2x Platinum Singles: "Woman To Woman", "Natural Born Killaz", "U Better Recognize", "Murder Was The Case", What Would You Do?" |

| 1995 | Tha Dogg Pound – Dogg Food Released: October 31, 1995 Chart positions: No.1 Billboard RIAA certification: 2x Platinum Singles: "Respect", "Let's Play House", "New York, New York" |

| 1996 | 2Pac – All Eyez On Me Released: February 13, 1996 Chart positions: No.1 Billboard RIAA certification: Diamond Singles: "California Love", "2 of Amerikaz Most Wanted", "How Do You Want It", "All Bout U", "Life Goes On", "I Ain't Mad at Cha" |

| Makaveli (2Pac) – The Don Killuminati: The 7 Day Theory Released: November 5, 1996 Chart positions: No.1 Billboard RIAA certification: 4x Platinum Singles: "Toss It Up", "To Live & Die in LA", "Hail Mary" |

| Snoop Doggy Dogg – Tha Doggfather Released: November 12, 1996 Chart positions: No.1 Billboard RIAA certification: 2x Platinum Singles: "Doggfather", "Snoop's Upside Ya Head", "Vapors" |

| Death Row Greatest Hits Released: November 26, 1996 Chart positions: No.36 Billboard |

| Christmas on Death Row Released: December 5, 1996 Chart positions: No.155 Billboard Singles: "Santa Clause Goes Straight to the Ghetto" |

| 1997 | Gridlock'd Released: January 28, 1997 Chart positions: No.1 Billboard RIAA certification: Platinum Singles: "Wanted Dead or Alive", "Lady Heroin", "It's Over Now" |

| Lady of Rage – Necessary Roughness Released: June 4, 1997 Chart positions: No.32 Singles: "Sho Shot", "Get Wit' Da Wickedness" |

| Gang Related Released: October 7, 1997 Chart positions: No.2 Billboard RIAA certification: 2x platinum Singles: "Made Niggaz" |

| 1998 | Daz Dillinger – Retaliation, Revenge and Get Back Released: March 31, 1998 Chart positions: No.8 Billboard RIAA certification: Gold Singles: "In California", "It Might Sound Crazy" |

| Michel'le – Hung Jury Released: August 24, 1998 Chart positions: No.56 Billboard Singles: "Hang Tyme", "Can I Get A Witness?" |

| 2Pac – Greatest Hits Released: November 24, 1998 Chart positions: No.3 Billboard RIAA certification: Diamond (10x Platinum) Singles: "Changes", "Unconditional Love" |

| 1999 | Suge Knight Represents: Chronic 2000 Released: April 27, 1999 Chart positions: No.11 Billboard RIAA certifications: Gold Singles: "Who Do U Believe In?", "Like It or Not" |

| 2000 | Too Gangsta for Radio Released: September 26, 2000 Chart positions: No.171 Billboard Singles: "Thug Nature" |

| Snoop Doggy Dogg – Dead Man Walkin' Released: October 31, 2000 Chart positions: No.24 Billboard Singles: "Head Doctor" |

| 2001 | Tha Dogg Pound – 2002 Released: July 31, 2001 Chart positions: No.36 Billboard Singles: "Just Doggin'" |

| Snoop Doggy Dogg – Death Row: Snoop Doggy Dogg at His Best Released: October 23, 2001 Chart positions: No.28 Billboard Singles: |

| 2Pac – Until the End of Time Released: March 27, 2001 Chart positions: No.1 Billboard RIAA certification: 3x Platinum Singles: "Until the End of Time", "Letter 2 My Unborn" |

| 2002 | 2Pac – Better Dayz Released: November 26, 2002 Chart positions: No.5 Billboard RIAA certification: 2x Platinum Singles: "Still Ballin'", "Thugz Mansion", "Who Do U Believe In?" |

| 2003 | Dysfunktional Family Released: March 11, 2003 Chart positions: No.95 Billboard Singles: "Dysfunktional Family" |

| 2Pac – Nu-Mixx Klazzics Released: October 7, 2003 Chart positions: No.15 Billboard |

| 2005 | The Very Best of Death Row Released: February 22, 2005 |

| Kurupt – Against the Grain Released: August 23, 2005 Chart positions: No.60 Billboard |

| 2007 | 2Pac – Nu-Mixx Klazzics Vol. 2 Released: August 14, 2007 Chart positions: No.45 Billboard |

| 2009 | Dr. Dre – The Chronic Re-Lit Released: September 1, 2009 |

| Snoop Doggy Dogg – Death Row: The Lost Sessions Vol. 1 Released: October 13, 2009 Chart positions:No.129 Billboard |

| Death Row The Ultimate Collection Released: November 24, 2009 |

| 2010 | Kurupt – Down & Dirty Released: April 9, 2010 |

| Danny Boy – It's About Time Released: April 20, 2010 |

| Crooked I – Hood Star Released: June 16, 2010 |

| 2011 | Sam Sneed – Street Scholars Released: January 25, 2011 |

| LBC Crew – Haven't You Heard... Released: February 8, 2011 |

| O.F.T.B. – Damn Near Dead Released: July 12, 2011 |

| Jewell – Black Diamond Released: TBC, November 2011 |

| 2012 | 20 To Life: Volume 1 Released: May 10, 2012 |

| Tha Dogg Pound - Doggy Bag Released: July 3, 2012 |

| 20 To Life: Volume 2 Released: September 25, 2012 |

See also[edit]

Death Row Records artists

References[edit]

Jump up ^ "Tha Row Records - Company Profile, Information, Business Description, History, Background Information on Tha Row Records". referenceforbusiness.com. 

Jump up ^ HipHopDX (February 6, 2008). "Warner To Acquire Death Row Records?". HipHopDX. 

Jump up ^ Ruthless (Heller/Reavill, 2007) ISBN 1-4169-1794-2

Jump up ^ Ice Cube: Attitude (McIver, 2002) ISBN 1-86074-428-1

Jump up ^ [1]

Jump up ^ "Erotic D Interview- Part 1 (June 2008)". Retrieved 7 August 2013. 

^ Jump up to: a b c Sullivan, Randall (2003). LAbyrinth: A Detective Investigates the Murders of Tupac Shakur and Notorious B.I.G., the Implication of Death Row Records' Suge Knight, and the Origins of the Los Angeles Police Scandal. Grove Press. p. 56. ISBN 0-8021-3971-X. 

Jump up ^ Fischer, Blair R. (March 12, 1998). "To The Extreme and Back". Rolling Stone. Retrieved November 14, 2008. 

^ Jump up to: a b c scottgrib (September 25, 2001). "Welcome to Death Row (Video 2001)". IMDb. 

Jump up ^ Recording Industry Association of America Archived October 17, 2015, at the Wayback Machine.. RIAA. Retrieved on July 11, 2011.

Jump up ^ Jon Pareles (November 14, 1999). Music; Still Tough, Still Authentic. Still Relevant?. The New York Times. Retrieved March 18, 2008.

^ Jump up to: a b Rollin' With Dre: The Unauthorized Account: An Insider's Tale of the Rise, Fall, and Rebirth of West Coast Hip Hop (Williams/Alexander, 2008) ISBN 0-345-49822-4

Jump up ^ Recording Industry Association of America. RIAA. Retrieved on July 11, 2011.

Jump up ^ https://www.allmusic.com/album/r185654

Jump up ^ Snoop Doggy Dogg Trial: 1995–96 – A Rising Rap Star, Murder Was The Charge, Jury Frees Snoop Dogg, Suggestions For Further Reading. Law.jrank.org. Retrieved on July 11, 2011.

Jump up ^ "Rap Research Archive". rapresearcharchive.blogspot.com. 

Jump up ^ "MC Hammer Interview - part 1". daveyd.com. June 1997. Retrieved March 20, 2009. 

Jump up ^ "MC Hammer". MTV. 

Jump up ^ "MC Hammer". MTV. 

Jump up ^ "2pac Too Late Playa Feat Mc Hammer, Big Daddy Kane, Nutt-so Danny Boy". Wn.com. Retrieved 2011-05-10. 

Jump up ^ Burgess, Omar (2009-03-18). "Death Row Records: The Pardon | Rappers Talk Hip Hop Beef & Old School Hip Hop". HipHop DX. Retrieved 2011-05-10. 

Jump up ^ "MC Hammer Interview - part 2". daveyd.com. June 1997. Retrieved March 20, 2009. 

Jump up ^ "What had happened was MC Hammer". vibe.com. March 2009. Archived from the original on January 6, 2010. 

Jump up ^ Philips, Chuck (September 6, 2002). "Who Killed Tupac Shakur?". The Los Angeles Times. Retrieved 2012-07-15. 

Jump up ^ Philips, Chuck (September 7, 2002). "How Vegas police probe floundered in Tupac Shakur case". LA Times. Retrieved 8 October 2013. 

Jump up ^ Interscope Music Group – Company History. In 1996, Alex Roberts was arrested at his home in Malibu and released on a $1,000,000 bond pending further investigation under a grand jury indictment involving organized crime ties including money laundering, extortion and racketeering charges. Fighting his case for 4 1/2 years out on bail he was finally taken into custody November 19th, 2001 in Los Angeles, California Superior Court and sentenced to state and federal charges amounting to five years of prison time. His refusal to cooperate with federal authorities also lead to any reduced sentence including his deportation to Europe even though he had been raised in the USA since birth, holding dual citizenship. Fundinguniverse.com. Retrieved on July 11, 2011.

Jump up ^ Scott, Cathy. Las Vegas Sun, "The death of Tupac Shakur one year later", September 6, 1997

Jump up ^ [2] Archived June 28, 2008, at the Wayback Machine.

Jump up ^ Suge Knight Interview. Ukmusic.com. Retrieved on July 11, 2011.

Jump up ^ Life After Death Row: Crooked-I, Russel Simmons, Master P, Loon, Bun-B, WC, Jay Cee: Movies & TV. Amazon.com. Retrieved on July 11, 2011.

Jump up ^ Walker, Verbal. (February 21, 2005) Crooked I’s Restraining Order | Get The Latest Hip Hop News, Rap News & Hip Hop Album Sales. HipHop DX. Retrieved on July 11, 2011.

Jump up ^ Moss, Corey. (July 25, 2005) Petey Pablo Eyez Tupac, Teams With Timbaland, Lil Jon – Music, Celebrity, Artist News. MTV. Retrieved on July 11, 2011.

Jump up ^ Daily News – : Tha Realest Leaves Tha Row, Preparing Debut Album. Allhiphop.com (March 31, 2005). Retrieved on July 11, 2011.

Jump up ^ "Electric chair is hot item at Death Row Records auction". The Orange County Register. Archived from the original on June 28, 2009. 

Jump up ^ Discogs tracklist

Jump up ^ Dr. Dre's Chronic Get Expanded Re-Release. MTV.com. Retrieved on August 19, 2009

Jump up ^ mr said that he had been in the morning to you but I'm still waiting on the phone with the best thing about being able too see my friends and relatives Snoop Dogg – Death Row: The Lost Sessions Volume 1 | Read Hip Hop Reviews, Rap Reviews & Hip Hop Album Reviews. HipHop DX (October 13, 2009). Retrieved on July 11, 2011.

Jump up ^ Death Row Records To Release Box Set Including Work From Tupac, Snoop Dogg & Dr. Dre Archived November 3, 2009, at the Wayback Machine.. Keepittrill.com. Retrieved on July 11, 2011.

Jump up ^ HipHopDX (December 5, 2012). "WIDEawake Death Row Records Reportedly Being Sold In Wake Of Parent Company's Bankruptcy". HipHopDX. 

Jump up ^ "Results Announcement". ft.com. 

Jump up ^ "Dr. Dre: The Chronic". RIAA. 

Further reading[edit]

Have Gun Will Travel: The Spectacular Rise and Violent Fall of Death Row Records, Ronin Ro, Doubleday, 1998, 384 pages, ISBN 0-385-49134-4

Labyrinth: A Detective Investigates the Murders of Tupac Shakur and Notorious B.I.G., the Implications of Death Row Records' Suge by Randall Sullivan, Atlantic Monthly Press, April 2, 2002, 384 pages, ISBN 0-87113-838-7

The Killing of Tupac Shakur, by Cathy Scott, Huntington Press, 2002 (2nd ed), 235 pages, ISBN 0-929712-20-X

Welcome to Death Row, Director: S. Leigh Savidge & Jeff Scheftel, (Video) 2001

External links[edit]

Official Death Row Records website

Death Row Records – Official Myspace

Death Row Records – Official Twitter

Death Row Records – Official YouTube

Interview with new owner of Death Row Records

interview of MJ[1] Sales Inc

[3]

Suge Knight

| [hide] v t e Rampart scandal |

| Notable accused officers | Nino Durden Kevin Gaines Brian Liddy David Mack Rafael Pérez |

| Victims | Frank Lyga Javier Ovando The Notorious B.I.G. |

| Coverup and investigation | Brian S. Bentley Bernard Parks Russell Poole |

| Gang involvement | 18th Street gang Bloods Death Row Records Suge Knight |

| Other | Community Resources Against Street Hoodlums Los Angeles Police Department LAPD Rampart Division |

Jump up ^ Cite error: The named reference imdb.com was invoked but never defined (see the help page).

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Death_Row_Records&oldid=806810326"

Categories:

Rampart scandal

American independent record labels

Gangsta rap record labels

Hip hop record labels

Record labels based in California

Vanity record labels

Record labels established in 1991

Record labels disestablished in 2008

1991 establishments in California

2008 disestablishments in California

Defunct companies based in the Greater Los Angeles Area

Dr. Dre

Tupac Shakur

Hidden categories:

Webarchive template wayback links

Use mdy dates from July 2011

Pages using deprecated image syntax

Articles needing additional references from May 2015

All articles needing additional references

All articles with unsourced statements

Articles with unsourced statements from August 2017

Pages with reference errors

Pages with broken reference names

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Català

Čeština

Dansk

Deutsch

Eesti

Español

Français

한국어

Hrvatski

Italiano

עברית

ქართული

Nederlands

日本語

Norsk

Polski

Português

Русский

Simple English

Српски / srpski

Suomi

Svenska

Türkçe

Edit links

 This page was last edited on 24 October 2017, at 08:40.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews