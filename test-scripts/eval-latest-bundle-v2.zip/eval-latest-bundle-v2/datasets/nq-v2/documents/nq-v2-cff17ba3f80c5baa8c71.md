# List of urban parks by size

List of urban parks by size - Wikipedia

List of urban parks by size

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| This article needs additional citations for verification. Please help improve this article by adding citations to reliable sources. Unsourced material may be challenged and removed. (May 2014) (Learn how and when to remove this template message) |

A list of international urban parks larger than 1,000 acres (405 hectares; 4 square kilometres; 2 square miles) and contained entirely within a city's municipal or metropolitan boundary.

| City | Region/State | Country | Park name | Size in acres | Size in hectares |

| Moscow | Moscow | Russia | Losiny Ostrov National Park | 7008116213575882060♠28,717.0 | 7008115999901862958♠11,600.0 |

| El Paso | Texas | United States | Franklin Mountains State Park | 7007981281745303552♠24,248.0 | 7007981281745303552♠9,812.8 |

| Edmonton | Alberta | Canada | North Saskatchewan River valley parks system | 7007728434156032000♠18,000.0 | 7007728434156032000♠7,284.3 |

| Sydney | New South Wales | Australia | Western Sydney Parklands | 7007527999832400803♠13,047.2 | 7007527999832400803♠5,280.0[1] |

| Lahore and Kasur | Punjab | Pakistan | Changa Manga | 7007502740973354752♠12,423.0 | 7007502740973354752♠5,027.4 |

| Toronto | Ontario | Canada | Rouge Park | 7007500029579551744♠12,356.0 | 7007500029579551744♠5,000.3 |

| Dallas | Texas | United States | Trinity River Project | 7007404685642240000♠10,000.0 | 7007404685642240000♠4,046.9 |

| London | Greater London | United Kingdom | Lee Valley Park | 7007404685642240000♠10,000.0 | 7007404685642240000♠4,046.9 |

| Houston | Texas | United States | Cullen Park | 7007375143590356480♠9,270.0 | 7007375143590356480♠3,751.4 |

| Ulsan | Yeongnam | South Korea | Ulsan Grand Park | 7007364014735194880♠8,995.0 | 7007364014735194880♠3,640.1[2][3] |

| Los Angeles | California | United States | Topanga State Park | 7007362598335447040♠8,960.0 | 7007362598335447040♠3,626.0 |

| Seongnam and Gwangju | Gyeonggi-do | South Korea | Namhansanseong | 7007344499984154782♠8,512.8 | 7007344499984154782♠3,445.0[4] |

| Moscow | Moscow | Russia | Izmaylovsky Park | 7007159999753001144♠3,953.7 | 7007160404438643384♠1,604.0 |

| Jacksonville | Florida | United States | Timucuan Ecological and Historic Preserve | 7007318487600442880♠7,870.0 | 7007318487600442880♠3,184.9 |

| Houston | Texas | United States | George Bush Park | 7007315654800947200♠7,800.0 | 7007315654800947200♠3,156.5 |

| Phoenix | Arizona | United States | North Mountain Preserve | 7007303514231680000♠7,500.0 | 7007303514231680000♠3,035.1 |

| Louisville | Kentucky | United States | Jefferson Memorial Forest | 7007243256539550464♠6,011.0 | 7007243256539550464♠2,432.6 |

| San Diego | California | United States | Mission Trails Regional Park | 7007292142565133056♠7,219.0 | 7007292142565133056♠2,921.4 |

| Raleigh | North Carolina | United States | William B. Umstead State Park | 7007225774119805696♠5,579.0 | 7007225774119805696♠2,257.7 |

| Moscow | Moscow | Russia | Bitsa Park | 7007220836954970368♠5,457.0 | 7007220836954970368♠2,208.4 |

| Brescia | Lombardy | Italy | Brescia Hills Park (part) | 7007218299575993523♠5,394.3 | 7007218299575993523♠2,183.0 |

| Mexico City | State of Mexico | Mexico | Sierra de Guadalupe | 7007215373698800128♠5,322.0 | 7007215373698800128♠2,153.7 |

| Honolulu | Hawaii | United States | Ahupuaʻa O Kahana State Park | 7007211610122327296♠5,229.0 | 7007211610122327296♠2,116.1 |

| Portland | Oregon | United States | Forest Park | 7007208696385703168♠5,157.0 | 7007208696385703168♠2,087.0 |

| Indianapolis | Indiana | United States | Eagle Creek Park and Golf Course | 7007192873177091584♠4,766.0 | 7007192873177091584♠1,928.7 |

| Memphis | Tennessee | United States | Shelby Farms | 7007182108539008000♠4,500.0 | 7007182108539008000♠1,821.1 |

| Anchorage | Alaska | United States | Far North Bicentennial Park | 7007182108539008000♠4,500.0 | 7007182108539008000♠1,821.1 |

| Santiago | Santiago Metropolitan Region | Chile | Parque Metropolitano de Santiago | 7007178466368227840♠4,410.0 | 7007178466368227840♠1,784.7 |

| Halifax | Nova Scotia | Canada | Blue Mountain Birch Cove Wilderness Area[5] | 4,366.4 | 1,767.0 |

| Virginia Beach | Virginia | United States | False Cape State Park and Natural Area Preserve | 7007174864666011904♠4,321.0 | 7007174864666011904♠1,748.6 |

| Madrid | Madrid | Spain | Casa de Campo | 7007172234209337344♠4,256.0 | 7007172234209337344♠1,722.3 |

| Los Angeles | California | United States | Griffith Park | 7007170655935332608♠4,217.0 | 7007170655935332608♠1,706.6 |

| Philadelphia | Pennsylvania | United States | Fairmount Park (proper)[6] | 7007168632507121408♠4,167.0 | 7007168632507121408♠1,686.3 |

| Lethbridge | Alberta | Canada | Oldman River valley parks system | 7007161874256896000♠4,000.0 | 7007161874256896000♠1,618.7 |

| Jacksonville | Florida | United States | Pumpkin Hill Creek Preserve | 7007157665526216704♠3,896.0 | 7007157665526216704♠1,576.7 |

| Austin | Texas | United States | Walter E. Long Park | 7007150340716092160♠3,715.0 | 7007150340716092160♠1,503.4 |

| Chico | California | United States | Bidwell Park | 7007148519630702080♠3,670.0 | 7007148519630702080♠1,485.2 |

| Fort Worth | Texas | United States | Fort Worth Nature Center/Wildlife Refuge | 7007148195882188288♠3,662.0 | 7007148195882188288♠1,482.0 |

| Dallas | Texas | United States | Mountain Creek Lake Park | 7007147426979468032♠3,643.0 | 7007147426979468032♠1,474.3 |

| Kingsport | Tennessee | United States | Bays Mountain Park | 7007145079802743040♠3,585.0 | 7007145079802743040♠1,450.8 |

| Meridian | Mississippi | United States | Bonita Lakes Park | 7007140102169343488♠3,462.0 | 7007140102169343488♠1,401.0 |

| Virginia Beach | Virginia | United States | North Landing River State Natural Area Preserve | 7007139211860930560♠3,440.0 | 7007139211860930560♠1,392.1 |

| St. John's | Newfoundland and Labrador | Canada | Pippy Park | 7007137593118361600♠3,400.0 | 7007137593118361600♠1,375.9 |

| Calgary | Alberta | Canada | Fish Creek Provincial Park | 7007134800787430144♠3,331.0 | 7007134800787430144♠1,348.0 |

| Dallas | Texas | United States | Trinity River Park | 7007128406754282752♠3,173.0 | 7007128406754282752♠1,284.1 |

| Nashville | Tennessee | United States | Warner Parks | 7007126868948842240♠3,135.0[7] | 7007126868948842240♠1,268.7 |

| Tulsa | Oklahoma | United States | Mohawk Park and Golf Course | 7007125452549094400♠3,100.0 | 7007125452549094400♠1,254.5 |

| Brecksville | Ohio | United States | Brecksville Reservation (part) | 7007122457875341824♠3,026.0 | 7007122457875341824♠1,224.6 |

| Łodz | Łódź Voivodeship | Poland | Las Łagiewnicki | 7007120500006204666♠2,977.6 | 7007120500006204666♠1,205.0 |

| Natal | Rio Grande do Norte | Brazil | Natal Dunes State Park | 7007117196961992704♠2,896.0 | 7007117196961992704♠1,172.0 |

| Jacksonville | Florida | United States | Cecil Field Greenway | 7007115982905065984♠2,866.0 | 7007115982905065984♠1,159.8 |

| Fortaleza | Ceará | Brazil | Cocó Park | 7007115537750859520♠2,855.0 | 7007115537750859520♠1,155.4 |

| Calgary | Alberta | Canada | Nose Hill Park | 7007112704951363840♠2,785.0 | 7007112704951363840♠1,127.0 |

| New York City | New York | United States | Pelham Bay Park | 7007111895580079360♠2,765.0 | 7007111895580079360♠1,119.0 |

| Newport News | Virginia | United States | Newport News Park (part) | 7007108779500634112♠2,688.0 | 7007108779500634112♠1,087.8 |

| Lisbon | Lisboa Region | Portugal | Monsanto Forest Park | 7006999978221975040♠2,471.0 | 7006999978221975040♠1,000.0 |

| Paris | Île-de-France | France | Bois de Vincennes | 7006993907937341440♠2,456.0 | 7006993907937341440♠993.9 |

| San Diego | California | United States | Los Peñasquitos Canyon Preserve | 7006973268969587200♠2,405.0 | 7006973268969587200♠973.3 |

| Birmingham | West Midlands | United Kingdom | Sutton Park | 7006971245541376000♠2,400.0 | 7006971245541376000♠971.2 |

| Kansas City | Missouri | United States | Longview Lake Park (part) | 7006963556514173440♠2,381.0 | 7006963556514173440♠963.6 |

| London | Greater London | United Kingdom | Richmond Park | 7006955058115686400♠2,360.0 | 7006955058115686400♠955.1 |

| Kansas City | Missouri | United States | Blue River Parkway | 7006938466004354560♠2,319.0 | 7006938466004354560♠938.5 |

| Regina | Saskatchewan | Canada | Wascana Centre | 7006930776977152000♠2,300.0[8] | 7006930776977152000♠930.8 |

| Strongsville | Ohio | United States | Mill Stream Run Reservation (part) | 7006905686467333120♠2,238.0 | 7006905686467333120♠905.7 |

| Lee's Summit | Missouri | United States | Fleming Park (part) | 7006902044296552960♠2,229.0 | 7006902044296552960♠902.0 |

| Bristol | Tennessee | United States | Steele Creek Park | 7006900020868341760♠2,224.0 | 7006900020868341760♠900.0 |

| Lynn | Massachusetts | United States | Lynn Woods Reservation | 7006890308412928000♠2,200.0[9] | 7006890308412928000♠890.3 |

| Saint John | New Brunswick | Canada | Rockwood Park | 7006890308412928000♠2,200.0[10] | 7006890308412928000♠890.3 |

| Houston | Texas | United States | Bear Creek Pioneers Park | 7006877358472376320♠2,168.0 | 7006877358472376320♠877.4 |

| Paris | Île-de-France | France | Bois de Boulogne | 7006845792992281600♠2,090.0 | 7006845792992281600♠845.8 |

| Berkeley | California | United States | Tilden Regional Park | 7006841341450216960♠2,079.0[11] | 7006841341450216960♠841.3 |

| Los Angeles | California | United States | Sepulveda Basin Recreation Area | 7006821916539389440♠2,031.0 | 7006821916539389440♠821.9 |

| Galveston | Texas | United States | Galveston Island State Park | 7006814632197829120♠2,013.0 | 7006814632197829120♠814.6 |

| Belgrade | Serbia | Ada Ciganlija | 7006799658829066240♠1,976.0 | 7006799658829066240♠799.7 |

| Portland | Oregon | United States | Smith and Bybee Wetlands Natural Area | 7006798444772139520♠1,973.0 | 7006798444772139520♠798.4 |

| Dallas | Texas | United States | White Rock Lake Park | 7006789946373652480♠1,952.0 | 7006789946373652480♠789.9 |

| Vancouver | British Columbia | Canada | Pacific Spirit Regional Park | 7006762832435622400♠1,885.0 | 7006762832435622400♠762.8 |

| Kansas City | Missouri | United States | Swope Park | 7006730457584243200♠1,805.0 | 7006730457584243200♠730.5 |

| San Diego | California | United States | Torrey Pines State Reserve | 7006728434156032000♠1,800.0 | 7006728434156032000♠728.4 |

| Meriden | Connecticut | United States | Hubbard Park | 7006728434156032000♠1,800.0 | 7006728434156032000♠728.4 |

| San Jose | California | United States | Calero County Park | 7006721149814471680♠1,782.0 | 7006721149814471680♠721.1 |

| New York City | New York | United States | Greenbelt Park | 7006719531071902720♠1,778.0 | 7006719531071902720♠719.5 |

| Austin | Texas | United States | Barton Creek Greenway | 7006716698272407040♠1,771.0 | 7006716698272407040♠716.7 |

| Jacksonville | Florida | United States | Little Talbot Island State Park | 7006715484215480320♠1,768.0 | 7006715484215480320♠715.5 |

| Dublin | Leinster | Ireland | Phoenix Park | 7006712246730342400♠1,760.0 | 7006712246730342400♠712.2 |

| San Diego | California | United States | Mission Bay Park | 7006710627987773440♠1,756.0 | 7006710627987773440♠710.6 |

| Washington, D.C. | District of Columbia | United States | Rock Creek Park | 7006709818616488960♠1,754.0 | 7006709818616488960♠709.8 |

| San Diego | California | United States | Tijuana River Valley San Diego | 7006692012448230400♠1,710.0 | 7006692012448230400♠692.0 |

| Jacksonville | Florida | United States | Big Talbot Island State Park | 7006691203076945920♠1,708.0 | 7006691203076945920♠691.2 |

| Monza | Lombardy | Italy | Monza Park | 7006688002013515801♠1,700.1 | 7006688002013515801♠688.0 |

| North Little Rock | Arkansas | United States | Burns Park | 7006687965591808000♠1,700.0[12] | 7006687965591808000♠688.0 |

| Mexico City | Federal District | Mexico | Chapultepec Park | 7006685942163596800♠1,695.0 | 7006685942163596800♠685.9 |

| Wheeling | West Virginia | United States | Oglebay Park | 7006667731309696000♠1,650.0 | 7006667731309696000♠667.7 |

| Lawrence | Indiana | United States | Fort Harrison State Park | 7006663684453273600♠1,640.0 | 7006663684453273600♠663.7 |

| Eureka Springs | Arkansas | United States | Lake Leatherwood Park | 7006655590740428800♠1,620.0 | 7006655590740428800♠655.6 |

| Philadelphia | Pennsylvania | United States | Pennypack Park | 7006654781369144320♠1,618.0 | 7006654781369144320♠654.8 |

| Madrid | Madrid | Spain | Parque Lineal del Manzanares | 7006649925141437440♠1,606.0 | 7006649925141437440♠649.9 |

| Claremont | California | United States | Claremont Hills Wilderness Park | 7006643045485519360♠1,589.0 | 7006643045485519360♠643.0 |

| Chorzów | Silesia | Poland | Silesian Culture and Recreation Park | 7006619978403911680♠1,532.0 | 7006619978403911680♠620.0 |

| Phoenix | Arizona | United States | Adobe Dam Recreation Area | 7006617550290058240♠1,526.0 | 7006617550290058240♠617.6 |

| Riverside | California | United States | Hidden Valley Wildlife Area | 7006611075319782400♠1,510.0 | 7006611075319782400♠611.1 |

| Des Moines | Iowa | United States | Water Works Park | 7006607028463360000♠1,500.0 | 7006607028463360000♠607.0 |

| Birmingham | Alabama | United States | Red Mountain Park | 7006607028463360000♠1,500.0 | 7006607028463360000♠607.0 |

| Vienna | Vienna | Austria | Prater | 7006607028463360000♠1,500.0 | 7006607028463360000♠607.0 |

| Nashville | Tennessee | United States | Beaman Park | 7006604195663864320♠1,493.0 | 7006604195663864320♠604.2 |

| San Francisco | California | United States | Presidio of San Francisco Park | 7006603386292579840♠1,491.0 | 7006603386292579840♠603.4 |

| Chennai | Tamil Nadu | India | Arignar Anna Zoological Park | 7006602981606937600♠1,490.0 | 7006602981606937600♠603.0 |

| Lincoln | Nebraska | United States | Wilderness Park | 7006595697265377280♠1,472.0 | 7006595697265377280♠595.7 |

| Cincinnati | Ohio | United States | Mount Airy Forest | 7006595292579735040♠1,471.0 | 7006595292579735040♠595.3 |

| Houston | Texas | United States | Memorial Park | 7006593269151523840♠1,466.0 | 7006593269151523840♠593.3 |

| Omaha | Nebraska | United States | Glenn Cunningham Lake | 7006582342639183360♠1,439.0 | 7006582342639183360♠582.3 |

| Los Angeles | California | United States | Hansen Dam Recreation Center | 7006581533267898880♠1,437.0 | 7006581533267898880♠581.5 |

| Virginia Beach | Virginia | United States | Stumpy Lake Park | 7006580723896614400♠1,435.0 | 7006580723896614400♠580.7 |

| Lee's Summit | Missouri | United States | Longview Lake Park (part) | 7006578295782760960♠1,429.0 | 7006578295782760960♠578.3 |

| Riverside | California | United States | Sycamore Canyon Wilderness Park | 7006576272354549760♠1,424.0 | 7006576272354549760♠576.3 |

| Quito | Pichincha | Ecuador | Parque Metropolitano Guangüiltagua | 7006573998021240371♠1,418.4 | 7006573998021240371♠574.0[13] |

| Anchorage | Alaska | United States | Kincaid Park | 7006571011441200640♠1,411.0 | 7006571011441200640♠571.0 |

| Munich | Bavaria | Germany | Englischer Garten | 7006566559899136000♠1,400.0 | 7006566559899136000♠566.6 |

| San Antonio | Texas | United States | Rancho Diana | 7006563322413998080♠1,392.0 | 7006563322413998080♠563.3 |

| Honolulu | Hawaii | United States | Sacred Falls State Park | 7006556038072437760♠1,374.0 | 7006556038072437760♠556.0 |

| Huntersville | North Carolina | United States | Latta Plantation Nature Preserve | 7006543492817528320♠1,343.0 | 7006543492817528320♠543.5 |

| Colorado Springs | Colorado | United States | Garden of the Gods Park | 7006533780362114560♠1,319.0 | 7006533780362114560♠533.8 |

| New Orleans | Louisiana | United States | New Orleans City Park | 7006526091334912000♠1,300.0 | 7006526091334912000♠526.1 |

| St. Louis | Missouri | United States | Forest Park | 7006523258535416320♠1,293.0 | 7006523258535416320♠523.3 |

| San Diego | California | United States | Black Mountain Park | 7006519616364636160♠1,284.0 | 7006519616364636160♠519.6 |

| Colorado Springs | Colorado | United States | North Cheyenne Cañon Park | 7006509903909222400♠1,260.0 | 7006509903909222400♠509.9 |

| New York City | New York | United States | Flushing Meadows – Corona Park | 7006507880481011200♠1,255.0 | 7006507880481011200♠507.9 |

| Toronto | Ontario | Canada | Tommy Thompson Park | 7006499786768166400♠1,235.0 | 7006499786768166400♠499.8 |

| Oakland | California | United States | Martin Luther King, Jr. Shoreline Park | 7006493716483532800♠1,220.0 | 7006493716483532800♠493.7 |

| Chicago | Illinois | United States | Lincoln Park | 7006492097740963840♠1,216.0 | 7006492097740963840♠492.1 |

| Washington, D.C. | District of Columbia | United States | Anacostia Park | 7006491693055321600♠1,215.0 | 7006491693055321600♠491.7 |

| Phoenix | Arizona | United States | Cave Buttes Recreation Area I & II | 7006485622770688000♠1,200.0 | 7006485622770688000♠485.6 |

| Baltimore | Maryland | United States | Gwynns Falls Leakin Park | 7006485622770688000♠1,200.0 | 7006485622770688000♠485.6 |

| Jersey City | New Jersey | United States | Liberty State Park | 7006480766542981120♠1,188.0 | 7006480766542981120♠480.8 |

| Madrid | Madrid | Spain | Parque de Valdebebas | 7006479957171696640♠1,186.0 | 7006479957171696640♠480.0 |

| Glendale | Arizona | United States | Thunderbird Conservation Park | 7006479552486054400♠1,185.0 | 7006479552486054400♠479.6 |

| Tallahassee | Florida | United States | Alfred B. Maclay Gardens State Park | 7006477124372200960♠1,179.0 | 7006477124372200960♠477.1 |

| Columbus | Ohio | United States | Three Creeks Parks | 7006467816602429440♠1,156.0 | 7006467816602429440♠467.8 |

| Mesa | Arizona | United States | Red Mountain Park | 7006463891151699712♠1,146.3[14] | 7006463891151699712♠463.9 |

| New York City | New York | United States | Van Cortlandt Park | 7006463769746007040♠1,146.0[15] | 7006463769746007040♠463.8 |

| Memphis | Tennessee | United States | T.O. Fuller State Park | 7006460532260869120♠1,138.0[16] | 7006460532260869120♠460.5 |

| Austin | Texas | United States | Emma Long Metropolitan Park | 7006460127575226880♠1,137.0[17] | 7006460127575226880♠460.1 |

| Huntsville | Alabama | United States | Monte Sano Nature Preserve | 7006447987005959680♠1,107.0[18] | 7006447987005959680♠448.0 |

| Winnipeg | Manitoba | Canada | Assiniboine Park | 7006445154206464000♠1,100.0 | 7006445154206464000♠445.2 |

| Detroit | Michigan | United States | Rouge Park | 7006445154206464000♠1,100.0 | 7006445154206464000♠445.2 |

| London | Greater London | United Kingdom | Bushy Park | 7006444749520821760♠1,099.0 | 7006444749520821760♠444.7 |

| Charlotte | North Carolina | United States | McDowell Nature Preserve | 7006444344835179520♠1,098.0 | 7006444344835179520♠444.3 |

| San Diego | California | United States | Balboa Park | 7006522449164131840♠1,291.0 | 7006522449164131840♠522.4 |

| Colorado Springs | Colorado | United States | Cheyenne Mountain State Park | 7006428966780774400♠1,060.0 | 7006428966780774400♠429.0 |

| Brasília | Federal District | Brazil | Parque da Cidade Dona Sarah Kubitschek | 7006419998946942361♠1,037.8 | 7006419998946942361♠420.0 |

| Bedford | Ohio | United States | Bedford Reservation (part) | 7006418040268433920♠1,033.0 | 7006418040268433920♠418.0 |

| Dallas | Texas | United States | Rochester Park | 7006417635582791680♠1,032.0 | 7006417635582791680♠417.6 |

| Arlington | Texas | United States | River Legacy Park | 7006417230897149440♠1,031.0 | 7006417230897149440♠417.2 |

| San Francisco | California | United States | Golden Gate Park | 7006415612154580480♠1,027.0 | 7006415612154580480♠415.6 |

| San Luis Potosí | San Luis Potosí | Mexico | Parque Tangamanga I | 7006410755926873600♠1,015.0 | 7006410755926873600♠410.8 |

| Birmingham | Alabama | United States | Ruffner Mountain Park | 7006409137184304640♠1,011.0 | 7006409137184304640♠409.1 |

| San Antonio | Texas | United States | Olmos Basin | 7006408732498662400♠1,010.0 | 7006408732498662400♠408.7 |

| Willoughby Hills | Ohio | United States | North Chagrin Reservation (part) | 7006406304384808960♠1,004.0 | 7006406304384808960♠406.3 |

| Perth | Western Australia | Australia | Kings Park | 7006405899699166720♠1,003.0 | 7006405899699166720♠405.9 |

| Vancouver | British Columbia | Canada | Stanley Park | 7006404685642240000♠1,000.0 | 7006404685642240000♠404.7 |

See also[edit]
Lists of urban parks by country or region[edit]

Urban parks in Canada

References[edit]

Jump up ^ "Western Sydney Regional Park Draft Plan of Management" (PDF). NSW Government. Retrieved 16 May 2013. ...It is approximately 5,280 hectares in size and is the largest urban park in Australia.... 

Jump up ^ "조성배경". ulsanpark.com (in Korean). Retrieved 12 March 2015. 

Jump up ^ "Ulsan Grand Park (울산대공원)". Official Site of Korea Tourism Org. Retrieved 15 June 2013. 

Jump up ^ http://terms.naver.com/entry.nhn?docId=1075373&cid=40942&categoryId=31925

Jump up ^ Environment, Nova Scotia (2009-04-01). "Blue Mountain - Birch Cove Lakes Wilderness Area | Protected Areas | Nova Scotia Environment". www.novascotia.ca. Retrieved 2017-04-25. 

Jump up ^ "Fairmount Park" is officially the name of Philadelphia's entire municipal park system, consisting of 63 units. The system is named after the original Fairmount Park, the system's oldest unit, which occupies nearly half of the system's area.

Jump up ^ Recent acquisition of the Hill Tract has added 451 acres to the existing 2684 acres http://www.nashville.gov/Parks-and-Recreation/Nature-Centers-and-Natural-Areas/Warner-Park-Nature-Center.aspx http://www.friendsofwarnerparks.com/ht_about.html

Jump up ^ "Walk 1 - A Place for People!". Wascana Centre Authority. Retrieved 2010-04-02. 

Jump up ^ "Welcome to Lynn Woods!". Friends of Lynn Woods. Retrieved 2012-02-28. 

Jump up ^ "Rockwood Park". Tourism New Brunswick. Archived from the original on 30 March 2010. Retrieved 2010-08-19. 

Jump up ^ http://www.ebparks.org/parks/tilden

Jump up ^ "Burns Park". 

Jump up ^ "Parque Metropolitano". 

Jump up ^ "Archived copy". Archived from the original on 1 September 2013. Retrieved 9 July 2013. 

Jump up ^ http://www.vcpark.org/

Jump up ^ http://tnstateparks.com/parks/about/t-o-fuller

Jump up ^ http://austinparks.org/our-parks.html?parkid=247

Jump up ^ http://landtrustnal.org/properties/monte-sano-preserve/

Jump up ^ "Archived copy". Archived from the original on 29 October 2013. Retrieved 3 December 2012. 

						Retrieved from "https://en.wikipedia.org/w/index.php?title=List_of_urban_parks_by_size&oldid=830235582"

Categories:

Lists by area

Lists of parks

Urban public parks

Hidden categories:

CS1 Korean-language sources (ko)

Use dmy dates from September 2014

Articles needing additional references from May 2014

All articles needing additional references

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Español

Edit links

 This page was last edited on 13 March 2018, at 16:13.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews