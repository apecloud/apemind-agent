# Party leaders of the United States Senate

Party leaders of the United States Senate - Wikipedia

Party leaders of the United States Senate

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| This article does not cite any sources. Please help improve this article by adding citations to reliable sources. Unsourced material may be challenged and removed. (February 2016) (Learn how and when to remove this template message) |

Current leaders

Majority Leader

Mitch McConnell (R)

Majority Whip

John Cornyn (R)

Minority Leader

Chuck Schumer (D)

Minority Whip

Dick Durbin (D)

Party Leaders of the U.S. Senate

| This article is part of a series on the |

| United States Senate |

| History of the United States Senate |

| Members |

| Current members (by seniority by class) Former members Hill committees (DSCC NRSC) United States Vice President (list) President pro tempore (list) Presiding officer Party leaders Party leadership of the United States Senate Democratic Caucus Republican Conference |

| Politics and procedure |

| Advice and consent Blue slip Closed session (list) Cloture Committees (list) Executive session Morning business Filibuster Nuclear option Recess appointment Quorum Quorum call Salaries Saxbe fix Seal Holds Senatorial courtesy Standing Rules Traditions Unanimous consent Vice Presidents' tie-breaking votes |

| Places |

| United States Capitol Senate chamber Senate Reception Room Senate office buildings (Dirksen Hart Russell) |

| v t e |

The Senate Majority and Minority Leaders are two United States Senators and members of the party leadership of the United States Senate. These leaders serve as the chief Senate spokespeople for the political parties respectively holding the majority and the minority in the United States Senate, and manage and schedule the legislative and executive business of the Senate. They are elected to their positions in the Senate by their respective party caucuses, the Senate Democratic Caucus and the Senate Republican Conference.

By rule, the Presiding Officer gives the Majority Leader priority in obtaining recognition to speak on the floor of the Senate. The Majority Leader customarily serves as the chief representative of their party in the Senate, and sometimes even in all of Congress if the House of Representatives and thus the office of Speaker of the House is controlled by the opposition party.

The Assistant Majority and Minority Leaders of the United States Senate (commonly called Senate Majority and Minority Whips) are the second-ranking members of each party's leadership. The main function of the Majority and Minority Whips is to gather votes on major issues. Because they are the second ranking members of the Senate, if there is no floor leader present, the whip may become acting floor leader. Before 1969, the official titles were Majority Whip and Minority Whip.

Contents
 [hide] 

1 Current floor leaders

2 History

3 List of party leaders

4 See also

5 Notes

6 External links

Current floor leaders[edit]

The Senate is currently composed of 51 Republicans, 47 Democrats, and 2 independents, both of whom caucus with the Democrats.

The current leaders are long-time Senators Mitch McConnell (R) from Kentucky and Chuck Schumer (D) from New York. The current Assistant Leaders/Whips are long-time Senators John Cornyn (R) from Texas and Dick Durbin (D) from Illinois.

History[edit]

The Democrats began the practice of electing floor leaders in 1920 while they were in the minority. John W. Kern was a Democratic Senator from Indiana. While the title was not official, he is considered[by whom?] to be the first Senate party leader from 1913 through 1917 (and in turn, the first Senate Democratic Leader), while serving concurrently as Chairman of the Senate Democratic Caucus. In 1925 the majority (at the time) Republicans also adopted this language when Charles Curtis became the first (official) Majority Leader[citation needed], although his immediate predecessor Henry Cabot Lodge is considered the first (unofficial) Senate Majority Leader.

The Constitution designates the Vice President of the United States as President of the United States Senate. The Constitution also calls for a President pro tempore to serve as the leader of the body when the President of the Senate (the Vice President) is absent. In practice, neither the Vice President nor the President pro tempore—customarily the most senior (longest-serving) Senator in the majority party—actually presides over the Senate on a daily basis; that task is given to junior Senators of the majority party. Since the Vice President may be of a different party than the majority and is not a member subject to discipline, the rules of procedure of the Senate give the presiding officer very little power and none beyond the presiding role. For these reasons, it is the Majority Leader who, in practice, manages the Senate. This is in contrast to the House of Representatives where the elected Speaker of the House has a great deal of discretionary power and generally presides over votes on bills.[citation needed]

List of party leaders[edit]

The Democratic Party first selected a leader in 1920. The Republican Party first formally designated a leader in 1925.

| Cong- ress | Dates | Democratic Whip | Democratic Leader | Majority | Republican Leader | Republican Whip |

| 63rd | May 28, 1913 – March 4, 1915 | J. Hamilton Lewis | None | Democratic ← Majority | None | None |

| 64th | March 4, 1915 – December 6, 1915 |

| December 6, 1915 – December 13, 1915 | James Wadsworth |

| December 13, 1915 – March 4, 1917 | Charles Curtis |

| 65th | March 4, 1917 – March 4, 1919 |

| 66th | March 4, 1919 – April 27, 1920 | Peter Gerry | Republican Majority → | Henry Cabot Lodge Unofficial |

| April 27, 1920 – March 4, 1921 | Oscar Underwood |

| 67th | March 4, 1921 – March 4, 1923 |

| 68th | March 4, 1923 – December 3, 1923 |

| December 3, 1923 – November 9, 1924 | Joseph Taylor Robinson |

| November 9, 1924 – March 4, 1925 | Charles Curtis Acting | Wesley Jones Acting |

| 69th | March 4, 1925 – March 4, 1927 | Charles Curtis | Wesley Jones |

| 70th | March 4, 1927 – March 4, 1929 |

| 71st | March 4, 1929 – March 4, 1931 | Morris Sheppard | James E. Watson | Simeon Fess |

| 72nd | March 4, 1931 – March 4, 1933 |

| 73rd | March 4, 1933 – January 3, 1935 | J. Hamilton Lewis | Democratic ← Majority | Charles L. McNary | Felix Hebert |

| 74th | January 3, 1935 – January 3, 1937 | None[Note 1] |

| 75th | January 3, 1937 – July 14, 1937 |

| July 22, 1937 – January 3, 1939 | Alben W. Barkley |

| 76th | January 3, 1939 – April 9, 1939 |

| April 9, 1939 – January 3, 1940 | Sherman Minton |

| January 3, 1940 – January 3, 1941 | Warren Austin Acting |

| 77th | January 3, 1941 – January 3, 1943 | J. Lister Hill | Charles L. McNary |

| 78th | January 3, 1943 – February 25, 1944 | Kenneth Wherry |

| February 25, 1944 – January 3, 1945 | Wallace H. White Jr. Acting |

| 79th | January 3, 1945 – January 3, 1947 | Wallace H. White Jr. |

| 80th | January 3, 1947 – January 3, 1949 | Scott W. Lucas | Republican Majority → |

| 81st | January 3, 1949 – January 3, 1951 | Francis Myers | Scott W. Lucas | Democratic ← Majority | Kenneth S. Wherry | Leverett Saltonstall |

| 82nd | January 3, 1951 – January 3, 1952 | Lyndon B. Johnson | Ernest McFarland |

| January 3, 1952 – January 3, 1953 | Styles Bridges |

| 83rd | January 3, 1953 – July 31, 1953 | Earle Clements | Lyndon B. Johnson | Republican Majority → | Robert A. Taft |

| August 3, 1953 – January 3, 1955 | William F. Knowland |

| 84th | January 3, 1955 – January 3, 1957 | Democratic ← Majority |

| 85th | January 3, 1957 – January 3, 1959 | Mike Mansfield | Everett Dirksen |

| 86th | January 3, 1959 – January 3, 1961 | Everett Dirksen | Thomas Kuchel |

| 87th | January 3, 1961 – January 3, 1963 | Hubert Humphrey | Mike Mansfield |

| 88th | January 3, 1963 – January 3, 1965 |

| 89th | January 3, 1965 – January 3, 1967 | Russell B. Long |

| 90th | January 3, 1967 – January 3, 1969 |

| 91st | January 3, 1969 – September 7, 1969 | Ted Kennedy | Hugh Scott |

| September 24, 1969 – January 3, 1971 | Hugh Scott | Robert Griffin |

| 92nd | January 3, 1971 – January 3, 1973 | Robert Byrd |

| 93rd | January 3, 1973 – January 3, 1975 |

| 94th | January 3, 1975 – January 3, 1977 |

| 95th | January 3, 1977 – January 3, 1979 | Alan Cranston | Robert Byrd | Howard Baker | Ted Stevens |

| 96th | January 3, 1979 – November 1, 1979 |

| November 1, 1979 – March 5, 1980 | Ted Stevens Acting |

| March 5, 1980 – January 3, 1981 | Howard Baker |

| 97th | January 3, 1981 – January 3, 1983 | Republican Majority → |

| 98th | January 3, 1983 – January 3, 1985 |

| 99th | January 3, 1985 – January 3, 1987 | Bob Dole | Alan Simpson |

| 100th | January 3, 1987 – January 3, 1989 | Democratic ← Majority |

| 101st | January 3, 1989 – January 3, 1991 | George Mitchell |

| 102nd | January 3, 1991 – January 3, 1993 | Wendell H. Ford |

| 103rd | January 3, 1993 – January 3, 1995 |

| 104th | January 3, 1995 – June 12, 1996 | Tom Daschle | Republican Majority → | Trent Lott |

| June 12, 1996 – January 3, 1997 | Trent Lott | Don Nickles |

| 105th | January 3, 1997 – January 3, 1999 |

| 106th | January 3, 1999 – January 3, 2001 | Harry Reid |

| 107th | January 3, 2001 – January 20, 2001 | Democratic ← Majority |

| January 20, 2001 – June 6, 2001 | Republican Majority → |

| June 6, 2001 – January 3, 2003[Note 2] | Democratic ← Majority |

| 108th | January 3, 2003 – January 3, 2005 | Republican Majority → | Bill Frist | Mitch McConnell |

| 109th | January 3, 2005 – January 3, 2007 | Dick Durbin | Harry Reid |

| 110th | January 3, 2007 – December 18, 2007 | Democratic ← Majority | Mitch McConnell | Trent Lott |

| December 19, 2007 – January 3, 2009 | Jon Kyl |

| 111th | January 3, 2009 – January 3, 2011 |

| 112th | January 3, 2011 – January 3, 2013 |

| 113th | January 3, 2013 – January 3, 2015 | John Cornyn |

| 114th | January 3, 2015 – January 3, 2017 | Republican Majority → |

| 115th | January 3, 2017 – January 3, 2019 | Chuck Schumer |

| Cong- ress | Dates | Democratic Whip | Democratic Leader | Majority | Republican Leader | Republican Whip |

See also[edit]

| This article is part of a series on the |

| Politics of the United States of America |

| Federal Government[show] Constitution of the United States Law Taxation |

| Legislature[show] United States Congress House of Representatives Speaker Paul Ryan (R) Majority Leader Kevin McCarthy (R) Minority Leader Nancy Pelosi (D) Congressional districts United States Senate President Mike Pence (R) President Pro Tempore Orrin Hatch (R) President Pro Tempore Emeritus Patrick Leahy (D) Majority Leader Mitch McConnell (R) Minority Leader Chuck Schumer (D) |

| Executive[show] President of the United States Donald Trump (R) Vice President of the United States Mike Pence (R) Cabinet Federal agencies Executive Office |

| Judiciary[show] Supreme Court of the United States Chief Justice John Roberts Kennedy Thomas Ginsburg Breyer Alito Sotomayor Kagan Gorsuch Courts of Appeals District Courts (list) Other tribunals |

| Elections[show] Presidential elections Midterm elections Off-year elections |

| Political parties[show] Democratic Republican Third parties |

| Federalism[show] State Government Governors Legislatures (List) State courts Local government |

| Other countries Atlas |

| v t e |

Party leaders of the United States House of Representatives

President pro tempore of the United States Senate

Vice President of the United States (President of the United States Senate)

Party divisions of United States Congresses

List of political parties in the United States

Notes[edit]

Jump up ^ No Republican whips were appointed from 1935 to 1944 since only 17 Republicans were in the Senate following the landslide reelection of President Franklin D. Roosevelt in 1936. Accordingly, the minutes of the Republican Conference for the period state: "On motion of Senator Hastings, duly seconded and carried, it was agreed that no Assistant Leader or Whip be elected but that the chairman be authorized to appoint Senators from time to time to assist him in taking charge of the interests of the minority." A note attached to the conference minutes added: "The chairman of the conference, Senator McNary, apparently appointed Senator Austin of Vermont as assistant leader in 1943 and 1944, until the conference adopted Rules of Organization." Source: Party Whips Archived 2010-03-09 at the Wayback Machine., via Senate.gov

Jump up ^ Democrats remained in control after November 25, 2002, despite a Republican majority resulting from Jim Talent's special election victory in Missouri. There was no reorganization as the Senate was no longer in session. Party Division in the Senate, 1789–present, via Senate.gov

External links[edit]

Majority and Minority Leaders and Party Whips, via Senate.gov

Republican Majority

Democratic Minority

| [show] v t e Current leadership of the United States Senate |

| President: Mike Pence (R) President pro tempore: Orrin Hatch (R) |

| Majority (Republican) | Minority (Democratic) |

| Mitch McConnell (Leader) John Cornyn (Whip) John Thune (Conference Chair) John Barrasso (Policy Committee Chair) Roy Blunt (Conference Vice Chair) Cory Gardner (Campaign Committee Chair) Mike Lee (Steering Committee Chair) Mike Crapo (Chief Deputy Whip) | Chuck Schumer (Leader and Caucus Chair) Dick Durbin (Whip) Patty Murray (Assistant Leader) Debbie Stabenow (Policy Committee Chair) Mark Warner and Elizabeth Warren (Caucus Vice Chair) Amy Klobuchar (Steering Committee Chair) Bernie Sanders (Outreach Committee Chair) Joe Manchin (Policy Committee Vice Chair) Tammy Baldwin (Caucus Secretary) Chris Van Hollen (Campaign Committee Chair) Jeff Merkley (Chief Deputy Whip) Patrick Leahy (Senate President pro tempore emeritus) |

| [show] v t e United States Congress |

| House of Representatives Senate (114th←115th→116th) Lists of congressional lists |

| [show] Members and leaders |

| Current | By length of service Freshmen Youngest members Resident Commissioner of Puerto Rico Delegates |

| Senate | Current by seniority Dean of the Senate Former U.S. Senators living Earliest serving Earliest living Expelled or censured Classes Born outside the U.S. |

| House | Current by seniority Dean of the House Former U.S. Representatives living Oldest living Earliest serving Expelled, censured, and reprimanded |

| Senate | President (list) President pro tempore (list) Majority and minority leaders Assistant party leaders Democratic Caucus (Chair Secretary Policy Committee Chair) Republican Conference (Chair Vice-Chair Policy Committee Chair) |

| House | Speaker Leaders Bipartisan Legal Advisory Group Democratic Caucus Republican Conference |

| Districts | List Apportionment |

| Caucuses, women and minorities | Congressional caucus African Americans in the House Congressional Black Caucus African Americans in the Senate Arab and Middle-Eastern members Asian Pacific American members Congressional Asian Pacific American Caucus Hispanic and Latino members Congressional Hispanic Caucus Congressional Hispanic Conference Jewish members LGBT members LGBT Equality Caucus Native American members Women in the House Congressional Caucus for Women's Issues Women in the Senate |

| Related | By length of service historically |

| [show] Powers, privileges, procedure, committees, history, and media |

| Powers | Article I Copyright Commerce (Dormant) Contempt of Congress Declaration of war Impeachment Naturalization "Necessary and Proper" Power of enforcement Taxing/spending |

| Privileges and benefits | Salaries Franking Immunity |

| Procedure | Act of Congress (list) Appropriation bill Blue slip Budget resolution Censure Closed sessions House Senate Cloture Concurrent resolution Continuing resolution Dear colleague letter Discharge petition Engrossed bill Enrolled bill Expulsion Joint resolution Joint session (list) Lame-duck session Majority of the majority (Hastert Rule) Multiple referral Procedures (House) Quorum call Reconciliation Rider Saxbe fix Sponsorship Suspension of the rules Unanimous consent Veto Line-item veto Pocket veto Veto override |

| Senate-specific | Advice and consent Classes Executive communication Executive session Filibuster Jefferson's Manual Senate Journal Morning business Nuclear option Presiding Officer Recess appointment Reconciliation Riddick's Senate Procedure Senate hold Senatorial courtesy Seniority Standing Rules Tie-breaking votes Traditions Treaty Clause |

| Committees | Chairman and ranking member Of the Whole Conference Discharge petition Hearings Markup Oversight List (Joint) List (House) List (Senate) Select and special Standing Subcommittees |

| Items | Gavels Mace of the House Seal of the Senate |

| History | Biographical Directory Congressional apportionment Divided government House Gerrymandering Party control Senate Senate election disputes Senatorial memoirs Representative memoirs |

| Media | C-SPAN Congressional Quarterly The Hill Politico Roll Call |

| [show] Offices, employees, services, and the Capitol Complex |

| Legislative offices | Congressional staff Government Accountability Office (Comptroller General) Architect of the Capitol Capitol Police (Capitol Police Board) Capitol Guide Service (Capitol Guide Board) Congressional Budget Office (CBO) Compliance Library of Congress Government Publishing Office (GPO) Technology Assessment |

| Senate | Curator Historical Library |

| House | Congressional Ethics Emergency Planning, Preparedness, and Operations Interparliamentary Affairs Legislative Counsel Law Revision Counsel Library |

| Senate | Secretary Chaplain Curator Inspector General Historian Librarian Pages Parliamentarian Sergeant at Arms and Doorkeeper |

| House | Chaplain Chief Administrative Officer Clerk Doorkeeper Floor Operations Floor Services Chief Historian Pages (Page Board) Parliamentarian Postmaster Reading Clerk Sergeant at Arms |

| Library of Congress | Congressional Research Service (reports) Copyright Office (Register of Copyrights) Law Library Poet Laureate THOMAS Adams Building Jefferson Building Madison Building |

| Government Publishing Office | Public Printer Congressional Pictorial Directory Congressional Record Official Congressional Directory United States Government Manual Serial Set Statutes at Large United States Code |

| Capitol | Brumidi Corridors Congressional Prayer Room Crypt Dome Statue of Freedom Rotunda Hall of Columns Statuary Hall Visitor Center The Apotheosis of Washington Statue of Freedom Declaration of Independence painting Scene at the Signing of the Constitution of the United States Apotheosis of Democracy First Reading of the Emancipation Proclamation of President Lincoln Surrender of General Burgoyne Surrender of Lord Cornwallis Revolutionary War Door Westward the Course of Empire Takes Its Way Vice President's Room Vice Presidential Bust Collection |

| Senate | Dirksen Hart Mountains and Clouds Russell |

| House | Building Commission Cannon Ford Longworth O'Neill Rayburn |

| Other facilities | Botanic Garden Health and Fitness Facility House Recording Studio Senate chamber Old Senate Chamber Old Supreme Court Chamber Power Plant Webster Page Residence Subway |

`

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Party_leaders_of_the_United_States_Senate&oldid=832195445"

Categories:

Leaders of the United States Senate

Lists of United States Senators

Political whips

Hidden categories:

Webarchive template wayback links

Articles lacking sources from February 2016

All articles lacking sources

Pages using multiple image with auto scaled images

Articles with specifically marked weasel-worded phrases from July 2017

All articles with unsourced statements

Articles with unsourced statements from November 2009

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

Català

Deutsch

Español

فارسی

Français

Italiano

日本語

Polski

Português

Simple English

Svenska

Tiếng Việt

中文
				4 more

Edit links

 This page was last edited on 24 March 2018, at 12:18.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews