# Companies Act 2013

Companies Act 2013 - Wikipedia

Companies Act 2013

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| Companies Act 2013 |

| An Act to consolidate and amend the law relating to companies. |

| Citation | Act No. 18 of 2013 |

| Territorial extent | India |

| Enacted by | Parliament of India |

| Date assented to | 29 August 2013 |

| Date signed | 29 August 2013 |

| Date commenced | 12 September 2013 (98 sections) 1 April 2014 (184 sections) |

| Legislative history |

| Bill | The Companies Bill, 2012 |

| Bill citation | Bill No. 121-C of 2011 |

| Repealing legislation |

| The Companies Act 1956 |

| Status: In force |

The Companies Act 2013 is an Act of the Parliament of India on Indian company law which regulates incorporation of a company, responsibilities of a company, directors, dissolution of a company. The 2013 Act is divided into 29 chapters containing 470 sections as against 658 Sections in the Companies Act, 1956 and has 7 schedules.[1]The Act has replaced The Companies Act, 1956 (in a partial manner) after receiving the assent of the President of India on 29 August 2013. The Act came into force on 12 September 2013 with few changes like earlier private companies maximum number of member was 50 and now it will be 200. A new term of "one person company" is included in this act that will be a private company and with only 98 provisions of the Act notified.[2][3] A total of another 184 sections came into force from 1 April 2014.[4]

The Ministry of Company Affairs thereafter published a notification for exempting private companies from the ambit of various sections under the Companies Act.[5]

Contents
 [hide] 

1 History

2 New Concepts

3 Brief description of new concepts

4 See also

5 Notes

6 External links

History[edit]

Companies Act 1956 was an Act of the Parliament of India, enacted in 1956, which enabled companies to be formed by registration, sets out the responsibilities of companies, their directors and secretaries and also provides for the procedures for its winding.[6]

New Concepts[edit]

One Person Companies (OPC)[7]sec 2(62)

Women Directors (second proviso to sec 149(1) or 149 subsection read with rule 3 of companies (appointment and qualifications of directors rules, 2014)

Corporate Social Responsibility

Registered Valuers

Rotation of Auditors

Class Action

Dormant Company sec 455(1)

Fast Track Mergers

Serious Fraud Investigation Office

Brief description of new concepts[edit]

One Person Company is a company with only one person as a member. That one person will be the shareholder of the company. It avails all the benefits of a private limited company such as separate legal entity, protecting personal assets from business liability, and perpetual succession. One Person Company (OPC) is a Company registered with ONLY ONE PERSON as its shareholder. The Nominee shall act as the deemed director on the death or incapacity of the One Person. An OPC is classified as a private company under Companies Act.

Woman Director: Every Listed Company and Public Company with paid up capital of Rs 100 Crores or more / Public Company with turnover of Rs 300 Crores or more shall have at least one Woman Director, in accordance with the Rule 3 to the Companies (Appointment of directors) Rules, 2014.

Corporate Social Responsibility Clause (135)[8] Every company having net worth of rupees five hundred crore or more, or turnover of rupees one thousand crore or more or a net profit of rupees five crore or more during any financial year shall constitute a Corporate Social Responsibility Committee of the Board consisting of three or more directors, out of which at least one director shall be an independent director.

Registered Valuers - Valuation by registered valuers. Clause (247) (1) Where a valuation is required to be made in respect of any property, stocks, shares, debentures, securities or goodwill or any other assets (herein referred to as the assets) or net worth of a company or its liabilities under the provision of this Act, it shall be valued by a person having such qualifications and experience and registered as a valuer in such manner, on such terms and conditions as may be prescribed and appointed by the audit committee or in its absence by the Board of Directors of that company.

Class action suits (clause 245) For the first time, a provision has been made for class action suits. It is provided that specified number of member(s), depositor(s) or any class of them, may, if they are of the opinion that the management or control of the affairs of the company are being conducted in a manner prejudicial to the interests of the company or its members or depositors, file an application before the Tribunal on behalf of the members or depositors. Where the members or depositors seek any damages or compensation or demand any other suitable action from or against an audit firm, the liability shall be of the firm as well as of each partner who was involved in making any improper or misleading statement of particulars in the audit report or who acted in a fraudulent, unlawful or wrongful manner. The order passed by the Tribunal shall be binding on the company and all its members, depositors and auditors including audit firm or expert or consultant or advisor or any other person associated with the company.

Dormant Company - Where a company is formed and registered under this Act for a future project or to hold an asset or intellectual property and has no significant accounting transaction, such a company or an inactive company may make an application to the Registrar for obtaining the status of a dormant company(inactive company)

Serious Fraud Investigation Office (clause 211) Statutory status to SFIO has been proposed. Investigation report of SFIO filed with the Court for framing of charges shall be treated as a report filed by a Police Officer. SFIO shall have power to arrest in respect of certain offences of the Bill which attract the punishment for fraud. Those offences shall be cognizable and the person accused of any such offence shall be released on bail subject to certain conditions provided in the relevant clause of the Bill.

Fast Track Mergers : The Companies Act, 2013 has separate provisions of fast track merger under Section 233 of Companies Act, 2013. These provisions are notwithstanding with the normal provisions of merger under Section 230 and 232 of this Act. Under fast track merger processes Central Government has the power to sanction all such scheme and there will be no requirement to approach National Company Law Tribunal .

See also[edit]

Indian company law

UK company law

European company law

US corporate law

Notes[edit]

Jump up ^ Prasad, Suresh. "Complete list of Sections of Companies Act, 2013". AUBSP. Retrieved August 7, 2016. 

Jump up ^ "Commencement Notification Of Companies Act 2013" (PDF). Ministry of Corporate Affairs, India. Retrieved 11 January 2014. 

Jump up ^ Varma, Sindhu. "India: New Companies Act, 2013 – The Cat Is Finally Out". Mondaq. Retrieved 27 March 2014. 

Jump up ^ "MCA notifies 183 sections of Companies Act 2013". Business Standards. 26 March 2014. Retrieved 27 March 2014. 

Jump up ^ http://www.companiesact.in/Companies-Act-2013/News-Details/545/%20MCA%20lays%20draft%20notification%20us%20462%20for%20Private%20Companies%20in%20Parliament

Jump up ^ "Business Portal of India : Starting a Business : Regulatory Requirements : Companies Act". National Portal of India. Government of India. 

Jump up ^ https://www.icsi.edu/portals/70/516102013.pdf

Jump up ^ Prasad, Suresh. "Section 135 - Corporate Social Responsibility Committee". AUBSP. Retrieved September 4, 2015. 

External links[edit]

Notified sections of Companies Act, 2013

Act No. 1 of 1956

Text of the Companies Act, 1956

http://www.mca.gov.in/Ministry/pdf/Companies_Cost_Records_and_Audit_%20amdt_Rules_2015.pdf

http://www.mca.gov.in/Ministry/pdf/General_Circular_8-2015.pdf

http://www.mca.gov.in/Ministry/pdf/Exemptions_to_private_companies_05062015.pdf

http://www.mca.gov.in/Ministry/pdf/Exemptions_to_Section8_companies_05062015.pdf

| [hide] v t e Indian Legislation |

| Constitution of India (amendments) Indian Penal Code CrPC |

| In Force |

| Consumer | Real Estate (Regulation and Development) Act, 2016 Consumer Protection Act, 1986 Essential Commodities Act Essential Services Maintenance Act |

| Corruption | Benami Transactions Black Money Corruption Lokpal Mines & Minerals Act 2015 Money Laundering Whistle Blowers |

| Criminal | Armed Forces (Special Powers) Act Armed Forces Tribunal Act, 2007 Arms Act, 1959 Army Act Criminal Law (Amendment) Act, 2013 Indian Evidence Act Juvenile Justice (Care and Protection of Children) Act, 2015 National Security Act (India) Protection of Women from Domestic Violence Act, 2005 Scheduled Caste and Scheduled Tribe (Prevention of Atrocities) Act, 1989 Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013 |

| Education | National Institutes of Technology Act, 2007 Right of Children to Free and Compulsory Education Act University Grants Commission Act, 1956 |

| Environment | Biological Diversity Act, 2002 Environment Protection Act, 1986 Indian Forest Act, 1927 National Green Tribunal Act Prevention of Cruelty to Animals Act Protection of Plant Varieties and Farmers' Rights Act, 2001 Wildlife Protection Act, 1972 CAMPA bill Air (Prevention and Control of Pollution) Act |

| Financial | Aadhaar Act Banking Regulation Act, 1949 COFEPOSA Depositories Act Electricity Act Expenditure Tax Act, 1987 Factories Act,1948, India Finance Act (India) Fiscal Responsibility and Budget Management Act, 2003 Foreign Contribution Regulation Act Foreign Exchange Management Act Geographical Indications of Goods (Registration and Protection) Act, 1999 Government Securities Act, 2006 Indian Contract Act, 1872 Indian Stamp Act, 1899 Insolvency and Bankruptcy Code Insurance Act, 1938 Minimum Wages Act 1948 National Rural Employment Guarantee Act, 2005 Negotiable Instruments Act, 1881 Securities Laws (Amendment) Act, 2014 Securitisation and Reconstruction of Financial Assets and Enforcement of Security Interest Act, 2002 The Competition Act, 2002 The High Denomination Bank Notes (Demonetisation) Act, 1978 The Income-tax Act, 1961 Urban Land (Ceiling and Regulation) Act, 1976 |

| Healthcare | Central Council of Homoeopathy Act, 1973 Clinical Establishments Act Dentist Act Drugs and Cosmetics Act, 1940 Drugs and Magic Remedies Act Indian Medical Council Act Mental Health Act, 1987 Narcotic Drugs and Psychotropic Substances Act, 1985 |

| Personal | Hindu Adoptions and Maintenance Act (1956) Majority Act (India) Hindu Minority and Guardianship Act Hindu Succession Act, 1956 Special Marriage Act, 1954 The Hindu Marriage Act, 1955 The Muslim Women (Protection of Rights on Divorce) Act 1986 |

| Social | Child Labour (Prohibition and Regulation) Act Indecent Representation of Women (Prohibition) Act Interstate Migrant Workmen Act 1979 National Food Security Act, 2013 Pre-Conception and Pre-Natal Diagnostic Techniques Act, 1994 The Prohibition of Child Marriage Act, 2006 The Scheduled Tribes and Other Traditional Forest Dwellers (Recognition of Forest Rights) Act, 2006 Street Vendors Act, 2014 Unorganised Workers' Social Security Act |

| State Laws | Anti-Superstition and Black Magic Act The Bombay Prohibition Act, 1949 Bombay Prohibition (Gujarat Amendment) 2009 Chhattisgarh Food Security Act, 2012 Maharashtra Control of Organised Crime Act The Gujarat Local Authorities Laws (Amendment) Bill, 2009 Puducherry Prevention of Anti-Social Activities Act |

| State Reorganisation | Chhattisgarh Jharkhand Punjab States Telangana Uttarakhand |

| Terrorism | Unlawful Activities (Prevention) Act |

| Transportation | Aircraft Act Motor Vehicles Act, 1988 National Waterways Act, 2016 Inland Vessels Act Metro Railways Act, 1978 Metro Railway Act, 2002 |

| Organisation / Body | Chartered Accountants Act, 1949 Companies Act 2013 Gram Nyayalayas Act, 2008 Indian Trusts Act, 1882 Panchayats (Extension to Scheduled Areas) Act 1996 Reserve Bank of India Act, 1934 The Indian Partnership Act, 1932 Societies' Registration Act The Limited Liability Partnership Act, 2008 |

| Repeal | Repealing and Amending Act, 2015 Repealing and Amending Act, 2016 |

| Other | Delimitation Act Enemy Property Act, 1968 Information Technology Act, 2000 Nuclear Liability Act Representation of the People Act, 1951 Right to Fair Compensation and Transparency in Land Acquisition, Rehabilitation and Resettlement Act, 2013 Right to Information Act, 2005 State Emblem of India (Prohibition of Improper Use) Act, 2005 The Foreigners Act, 1946 |

| Ordinance | List of Ordinances |

| Repealed |

| Pre-Independence | Age of Consent Act, 1891 Criminal Tribes Act Hindu Widows' Remarriage Act, 1856 Official Secrets Act (India) Public Debt Act, 1944 |

| Post-Independence | Anti-Copying Act, 1992 Foreign Exchange Regulation Act Gift Tax Act, 1958 Illegal Migrants (Determination by Tribunal) Act, 1983 Interest Tax Act, 1974 Juvenile Justice (Care and Protection of Children) Act, 2000 Maintenance of Internal Security Act Prevention of Terrorism Act, 2002 Terrorist and Disruptive Activities (Prevention) Act The Gold (Control) Act, 1968 Wealth Tax Act, 1957 |

| Bills |

| Proposed | Foreign Education Providers Bill, 2013 Geospatial Information Regulation Bill Gujarat Control of Organised Crime Act Indian Institute of Management Bill, 2017 Marriage Laws Amendment Bill Road Transport and Safety Bill Uniform civil code |

| Lapsed | Women's Reservation Bill |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Companies_Act_2013&oldid=819282560"

Categories:

Acts of the Parliament of India 2013

Indian company law

Hidden categories:

Use dmy dates from March 2016

Use Indian English from March 2016

All Wikipedia articles written in Indian English

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			Languages

हिन्दी

ਪੰਜਾਬੀ

தமிழ்

Edit links

 This page was last edited on 8 January 2018, at 14:12.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews