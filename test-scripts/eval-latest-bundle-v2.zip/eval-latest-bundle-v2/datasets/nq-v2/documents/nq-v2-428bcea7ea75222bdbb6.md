# That's So Raven

That's So Raven - Wikipedia

That's So Raven

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

This article is about the teen sitcom series. For the soundtrack, see That's So Raven (soundtrack). For other similarly titled TV series, see Raven (disambiguation).

| That's So Raven |

| Genre | Sitcom |

| Created by | Michael Poryes Susan Sherman |

| Starring | Raven-Symoné Orlando Brown Kyle Massey Anneliese van der Pol T'Keyah Crystal Keymáh Rondell Sheridan |

| Theme music composer | John Coda |

| Opening theme | "That's So Raven" by Raven-Symoné, Orlando Brown, and Anneliese van der Pol |

| Ending theme | "That's So Raven (Instrumental)" (except episode 89) |

| Country of origin | United States |

| Original language(s) | English |

| No. of seasons | 4 |

| No. of episodes | 100 (list of episodes) |

| Production |

| Executive producer(s) | Marvin Harris (season 1-4) Michael Poryes (season 1) Sean McNamara (season 1–3) David Brookwell (season 1–3) Dennis Rinsler Marc Warren (season 3–4) Raven-Symoné (season 4) |

| Location(s) | Sunset Gower Studios Hollywood Center Studios Los Angeles, California |

| Camera setup | Videotape; multi-camera |

| Running time | approx. 23 minutes |

| Production company(s) | Disney Channel Original Brookwell McNamara Entertainment (season 1–3) That's So Productions (season 4) Warren & Rinsler Productions (season 4) |

| Distributor | Buena Vista Television |

| Release |

| Original network | Disney Channel |

| Picture format | 480i |

| Original release | January 17, 2003 (2003-01-17) – November 10, 2007 (2007-11-10) |

| Chronology |

| Followed by | Cory in the House (2007–2008) Raven's Home (2017−present) |

| External links |

| Official website |

That's So Raven is an American supernatural sitcom that debuted on Disney Channel on January 17, 2003, and ended its run on November 10, 2007. The series was nominated in 2005 and 2007 for Emmy Awards for Outstanding Children's Programming.

The show was set in San Francisco and revolved around teenager Raven Baxter, played by Raven-Symoné, her friends Eddie (Orlando Brown) and Chelsea (Anneliese van der Pol), her family members; mother Tanya Baxter (T'Keyah Crystal Keymáh), father Victor Baxter (Rondell Sheridan) and brother Cory (Kyle Massey). The title character drew on her psychic powers, ingenuity, and talent as a fashion designer as well as a variety of disguises to get into and out of amusing adolescent and pre-adolescent situations.

Reruns of episodes aired on the ABC Kids Saturday morning segment of Disney-owned broadcast network ABC in the United States until August 27, 2011, when the block was discontinued. No announcement was made as to whether the show would get complete season releases on DVD. That's So Raven garnered higher ratings than any other Disney Channel show at the time. It went on to be the first show in Disney Channel history to make the 100-episode mark.[1]

The show was so popular that it received a spin-off focusing on Cory. The show was called Cory in the House. The series lasted for two seasons and had 34 episodes. In October 2016, Raven-Symoné announced that there would be a second spin-off about Raven raising her two children, one with psychic visions.[2][3] The show, titled Raven's Home, premiered on July 21, 2017.[4]

Contents
 [hide] 

1 Overview

2 Production

2.1 Opening sequence

3 Episodes

3.1 Crossover with The Suite Life of Zack & Cody and Hannah Montana

4 Cast and characters

4.1 Main

4.2 Recurring

5 Reunion

6 Merchandise

6.1 Soundtrack albums

6.2 Series novelizations

6.3 Video games

7 Reception

8 VHS and DVD releases

8.1 Volume releases

9 Other releases

10 Name in other countries

11 Spin-off and Sequels

11.1 Cory in the House

11.2 Failed Movie Attempt

11.3 Raven's Home

12 Indian adaptation

13 Awards and nominations

14 See also

15 References

16 External links

Overview[edit]

Raven Baxter, a teenage girl, receives short psychic visions of the future events when in deep situations. Attempting to make these visions come true frequently results in trouble and hilarious situations for herself, her family, and her friends.

Production[edit]

The name for the main character changed several times prior to production, starting with Dawn Baxter in a show named The Future Is on Me. Names changed to Rose Baxter in a show called Absolutely Psychic but finally settling on Raven Baxter when actress Raven-Symoné won the lead part, with the show titled That's So Raven. Symoné originally auditioned for the role of the best friend, Chelsea. Raven-Symoné was credited simply as "Raven" throughout the series.

The show filmed a special pilot episode on April 12, 2001, and the first season was filmed from November 9, 2001 – June 2002.[5]

That's So Raven was responsible for many firsts for Disney Channel: the series was the highest-rated series in the history of Disney Channel and the first series to garner more than three-million viewers; the third longest-running original series in Disney Channel history, the first Disney Channel series to reach 100 episodes, the first Disney Channel series to produce a spinoff (Cory in the House) and one of the first two live action original series where the lead and most of the supporting main characters are minorities (The Famous Jett Jackson being the other).

In addition, it was also the first Disney Channel sitcom to be shot on videotape, to use a multi-camera format, to be shot in front of a studio audience or use a laugh track,[citation needed] and to use the simulated film look created by FilmLook, Inc. (all of which has become standard on all Disney Channel comedies, though a 'filmized' appearance was given to all of the channel's videotaped sitcoms produced from 2009 onward, as the live-action Disney Channel Original Series begin being produced in high definition).

The first three seasons were produced by Brookwell McNamara Entertainment. The company later left at the end of season 3, being replaced by Warren & Rinsler Productions. Raven-Symoné then received a producer credit for the show's fourth and final season, with the credit being called "That So Productions". It became the first Disney Channel series to create a spin-off, Cory in the House, which followed her younger brother, Cory, as his dad became the head chef for the President of the United States, causing the two of them to move to Washington, D.C.

In the fourth season of That's So Raven and on Cory in the House, Victor states that Tanya (T'Keyah Crystal Keymáh) is in England studying to be a lawyer. The show shot its final few episodes in January 2006, but they weren't all aired until a year later, with the series finale airing in March 2007 and the second-to-last episode shown that November.

Opening sequence[edit]

The show's title theme song was written by John Coda, who also composed the music cues to signify scene changes and commercial breaks for this series as well as Even Stevens. It was produced by Jeffrey "Def Jef" Fortson and Christopher B. Pearman and was performed by Raven-Symoné, Anneliese van der Pol and Orlando Brown.

Each season had opening credits composed of footage from the episodes of that season. Each season also made an exception to the guideline by showing footage from the previous seasons, most of the time when it was needed. For example, if footage being shown was of the characters dancing, then footage of a character or characters would be shown. When originally broadcast, season two followed the guideline, but when season three began airing, the opening credits from season two were inexplicably replaced with the opening credits from season three for daytime network rebroadcasts and subsequent syndication.

Each opening sequence, before going to the title card, always ended with the main cast being together (in clips that were not part of any episode). Seasons one, two, and three were of the Baxters sitting on their living room couch, and season four was of the Baxters (with the exception of Tanya), Eddie, and Chelsea coming down the Baxters' living room stairs.

At the end of the opening credits, Raven stands next to the title card and says, "Yep, that's me." This remained in season four, except with a new addition. Raven's catchphrase "Oh, Snap!" was dubbed in right before she says, "Yep, that's me."

Raven-Symoné performs most of the theme, while Brown performs a rap near the end of the theme and some scattered vocals in the beginning of the theme. Anneliese van der Pol sings the show's title in the chorus. A full-length version of this theme was heard in a music video which aired a few months before the show's U.S. premiere and also can be heard on the show's first soundtrack, released in 2004.

In Disney Channel Asia, an Asian version[clarification needed] of the show's theme song was made. The music video debuted on January 17, 2007, back-to-back with the 100th episode of That's So Raven. It also aired in China on CCTV as 那是因此掠夺.[1]

Episodes[edit]

Main article: List of That's So Raven episodes

The series is the third-longest running Disney Channel Original Series, with its popularity extending the show's contract from 65 to 100 episodes. The last episode produced was "The Way We Were", but then "Checkin' Out" was produced. Although it was chronologically the last episode, it did not air last; instead, "Where There's Smoke" aired last.

| Season | Episodes | Originally aired |

| First aired | Last aired |

| 1 | 21 | January 17, 2003 (2003-01-17) | March 5, 2004 (2004-03-05) |

| 2 | 22 | October 3, 2003 (2003-10-03) | September 24, 2004 (2004-09-24) |

| 3 | 35 | October 1, 2004 (2004-10-01) | January 16, 2006 (2006-01-16) |

| 4 | 22 | February 20, 2006 (2006-02-20) | November 10, 2007 (2007-11-10) |

Crossover with The Suite Life of Zack & Cody and Hannah Montana[edit]

Main article: That's So Suite Life of Hannah Montana

The episode "Checkin' Out" is the first part of a three-way crossover that continues on The Suite Life of Zack & Cody and concludes on Hannah Montana. Raven Baxter meets Zack and Cody while visiting the Tipton Hotel to do a photo shoot promoting a fashion line for boys. During her stay, Raven upsets Cody with a psychic vision and London Tipton refuses to take interest in one of Raven's clothing designs until Hannah Montana arrives and shows an interest.

Cast and characters [edit]

The cast of That's So Raven (seasons 1-3), (From left to right, above): Kyle Massey (Cory Baxter), T'Keyah Crystal Keymáh (Tanya Baxter), Rondell Sheridan (Victor Baxter), (From left to right, below): Orlando Brown (Eddie Thomas), Raven-Symoné (Raven Baxter) and Anneliese van der Pol (Chelsea Daniels).

Main[edit]

Raven-Symoné (credited as Raven), portrays Raven Lydia Baxter, the main character. Aged 14–17. A precognitive teenager. She has a sassy attitude and a grand personality, and is well known for her style. She also loves fashion, and designs her own clothing. She has friends and a loving family, and she goes to public school. However, on various occasions, she gets "psychic visions" about what may or may not happen later. She is only able to "see" a small segment of some future event, and she frequently errs on what it really means, in which case her attempts to change these events only end up making it happen or making it worse. Her main catchphrases are "Oh Fudge!", "Oh snap!", "Ya nasty!", "How y'all doin'?", and "Oh, no he didn't!" She abruptly says, "I'm okay!" if she falls down in one of her disguises. And, if big guys throw her, she tells them to do it "gently!" In addition, when she disapproves of something, she exclaims "Gotta go!" When she makes an appearance on Cory in the House, her father exclaims, "You didn't get kicked out of design school because they don't give out refunds!", which shows she is attending design school. Raven is also a master of disguise, which fits in with her trouble-making antics and passion for becoming a fashion designer, like her idol, Donna Cabonna, whom she worked for as an intern. Raven Baxter is extremely allergic to mushrooms, and her favorite drink is orange juice. According to Chelsea, her favorite gemstone is diamond, her favorite vegetable is corn, and her favorite animal is stuffed. Often referred to as Rae, Raven does not enjoy nature or camping. She has appeared in every episode of the series, along with her younger brother Cory. In the second spin-off, Raven's Home, Raven eventually married her first love Devon but they got divorced. In between that time, they had two children Nia and Booker - latter of whom, shares Raven's ability to see into the future.

Orlando Brown portrays Edward "Eddie" Thomas. Aged 14–17. He is Raven's male best friend. He is an aspiring rapper, and is a guard on the school basketball team. He is like a "big brother" to Cory Baxter and was commonly portrayed as playful, ambitious, loyal, girl crazy and quick to jump to conclusions. Occasionally, he says "Told ya! Told ya twice!" after he tells Raven not to do something that they both knew she would do. Another common catchphrase of his is "Holla!" after he finishes talking to his friends or girls that he likes. His parents are divorced, which is mentioned several times throughout the series. It is also said that he has a little brother. In one episode, Eddie and Raven not only start to develop romantic feelings for each other but they also kiss on the lips at two separate times; however, by the end of the episode, they decide to remain friends (though its strongly implied they're still interested in one another). Eddie has appeared in every episode except Juicer Consequences.

Kyle Massey portrays Cory Baxter. Aged 10–13. Cory is Raven's younger brother who sometimes acts as the main antagonist of the series. He and Raven often argue, but in the long run, they care deeply for each other. Even as he gets older, he claims that playing pranks on Raven is one of his guilty pleasures. Cory has two best friends, William and Larry. Together, the 3 boys form the band Cory and the Boys, with Cory as the drummer and lead singer, while Larry is the guitarist. William starts out playing the clarinet and then plays the keyboard. The band has one song: "Feelin' the Love". Cory is an aspiring businessman. He is shown to be obsessed with money and often creates "get-rich-quick" schemes behind his parents' backs, in which he always gets into trouble. Cory also has a close relationship with his pet rat, Lionel. Earlier in the series, he had a crush on Chelsea. In the third season starts a relationship with Cindy. His catchphrases are "Cha-ching" and "You Know How I Do!". He and Victor are the main characters in the spin-off series Cory in the House. He has appeared in every episode of the series, along with his older sister Raven.

Anneliese van der Pol portrays Chelsea Daniels. Aged 14–17. Often referred to as Chels, She is Raven's female best friend. She is an environmentalist, vegetarian, and closet artist. She is portrayed as being clumsy and dimwitted (although the first two seasons portray her to be just as smart as Raven, but to extreme limits); at times, her stupidity is so potent that she is frequently oblivious to what should be obvious and unable to discern sarcasm from sincerity. She usually uses the catchphrases "That makes more sense!" or '"This is awkward!" She also likes to make jokes, which only she would laugh at. Despite her apparent lack of common sense and intelligence, she has a few surprises up her sleeve—such as occasionally knowing certain "smart" things, which usually tends to surprise everyone else. In Season 1, it is revealed that Raven and Chelsea's friendship goes all the way back to when they were in pre-school, but she was also shown to be dimwitted back then because she did not notice Raven blowing out the candles on her birthday cake. It should also be noted that Chelsea was just as caring when she was young as she is now because one of her unfulfilled wishes on that same birthday was to stop global warming. She is quite similar to Newt (from Cory in the House) in personality. She is very passionate in saving the environment and caring for the animals, and also much more spiritual compared to Raven who can be materialistic, though it occasionally leads to troubling events like the three friends disputing over a goat and nearly turning herself and Raven into cows. In earlier episodes, Cory has a huge crush on her and unsuccessfully pursues her. Occasionally, Chelsea refers to a specific relative, Cousin Earl, at times. Her parents are Therapists. She also has a dog named Sam. Chelsea is present in every episode except Mother Dearest, Smell of Victory, and Saturday Afternoon Fever.

T'Keyah Crystal Keymáh portrays Tanya Baxter. (seasons 1–3). Tanya is the mother of Raven and Cory, and wife of Victor. She is a firm, but fun and caring mother who, despite the antics of her children, is always there for them. She halted her studies to raise her family, but decided once the children were older to continue studying law. Before that, she briefly worked as Raven's English teacher at the request of Raven's school principal. Her catchphrase is "Momma like!" She has a very competitive nature to her personality. It's learned that her mother, Viv, is also psychic. In season 4, Tanya is not present; it is said that she has gone off to England to attend law school. On Cory in the House, she is still in England and she does not visit Cory and Victor but is mentioned. In the pilot episode of Raven's Home, it is revealed by Booker that Tanya is still living.

Rondell Sheridan portrays Victor Baxter, the father of Raven and Cory, and husband of Tanya. He starts out as a chef in a restaurant, but he later opens his own restaurant, The Chill Grill. His biggest rival is Leonard Stevenson. In Cory in the House, he gets a job as the President's chef, and it is unknown what became of his restaurant. His catchphrases are "Here comes the pain!" and "I'll go pack!" (Cory in the House)

Recurring[edit]

Señorita Rodriguez, played by Rose Abdoo
Señorita Rodriguez is the Spanish teacher at Chelsea Daniels, Eddie Thomas, and Raven Baxter's school. She also sponsors the Bayside Barracudian newspaper. Other roles she has taken on include teaching the "Drama Club", advising the "Bayside Outdoor Club", and creating/leading the "FLUB" (Future Leaders United in Business) Club. Retailers say she takes too many freebies. She has appeared in several episodes throughout the series. Whenever she is in a conversation with someone, she quickly gets their hopes up with positive responses, followed by a sly laugh, and an abrupt "NO!" with a negative tone—her catchphrase.

Devon Carter, played by Lil' J
Devon Carter is Raven's steady boyfriend from seasons 2–4. He previously had braces on his teeth and bad acne, and was known as "Bucktooth Carter". After he had his braces removed and his face "cleared up" over the summer, and came back to school, Raven and Alana were constantly fighting to be his girlfriend. He eventually becomes Raven's boyfriend, and continues to be, even after he moves to Seattle, Washington. Although he and his family move to Seattle, he still sees Raven when his father visits San Francisco on business trips. After his family leaves Tanya assures Raven that Devon will always be in her heart. Even though they say they are each other's "only love", we also see Raven have numerous crushes between Devon's visits. Devon has a little sister named Nadine who is jealous of Raven because she doesn't want to share her big brother. In the second spin-off, Raven's Home, Devon and Raven eventually married but got divorced. In between that time, they had two children, Nia and Booker, the latter of whom shares Raven's ability to see into the future.

Alana Rivera, played by Adrienne Bailon
Alana Rivera is Raven's ex-best friend. She finds great pleasure in teasing and bullying Raven. She hangs out with her posse, which includes followers Muffy and Loka. She was first introduced in Season 2 in the episode "Don't Have a Cow". In "Run Raven Run", we learn that Alana and Raven were best friends until 4th grade when a school play had them both competing for the role of the Tooth Fairy (which Raven got, while Alana portrayed the tooth decay), and would ultimately end their friendship. Alana and Raven almost became friends again when Raven "teamed up" with Alana's posse (in the episode "Clothes Minded"), which happens after Chelsea and Eddie do not support Raven's school "protest". In the episode "Run, Raven, Run", Raven and Alana briefly become friends until Chelsea reveals that Raven put chewing gum in Alana's hair. This causes her to get her head shaved and covered up. Alana, Muffy, and Loka also spend the night at Raven's house in the episode "Shake, Rattle, and Rae". In this episode, Raven and Alana almost become friends again, until Alana announces that "the score is 1–0". She was replaced in season 3 by Bianca (Erica Rivera), because, according to Muffy, she was so bad, she got sent to military school, while Bianca was so bad that she got kicked out of military school.

Bianca, played by Erica Rivera
Bianca is Raven's enemy in two episodes of season 3, she replaced Alana when she was sent to military school and she took over Alana's posse. She did not appear in season 4, she was maybe sent back to military school leaving Muffy as Raven's foremost enemy.

Muffy, played by Ashley Drane
Muffy is a member of Alana's (and, later on, Bianca's) posse. Her role in the posse is to record important events (like an organizer) and tends to explain what Alana (and, later on, Bianca) say which is usually brief. She took over as Raven's foremost enemy after Bianca left. There is some speculation that she might be psychic because she knows everything that Alana and Bianca are thinking. She also has a younger sister, Buffy, who is Sydney's age, and enemy.

Loca, played by Andrea Edwards
Loca is a member of Alana's (and, later on, Bianca's) posse. She is rough, and she did the "bad work" for Alana (and then Bianca). She is a tall girl, whom nobody likes to mess with. She is also romantically interested in Eddie; she likes to give him arm punches every time she sees him. She is obsessed with the boy band Boyz 'N Motion, and also loves s'mores, as seen in the episode "Shake, Rattle, and Rae". Unlike Muffy, Bianca, or Alana, it shows in later episodes (season 3), she doesn't have it out personally for Raven. She even shows compassion (briefly) for Raven in the season 3 episode "Boyz 'N Commotion". Loca is shown to be nicer than Muffy or Bianca in personality and somewhat became friends with Raven.

William, played by Frankie Ryan Manriquez
William is one of Cory's best friends. He is known to be very smart, and loves ducks. He is afraid of girls, and he can play the clarinet and keyboard. His classmates call him "Captain Brainypants". He "invents" many different gadgets in various episodes, such as the "remote-controlled refrigerator opener". He once does Raven's science project, in exchange for her designing him a new wardrobe to look "cooler". It has been implied that William is younger than Cory, but it is not known how much younger.

Larry, played by David Henrie
Larry is Cory's other best friend. He is Jewish, as revealed in the episode "Raven, Sydney, And The Man", when he invites Cory to his Bar Mitzvah. He is the guitar player in "Cory and the Boys". He also has a yellow sweatshirt that he wears all the time during the winter, as mentioned in the episode "The Lying Game", although no other reference to this is made. He takes cotillion class, as revealed in the episode "Mad Hot Cotillion". He is also known to be over-worried, and slightly strange, at times.

Stanley played by Bobb'e J. Thompson
Stanley is Eddie's next-door neighbor, who is obsessed with Raven. He serves as the primary antagonist of the show, he has a frenemy relationship with Eddie and Cory, although he is usually seen scamming them. Stanley was originally brought in as a love interest for Raven's next-door neighbor, Sierra, but he becomes much more interested in Raven, and in one episode, Loka. Stanley is rude, obnoxious, mean, sarcastic, and deceptive to everyone. He is a young salesman, who usually tricks Cory into buying something that would eventually go wrong. Stanley is always trying desperately to get Raven to like him, but he suddenly leaves her alone after seeing her kiss Andre in the episode "Mr. Perfect". He loves to eat cheese sandwiches. He also competes against Chelsea in a ping-pong match, and loses. In the same episode ("Taken to the Cleaners"), he asks Victor to make him a cheese sandwich in the shape of a ping-pong paddle. His catchphrases include "My brotha!", which he exclaims whenever he is trying to "show someone up"; and "I may have said that, but I say a lot of things." This is a partial denial of his ability to be nice to other people. He appears primarily in Seasons 3 and 4, in the episodes "Opportunity Shocks"; "Taken to the Cleaners"; "The Grill Next Door"; "Mr. Perfect"; "The Four Aces"; "Driving Miss Lazy"; "Sister Act"; "Checkin' Out"; "Fur Better or Worse" and "When 6021 Met 4267". He also appeared in the Cory in the House episode "Uninvited Pest" when he covets the Presidential medal Cory was going to receive for his Young Businessperson of the Year project. He got into the "Up with Goodness" program, feigned an ankle injury, and stole Cory's presentation. It is also noted that he has a fear of bones, which helps Cory prove that Stanley faked the injury and stole his presentation.

Sydney, played by Sydney Park
Sydney is a girl at Bayside Community Center, whom Raven mentors. When they first meet, Sydney embarrasses Raven by constantly insulting her. However, when Raven learns that Sydney is a foster child, they quickly develop a friendship. Sydney is an aspiring comedian, and she even "performed" at Cory's "bro mitzvah" in the episode "Raven, Sydney, and the Man". Raven and Sydney are now very close friends, and even enter a Little Miss and Her Big Sis pageant. Raven and Sydney are often compared as sisters, although they are not actually related. In the episode "Rae of Sunshine" Sydney has trouble making friends so she embarrasses Raven again, but then at the end, she makes friends without embarrassing Raven.

Donna Cabonna, played by Anne-Marie Johnson
Donna Cabonna is a world-renowned fashion designer, and Raven's arrogant, snooty, trashy boss. Her name is a parody of real-life designers Donna Karan and Dolce & Gabbana. Donna has started Raven as an intern, in which she is often stuck with many tedious jobs such as getting Donna her coffee and picking after her dog Coco. In one episode in Season 4, she makes Raven her "temporary assistant" when Tiffany goes on a business trip. Raven's full devotion to her boss causes Devon to break up with her, but they quickly re-unite after a brief talk. Donna has a boyfriend named Teddy (Richard Steven Horvitz), who is much shorter than her, with whom she plays "break-up and make-up" every weekend. Despite the many conflicts between Raven and her boss, Donna is very supportive of Raven and believes that she could go far in the fashion industry with her talents.

Tiffany, played by Jodi Shilling
Tiffany is Donna's "personal assistant", and Raven's primary nemesis in the fourth season. Ever since their first meeting, Tiffany and Raven do not like each other. On Raven's first day working for Donna (in the episode "Dues & Don'ts"), Tiffany lies to Raven by telling her that Donna Cabonna's office belongs to Raven. They are constantly "competing" to be Donna's favorite assistant. She apparently shares many similarities with Muffy.

Cindy, played by Jordyn Colemon
Cindy is Cory's girlfriend. Cory meets Cindy in "Double Vision". By the events of "Bend It Like Baxter" they're dating. By the series final "Where There's Smoke" Cindy has started smoking. After the intervention that Raven and the gang hold for Cory when they think that he's smoking, Cindy tells the truth and promises to never smoke again.

The Juicer, played by Dan Mott
The Juicer is a nickname given to him for his strong hands "juicing" things; his real name is not revealed. He likes to squeeze kid's heads. He first appeared in season 4 in the episode "Juicer Consequences". The Juicer is the school bully. The Juicer has shown his caring side in "Where There's Smoke" when he lectured Cory and Cindy about the dangers of smoking. He also guest starred in the first spin off show "Cory in the House". "Cory in the House" revealed that The Juicer wears reading glasses and enjoys books about cats.

Freckles, played by Jake Carlis
Freckles is a nickname given to him because of his freckles; his name is not revealed. He is a kid in the day care in the Mr. Perfect episode (season 3 episode 30). He attempts to console Stanley after Raven rejects his advances. Featured role in That's So Raven

Reunion[edit]

Eight years after the series ended, there was speculation and rumors that the series would get a second spin-off or revamp. On August 14, 2015, a reunion with Raven and her former co-stars happened on The View, where they discussed all things about the show and past times. Crystal Keymah and Sheridan were not present, but got a special mention from Symoné herself.[6]

Merchandise[edit]

The That's So Raven franchise has been modeled after fellow Disney Channel hit Lizzie McGuire. Raven has a clothing line, DVD releases, novels, bedroom sets, a perfume, a Girl Talk board game,[7] three video games[8] and two soundtracks, That's So Raven: Songs from and inspired by the hit TV show and That's So Raven Too!.

In February 2005, That's So Raven toys were featured in the McDonald's Happy Meal. In April 2005, a doll based on Raven Baxter was released[9] and another was released the following year.

In September 2005, the show also spawned a fragrance and an MP3 player. That same month, the clothing line was shipped to Macy's stores. As of 2006, That's So Raven merchandise had made $400 million.[10]

Soundtrack albums[edit]

That's So Raven

That's So Raven Too!

Series novelizations[edit]

Main article: List of That's So Raven books

What You See Is What You Get – Smell of Victory & A Dog by Any Other Name

Rescue Me – Driven To Insanity & Mother Dearest

In Raven We Trust – Test of Friendship & Saturday Afternoon Fever

Step Up – Dissin' Cousins & Party Animal

Family Affair – If I Only Had a Job & Teach Your Children Well

2 Good 2 B True – To See or Not to See & Ye Olde Dating Game

Tell It Like It Is – Campaign in the Neck & Separation Anxiety

Dueling Divas' – A Fight at the Opera & The Parties

Showtime! – Wake Up, Victor & A Fish Called Raven

Psyched – Psychics Wanted & Saving Psychic Raven

Boyfriend Blues – Four's a Crowd & Blue in the Face

Be Mine – Hearts And Minds & Close Encounters of the Nerd Kind

The Real Deal – That's So Not Raven & Run, Raven, Run

Over the Top – Out of Control & He's Got the Power

Rebel Raven – Clothes Minded & Spa Day Afternoon

Superstar – Radio Heads & The Road to Audition

House Party – Hizzouse Party & Leave It to Diva

Queen of Hearts – There Goes the Bride & Royal Treatment

Raven Rocks – A Goat's Tale & Boyz 'N Commotion

Extreme Fever – Extreme Cory & When There's Smoke

Video games[edit]

That's So Raven has spawned three video games:

That's So Raven, Game Boy Advance

That's So Raven 2, Game Boy Advance

That's So Raven: Psychic on the Scene, Nintendo DS

Reception[edit]

The series premiere was watched by 3.5 million viewers, the first Disney Channel series to garner more than 3 million viewers. The most watched episode of That's So Raven is "Country Cousins", scoring 10.8 million viewers.

VHS and DVD releases[edit]
Volume releases[edit]

| !# | VHS and DVD title | Episodes featured | Release date | Bonus features |

| 1 | That's So Raven: Supernaturally Stylish[11] | "If I Only Had a Job" "He's Got the Power" "That's So Not Raven" "Boyz 'N Commotion" | December 7, 2004 | "Supernatural" (music video) "That's So Raven" (music video) |

| 2 | That's So Raven: Disguise the Limit[12] | "Art Breaker" "Country Cousins (Part 1)" "Country Cousins (Part 2)" "The Grill Next Door" | August 16, 2005 | Master of Disguises (featurette) Visual commentary by Raven on selected scenes |

| 3 | That's So Raven: Raven's House Party[13] | "Opportunity Shocks" "Double Vision" "Too Much Pressure" "Four Aces Club" "Vision Impossible" | December 6, 2005 | Never-before-seen episode Bloopers and outtakes That's So Raven Radio Trivia Game |

| 4 | That's So Raven: Raven's Makeover Madness (Only on DVD)[14] | "Pin Pals" "Dues and Don'ts" "Adventures in Boss-Sitting" "Hook Up My Space" "When 6021 Met 4267" | July 18, 2006 | Never-before-seen episode So You Think You Know Raven (Volume 1, trivia game) |

Other releases[edit]

| DVD title | Episode featured | Release date | Bonus features |

| Disney Channel Holiday (VHS and DVD) | "Escape Clause" | November 1, 2005 | N/A |

| That's So Suite Life of Hannah Montana[15] | "Checkin' Out" | January 16, 2007 | So You Think You Know Raven (Volume 2, trivia game) |

| Hannah Montana Volume 4: One in a Million[16] | "Run, Raven, Run" | January 28, 2008 | N/A |

Name in other countries[edit]

| Countries | Name |

| Australia | That's So Raven |

| Brazil | As Visões da Raven |

| Denmark | That's So Raven |

| Spain | Raven |

| Greece | Raven |

| Finland | That's So Raven |

| France | Phénomène Raven |

| Germany | Raven Blickt Durch |

| Hong Kong | 好係Raven |

| India | That's so Raven |

| Italy | Raven |

| Japan | レイブン 見えちゃってチョー大変! (Reibun Mie Chatte Cho Taihen!) |

| Mexico | Es Tan Raven |

| Philippines | That's So Raven |

| Poland | Świat Raven |

| Portugal | Raven |

| United Kingdom | That's So Raven |

| Taiwan | 天才魔女 |

| Turkey | Tam Raven'a Göre |

Spin-off and Sequels[edit]
Cory in the House[edit]

Main article: Cory in the House

Cory in the House is the first Disney Channel spin-off and it premiered on January 12, 2007. It was the one chosen out of the many pitched and proposed spin-offs that were to have aired after the completion of That's So Raven, including one about Raven going off to college. Originally Raven-Symoné was offered the spin-off, but she declined it, therefore Disney Channel decided to give it to Kyle Massey.

The storyline involves Cory and Victor adjusting to life in Washington, D.C.; Victor has received a job as the Head Chef to the President. The show takes place while Raven is attending fashion college and Tanya is still in London.

The series is similar to its sister show, That's So Raven. Cory has two best friends, one a boy, Newton Livingston III (Jason Dolley), and one a girl, Meena Paroom (Maiara Walsh). Note that in That's So Raven, the main character also has two best friends, one a boy and one a girl and Newt and Meena's persona's are similar to Chelsea and Eddie. Cory attends a middle school in Washington, D.C. Also in the series, the president's daughter Sophie (Madison Pettis) constantly pesters Cory, like Cory did to Raven in That's So Raven. Cory also participates in crazy situations in which he learns a moral lesson and will most likely get punished. Candy Smiles plays in Cory's love life multiple times, and Stickler continuously spies on Cory, Newton and especially Meena's.

It is implied the episode, "When 6021 Met 4267", that Cory and Victor did move back to San Francisco.

In the episode "That's So in the House", Raven came to show designs of new tour guide uniforms to President Martinez (John D'Aquino). Unfortunately, she has a vision of a clock falling on the President, and tackles him, earning the Secret Service a chance to chase her around the grounds. Cory poses as his sister to display the uniforms, modeled by Newton and Meena. Raven is discovered outside the Oval Office window, and chased, until she actually does save Mr. Martinez from the clock. The episode ends with the credits sequence for That's So Pooshnick, a show from Meena's country about a psychic girl who can see the past and always ends up messing up trying to stop the vision from happening again.

Stanley and the Juicer have also made special appearances on the show as well.

Failed Movie Attempt[edit]

In 2011, to promote her latest film Vampires Suck, Anneliese van der Pol revealed in an interview that a That's So Raven film had been written but failed to go into production. "The storyline saw us going to France. [Raven] was going to start a fashion line in France. Eddie and [Chelsea] were going to fly out and meet her. Of course, something tragic happens. We have to rescue the situation." Van der Pol admitted that Raven's schedule at the time was booked solid for a year and the possibility of the film seemed unlikely. "But no, It's not ever happening. If I hear something, I will be the first to sign on." She also commented on reprising her role of Chelsea Daniels.[17]

Raven's Home[edit]

Main article: Raven's Home

On October 27, 2016, it was announced that Raven-Symoné will star in and develop a sequel to the original series. Raven departed as a host of The View later in 2016 in order to work on the series full-time.[18]In November 2016, it was announced that Anneliese van der Pol will reprise her role of Chelsea Daniels.[19]

In the new series, Raven Baxter will be a divorced mother of two pre-teens, Nia and Booker.[20] Booker will inherit his mother's psychic abilities during middle school.[20] Chelsea Daniels is also a divorced mother, who is raising a son, Levi, and moves in with Raven.[21]

Indian adaptation[edit]

Main article: Palak Pe Jhalak

Palak Pe Jhalak is the sixth Disney Channel India series to be adapted in Hindi after Art Attack, Good Luck Charlie, The Suite Life of Zack and Cody, Shake It Up and Jessie, and premiered on September 27, 2015. Ayesha Kaduskar is seen playing the role of Nysha Kapoor, a character similar to Raven Baxter played by Raven-Symoné.[22] The original That's So Raven aired on Disney Channel India as well from 2004 to 2010 and Star Plus from 2003 to 2008.

Awards and nominations[edit]

| Year | Award | Category | Recipient | Result |

| 2003 | BAFTA Children's Awards | International | That's So Raven | Nominated[23] |

| 2004 | BET Comedy Awards | Outstanding Lead Actress in a Comedy Series | Raven-Symoné | Nominated[24] |

| Outstanding Comedy Series | That's So Raven | Nominated[24] |

| Gracie Allen Awards | Outstanding Children/Adolescent Program | That's So Raven | Won[25] |

| NAACP Image Awards | Outstanding Performance in a Youth/Children's Program | Raven-Symoné | Won[26] |

| Kids Choice Awards | Favorite Female TV Star | Raven-Symoné | Won[27] |

| NAMIC Vision Awards | Best Comedic Performance | Raven-Symoné | Nominated[28] |

| Children's | That's So Raven | Nominated[28] |

| Teen Choice Awards | Choice TV Actress: Comedy | Raven-Symoné | Nominated[29] |

| Choice TV Show: Comedy | That's So Raven | Nominated[29] |

| Young Artist Awards | Best Performance in a TV Series (Comedy or Drama) – Leading Young Actor | Kyle Massey | Nominated[30] |

| Best Performance in a TV Series (Comedy or Drama) – Leading Young Actress | Raven-Symoné | Nominated[30] |

| 2005 | BET Comedy Awards | Outstanding Lead Actress in a Comedy Series | Raven-Symoné | Nominated[31] |

| Outstanding Comedy Series | That's So Raven | Nominated[31] |

| Casting Society of America | Best Casting – Children's Programming | Joey Paul Jensen | Won[32] |

| Genesis Awards | Children's Programming | That's So Raven | Won[33] |

| Gracie Allen Awards | Outstanding Female Lead in a Comedy | Raven-Symoné | Won[34] |

| NAACP Image Awards | Outstanding Performance in a Youth/Children's Series/Special | Raven-Symoné | Won[35] |

| Kids Choice Awards | Favorite TV Actress | Raven-Symoné | Won[36] |

| NAMIC Vision Awards | Best Comedic Performance | Raven-Symoné | Nominated[28] |

| Children's | That's So Raven | Nominated[28] |

| Primetime Emmy Awards | Outstanding Children's Program | That's So Raven | Nominated[37] |

| Teen Choice Awards | Choice TV Actress: Comedy | Raven-Symoné | Nominated[38] |

| Choice TV Show: Comedy | That's So Raven | Nominated[38] |

| Young Artist Awards | Best Performance in a Television Series – Guest Starring Young Actor | Christopher Malpede | Won[39] |

| Outstanding Young Performers in a TV Series | Orlando Brown Kyle Massey Anneliese van der Pol Raven-Symoné | Won[39] |

| 2006 | Casting Society of America | Best Casting – Children's TV Programming | Joey Paul Jensen | Nominated[40] |

| NAACP Image Awards | Outstanding Performance in a Youth/Children's Series or Special | Raven-Symoné | Won[41] |

| Outstanding Directing in a Comedy Series | Eric Dean Seaton | Nominated[41][42] |

| Kids Choice Awards | Favorite TV Actress | Raven-Symoné | Nominated[43][44] |

| Favorite TV Show | That's So Raven | Nominated[43][44] |

| NAMIC Vision Awards | Best Comedic Performance | Raven-Symoné | Nominated[45][46] |

| Best Children's | That's So Raven | Won[46] |

| Teen Choice Awards | TV – Choice Actress: Comedy | Raven-Symoné | Nominated[47] |

| Young Artist Awards | Best Family Television Series (Comedy) | That's So Raven | Nominated[48] |

| 2007 | NAACP Image Awards | Outstanding Actress in a Comedy Series | Raven-Symoné | Nominated[49][50] |

| Outstanding Performance in a Youth/Children's Program – Series or Special | Kyle Massey | Nominated[49][50] |

| Raven-Symoné | Won[50] |

| Outstanding Children's Program | That's So Raven | Won[50] |

| Kids Choice Awards | Favorite TV Actress | Raven-Symoné | Nominated[51][52] |

| NAMIC Vision Awards | Children's | That's So Raven | Won[53] |

| Primetime Emmy Awards | Outstanding Children's Program | That's So Raven | Nominated[54] |

| Writers Guild of America | Children's Episodic & Specials | Deborah Swisher ("Fur Better or Worse") | Nominated[55][56] |

| Young Artist Awards | Best Performance in a TV Series (Comedy or Drama) – Leading Young Actor | Kyle Massey | Won[57] |

| 2008 | NAACP Image Awards | Outstanding Performance in a Youth/Children's Program (Series or Special) | Raven-Symoné | Won |

| Outstanding Children's Program | That's So Raven | Won[58] |

| Kids Choice Awards | Favorite TV Actress | Raven-Symoné | Nominated[59][60] |

| NAMIC Vision Awards | Best Performance – Comedy | Raven-Symoné | Nominated[61][62] |

See also[edit]

Disney portal

2000s portal

Television portal

So Weird

References[edit]

^ Jump up to: a b Seidman, Robert (August 13, 2009). "On T.O., Jim Roe and how some media covers cable ratings (AKA I have T.O.'s back on this)". TV by the Numbers. Retrieved November 28, 2013. 

Jump up ^ Wagmeister, Elizabeth (October 27, 2016). "Raven-Symoné to Exit 'The View' for Disney Channel's 'That's So Raven' Spinoff". Variety. Retrieved October 27, 2016. 

Jump up ^ de Morales, Lisa (October 27, 2016). "Raven-Symoné Becomes Latest To Leave 'The View'". Deadline.com. Retrieved October 27, 2016. 

Jump up ^ Snetiker, Marc (April 4, 2017). "That's So Raven spin-off Raven's Home a go at Disney Channel". Entertainment Weekly. Retrieved April 4, 2017. 

Jump up ^ "Raven Symone To Star in Disney Channel Original Series That's So Raven; Production To Begin in Los Angeles Nov. 9". Free Online Library. November 8, 2001. Retrieved November 28, 2013. 

Jump up ^ "The 'That's So Raven' Cast Reunited -- And It's About To Happen Again". MTV News. Retrieved August 12, 2015. 

Jump up ^ "Archived copy". Archived from the original on July 25, 2006. Retrieved July 20, 2006. 

Jump up ^ "Yahoo". Videogames.yahoo.com. Archived from the original on March 25, 2007. Retrieved October 3, 2017. 

Jump up ^ "Collectible Barbies: Become A Barbie Collector - Barbie Signature". Barbiecollector.com. Retrieved October 3, 2017. 

Jump up ^ Vanderberg, Marcus (March 16, 2005). "BHM Star: Raven-Symoné". AOL Black Voices. Archived from the original on March 13, 2007. Retrieved November 28, 2013. 

Jump up ^ "That's So Raven - Supernatural Style: Orlando Brown, T'Keyah Crystal Keymáh, Kyle Orlando Massey, Raven (VII), Rondell Sheridan, Anneliese van der Pol, Debbie". Amazon.com. Retrieved August 20, 2011. 

Jump up ^ "That's So Raven - Disguise the Limit: Orlando Brown, T'Keyah Crystal Keymáh, Kyle Orlando Massey, Raven (VII), Rondell Sheridan, Anneliese van der Pol, Debbie Alle". Amazon.com. Retrieved August 20, 2011. 

Jump up ^ "That's So Raven - Raven's House Party: Raven-Symoné, Orlando Brown". Amazon.com. Retrieved August 20, 2011. 

Jump up ^ "That's So Raven - Raven's Makeover Madness: Raven, Orlando Brown, Anneliese van der Pol, Kyle Massey, Rondell Sheridan, T'Keyah Crystal Keymáh". Amazon.com. Retrieved July 28, 2013. 

Jump up ^ "That's So Suite Life of Hannah Montana: David Kendall (II), Lee Shallat Chemel, Casey Lynn De Stefano, Andrew Tsao, Henry Chan (IV), Jim Drake (II): Movies & TV". Amazon.com. Retrieved August 20, 2011. 

Jump up ^ "Hannah Montana - One in a Million: Miley Cyrus: Movies & TV". Amazon.com. Retrieved August 20, 2011. 

Jump up ^ Orange, B. Alan (September 4, 2010). "EXCLUSIVE: Anneliese Van Der Pol Explains Why Vampires Suck!". MovieWeb. Retrieved November 28, 2013. 

Jump up ^ "Raven-Symoné to star in That's So Raven spin-off at Disney Channel". Entertainment Weekly. Retrieved October 27, 2016. 

Jump up ^ Harnick, Chris (November 14, 2016). "Chelsea's Back! Anneliese van der Pol Returning for That's So Raven Sequel Series". E! News. Retrieved November 15, 2016. 

^ Jump up to: a b Swift, Andy (November 8, 2016). "That's So Raven Spinoff: Meet Raven's 'Confident' Psychic Daughter and 'Young Donald Glover'-Type Son". TVLine. Retrieved November 10, 2016. 

Jump up ^ Serrao, Nivea (November 14, 2016). "That's So Raven: Anneliese van der Pol to return as Chelsea in sequel". Entertainment Weekly. Retrieved November 15, 2016. 

Jump up ^ "Archived copy". Archived from the original on September 23, 2015. Retrieved September 22, 2015. 

Jump up ^ "Children's in 2003". bafta.org. Retrieved August 12, 2015. 

^ Jump up to: a b "BET COMEDY AWARDS (List of Award Winners and Nominees)". Who's Dated Who?. Retrieved August 12, 2015. 

Jump up ^ "Archived copy". Archived from the original on May 30, 2010. Retrieved June 16, 2010. 

Jump up ^ "2004 NAACP Image Awards". infoplease.com. Retrieved August 12, 2015. 

Jump up ^ "Nickelodeon Kids Choice Awards Press Site". nickkcapress.com. Retrieved August 12, 2015. 

^ Jump up to: a b c d "Archived copy" (PDF). Archived from the original (PDF) on July 14, 2010. Retrieved June 7, 2015. 

^ Jump up to: a b "TEEN CHOICE AWARDS (List of Award Winners and Nominees)". Who's Dated Who?. Retrieved August 12, 2015. 

^ Jump up to: a b "25th Annual Young Artist Awards - Winners and Nominations". youngartistawards.org. Retrieved August 12, 2015. 

^ Jump up to: a b "BET COMEDY AWARDS (List of Award Winners and Nominees)". Who's Dated Who?. Retrieved August 12, 2015. 

Jump up ^ "Casting Society of America, USA". imdb.com. Retrieved August 12, 2015. 

Jump up ^ Humane Society of the United States (February 8, 2007). "The Animal Power of the 21st Genesis Awards!". prnewswire.com. Retrieved August 12, 2015. 

Jump up ^ "Archived copy". Archived from the original on July 19, 2013. Retrieved July 17, 2013. 

Jump up ^ "2005 NAACP Image Awards". infoplease.com. Retrieved August 12, 2015. 

Jump up ^ "Kids Choice Awards 2005, Date, Kids Choice Awards 2005 Winners, 2005 Kids Choice Awards Winners by Category". altiusdirectory.com. Retrieved August 12, 2015. 

Jump up ^ "Outstanding Children's Program 2005". Emmys.com. Retrieved 3 October 2017. 

^ Jump up to: a b "TEEN CHOICE AWARDS (List of Award Winners and Nominees)". Who's Dated Who?. Retrieved August 12, 2015. 

^ Jump up to: a b "26th Annual Young Artist Awards - Nominations / Special Awards". youngartistawards.org. Retrieved August 12, 2015. 

Jump up ^ "Casting Society of America, USA". imdb.com. Retrieved August 12, 2015. 

^ Jump up to: a b "AALBC.com's Thumper's Corner Discussion Board: The 37th NAACP Image Awards Winners Announced". thumperscorner.com. Retrieved August 12, 2015. 

Jump up ^ "Television Academy". Television Academy. Retrieved August 12, 2015. 

^ Jump up to: a b "2006 Host/Nominee Release - Nickelodeon Kids' Choice Awards 2006 Press Site". nickkcapress.com. Archived from the original on July 18, 2013. Retrieved August 12, 2015. 

^ Jump up to: a b "Winners Release - Nickelodeon Kids' Choice Awards 2006 Press Site". nickkcapress.com. Retrieved August 12, 2015. 

Jump up ^ "12TH ANNUAL NAMIC VISION AWARD NOMINEES" (PDF). 1.prweb.com. Retrieved 3 October 2017. 

^ Jump up to: a b "Archived copy" (PDF). Archived from the original (PDF) on February 24, 2014. Retrieved February 12, 2013. 

Jump up ^ "TEEN CHOICE AWARDS (List of Award Winners and Nominees)". Who's Dated Who?. Retrieved August 12, 2015. 

Jump up ^ "27th Annual Young Artist Awards - Nominations / Special Awards". youngartistawards.org. Retrieved August 12, 2015. 

^ Jump up to: a b "January 2006 - blackfilm.com - features - The 38th NAACP Image Awards nominations". blackfilm.com. Retrieved August 12, 2015. 

^ Jump up to: a b c d "38th NAACP Image Awards". aalbc.com. Retrieved August 12, 2015. 

Jump up ^ "2007 Host/Nominees Release / Nickelodeon Kids' Choice Awards 2007 Press Kit". nickkcapress.com. Retrieved August 12, 2015. 

Jump up ^ "2007 KCA Winners Release / Nickelodeon Kids' Choice Awards 2007 Press Kit". nickkcapress.com. Retrieved August 12, 2015. 

Jump up ^ "Archived copy". Archived from the original on February 24, 2014. Retrieved February 12, 2013. 

Jump up ^ "Outstanding Children's Program 2007". Emmys.com. Retrieved 3 October 2017. 

Jump up ^ "Breaking News - 2007 Writers Guild Awards Television & Radio Nominees Announced - TheFutonCritic.com". thefutoncritic.com. Retrieved August 12, 2015. 

Jump up ^ "WRITERS GUILD OF AMERICA, USA (List of Award Winners and Nominees)". Who's Dated Who?. Retrieved August 12, 2015. 

Jump up ^ "28th Annual Young Artist Awards - Nominations / Special Awards". youngartistawards.org. Retrieved August 12, 2015. 

Jump up ^ "Archived copy". Archived from the original on June 30, 2015. Retrieved February 12, 2013. 

Jump up ^ "Nickelodeon Kids' Choice Awards 2008 Press Kit". nickkcapress.com. Retrieved August 12, 2015. 

Jump up ^ "Nickelodeon Kids' Choice Awards – 2008 Winners List – Pictures and Video - Allie is Wired". allieiswired.com. Archived from the original on July 6, 2014. Retrieved August 12, 2015. 

Jump up ^ M.I. "14th NAMIC Vision Awards Nominees". mykiru.ph. Retrieved August 12, 2015. 

Jump up ^ "Archived copy". Archived from the original on February 25, 2014. Retrieved February 12, 2013. 

External links[edit]

| Wikiquote has quotations related to: That's So Raven |

Official website

That's So Raven on IMDb

That's So Raven at TV.com

| [show] v t e That's So Raven |

| Episodes | Season 1 2 3 4 "That's So Suite Life of Hannah Montana" |

| Soundtracks | That's So Raven That's So Raven Too! |

| Video games | That's So Raven: Psychic on the Scene |

| Spin-offs | Cory in the House Raven's Home |

| Indian Adaptation | Palak Pe Jhalak |

| [show] v t e Disney Channel original programming |

| 1990s debuts | Flash Forward (1995–97) The Famous Jett Jackson (1998–2001) So Weird (1999–2001) The Jersey (1999–2004) |

| 2000s debuts | Totally Circus (2000) Even Stevens (2000–03) In a Heartbeat (2000–01) Totally Hoops (2001) Lizzie McGuire (2001–04) The Proud Family (2001–05) Kim Possible (2002–07) Totally in Tune (2002) That's So Raven (2003–07) Lilo & Stitch: The Series (2003–06) Phil of the Future (2004–06) Dave the Barbarian (2004–05) Brandy & Mr. Whiskers (2004–06) American Dragon: Jake Long (2005–07) The Suite Life of Zack & Cody (2005–08) The Buzz on Maggie (2005–06) The Emperor's New School (2006–08) Hannah Montana (2006–11) Disney Channel Games (2006–11) The Replacements (2006–09) Shorty McShorts' Shorts (2006–07) Cory in the House (2007–08) As the Bell Rings (2007–09) Phineas and Ferb (2007–15) Wizards of Waverly Place (2007–12) The Suite Life on Deck (2008–11) Stitch! (2008–15) Sonny with a Chance (2009–11) Jonas (2009–10) |

| 2010s debuts | Good Luck Charlie (2010–14) Fish Hooks (2010–14) Shake It Up (2010–13) Take Two with Phineas and Ferb (2010–11) A.N.T. Farm (2011–14) So Random! (2011–12) PrankStars (2011) Jessie (2011–15) Austin & Ally (2011–16) Gravity Falls (2012–16) Code: 9 (2012) Dog with a Blog (2012–15) Wander Over Yonder (2013–16) Liv and Maddie (2013–17) Win, Lose or Draw (2014) I Didn't Do It (2014–15) Girl Meets World (2014–17) K.C. Undercover (2015–18) Best Friends Whenever (2015–16) Descendants: School of Secrets (2015, short-form) Descendants: Wicked World (2015–17, short-form) Walk the Prank (2016) Mech-X4 (2016) |

| Current | Mickey Mouse (since 2013, short-form) Bunk'd (since 2015) Stuck in the Middle (since 2016) Bizaardvark (since 2016) Elena of Avalor (since 2016) Tangled: The Series (since 2017) Andi Mack (since 2017) Hotel Transylvania: The Series (since 2017) Raven's Home (since 2017) Big Hero 6: The Series (since 2017) |

| Upcoming | Bug Juice (1998–2001, early 2018) DuckTales (2018) Milo Murphy's Law (2018) Go Away, Unicorn! (2018) Amphibia (2019) The Owl House (2019) Star vs. the Forces of Evil (TBA) |

| See also | It's a Laugh Productions Disney Television Animation Brookwell McNamara Entertainment Crossovers Disney Channel Storytellers 25 Days of Christmas |

| [show] v t e ABC Kids |

| Disney's One Saturday Morning (1997–2002) | 101 Dalmatians: The Series Buzz Lightyear of Star Command Doug DuckTales Even Stevens Hercules Disney's House of Mouse Jungle Cubs Lizzie McGuire Lloyd in Space Mary-Kate and Ashley in Action! Mickey Mouse Works Pepper Ann Recess Sabrina: The Animated Series Science Court Teacher's Pet Teamo Supremo The New Adventures of Winnie the Pooh The Bugs Bunny and Tweety Show The Weekenders |

| ABC Kids (2002–2011) | Even Stevens (2002–2005) Fillmore! (2002–2004) Hannah Montana (2006–2011) Kim Possible (2002–2006) Lilo & Stitch: The Series (2003–2006) Lizzie McGuire (2002–2005) NBA Inside Stuff (2002–2004) Phil of the Future (2004–2006) Power Rangers (2002–2010) Recess (2002–2004) Teamo Supremo (2002–2003) That's So Raven (2003–2011) The Buzz on Maggie (2005–2006) The Emperor's New School (2006–2011) The Proud Family (2002–2006) The Replacements (2006–2011) The Suite Life of Zack & Cody (2005–2011) W.I.T.C.H. (2004–2005) |

| Related topics | Children's programming on the American Broadcasting Company Disney's One Too Saturday morning programming on Disney Channel Jambalaya Studios Disney Television Animation |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=That%27s_So_Raven&oldid=836904499"

Categories:

2000s American black sitcoms

2000s American supernatural television series

2000s American teen sitcoms

2003 American television series debuts

2007 American television series endings

ABC Kids

American fantasy television series

American high school television series

Disney Channel shows

English-language television programs

Psychic powers in television

Television series about friendship

Television series by Disney

Television series by Brookwell McNamara Entertainment

Television shows filmed in Los Angeles

Television shows set in San Francisco

That's So Raven

Hidden categories:

Use mdy dates from November 2013

Pages using deprecated image syntax

All articles with unsourced statements

Articles with unsourced statements from September 2009

Wikipedia articles needing clarification from October 2011

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikiquote

			Languages

العربية

Azərbaycanca

Chavacano de Zamboanga

Cymraeg

Dansk

Deutsch

Eesti

Español

Français

한국어

Bahasa Indonesia

Italiano

עברית

Latina

Magyar

Bahasa Melayu

Nederlands

日本語

Norsk

Polski

Português

Simple English

Српски / srpski

Suomi

Svenska

Tagalog

Türkçe

Tiếng Việt

中文
				20 more

Edit links

 This page was last edited on 17 April 2018, at 15:09.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews