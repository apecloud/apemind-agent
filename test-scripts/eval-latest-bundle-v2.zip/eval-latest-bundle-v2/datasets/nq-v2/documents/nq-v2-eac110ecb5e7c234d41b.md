# Transformers: Revenge of the Fallen

Transformers: Revenge of the Fallen - Wikipedia

Transformers: Revenge of the Fallen

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

This article is about the film. For other uses, see Transformers: Revenge of the Fallen (disambiguation).

"Transformers 2" redirects here. For other uses, see Transformers: Revenge of the Fallen (disambiguation).

| Transformers: Revenge of the Fallen |

| Theatrical release poster |

| Directed by | Michael Bay |

| Produced by | Don Murphy Tom DeSanto Lorenzo di Bonaventura Ian Bryce |

| Screenplay by | Ehren Kruger Alex Kurtzman Roberto Orci |

| Based on | Transformers by Hasbro |

| Starring | Shia LaBeouf Megan Fox Josh Duhamel Tyrese Gibson John Turturro |

| Music by | Steve Jablonsky Linkin Park Hans Zimmer |

| Cinematography | Ben Seresin |

| Edited by | Roger Barton Tom Muldoon Joel Negron Paul Rubell |

| Production company | di Bonaventura Pictures Hasbro |

| Distributed by | DreamWorks Pictures (North America) Paramount Pictures (International) |

| Release date | June 8, 2009 (2009-06-08) (Tokyo) June 24, 2009 (2009-06-24) (United States) |

| Running time | 150 minutes[1] |

| Country | United States |

| Language | English |

| Budget | $200 million[2] |

| Box office | $836.3 million[2] |

Transformers: Revenge of the Fallen is a 2009 American science fiction action film directed by Michael Bay and executive produced by Steven Spielberg, based on the Transformers toy line created by Hasbro. It is the sequel to 2007's Transformers, as well as the second installment in the live-action Transformers film series. Taking place two years after its predecessor, the plot revolves around Sam Witwicky, who is caught in the war between two factions of alien robots, the Autobots, led by Optimus Prime and the Decepticons, led by Megatron. Sam is having strange visions of Cybertronian symbols, and being hunted by the Decepticons under the orders of an ancient Decepticon named The Fallen, who seeks to get revenge on Earth by finding and activating a machine that would provide the Decepticons with an energon source, destroying the Sun and all life on Earth in the process. Returning Transformers include Optimus Prime, Bumblebee, Ironhide, Ratchet, Megatron, Starscream, and Scorponok.

With deadlines jeopardized by possible strikes by the Directors Guild of America and the Screen Actors Guild, Bay managed to finish the production on time with the help of previsualization and a scriptment by his writers Roberto Orci, Alex Kurtzman, and series newcomer Ehren Kruger. Shooting took place from May to November 2008, with locations in Egypt, Jordan, Pennsylvania, New Jersey, and California, as well as air bases in New Mexico and Arizona. This was the last film in the series to star Megan Fox, and was also the last film in the series to be co-produced by DreamWorks Pictures, leaving Paramount Pictures as the sole distributor of its future films.

Revenge of the Fallen premiered on June 8, 2009 in Tokyo and was released on June 24, 2009 in the United States. Metacritic said the film received "generally unfavorable reviews";[3] criticism was directed at its bland story, acting, crude humor, overall length, and abrupt ending. However, critics praised the visual effects, music, action sequences, and the voice performances of Peter Cullen and Hugo Weaving. The film won three Golden Raspberry Awards at the 30th Golden Raspberry Awards ceremony and became the highest-grossing film to win the Worst Picture award. The film grossed a total of $402.1 million in the US and Canada and $434.2 million in other territories, for a total of $836.3 million worldwide. It was the second highest-grossing film of 2009 in the US and Canada, 26th domestically, the 60th highest-grossing film of all time and fourth highest of the year worldwide. With over 11 million home media sales in 2009, it was also the top-selling film of the year in the United States. It was followed by Dark of the Moon in 2011, Age of Extinction in 2014, and The Last Knight in 2017.

Contents
 [hide] 

1 Plot

2 Cast

2.1 Voices

2.2 Non-speaking characters

3 Production

3.1 Development

3.2 Filming

3.3 Effects

3.4 Music

4 Marketing

4.1 Printed media

4.2 Video game

5 Release

6 Reception

6.1 Critical response

6.2 Box office

6.3 Home media

6.4 Awards and nominations

7 Sequels

8 References

9 External links

Plot[edit]

In 17,000 B.C., the Seven Primes travel across the galaxy to create Energon with star-absorbing machines named Sun Harvesters. One of them, later known as The Fallen, defies their sole rule to never destroy planetso imprison him before he can harvest the planet's Sun using the Matrix of Leadership. The Primes then sacrifice themselves to hide the Matrix in an unknown location.

In the present day, two years after Megatron's defeat, the Autobots and the U.S. military have formed the Non-biological Extraterrestrial Species Treaty (NEST), a classified international task force, to eliminate the surviving Decepticons. In Shanghai, the Autobots intercept two Decepticons, Demolisher and Sideways. Sideways is killed by the Autobot Sideswipe, while Optimus Prime kills Demolisher, but not before he warns them of the Fallen's return. At NEST's secure headquarters in Diego Garcia, National Security Adviser Theodore Galloway concludes the Decepticons are still on Earth to hunt the Autobots, since Megatron's corpse is at the bottom of the Laurentian Abyss and the last known AllSpark shard is secured in the base. Soundwave hacks into a military satellite, overhears the information, and sends Ravage to retrieve the shard.

Meanwhile, Sam Witwicky is preparing to attend college, leaving his girlfriend Mikaela Banes and guardian Bumblebee behind. He finds a smaller AllSpark shard and picks it up, causing him to start seeing Cybertronian symbols. The shard's energy pulse turns the appliances in the kitchen into murderous Transformers, who attack Sam and his family. After Bumblebee destroys the rampaging appliances, Sam gives the shard to Mikaela, who later captures the Decepticon Wheelie when he attempts to steal it. The Constructicons, upon discovering Megatron's location, travel to the Laurentian Abyss and resurrect Megatron using the stolen shard and parts torn off from one of their own allies. Megatron then travels to one of Saturn's moons, where he reunites with his master, the Fallen, who orders him to capture Sam alive and kill Optimus, the only Transformer who can defeat the Fallen.

Sam, Mikaela, and his college roommate Leo are attacked by Alice, a Decepticon Pretender posing as a college student. After killing her, they are captured by Megatron, Starscream, and the Decepticon Grindor, but Optimus and Bumblebee arrive and rescue the humans. Optimus fights Megatron, Starscream, and Grindor alone as Megatron reveals that the symbols in Sam's mind will lead the Decepticons to a new Energon source. After killing Grindor, Optimus is killed by Megatron. The other Autobots arrive and repel Megatron and Starscream before they could recapture Sam. As Sam goes into hiding with Mikaela, Leo, Bumblebee, Wheelie, and the Autobot twins Skids and Mudflap, the Decepticons launch devastating simultaneous attacks around the world, destroying ships in the Second Fleet and damaging Paris. The Fallen hijacks Earth's telecommunications systems, demanding that Sam be handed to him.

Sam, Mikaela, and Leo enlist the help of former Sector Seven agent, Seymour Simmons, who reveals that the Transformers visited Earth eons ago and the most ancient, known as Seekers, remained on Earth, hiding in secret. With help from Wheelie, they track down a Decepticon Seeker named Jetfire at the Smithsonian Air and Space Museum. They use their shard to revive Jetfire, who teleports the group to Egypt and explains the story of the Fallen. Jetfire and Wheelie turn against the Decepticons, and order them to locate the Matrix, which could revive Optimus. Sam's group finds the Matrix in Petra, but it disintegrates into dust in Sam's hands. Undeterred, Sam stuffs the Matrix's remains into his sock.

Meanwhile, NEST forces and the Autobots land near the Giza pyramid complex but are attacked by a large force of Decepticons. During the battle, many Constructicons combine to form Devastator, who destroys one of the pyramids to reveal the Sun Harvester inside, before he is killed by a destroyer's railgun called in by Simmons. Ravage and the Decepticon Rampage attempt to spring a trap with Sam's captured parents as bait, in order to force Sam to give them the Matrix, but Bumblebee interferes and kills them both. Major William Lennox and Master Sergeant Robert Epps call in an airstrike, which kills a majority of the Decepticon ground forces. However, Megatron manages to shoot Sam, seemingly killing him, before retreating upon getting attacked. Nearing his death, the Primes contact Sam through a vision, telling him the Matrix is earned, not found, and that he earned the right to bear it. They restore Sam's life and the Matrix, which he uses to revive Optimus.

The Fallen teleports to their location and steals the Matrix from Optimus, then returns to the pyramid with Megatron and activates the Sun Harvester. Jetfire, who was gravely wounded during the battle by Scorponok but did manage to kill his attacker, sacrifices himself in order to transplant his parts to Optimus, which give him immense strength and the ability to fly. Optimus knocks the Fallen and Megatron off the pyramid, destroying the Sun Harvester in the process. In the battle, Optimus disables Megatron and kills the Fallen; vowing vengeance, Megatron retreats with Starscream. The

Cast[edit]

Main article: List of Transformers film series characters

Shia LaBeouf as Sam Witwicky

A recent high school graduate who is unwittingly drawn again into the Autobot cause to unravel an ancient mystery implanted into his mind by the now-destroyed Allspark.

Megan Fox as Mikaela Banes

Sam's girlfriend who he trusted the Allspark fragment to begin unravel.

Josh Duhamel as Maj. William Lennox

An Army Rangers Major who establishes the NEST movement to help the Autobots with their battle against the remaining Decepticons.

Tyrese Gibson as CMSgt. Robert Epps

A U.S. Air Force sergeant in Lennox's team who leads NEST's SWAT unit.

John Turturro as Seymour Simmons

A former agent of the recently terminated Sector 7 who now runs a meat shop in New York City with his mother.

Ramón Rodríguez as Leo Spitz

A college roommate of Sam's who runs an online conspiracy blog and is obsessed with the Transformers.

Kevin Dunn as Ron Witwicky

Sam's father.

Julie White as Judith Witwicky

Sam's mother.

Isabel Lucas as Alice

A female pretender sent to spy on Sam in college who transforms into an Alice in Wonderland android.

John Benjamin Hickey as Theo Galloway

A national security adviser who often chastises NEST for their destructive tactics.

Glenn Morshower as U.S. Marine Corps General Morshower

The supervisor of NEST.

Matthew Marsden as Graham

A NEST officer.

Rainn Wilson as Prof. R. A. Colan

Sam and Leo's astronomy teacher.

Marc Evan Jackson as Commander

U.S. Central Command

Katie Lowes as April the Residential Assistant

Voices[edit]

Optimus Prime, Universal Studios Florida

Peter Cullen as Optimus Prime

The leader of the Autobots who transforms into a blue and red 1994 Peterbilt 379 semi-trailer truck. He is said to be the only Transformer capable of defeating The Fallen.

Mark Ryan as Jetfire

An ancient Decepticon-turned-Autobot Seeker who transforms into a Lockheed SR-71 Blackbird.[a]

Reno Wilson as Mudflap

An Autobot infiltrator and Skids' twin who transforms into a red 2007 Chevrolet Trax.

Jess Harnell as Ironhide

The Autobot weapons specialist and Optimus' new second-in-command who transforms into a black 2006 GMC Topkick C4500.

Robert Foxworth as Ratchet

The Autobot medical officer who transforms into a yellow 2004 search and rescue Hummer H2 ambulance.

André Sogliuzzo as Sideswipe

The Autobot combat instructor who transforms into a silver 2009 Chevrolet Corvette Stingray concept car.

Grey DeLisle as Arcee

A female Autobot who transforms into a pink Ducati 848.[b]

Hugo Weaving as Megatron

The Fallen's apprentice and the leader of the Decepticons who transforms into a Cybertronian hover tank.

Tony Todd as The Fallen

A rogue Prime who is the first and founder of the Decepticons, as well as the master of Megatron.

Charlie Adler as Starscream

Megatron's second-in-command who transforms into a Lockheed Martin F-22 Raptor.

Frank Welker as:

Soundwave

The Decepticon communications officer who transforms into a Cybertronian satellite.

Devastator

A massive Decepticon who is the combination of eight Constructicons.

Reedman, a razor-thin Decepticon composed of thousands of minuscule bead-like Decepticons.[c]

Tom Kenny as:

Wheelie

A former Decepticon drone and later an Autobot who transforms into a blue radio-controlled toy monster truck.

Skids

An Autobot messenger and Mudflap's twin who transforms into a green 2007 Chevrolet Beat.

Calvin Wimmer voices Demolishor (credited as "Wheelbot")

A huge Constructicon who transforms into a red and white Terex O&K RH 400 excavator. He hides out in Shanghai with the Decepticon Sideways.

John DiCrosta as Scalpel (credited as "Doctor")

A spider-like Decepticon who transforms into a microscope.

Michael York as Prime #1

One of the Seven Primes.

Kevin Michael Richardson as:

Prime #2

One of the Seven Primes.

Rampage (credited as "Skipjack")

A Constructicon who transforms into a red Caterpillar D9T bulldozer. He forms the left leg of Devastator.

Robin Atkin Downes as Prime #3

One of the Seven Primes

Non-speaking characters[edit]

Jolt

An Autobot technician who transforms into a blue Chevrolet Volt.

Sideways

A Decepticon surveillance agent who transforms into a silver Audi R8; he hides out in Shanghai alongside Demolishor.

Scorponok

A scorpion-like Decepticon who was a minion of Blackout in the previous installment; he makes a cameo in this film.

Scrapper

A Constructicon who transforms into a yellow Caterpillar 992G scoop loader. He forms the right arm of Devastator.

Mixmaster

A Constructicon who transforms into a black and silver Mack concrete mixer truck. He forms the head of Devastator.

Scrapmetal

A Constructicon who transforms into a yellow Volvo EC700C crawler excavator fitted with a Stanley UP 45SV attachment. His spare parts are used to resurrect Megatron.

Long Haul

A Constructicon who transforms into a green Caterpillar 773B dump truck. He forms the right leg of Devastator.

Scavenger

A large Constructicon who shares the same model of Demolishor; Scavenger is not seen in robot mode. He forms the torso of Devastator.

Hightower

A Constructicon who transforms into a yellow KOBELCO CKE2500 II crawler crane; Hightower is not seen in robot mode. He forms the left arm of Devastator.

Overload

A Constructicon who transforms into a red KW Dart D4661 Tractor Truck articulated dump truck; Overload is not seen in robot mode. He forms the lower torso of Devastator.

Ravage

A feline-like beast sent down by Soundwave to steal the spark from the NEST HQ in order to revive Megatron.

Several clones of Scrapper, Mixmaster, Bonecrusher, Long Haul and Rampage are seen during the final battle in Egypt. An unnamed Decepticon bulldozer and dump truck, possibly clones of Rampage and Long Haul, were seen combining to form Devastator's left hand and left leg, respectively.

Notes

Jump up ^ Mark Ryan also voices Bumblebee, but the character is not listed in the credits.

Jump up ^ Grey DeLisle also voices Chromia and Elita-One, but the characters are not listed in the credits.

Jump up ^ Frank Welker also voices Ravage and Grindor, but the characters are not listed in the credits.

Production[edit]
Development[edit]

Major hurdles for film's initial production stages included the 2007–2008 Writers Guild of America strike as well as the threat of strikes by other guilds. Prior to a potential Directors Guild of America strike, Bay began creating animatics of action sequences featuring characters rejected for the 2007 film. This would allow animators to complete sequences if the Directors Guild of America went on strike in July 2008, which ultimately did not happen.[4][5] Bay considered making a small project in between Transformers and its sequel, but decided against the idea, saying "you have your baby and you don't want someone else to take it".[6]

Screenwriters Roberto Orci and Alex Kurtzman, who had written the first film, originally passed on the opportunity to write a sequel due to schedule conflicts. The studio began courting other writers in May 2007, but were unimpressed with other pitches and eventually convinced Orci and Kurtzman to return.[4] The studio also hired Ehren Kruger, who had impressed Bay and Hasbro president Brian Goldner with his knowledge of the Transformers mythology.[7] The writing trio were paid $8 million.[4] Screenwriting was interrupted by the 2007–2008 Writers Guild of America strike, but to avoid production delays, the writers spent two weeks writing a treatment, which they handed in the night before the strike began.[8] Bay then expanded the outline into a 60-page scriptment,[9] which included more action, humor, and characters.[8][10] The three writers spent four months finishing the screenplay while "locked" in two hotel rooms by Bay; Kruger wrote in his own room and the trio would check on each other's work twice a day.[11]

Orci described the film's theme as "being away from home", with the Autobots contemplating living on Earth as they cannot restore Cybertron, while Sam goes to college.[12] He wanted the focus between the robots and humans "much more evenly balanced",[13] "the stakes [to] be higher", and more focused on the science fiction elements.[14] Orci added he wanted to "modulate" the humor more,[15] and felt he managed the more "outrageous" jokes by balancing them with a more serious plot approach to the Transformers' mythology.[16] Bay concurred that he wanted to please fans by making the tone darker,[17] and that "mums will think it[']s safe enough to bring the kids back out to the movies."[18] Two elements were added late into the film: the Autobot Jolt—as General Motors wanted to advertise the Chevrolet Volt—and the railgun that kills Devastator, a new acquisition by the U.S. Military.[19]

In September 2007, Paramount announced a late June 2009 release date for the sequel to Transformers.[20] The film was given a $200 million budget, which was $50 million more than the first film,[21] and some of the action scenes rejected for the original were written into the sequel.[22] Producer Lorenzo di Bonaventura later stated the studio proposed filming two sequels simultaneously, but he and Bay agreed that the idea was not the right direction for the series.[23]

Prior to the first film's release, producer Tom DeSanto had "a very cool idea" to introduce the Dinobots,[24] while Bay was interested in including an aircraft carrier, which was dropped from the 2007 film.[25] Orci claimed they did not incorporate these characters into Revenge of the Fallen because they could not think of a way to justify the Dinobots' choice of form,[12] and were unable to fit in the aircraft carrier.[26] Orci also admitted he was dismissive of the Dinobots because he does not like dinosaurs, saying "I recognize I am weird in that department."[27] However, he became fonder of them during filming because of their popularity with fans.[28] He added "I couldn't see why a Transformer would feel the need to disguise himself in front of a bunch of lizards. Movie-wise, I mean. Once the general audience is fully on board with the whole thing, maybe Dinobots in the future."[29] When asked on the subject, Michael Bay said he hated the Dinobots and they had never been in consideration for being featured in the movies.[30]

During production, Bay attempted to create a misinformation campaign to increase debate over what Transformers would be appearing in the film, as well as to try to throw fans off from the story of the film; however, Orci confessed it was generally unsuccessful.[26] The studio went as far as to censor MTV and Comic Book Resources interviews with Mowry and Furman, who confirmed Arcee and The Fallen would be in the picture.[31] Bay told Empire that Megatron would not be resurrected, claiming his new tank form was a toy-only character,[21] only for Orci to confirm Megatron would return in the film in February 2009.[32] Bay also claimed he faked the leaking of daily call sheets from the first week of filming, that revealed Ramón Rodríguez's casting,[33] and the appearance of Jetfire and the twins.[34]

Filming[edit]

Inspired by its use in Christopher Nolan's The Dark Knight, three action sequences in Revenge of the Fallen were shot using IMAX cameras.[17] Although screenwriter Roberto Orci suggested that the IMAX footage would be 3D,[35] Bay later said he found 3D too "gimmicky". Bay added that shooting in IMAX was easier than using stereoscopic cameras.[36]

The majority of interior scenes for the film were shot in the former Hughes Aircraft soundstages at Playa Vista.[37] From June 2–4, the production filmed an action sequence at the Bethlehem Steel site in Bethlehem, Pennsylvania, which was used to represent a portion of Shanghai.[9][38] Afterwards, they shot at the Steven F. Udvar-Hazy Center.[39] The crew moved to Philadelphia on June 9, where they shot at a defunct PECO Richmond power station, the University of Pennsylvania, Drexel University, the Eastern State Penitentiary, Fairmount Park, Philadelphia City Hall, Rittenhouse Square, historic Chancellor Street (which represents a street near Place de la Concorde in Paris), and Wanamaker's.[40][41][42][43] The production moved to Princeton University on June 22.[44] Filming there angered some students at the University of Pennsylvania, believing Bay had chosen to reshoot scenes at Princeton and script Princeton's name in the film. One shot that was filmed in the University of Pennsylvania was the party scene, filmed at what students call "The Castle". "The Castle" is home to the prestigious Psi Upsilon Fraternity. However, neither the University of Pennsylvania nor Princeton gave Bay permission to be named in the film because of a scene that both institutions felt "did not represent the school" in which Sam's mother ingests marijuana-laced brownies.[45]

Three days of filming were spent in Egypt.

Bay scheduled a break for filming beginning on June 30, turning his attention to animation and second unit scenes because of the potential guild strike.[46] Shooting for the Shanghai battle later continued in Long Beach, California.[47] In September, the crew shot at Holloman Air Force Base and White Sands Missile Range in New Mexico. The two locations were used for Qatar in Transformers and stood in for Egypt in this film.[48] A scale model in Los Angeles was also used for some close-ups of the pyramids.[21] Shooting at Tucson International Airport and the 309th Aerospace Maintenance and Regeneration Group's aircraft boneyard took place in October under the fake working title Prime Directive (a reference to Star Trek).[49] Filming also took place at Camp Pendleton and Davis–Monthan Air Force Base.[37]

The first unit then shot for three days in Egypt at the Giza pyramid complex and Luxor. The shoot was highly secretive, but according to producer Lorenzo di Bonaventura, a crew of 150 Americans and "several dozen local Egyptians" ensured a "remarkably smooth" shoot.[50] Bay earned the Egyptian government's approval to film at the pyramids by contacting Zahi Hawass, whom Bay said "put his arm around me and said, 'Don't hurt my pyramids.'"[37] A 50-foot-tall (15 m) camera crane was used at the location.[21] Bay stated he found the climax of the first film to be weak, partly because it was shot across five different city blocks, making the action confusing and hard to follow. On this film, the final battle in Egypt was devised to make it easier to follow the action.[51]

Four days were then spent in Jordan; the Royal Jordanian Air Force aided in filming at Petra, Wadi Rum and Salt because King Abdullah II is a big fan of science fiction movies.[52][53] Filming continued at the Place de la Concorde in Paris with second unit shots of the Eiffel Tower and the Arc de Triomphe.[54] The cast and crew finished principal photography on the aircraft carrier USS John C. Stennis on November 2, 2008.[55]

Effects[edit]

Starscream confronts Sam. In his audio commentary for the 2007 film, Michael Bay said he wanted more close-ups of robots for the sequel.

Hasbro became more involved in the designs of the robots than the company was for Transformers.[15] The company, along with Takara Tomy, suggested to the filmmakers that combining robots be the main draw for the sequel.[56] They insisted on keeping the alternate modes of some of the returning characters similar so that consumers would not have to buy toys of the same characters.[57] Bay used real F-16 Fighting Falcon and tank fire when filming the battles.[23] Many of the new Autobot cars supplied by General Motors were brightly colored to look distinctive on screen.[58] Revenge of the Fallen features 46 robots, while the original movie had 14.[59]

Scott Farrar returned as visual effects supervisor and anticipated moodier use of lighting as well as deeper roles for the Decepticons.[clarification needed] He stated that with the bigger deadline, post-production would become a "circus".[60] The producers expected that with a bigger budget and the special effects worked out, the Transformers would have a larger role. Peter Cullen recalled, "Don Murphy mentioned to me, 'Only because of the tremendous expense to animate Optimus Prime, he'll be in just a certain amount of [Transformers].' But he said, 'Next time, if the movie is a success, you're gonna be in it a ton.'"[61] Michael Bay hoped to include more close-ups of the robots' faces.[62] The heads had to be designed with more pieces in order to express emotions in a more convincing way.[59] Farrar said the animators implemented more "splashes and the hits and the fighting on dirt or moving, banging into trees, [...] things splinter and break, [the robots] spit, they outgas, they sweat, they snort." Shooting in the higher resolution of IMAX required up to 72 hours to render a single frame of animation.[63][64] While ILM used 15 terabytes for Transformers, they used 140 for the sequel.[53] Particularly problematic effects were the lighting, with scenes such as Jetfire inside the Smithsonian requiring 41 light sources, and the destruction of the pyramid, which appears in about five shots and required seven months to simulate the behavior of the blocks.[59] Orci hinted the majority of the Decepticons were entirely computer-generated in both robot and alternate modes, making it easier to write additional scenes for them in post-production.[65] Rendering the Devastator took over 85% of ILM's render farm capacity, and the complexity of the scene and having to render it at IMAX resolution caused one computer to "explode".[66]

Music[edit]

See also: Transformers: Revenge of the Fallen – The Album and Transformers: Revenge of the Fallen – The Score

The score to Revenge of the Fallen was composed by Steve Jablonsky, who reunited with director Michael Bay to record his score with a 71-piece ensemble of the Hollywood Studio Symphony at the Sony Scoring Stage.[67] Jablonsky and his score producer Hans Zimmer composed various interpretations of a song by Linkin Park called "New Divide" for the score.[68]

Marketing[edit]

An additional $150 million was spent to market the film globally.[69] Hasbro's Revenge of the Fallen toy line included new molds of new and returning characters, as well as 2007 figures with new mold elements or new paint schemes.[70] The first wave was released on May 30, although Bumblebee and Soundwave debuted beforehand.[71] The second wave came in August 2009, which introduced toys such as 2¼-inch human action figures that fit inside the transforming robots, and non-transforming replicas of the cars that can be used on a race track. Product placement partners on the film include Burger King, 7-Eleven, LG phones, Kmart, Wal-Mart, YouTube, Nike, Inc. and M&M's, as well as Jollibee in the Philippines.[72] General Motors' financial troubles limited its involvement in promotion of the sequel, although Paramount acknowledged with or without GM, their marketing campaign was still very large and had the foundation of the 2007 film's success.[73][74][75] Kyle Busch drove a Revenge of the Fallen decorated car at Infineon Raceway on June 21, 2009,[76] while Josh Duhamel drove a 2010 Camaro at the Indianapolis 500.[77] At the movie's launch in China, a version of Bumblebee was constructed using a Volkswagen Jetta.[78]

Printed media[edit]

Chris Mowry and artist Alex Milne, who had collaborated on The Reign of Starscream comic book, reunited for IDW Publishing's prequel to the film. Originally set to be a five-part series entitled Destiny,[79] it was split into two simultaneously published series, titled Alliance and Defiance. Alliance is drawn by Milne and began in December 2008; it focuses on the human and Autobot perspectives.[80] Defiance, which started the following month, is drawn by Dan Khanna and is set before either film, showing the beginnings of the war.[81]

After the 2007 film, and serving as a bridge between the two films, Alan Dean Foster wrote Transformers: The Veiled Threat,[82] originally titled Infiltration. During the writing, Foster collaborated with IDW to make sure their stories did not contradict each other.[83]

The first printed media directly related to the second film was a 32-page coloring and activity book by publisher HarperCollins, which became available on May 5, 2009 and was the first official source to openly give out key plot points to the film.[84] On June 1, 2009 DK Publishing published a 96-page book entitled Transformers: The Movie Universe, which intended to provide factual data on the characters of the film.[85]

On June 10, 2009, the comic book adaptation of the film, written by Simon Furman was released.[86] Additionally, Alan Dean Foster also wrote the novelization for the film.[87] Meanwhile, Dan Jolley wrote Transformers: Revenge of the Fallen: The Junior Novel, a 144-page book oriented at a younger audience than the one by Foster.[88] Lastly, a book titled Transformers: The Art of the Movies was released, documenting behind-the scenes aspects of the making of the film.

Other minor tie-in publications include Transformers: Revenge of the Fallen: The Last Prime, Transformers: Revenge of the Fallen: The Reusable Sticker Book, Transformers: Revenge of the Fallen: Made You Look!, Transformers: Revenge of the Fallen: Rise of the Decepticons, Transformers: Revenge of the Fallen: Spot the 'Bots', Transformers: Revenge of the Fallen: Mix and Match, Operation Autobot, When Robots Attack and Transformers: Revenge of the Fallen 2010 Wall Calendar.

Video game[edit]

Main article: Transformers: Revenge of the Fallen (video game)

Revenge of the Fallen video games are available on the following platforms:

PlayStation 3 and Xbox 360 (Developed by Luxoflux and published by Activision)[89][90]

Games for Windows (Developed by Beenox), which is similar to the PS3 and Xbox 360 version[91]

Wii and PlayStation 2 (Developed by Krome Studios)[92]

PlayStation Portable (Developed by Savage Entertainment)[93]

Nintendo DS (Developed by Vicarious Visions), which is separated into two games, Autobots and Decepticons.[94]

Release[edit]

Revenge of the Fallen premiered on June 8, 2009 in Tokyo, Japan.[95] After its UK release on June 19, 2009, it was released in regular and IMAX theaters in North America on June 24[96] (though some theaters held limited-access advance screenings on June 22). The IMAX release featured additional scenes of extended robot fighting sequences, which were not seen in the regular theatre version.[97]

Reception[edit]
Critical response[edit]

On review aggregator Rotten Tomatoes, Revenge of the Fallen has an approval rating of 19% based on 244 reviews, with an average rating of 3.9/10. The site's critical consensus reads, "Transformers: Revenge of the Fallen is a noisy, underplotted, and overlong special effects extravaganza that lacks a human touch."[98] On Metacritic gave the film an average score of 35 out of 100, based on 32 critics, indicating "generally unfavorable reviews".[99] In CinemaScore polls, however, users gave the film a "B+", compared to the "A" that the original film had scored.[100]

Actor Shia LaBeouf was unimpressed with the film, stating "We got lost. We tried to get bigger. It's what happens to sequels. It's like, how do you top the first one? You've got to go bigger. Michael Bay went so big that it became too big, and I think you lost the anchor of the movie...You lost a bit of the relationships. Unless you have those relationships, then the movie doesn't matter. Then it's just a bunch of robots fighting each other."[101] Bay has admitted his disappointment with the film and has apologized, saying the film was "crap" and blaming the 2007–2008 Writers' Strike, saying "It was very hard to put (the sequel) together that quickly after the writers' strike (of 2007–08)".[102]

According to The Washington Post, Revenge of the Fallen was Bay's worst-reviewed film at the time of release, faring even worse than Pearl Harbor (2001).[103] Betsy Sharkey of the Los Angeles Times described the film as "in-your-face, ear-splitting and unrelenting. It's easy to walk away feeling like you've spent 2 hours in the mad, wild, hydraulic embrace of a car compactor".[104]

Roger Ebert, who had given the 2007 film three stars,[105] gave the sequel only one, calling it "...a horrible experience of unbearable length", a phrase which later became the title of his third bad-movie-reviews collection. Later in his review, Ebert discouraged movie-goers from seeing the film by saying "If you want to save yourself the ticket price, go into the kitchen, cue up a male choir singing the music of hell, and get a kid to start banging pots and pans together. Then close your eyes and use your imagination."[106] He later wrote on his blog about the film, "The day will come when Transformers: Revenge of the Fallen will be studied in film classes and shown at cult film festivals. It will be seen, in retrospect, as marking the end of an era. Of course there will be many more CGI-based action epics, but never again one this bloated, excessive, incomprehensible, long (149 minutes) or expensive ($200 million)."[107] Ebert would continue to lambast the film (and, sometimes, the Transformers franchise in general) in other movie reviews and responses to letters and emails sent to him. Rolling Stone critic Peter Travers did not give the film any stars, considering that "Revenge of the Fallen has a shot at the title 'Worst Movie of the Decade'."[108] Which he later did name it the "worst film of the decade". Other reviewers, while still critical, were less damning of the film, The A.V. Club gave the film a "C-", complaining about the writing and length, but mentioning the effects and action scenes were impressive.[109] Among positive reviews, Robbie Collin of News of the World remarked "It's bigger. Badder. Boobier. And many other words beginning with B, including boneheadedly brilliant.",[110] Amy Biancolli of The Houston Chronicle called it "a well-oiled, loudly revving summer action vehicle that does all that's required, and then some",[111] Jordan Mintzer from Variety said it "takes the franchise to a vastly superior level of artificial intelligence",[112] and Owen Gleiberman of Entertainment Weekly wrote that "Revenge of the Fallen may be a massive overdose of popcorn greased with motor oil. But it knows how to feed your inner 10-year-old's appetite for destruction."[113]

On a year-end poll administered by Moviefone, the film was voted the "worst film of 2009", and Fox's performance the worst by an actress that year.[114] Comcast ranked the film as the 4th worst sequel of all time.[115] Empire named the film the 25th worst movie ever made.[116] In June 2009, David Germain from the Associated Press called the film the "worst-reviewed $400 million hit ever".[117]

| "On every level this movie is as bankrupt as GM. [...] Transformers: The Revenge of The Fallen is beyond bad, it carves out its own category of godawfulness." |

| — Peter Travers, American film critic[108] |

There was considerable negative reaction to the characters Mudflap and Skids, who some perceived as embodying racist stereotypes. Manohla Dargis of The New York Times said that "the characters [...] indicate that minstrelsy remains as much in fashion in Hollywood as when, well, Jar Jar Binks was set loose by George Lucas".[118] Critic Scott Mendelson said "To say that these two are the most astonishingly racist caricatures that I've ever seen in a mainstream motion picture would be an understatement."[119] Harry Knowles, founder of Ain't It Cool News, went further, asking his readers "not to support this film" because "you'll be taking [your children] to see a film with the lowest forms of humor, stereotypes, and racism around."[120] Bay (the director) has attempted to defend the film as "good clean fun" and insisted that "We're just putting more personality in."[121] Writers Roberto Orci and Alex Kurtzman responded to the controversy with "It's really hard for us to sit here and try to justify it. I think that would be very foolish, and if someone wants to be offended by it, it's their right. We were very surprised when we saw it, too, and it's a choice that was made. If anything, it just shows you that we don't control every aspect of the movie."[122]

Another major complaint about the film was Bay's usage of the IMAX format. Instead of using IMAX for complete unbroken sequences similar to director Christopher Nolan's approach for The Dark Knight, Bay chose to use the format primarily on a shot-by-shot basis, combining conventional 35mm footage and IMAX shots in the same sequence. That approach, combined with rapid cutting, created a jarring, highly unpleasant experience for most moviegoers.[123]

Box office[edit]

Despite mostly negative reviews from critics, the film was a box office success. Revenge of the Fallen grossed $16 million from midnight showings, at the time the most ever for a Wednesday midnight debut.[124] The film proceeded to beat Harry Potter and the Order of the Phoenix's record ($44.2 million) for the biggest Wednesday opening in history,[125] bringing in $62 million in total receipts on its first day (until The Twilight Saga: Eclipse topped this record with $68.5 million in 2010),[126] additionally ranking it as the second biggest opening day ever at the time, behind The Dark Knight.[127] The film grossed $108.9 million on its first weekend, the seventh-largest in history at the time, and brought in $200 million in its first five days, putting it in second place behind The Dark Knight's $203.7 million for the all-time biggest five-day opening.[128] Its gross from Friday to Sunday was also the biggest June opening weekend for one year, breaking Harry Potter and the Prisoner of Azkaban's record ($93.7 million), until Toy Story 3 claimed that record the following year ($110.3 million).[129]

Revenge of the Fallen remained #1 at the box office for two weeks straight by a close margin. Initial studio estimates showed a tie between it and that weekend's new release Ice Age: Dawn of the Dinosaurs, but the actual totals showed Revenge of the Fallen taking the #1 spot yet again with $42.3 million.[130] Also, it was the first film of 2009 to reach the $300 million mark in North America.[131] On July 27, a month after its release, the movie reached $379.2 million in the US, which brought it into the top 10 highest-grossing movies ever in that country as of August 2009.[132] Revenge of the Fallen closed its box office run with $402.1 million in the US & Canada and $836.3 million worldwide, being the twenty-fifth highest-grossing film of all time domestically, and the 84th highest-grossing film of all time.[133] Among 2009 films, it was the second highest grossing in the United States and Canada, behind Avatar,[134] and fourth globally behind Avatar, Harry Potter and the Half-Blood Prince, and Ice Age: Dawn of the Dinosaurs.[135] As of 2013, the film marks as the second highest-grossing Hasbro film of all time, behind only its sequel Transformers: Dark of the Moon. Box Office Mojo estimates that the film sold over 53 million tickets in the US.[136]

Home media[edit]

The film was released on October 20, 2009 in two-disc Blu-ray and DVD editions, and a single-disc DVD version.[137] Michael Bay has revealed that the Blu-ray release of the film, produced by Charles de Lauzirika, will feature variable aspect ratio for the scenes shot in IMAX format. A special IMAX edition is available exclusively at Wal-Mart.[138] Home versions include over three hours of bonus content and several interactive features, including "The AllSpark Experiment", which reveals Michael Bay's plans for a third movie in the series. At Target, the DVD and Blu-ray versions includes a transformable Bumblebee case. Both two-disc editions are the first to include Paramount's Augmented Reality feature, which allows the user to handle a 3D model of Optimus Prime on a computer by moving the package in front of a webcam.[139] First week sales of the DVD reached 7.5 million copies, making it the best-selling DVD of 2009. The Blu-ray version had the best first-week sales of 2009, with 1.2 million units.[140]

Awards and nominations[edit]

Revenge of the Fallen was among the films shortlisted for the Best Visual Effects at the 82nd Academy Awards,[141] but was only nominated for Best Sound Mixing (Greg P. Russell, Gary Summers and Geoffrey Patterson), eventually losing to The Hurt Locker.[142] The film won five Scream Awards, for Best Actress (Megan Fox), Breakout Performance-Female (Isabel Lucas), Best Sequel, Best F/X, and Scream Song of the Year ("New Divide");[143] and two Teen Choice Awards, for Choice Summer Movie Star: Female (Megan Fox) and Choice Summer Movie Star: Male (Shia LaBeouf).[144] Revenge of the Fallen was also nominated for the Saturn Award for Best Science Fiction Film but lost to Avatar,[145] Satellite Awards for Best Visual Effects and Best Sound,[146] a VES Award for Outstanding Visual Effects in a Visual Effects Driven Feature Motion Picture,[147] a SAG Award for Outstanding Performance by a Stunt Ensemble,[148] and an MTV Movie Award for Best WTF Moment (Isabel Lucas turning into a Decepticon).[149] Shia LaBeouf, the film and Megan Fox was nominated for a Nickelodeon Kids Choice Awards for Favorite Movie Actor, Favorite Movie and Favorite Movie Actress, but all lost to Taylor Lautner, Alvin and the Chipmunks: The Squeakquel and Miley Cyrus, respectively.

On the other hand, it was nominated for seven Razzie Awards including Worst Actress for Megan Fox (also for Jennifer's Body), Worst Supporting Actress for Julie White, Worst Screen Couple (for Shia LaBeouf and Megan Fox) and Worst Prequel, Remake, Rip-Off or Sequel,[150] winning three in the Worst Picture, Worst Director, and Worst Screenplay categories at the 30th Golden Raspberry Awards.[151]

Sequels[edit]

Main articles: Transformers: Dark of the Moon, Transformers: Age of Extinction, and Transformers: The Last Knight

The third film, Dark of the Moon was released June 29, 2011. The fourth film, Age of Extinction was released June 27, 2014. The fifth film, The Last Knight was released on June 21, 2017.

References[edit]

Jump up ^ "TRANSFORMERS: REVENGE OF THE FALLEN (12A)". BBFC. June 15, 2009. Retrieved January 19, 2016. 

^ Jump up to: a b "Transformers: Revenge of the Fallen (2009)". Box Office Mojo. Retrieved October 17, 2009. 

Jump up ^ "Transformers: Revenge of the Fallen (2009)". Metacritic. Retrieved 2011-07-07. 

^ Jump up to: a b c Fernandez, Jay (2007-10-10). "Heavy Metal for Sequel". Los Angeles Times. Retrieved 2008-09-28. 

Jump up ^ Davidson, Danielle (2008-01-23). "Writer's Strike Continues; DGA Signs Deal; Awards Questioned". The West Georgian. Archived from the original on June 28, 2009. Retrieved 2008-09-28. 

Jump up ^ Vary, Adam B. (2007-07-04). "Optimus Prime Time". Entertainment Weekly. Retrieved 2007-12-16. 

Jump up ^ Kit, Borys (2007-10-04). "Writing Team Built Fast for Transformers 2". The Hollywood Reporter. Archived from the original on October 11, 2007. Retrieved 2007-10-04. 

^ Jump up to: a b Billington, Alex (2009-01-14). "Kicking Off 2009 with Writers Alex Kurtzman and Roberto Orci – Part Two: Transformers 2". FirstShowing.net. Retrieved 2009-01-14. 

^ Jump up to: a b Thompson, Anne (2008-02-08). "Oscar Watch: Bay Hosts Transformers Tech Show". Variety. Archived from the original on March 21, 2008. Retrieved 2008-02-19. 

Jump up ^ Lee, Patrick (2009-03-31). "Orci & Kurtzman Reveal Transformers: Revenge of the Fallen Details". Sci Fi Wire. Retrieved 2009-03-31. 

Jump up ^ Sanchez, Stephanie (2008-09-17). "IESB Exclusive: Kurtzman and Orci on Transformers 2!". IESB. Retrieved 2008-09-17. 

^ Jump up to: a b Horowitz, Josh (July 24, 2008). "Writers Reveal Theme Of Transformers Sequel. The Bad News? No Dinobots". MTV Movies Blog. Archived from the original on August 28, 2008. Retrieved July 25, 2008. 

Jump up ^ Orci, Roberto (2008-05-25). "The Official "Hey Roberto" Thread". Don Murphy. Retrieved 2010-08-01. 

Jump up ^ Topel, Fred (2008-07-21). "Transformers 2 Scribe Sets Record Straight". Rotten Tomatoes. Retrieved 2010-08-01. 

^ Jump up to: a b "More on Transformers 2 From Writer Roberto Orci". Seibertron.com. 2008-02-18. Retrieved 2008-02-19. 

Jump up ^ Goldman, Eric (January 14, 2009). "Transformers 2 Rumor Confirmed". IGN. Archived from the original on January 19, 2009. Retrieved January 14, 2009. 

^ Jump up to: a b "Exclusive Video: Director Michael Bay talks Transformers: Revenge of the Fallen". Collider. 2009-02-09. Retrieved 2009-02-09. 

Jump up ^ "Q&A With Michael Bay". Toy Fair 09, New York City. 2009. Retrieved 2011-07-07. 

Jump up ^ Fernandez, Jay A. (2011-04-11). "ROUNDTABLE: The Writers Behind Summer's Biggest Blockbusters (Exclusive Video)". The Hollywood Reporter. Retrieved 2011-12-22. 

Jump up ^ McClintock, Pamela (2007-09-26). "Transformers Sequel Sets 2009 Date". Variety. Retrieved 2007-09-27. 

^ Jump up to: a b c d de Semelyn, Nick (February 2009). "20 to Watch in 2009". Empire. pp. 67–69. 

Jump up ^ "Transformers: Behind the Scenes" (Video). The Hollywood Reporter. Retrieved 2009-04-03. 

^ Jump up to: a b Savage, Brian. "TCC Exclusive: Transformers: Revenge of the Fallen at Toy Fair 2009". Transformers Collectors Club. Retrieved 2011-07-07. 

Jump up ^ "Transformer Producer Wants Dinobots in TF2". UGO Networks. June 5, 2007. Archived from the original on December 14, 2007. Retrieved December 16, 2007. 

Jump up ^ Kolan, Patrick (June 13, 2007). "Transformers Roundtable with Michael Bay". IGN. Archived from the original on January 22, 2009. Retrieved June 13, 2007. 

^ Jump up to: a b "Roberto Orci – Soundwave Will Not be a Pick Up In Transformers: Revenge of the Fallen". TFW2005. 2008-10-18. Retrieved 2008-10-19. 

Jump up ^ Orci, Roberto (2008-10-20). "he All New "Hey Roberto" Thread". Don Murphy. Retrieved 2009-03-17. 

Jump up ^ Orci, Roberto (2008-06-19). "The All New "Hey Roberto" Thread". Don Murphy. Retrieved 2008-06-25. 

Jump up ^ Orci, Roberto (2008-08-08). "Welcome Mr. Roberto Orci, You May Ask Him Questions". TFW2005. Retrieved 2009-03-24. 

Jump up ^ "Michael Bay on the Dinobots: "I hate them."". Seibertron.com. 2009-07-27. Retrieved 2009-07-27. 

Jump up ^ "Transformers 2: Did The Fallen Fall Off The Radar?". Seibertron. 2008-08-05. Retrieved 2008-08-06. 

Jump up ^ "Megatron's Return in Transformers 2 is Confirmed". Worst Previews. 2009-02-22. Retrieved 2009-02-22. 

Jump up ^ Bay, Michael (2008-07-31). "Re: Transformers Script". Shoot For The Edit: The Official Michael Bay Forums. Retrieved 2008-09-28. 

Jump up ^ "Transformers 2: Revenge of the Fallen Call Sheet Reveals Major Spoilers". MovieWeb. 2008-06-06. Retrieved 2008-06-06. 

Jump up ^ Orci, Robert (September 24, 2008). "Welcome Mr. Roberto Orci, You May Ask Questions". TFW2005. Archived from the original on January 21, 2016. Retrieved September 24, 2008. Some sequences will be in IMAX 3D 

Jump up ^ "Michael Bay Talks Transformers 2 and 3 at ShoWest". Collider. 2009-04-02. Retrieved 2009-04-03. 

^ Jump up to: a b c Debruge, Peter (March 31, 2009). "Who Made the Movie: Transformers II". Variety. Archived from the original on March 17, 2011. Retrieved April 1, 2009. 

Jump up ^ Duck, Michael (2008-01-17). "Officials Fired up for Bethlehem Filming". The Morning Call. 

Jump up ^ Knight, Keith (2008-06-07). "More High-Fliers at Air & Space". The Washington Post. Retrieved 2008-06-09. 

Jump up ^ Klein, Michael (2008-06-08). "Roll 'em". The Philadelphia Inquirer. Archived from the original on 2008-06-11. Retrieved 2008-06-09. 

Jump up ^ Klein, Michael (2008-06-17). "Inqlings: The big Reach for an Anchor". The Philadelphia Inquirer. Archived from the original on 2008-06-22. Retrieved 2008-06-17. 

Jump up ^ Scott, Aaron (2008-06-23). "Transformers Sequel Brings Movie Studio to Wanamaker Bldg". CoStar Group. Retrieved 2008-06-24. 

Jump up ^ Chavez, Kellvin (2008-06-14). "More Pics From Transformers 2 Set Plus Video!". LatinoReview.com. Retrieved 2009-02-28. 

Jump up ^ Shamma, Tashin (2008-06-24). "Transformers: Revenge of the FallenCrash Lands on Campus". The Daily Princetonian. Retrieved 2008-06-24. 

Jump up ^ "Regarding Penn's Open Letter to Michael Bay". Michael Bay. October 30, 2009. Archived from the original on November 26, 2010. Retrieved June 27, 2008. 

Jump up ^ Fouché, Gwladys (2008-06-17). "Hollywood Prepares for the Actors' Strike". The Guardian. London. Retrieved 2011-07-07. 

Jump up ^ Sciretta, Peter (2008-08-27). "Optimus Prime Spotted in Long Beach". Slash Film. Retrieved 2008-08-27. 

Jump up ^ "Tyrese Gibson Talks Transformers 2, Partying in El Pas". What's Up Weekly. October 8, 2008. Archived from the original on July 24, 2011. Retrieved October 8, 2008. 

Jump up ^ Villarreal, Phil (2008-06-05). "Moviemaking at Local Resort Provides Glitz, Economic Lift". Arizona Daily Star. Retrieved 2008-06-05. 

Jump up ^ Waxman, Sharon (2008-10-21). "Hollywood Steps Lightly: Spielberg and Soft Diplomacy in the Middle East". WaxWord. Retrieved 2008-10-22. 

Jump up ^ "Transformers: Revenge Of The Fallen Trailer Breakdown". Empire Online. Retrieved 2009-05-02. 

Jump up ^ Jafaar, Ali (February 4, 2009). "Jordan Hosts Transformers shoot". Variety. Archived from the original on June 29, 2011. Retrieved February 5, 2009. 

^ Jump up to: a b Boucher, Geoff (2009-05-24). "Michael Bay, Master of the 'Huge Canvas'". Los Angeles Times. Retrieved 2011-07-07. 

Jump up ^ "Revenge of the Fallen Primary Shooting Completed, Second Unit Shooting in Paris". TFW2005. 2008-10-28. Retrieved 2008-10-28. 

Jump up ^ "Transformers 2 Wrap Filming on USS John C Stennis". Seibertron.com. 2008-11-07. Retrieved 2008-11-07. 

Jump up ^ "Making of Transformers: Shogo Hasui" (in Japanese). akara Tomy. May 17, 2009. Archived from the original on March 29, 2012. Retrieved August 12, 2011.  (translation)

Jump up ^ Orci, Roberto (2008-06-27). "Welcome Mr. Roberto Orci, You May Ask Him Questions". TFW2005. Retrieved 2011-07-07. 

Jump up ^ "Behind the Bots" (Video interview). Fox News. 2009-02-13. Retrieved 2009-02-23. 

^ Jump up to: a b c Desowitz, Bill (2009-06-30). "Escalating VFX for New Transformers". Animation World Network. Retrieved 2010-11-05. 

Jump up ^ White, Cindy (2007-10-01). "Transformers 2 More Ambitious". Sci Fi Wire. Archived from the original on 2008-06-09. Retrieved 2007-10-01. 

Jump up ^ Breznican, Anthony (2007-07-12). "Fan Buzz: Flesh out Those 'Bots". USA Today. Retrieved 2007-07-12. 

Jump up ^ Michael Bay's DVD audio commentary for Transformers, 2007, Paramount

Jump up ^ Cohen, David S. (2009-03-31). "Michael Bay Keeps VFX Shops Busy". Variety. Retrieved 2009-04-01. 

Jump up ^ "Transformers: Revenge of the Fallen Fun Facts". michaelbay.com. June 17, 2009. Archived from the original on June 22, 2009. Retrieved June 29, 2009. 

Jump up ^ "Roberto Orci Discusses Scene Additions, Fan Love, Starscream, and 40 Robots". TFW2005. 2009-01-27. Retrieved 2009-01-27. 

Jump up ^ "How the Giant-robot F/X in Transformers 2 nearly broke ILM. Seriously". Blastr. Retrieved 2011-07-04. 

Jump up ^ Dan Goldwasser (2009-06-18). "Steve Jablonsky scores Transformers: Revenge of the Fallen". ScoringSessions.com. Retrieved 2009-06-18. 

Jump up ^ "Transformers 2 song is 'New Divide'". The Linkin Park Times. May 6, 2009. Archived from the original on July 12, 2009. Retrieved May 7, 2009. 

Jump up ^ Thompson, Anne (2009-06-23). "Transformers: ROTF Premiere, LaBeouf's Wild Life". Variety. Archived from the original on June 27, 2009. Retrieved 2009-07-28. 

Jump up ^ "Transformers at Toy Fair 2009". Transformers Collectors Club. Retrieved 2009-02-14. 

Jump up ^ "Transformers: Revenge of the Fallen Coverage from Toyfare #140". TFW2005. 2009-02-11. Retrieved 2009-02-11. 

Jump up ^ "Official Press Release: Jollibee Transformers Revenge of the Fallen". Newworlds.ph. 2009-06-16. Retrieved 2009-07-22. 

Jump up ^ Claudia Eller (2009-04-06). "GM's troubles deprive 'Transformers 2' of crucial horsepower". Los Angeles Times. Retrieved 2009-04-06. 

Jump up ^ "Transformers 2 Product Placement". Product Placement News. 2008-09-04. Retrieved 2008-09-04. 

Jump up ^ Josh Modell (2008-10-07). "Taste Test Special Report: The National Association Of Convenience Stores Convention". The A.V. Club. Retrieved 2008-10-10. 

Jump up ^ "Kyle Busch #18 Transformers 2: Revenge of the Fallen / M&M's 2009 Firebird Diecast". Planet Diecast. January 2012. 

Jump up ^ "Actor Duhamel To Drive Indy 500 Pace Car". The Indy Channel. 2009-04-30. Retrieved 2009-04-30. 

Jump up ^ Ramsey, Jonathon (2009-07-16). "Beijing mall builds its own Transformer out of VW Jetta". Autoblog.com. Retrieved 2009-07-22. 

Jump up ^ Brian Jacks (August 1, 2008). "EXCLUSIVE: 'Transformers 2' Prequel Comic Gives Inside Scoop On 2009 Movie". MTV Splash Page. Archived from the original on August 28, 2008. Retrieved August 1, 2008. 

Jump up ^ Chris Mowry (w), Alex Milne (p). Transformers: Alliance (December 2008 to March 2009), IDW Publishing

Jump up ^ Chris Mowry (w). Transformers: Defiance (January–April 2009), IDW Publishing

Jump up ^ Alan Dean Foster (April 2009). Transformers: The Veiled Threat. Del Rey Books. p. 288. ISBN 978-0-345-51592-6. 

Jump up ^ Alan Dean Foster (2008-11-01). "Updates". Retrieved 2008-12-10. 

Jump up ^ Grieser, Andy (March 17, 2009). "'Transformers: Revenge of the Fallen' spoiled by coloring book?". Zap2it. Archived from the original on January 17, 2010. Retrieved November 5, 2010. 

Jump up ^ "Transformers: The Movie Universe". Dorling Kindersley. Retrieved 2010-11-05. 

Jump up ^ "Preview: Transformers: Revenge of the Fallen Official Movie Adaptation". Comic Book Resources. Retrieved 2009-06-21. 

Jump up ^ "Transformers: Revenge of the Fallen by Alan Dean Foster — Paperback". Del Rey Books. 2008-11-20. Retrieved 2010-11-05. 

Jump up ^ "Transformers: Revenge of The Fallen: The Junior Novel by Dan Jolley". Harper Collins. Retrieved 2010-11-05. 

Jump up ^ de Matos, Xav (2009-09-02). "Transform and roll out against Luxoflux this Friday". Joystiq. Retrieved 2010-11-05. 

Jump up ^ César A. Berardini (July 15, 2008). "X-Men Origins: Wolverine and Transformers: Revenge of the Fallen Movie Tie-ins Announced". TeamXbox. Archived from the original on July 17, 2008. Retrieved July 15, 2008. 

Jump up ^ "Vengeance Has Arrived as Transformers: Revenge of the Fallen Game Hits Retail Shelves Nationwide". Test freaks. 2009-06-23. Retrieved 2009-06-27. 

Jump up ^ "Exclusive Transformers: Revenge of the Fallen Game Interview". Superhero Hype. 2009-06-23. Retrieved 2009-06-27. 

Jump up ^ ""TRANSFORMERS: REVENGE OF THE FALLEN" GAME HITS SHELVES NATIONWIDE". Comic Book Resources. 2009-06-23. Retrieved 2009-06-27. 

Jump up ^ Harris, Craig (2009-04-15). "Transformers: Revenge of the Fallen First Look". IGN. Retrieved 2011-07-07. 

Jump up ^ Josue, Rachel (June 8, 2009). "'Transformers: Revenge Of The Fallen' Premieres In Japan". MTV. Archived from the original on October 6, 2010. Retrieved November 24, 2010. 

Jump up ^ "Transformers Moved Up Two Days". ComingSoon.net. 2009-02-12. Retrieved 2009-02-12. 

Jump up ^ "IMAX To Feature Longer Cut of Transformers 2 With "More Robot Fighting"". /Film. 2011-07-07. Retrieved 2015-10-26. 

Jump up ^ "Transformers: Revenge of the Fallen". Rotten Tomatoes. Retrieved July 4, 2017. 

Jump up ^ "Transformers: Revenge of the Fallen (2009)". Metacritic. Retrieved 2011-07-07. 

Jump up ^ Pamela Mcclintock (June 29, 2009). "'Transformers' on top with $390.4 mil". Variety. Archived from the original on July 3, 2009. Retrieved June 30, 2009. 

Jump up ^ "LaBeouf says next 'Transformers' will be better". Associated Press. May 13, 2010. Retrieved May 17, 2010. 

Jump up ^ "Michael Bay Apologizes For Transformers 2, Promises a Better Transformers 3". June 11, 2010. Archived from the original on May 20, 2011. Retrieved May 29, 2011. 

Jump up ^ Zak, Dan (2009-07-01). "Reaching Critical Mess". The Washington Post. Retrieved 2010-11-03. 

Jump up ^ Sharkey, Betsy (2009-06-24). "Entertainment: 'Transformers: Revenge of the Fallen'". Los Angeles Times. 

Jump up ^ Ebert, Roger (5 July 2007). "Transformers". Chicago Sun-Times. Retrieved 11 October 2016. 

Jump up ^ Ebert, Roger. "Transformers: Revenge of the Fallen :: rogerebert.com :: Reviews". The Chicago Sun-Times. Retrieved 2009-06-24. 

Jump up ^ Ebert, Roger (June 24, 2009). "The Fall of the Revengers". The Chicago Sun-Times. Archived from the original on June 26, 2009. Retrieved June 24, 2009. 

^ Jump up to: a b Peter Travers (2009-06-24). "Transformers: Revenge of the Fallen". Rollingstone.com. Retrieved 2011-07-08. 

Jump up ^ Robinson, Tasha. "Transformers: Revenge Of The Fallen | Film". A.V. Club. Retrieved 2009-07-22. 

Jump up ^ Collin, Robbie (2009-06-14). "Transformers: Revenge of the Fallen 12A (tbc)". News of the World. Archived from the original on 2009-06-17. Retrieved 2015-07-03. 

Jump up ^ Biancolli, Amy (2006-06-23). "No real changes in new Transformers". The Houston Chronicle. Retrieved 2010-11-03. 

Jump up ^ Mintzer, Jordan (June 15, 2009). "Transformers: Revenge of the Fallen". Variety. Archived from the original on August 5, 2011. Retrieved July 7, 2011. 

Jump up ^ Gleiberman, Owen (2009-06-26). "Movie Review: Transformers: Revenge of the Fallen". Entertainment Weekly. Retrieved 2010-11-03. 

Jump up ^ "Year-End Movies Poll Results". Moviefone. Retrieved 2011-07-07. 

Jump up ^ "Worst Sequels of All Time". Comcast. Archived from the original on August 11, 2011. Retrieved July 7, 2011. 

Jump up ^ "Empire's The 50 Worst Movies Ever". Empire magazine. Retrieved July 4, 2010. 

Jump up ^ "Transformers: Worst-Reviewed $400 Million Hit?". Access Hollywood. Retrieved July 4, 2010. 

Jump up ^ Dargis, Manohla (2009-06-24). "Movie Review — Transformers: Revenge of the Fallen — Invasion of the Robot Toys, Redux". The New York Times. Retrieved 2009-06-24. 

Jump up ^ "Scott Mendelson: Huff Post Review: Transformers Revenge of the Fallen: The IMAX Experience(2009)". The Huffington Post. 2009-06-23. Retrieved 2009-06-24. 

Jump up ^ "Harry says TRANSFORMERS 2 is foul mouthed, racist & misogynistic! It also runs an hour too long!". Ain't It Cool News. 2009-06-23. Retrieved 2009-06-24. 

Jump up ^ Sandy Cohen, The Associated Press (2009-06-24). "Jive-talking twin Transformers raise race issues". USA Today. Retrieved 2010-10-17. 

Jump up ^ "Orci and Kurtzman Respond to Claims of Racism in 'Transformers 2′". Film School Rejects. June 24, 2009. Archived from the original on June 27, 2009. Retrieved June 27, 2009. 

Jump up ^ "How The Transformers: Revenge of the Fallen IMAX Experience Compares with The Dark Knight". Filmwblog.com. Archived from the original on March 28, 2012. Retrieved July 7, 2011. 

Jump up ^ Sperling, Nicole (2009-06-29). "'Transformers 2' racks up record $16 million in Wednesday midnight shows". Entertainment Weekly. Retrieved 2010-11-03. 

Jump up ^ "'Transformers' Sequel Blasts Off on First Day". Boxofficemojo.com. Retrieved 2011-07-04. 

Jump up ^ Gray, Brandon (2010-07-01). "'Eclipse' Breaks Wednesday Record But Falls Short of 'New Moon'". Box Office Mojo. Retrieved 2010-11-03. 

Jump up ^ "Opening Day Records at the Box Office". Box Office Mojo. Retrieved 2010-11-03. 

Jump up ^ Gray, Brandon (2009-06-29). "Weekend Report: 'Revenge of the Fallen' Rises with Optimal Debut". Box Office Mojo. Retrieved 2010-11-03. 

Jump up ^ Gray, Brandon (2010-06-21). "Weekend Report: Pixar Pounds Its 'Toy' Chest". Box Office Mojo. Retrieved 2010-11-03. 

Jump up ^ "Transformers: Revenge of the Fallen Weekend Chart". Box Office Mojo. Retrieved 2009-07-22. 

Jump up ^ "Transformers 2 Passes $600 Million Worldwide Box Office". Newsarama. 2009-07-08. Retrieved 2015-10-26. 

Jump up ^ "'Revenge of the Fallen' Cracks the Top 10 All-Time List". Movie Buzz. 2009-07-27. Retrieved 2009-07-28. 

Jump up ^ "Transformers: Revenge of the Fallen (2009)". Box Office Mojo. Retrieved 2017-04-06. 

Jump up ^ "2009 Yearly Box Office Results". Box Office Mojo. Retrieved June 1, 2010. 

Jump up ^ "2009 Worldwide Grosses". Box Office Mojo. Retrieved July 11, 2010. 

Jump up ^ "Transformers: Revenge of the Fallen (2009)". Box Office Mojo. Retrieved May 31, 2016. 

Jump up ^ "Revenge of The Fallen DVD/Blu-ray: October 20th". MichaelBay.com. August 20, 2009. Archived from the original on August 26, 2009. Retrieved August 21, 2009. 

Jump up ^ "Interview: Michael Bay Talks Transformers II, The DVD, Extra IMAX Footage, and the "Autobot Twins"". Film.com. June 24, 2009. Archived from the original on August 13, 2011. Retrieved July 7, 2011. 

Jump up ^ "Star Trek flies out with space-age box". VideoBusiness. 2009-07-06. Retrieved 2009-08-21. 

Jump up ^ "Revenge of Fallen: Biggest-Selling Blu-ray Disc Release and Top-Selling DVD of 2009". MichaelBay.com (from TheHollywoodReporter). October 29, 2009. Retrieved March 11, 2010. [permanent dead link]

Jump up ^ Kilday, Greg (2010-01-06). "Seven films on Oscar's visual effects shortlist". Reuters. Retrieved 2010-11-03. 

Jump up ^ "Nominees & Winners for the 82nd Academy Awards". AMPAS. Retrieved 2010-11-03. 

Jump up ^ Murray, Rebecca. "Spike TV's SCREAM 2009 Awards Nominees and Winners". About.com. Archived from the original on September 5, 2009. Retrieved November 3, 2010. 

Jump up ^ "Teen Choice Award Winners". CBS News. Associated Press. 2009-08-10. Retrieved 2010-11-03. 

Jump up ^ "The 36th Saturn Award Nominations". Academy of Science Fiction, Fantasy & Horror Films. November 3, 2010. Archived from the original on May 1, 2011. 

Jump up ^ "2009 14th Annual SATELLITE AWARDS". International Press Academy. Archived from the original on September 28, 2010. Retrieved 2010-11-03. 

Jump up ^ "VES Announces Nominees for 8th Annual VES Awards". Visual Effects Society. January 18, 2010. Archived from the original on May 7, 2010. Retrieved November 3, 2010. 

Jump up ^ "The 16th Annual Screen Actors Guild Awards". Screen Actors Guild. Retrieved 2010-11-03. 

Jump up ^ "2010 MTV Movie Awards". MTV. Retrieved 2010-03-31. 

Jump up ^ "Box Office Hits, Remakes and Sequels Dominate This Year's RAZZIE Nominations". Golden Raspberry Foundation. Retrieved 2010-11-03. 

Jump up ^ "Sandra Bullock wins TWO Razzie Awards; 'Transformers 2' nabs THREE". Los Angeles Times. 2010-03-06. Retrieved 2010-03-07. 

External links[edit]

| Wikiquote has quotations related to: Transformers: Revenge of the Fallen |

Film portal

 Media related to Transformers: Revenge of the Fallen at Wikimedia Commons

Transformers: Revenge of the Fallen on IMDb

Transformers: Revenge of the Fallen at the TCM Movie Database

Transformers: Revenge of the Fallen at Box Office Mojo

Transformers: Revenge of the Fallen at Rotten Tomatoes

Transformers: Revenge of the Fallen at Metacritic

| [show] v t e Transformers |

| [show] Universe |

| Autobots | Optimus Prime Ultra Magnus Rodimus Optimus Primal Arcee Blaster Blurr Brawn Bulkhead Bumblebee Cliffjumper Drift Fireflight Grapple Grimlock Hoist Hot Shot Hound Inferno Ironhide Jazz Jetfire Kup Metroplex Mudflap Omega Supreme Outback Perceptor Powerglide Quickmix Ratchet Red Alert Roadbuster Seaspray Sentinel Prime Side Burn Sideswipe Skids Sky High Sky Lynx Skydive Sludge Smokescreen Snarl Sunstreaker Tow-Line Trench Vector Prime Windblade Wheeljack Wreck-Gar |

| Decepticons | Megatron/Galvatron Starscream Barricade Blackout Blast Off Blitzwing Bludgeon Bombshell Brawl Demolishor Dirge The Fallen Frenzy Inferno Kickback Knock Out Lugnut Motormaster Octane Onslaught Over-Run Overbite Ramjet Ransack Ravage Rumble Scorponok Shrapnel Skyquake Slipstream Shockwave Soundwave Thrust Vortex Waspinator Wildrider |

| Subgroups | Dinobots Female Autobots Gobots Monsterbots Powermasters Predacons Pretenders Seacons Targetmasters Thirteen Primes Throttlebots |

| Supporting characters | Primus Unicron Scourge Circuit Breaker Spike Witwicky Sparkplug Carly Witwicky Marissa Faireborn |

| Character lists | Primes and Matrix holders Female Transformers |

| Technology and physiology | Cybertron Matrix of Leadership Spark List of planets |

| [show] Media |

| Crossovers | Built to Rule Transformers Label Star Wars Transformers |

| Marvel | The Transformers Generation 2 New Avengers/Transformers |

| Dreamwave | Generation 1 Armada/Energon The War Within Micromasters |

| IDW | The Transformers Infiltration Strombringer Escalation Spotlight Megatron Origin Devastation Revelation All Hail Megatron Maximum Dinobots Bumblebee Last Stand of the Wreckers Ironhide Infestation Heart of Darkness Chaos The Death of Optimus Prime More than Meets the Eye Autocracy Robots in Disguise Monstrosity Windblade Primacy Revolution Lost Light First Strike Beast Wars The Gathering The Ascending Generations Hearts of Steel Infestation 2 Transformers (film comic series) |

| Lists | Comics characters UK comics |

| Main group | Generation 1 Characters Episodes Scramble City Generation 2 Beast Wars Characters Episodes Beast Machines Episodes Robots in Disguise (2001 series) Characters Armada Characters Episodes Energon Characters Episodes Cybertron Characters Episodes Animated Characters Episodes Prime Characters Episodes Rescue Bots Characters Episodes Robots in Disguise (2015 series) Characters Episodes Cyberverse |

| Japanese exclusive | The Headmasters Characters Super-God Masterforce Characters Victory Characters Zone Characters Beast Wars II Characters Beast Wars Neo Characters Robot Masters Go! |

| Web series | Cyber Missions Prime Wars Trilogy Characters Combiner Wars Titans Return Power of the Primes |

| Animated films | The Transformers: The Movie Beast Wars II: Lio Convoy's Close Call! Transformers Prime Beast Hunters: Predacons Rising |

| Live-action films (cast and characters) | Transformers Revenge of the Fallen Dark of the Moon Age of Extinction The Last Knight Bumblebee: The Movie |

| Audio releases | The Transformers: The Movie Theme Song Collection History of Music 1984–1990 The Album Song Universe The Score Revenge of the Fallen – The Album Revenge of the Fallen – The Score Dark of the Moon – The Album Dark of the Moon – The Score Age of Extinction - The Score The Last Knight – The Score |

| Video games | The Transformers (1986) Battle to Save the Earth Mystery of Convoy Beast Wars Beast Senshi Saikyō Ketteisen Beast Wars Transmetals DreamMix TV World Fighters Transformers (2003) Transformers (2004) The Game Autobots Decepticons Animated: The Game G1: Awakening Revenge of the Fallen Autobots Decepticons War for Cybertron DS version Cybertron Adventures Dark of the Moon Universe Fall of Cybertron Prime – The Game Rise of the Dark Spark Angry Birds Transformers Transformers: Devastation |

| Novels | Ghosts of Yesterday The Veiled Threat Exodus Dark of the Moon: The Junior Novel Exiles Retribution The Covenant of Primus |

| Engagement | BotCon Fun Publications Transformers: The Ride 3D The Transformers Experience HasCon |

| Category |

| [show] v t e Films directed by Michael Bay |

| Bad Boys (1995) The Rock (1996) Armageddon (1998) Pearl Harbor (2001) Bad Boys II (2003) The Island (2005) Transformers (2007) Transformers: Revenge of the Fallen (2009) Transformers: Dark of the Moon (2011) Pain & Gain (2013) Transformers: Age of Extinction (2014) 13 Hours: The Secret Soldiers of Benghazi (2016) Transformers: The Last Knight (2017) |

| [show] v t e Ehren Kruger |

| Feature films | Killers in the House (1998) Arlington Road (1999) New World Disorder (1999) Scream 3 (2000) Reindeer Games (2000) Imposter (2002) The Ring (2002) Rings (2005) The Ring Two (2005) The Skeleton Key (2005) The Brothers Grimm (2005) Blood & Chocolate (2007) Transformers: Revenge of the Fallen (2009) Transformers: Dark of the Moon (2011) Transformers: Age of Extinction (2014) Ghost in the Shell (2017) Ophelia (2018) Dumbo (2019) |

| [show] v t e Golden Raspberry Award for Worst Picture |

| Can't Stop the Music (1980) Mommie Dearest (1981) Inchon (1982) The Lonely Lady (1983) Bolero (1984) Rambo: First Blood Part II (1985) Howard the Duck / Under the Cherry Moon (1986) Leonard Part 6 (1987) Cocktail (1988) Star Trek V: The Final Frontier (1989) The Adventures of Ford Fairlane / Ghosts Can't Do It (1990) Hudson Hawk (1991) Shining Through (1992) Indecent Proposal (1993) Color of Night (1994) Showgirls (1995) Striptease (1996) The Postman (1997) An Alan Smithee Film: Burn Hollywood Burn (1998) Wild Wild West (1999) Battlefield Earth (2000) Freddy Got Fingered (2001) Swept Away (2002) Gigli (2003) Catwoman (2004) Dirty Love (2005) Basic Instinct 2 (2006) I Know Who Killed Me (2007) The Love Guru (2008) Transformers: Revenge of the Fallen (2009) The Last Airbender (2010) Jack and Jill (2011) The Twilight Saga: Breaking Dawn – Part 2 (2012) Movie 43 (2013) Saving Christmas (2014) Fantastic Four / Fifty Shades of Grey (2015) Hillary's America: The Secret History of the Democratic Party (2016) The Emoji Movie (2017) |

| Book |

| [show] v t e Golden Raspberry Award for Worst Screenplay |

| 1980–2000 | Can't Stop the Music – Bronte Woodard and Allan Carr (1980) Mommie Dearest – Frank Yablans, Frank Perry, Tracy Hotchner and Robert Getchell (1981) Inchon – Robin Moore and Laird Koenig (1982) The Lonely Lady – John Kershaw, Shawn Randall and Ellen Shephard (1983) Bolero – John Derek (1984) Rambo: First Blood Part II – Sylvester Stallone, James Cameron and Kevin Jarre (1985) Howard the Duck – Willard Huyck and Gloria Katz (1986) Leonard Part 6 – Jonathan Reynolds and Bill Cosby (1987) Cocktail – Heywood Gould (1988) Harlem Nights – Eddie Murphy (1989) The Adventures of Ford Fairlane – Daniel Waters, James Cappe & David Arnott (1990) Hudson Hawk – Steven E. de Souza, Daniel Waters, Bruce Willis and Robert Kraft (1991) Stop! Or My Mom Will Shoot – Blake Snyder, William Osborne and William Davies – (1992) Indecent Proposal – Amy Holden Jones (1993) The Flintstones – Jim Jennewein, Steven E. de Souza, Tom S. Parker and various others (1994) Showgirls – Joe Eszterhas (1995) Striptease – Andrew Bergman (1996) The Postman – Eric Roth and Brian Helgeland (1997) An Alan Smithee Film: Burn Hollywood Burn – Joe Eszterhas (1998) Wild Wild West – Jim Thomas, John Thomas, S. S. Wilson, Brent Maddock, Jeffrey Price and Peter S. Seaman (1999) Battlefield Earth – Corey Mandell and J. David Shapiro (2000) |

| 2001–present | Freddy Got Fingered – Tom Green & Derek Harvie (2001) Star Wars: Episode II – Attack of the Clones – George Lucas and Jonathan Hales (2002) Gigli – Martin Brest (2003) Catwoman – Theresa Rebeck, John Brancato, Michael Ferris and John Rogers (2004) Dirty Love – Jenny McCarthy (2005) Basic Instinct 2 – Leora Barish and Henry Bean (2006) I Know Who Killed Me – Jeffrey Hammond (2007) The Love Guru – Mike Myers & Graham Gordy (2008) Transformers: Revenge of the Fallen – Ehren Kruger, Alex Kurtzman and Roberto Orci (2009) The Last Airbender – M. Night Shyamalan (2010) Jack and Jill – Steve Koren and Adam Sandler, story by Ben Zook (2011) That's My Boy - David Caspe (2012) Movie 43 - Steve Baker, Ricky Blitt, Will Carlough, Tobias Carlson, Jacob Fleisher, Patrik Forsberg, Will Graham, James Gunn, Claes Kjellstrom, Jack Kukoda, Bob Odenkirk, Bill O'Malley, Matthew Alec Portenoy, Greg Pritikin, Rocky Russo, Olle Sarri, Elizabeth Wright Shapiro, Jeremy Sosenko, Jonathan van Tulleken and Jonas Wittenmark (2013) Saving Christmas - Darren Doane and Cheston Hervey (2014) Fifty Shades of Grey - Kelly Marcel (2015) Batman v Superman: Dawn of Justice - Chris Terrio and David S. Goyer (2016) The Emoji Movie - Tony Leondis, Eric Siegel and Mike White (2017) |

| [show] v t e Works by Hasbro Studios |

| Television series | The Adventures of Chuck and Friends Blazing Team G.I. Joe: Renegades Kaijudo Littlest Pet Shop Littlest Pet Shop: A World of Our Own My Little Pony: Friendship Is Magic Pound Puppies Transformers: Prime Transformers: Rescue Bots Transformers: Robots in Disguise Transformers: Cyberverse Micronauts |

| Television films | Equestria Girls Beast Hunters: Predacons Rising Equestria Girls – Rainbow Rocks Equestria Girls – Friendship Games Equestria Girls – Legend of Everfree Equestria Girls – Magical Movie Night Equestria Girls – Forgotten Friendship |

| Web series | Transformers: Combiner Wars Hanazuki: Full of Treasures Transformers: Titans Return Stretch Armstrong and the Flex Fighters Transformers: Power of the Primes |

| Game shows | Family Game Night The Game of Life Scrabble Showdown Monopoly Millionaires' Club |

| Films | Ouija |

| Other | Hubworld Clue Taylor Swift: Journey to Fearless |

| Animated | My Little Pony: The Movie |

| Live action | Jem and the Holograms Ouija: Origin of Evil Bumblebee: The Movie |

| See also | Hasbro Boulder Media Limited Claster Television Films Television programs |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Transformers:_Revenge_of_the_Fallen&oldid=838455497"

Categories:

2009 films

English-language films

Transformers films

2000s action thriller films

2000s science fiction films

2000s sequel films

American films

American action films

American science fiction action films

American sequel films

Ancient astronauts in fiction

Films scored by Steve Jablonsky

Films about revenge

Films adapted into comics

Films directed by Michael Bay

Films produced by Lorenzo di Bonaventura

Films set in 2009

Films set in Asia

Films set in Cairo

Films set in Egypt

Films set in Jordan

Films set in Los Angeles

Films set in New York City

Films set in Philadelphia

Films set in Paris

Films set in Shanghai

Films set in universities and colleges

Films set in Virginia

Films set in Washington, D.C.

Films shot in Arizona

Films shot in California

Films shot in Pennsylvania

Films shot in Egypt

Films shot in Jordan

Films shot in Los Angeles

Films shot in Lone Pine, California

Films shot in New York City

Films shot in Qatar

Films shot in San Diego

Films shot in Shanghai

Films shot in Virginia

Films shot in New Jersey

Films shot in New Mexico

Films shot in Paris

Films shot in Philadelphia

Films shot in Washington, D.C.

Films using computer-generated imagery

IMAX films

Robot films

Prehistoric people in popular culture

Science fiction adventure films

Screenplays by Alex Kurtzman and Roberto Orci

Screenplays by Ehren Kruger

Treasure hunt films

Di Bonaventura Pictures films

Paramount Pictures films

DreamWorks Pictures films

American teen films

Hidden categories:

CS1 Japanese-language sources (ja)

All articles with dead external links

Articles with dead external links from January 2018

Articles with permanently dead external links

Use mdy dates from January 2016

Wikipedia articles needing clarification from October 2012

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikimedia Commons

Wikiquote

			Languages

العربية

Azərbaycanca

Basa Banyumasan

Български

Català

Čeština

Cymraeg

Dansk

Deutsch

Ελληνικά

Español

فارسی

Fiji Hindi

Français

Galego

한국어

Հայերեն

Bahasa Indonesia

Italiano

עברית

ಕನ್ನಡ

Latviešu

Lietuvių

Magyar

Македонски

മലയാളം

Bahasa Melayu

မြန်မာဘာသာ

Nederlands

日本語

Norsk

Polski

Português

Română

Русский

Simple English

Српски / srpski

Suomi

Svenska

தமிழ்

ไทย

Türkçe

Українська

Tiếng Việt

中文
				36 more

Edit links

 This page was last edited on 27 April 2018, at 03:32.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews