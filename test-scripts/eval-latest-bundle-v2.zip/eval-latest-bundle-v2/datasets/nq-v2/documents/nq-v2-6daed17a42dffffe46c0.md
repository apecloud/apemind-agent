# Criminal Minds

Criminal Minds - Wikipedia

Criminal Minds

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

For other uses, see Criminal Minds (disambiguation).

| Criminal Minds |

| Genre | Police procedural Action Thriller Crime drama |

| Created by | Jeff Davis |

| Starring | Mandy Patinkin Thomas Gibson Lola Glaudini Shemar Moore Matthew Gray Gubler A. J. Cook Kirsten Vangsness Paget Brewster Joe Mantegna Rachel Nichols Jeanne Tripplehorn Jennifer Love Hewitt Aisha Tyler Adam Rodriguez Damon Gupton Daniel Henney |

| Country of origin | United States |

| Original language(s) | English |

| No. of seasons | 13 |

| No. of episodes | 299 (list of episodes) |

| Production |

| Executive producer(s) | Mark Gordon (2005–) Jeff Davis (2005–07) Edward Allen Bernero (2005–11) Deborah Spera (2006–11) Chris Mundy (2009–10) Simon Mirren (2009–11) Erica Messer (2010–) Janine Sherman Barrois (2010–15) Breen Frazier (2015–) Harry Bring (2017–) Glenn Kershaw (2017–) |

| Running time | 42 minutes |

| Production company(s) | The Mark Gordon Company Touchstone Television (2005–2007) (seasons 1–2) ABC Studios (2007–present) (season 3–present) Paramount Network Television (2005–2006) (season 1) CBS Paramount Network Television (2006–2009) (seasons 2–4) CBS Television Studios (2009–present) (season 5–present) |

| External links |

| Website |

Criminal Minds is an American police procedural crime drama television series created by Jeff Davis and is the original show in the Criminal Minds franchise. It premiered on September 22, 2005, on the broadcast network CBS. The series is produced by The Mark Gordon Company, in association with CBS Television Studios and ABC Studios (a subsidiary of The Walt Disney Company). Criminal Minds is set primarily at the FBI's Behavioral Analysis Unit (BAU) based in Quantico, Virginia. In accordance with the show's plot, Criminal Minds differs from many procedural dramas by focusing on profiling the criminal, called the "unsub" or "unknown subject", rather than the crime itself.

The show has an ensemble cast that has had many cast member changes since its inception. Matthew Gray Gubler, A.J. Cook, Kirsten Vangsness, and Shemar Moore[1] are the only actors to have appeared in every season. Thomas Gibson appeared in every season through to Season 12. The series follows a group of FBI profilers who set about catching various criminals through behavioral profiling. The plot focuses on the team working cases and on the personal lives of the characters, depicting the hardened life and statutory requirements of a profiler. The show spawned several spin-offs: Criminal Minds: Suspect Behavior in 2011, Criminal Minds: Beyond Borders in 2016, and a South Korean adaptation in 2017. On April 7, 2017, CBS renewed the series for a thirteenth season.[2]

Contents
 [hide] 

1 Background

2 Characters

2.1 Main

2.2 Recurring

3 Episodes

4 Reception

4.1 Critical reception

4.2 American ratings

4.2.1 Broadcast

4.2.2 DVR

5 Syndication

6 Franchise

6.1 Criminal Minds: Suspect Behavior

6.2 Criminal Minds: Beyond Borders

6.3 크리미널 마인드 (Criminal Minds Korea)

6.4 Video game

7 Awards and nominations

8 References

9 External links

Background[edit]

When the series premiered in September 2005, it featured FBI agents Jason Gideon, Aaron Hotchner, Elle Greenaway, Derek Morgan, Spencer Reid, Jennifer "JJ" Jareau, and Penelope Garcia. For season 1, Garcia was not a main cast member but rather had a recurring role, although she appeared in most episodes. In 2006, at the start of season 2, Lola Glaudini announced her departure from the show, as she wanted to return home to New York City.[3] Paget Brewster replaced her in the role of Emily Prentiss.

At the start of season 3, Mandy Patinkin announced his departure from the show because he was deeply disturbed by the content of the series.[4] He left letters of apology for his fellow cast members, explaining his reasons and wishing them luck. Joe Mantegna replaced him as David Rossi, a best-selling author and FBI agent who comes out of retirement. During season three, A. J. Cook became pregnant with her first child. Her pregnancy was written into the show. Cook's son, Mekhai Andersen, has been written into a recurring role as Jennifer's son Henry. Cook's void during maternity leave was filled by Meta Golding, who played Jordan Todd, an FBI agent who works with the agency's Counter Terrorism Unit. In season 6, JJ is forced to accept a promotion at The Pentagon, causing her to leave the BAU.

Later that season, Emily is seemingly killed off. Although she survives, she does not appear for the rest of the season. Cook and Brewster were both replaced by Rachel Nichols as Ashley Seaver, an FBI cadet. CBS's decision to release Cook and Brewster from their contracts resulted in numerous fans writing angry letters to the studio and signing protest petitions.[5] CBS rehired Cook and Brewster as Jennifer Jareau and Emily Prentiss, respectively; Nichols was released.[6][7] In February 2012 Brewster announced her departure from the show after the seventh season.[8] She was replaced in the eighth season by Jeanne Tripplehorn, who played Alex Blake, a linguistics expert.[9] Later in season nine, Paget Brewster made a special guest appearance, reprising her role as Emily Prentiss in the 200th episode.

After two seasons, Tripplehorn was released from the show.[10][11] Former Ghost Whisperer star Jennifer Love Hewitt joined the cast as Kate Callahan, a former undercover FBI agent who joins the BAU.[12] During season 10, Jason Gideon was killed off-screen. Executive producer and showrunner Erica Messer said CBS and ABC Studios were fine with the decision because it was clear that Patinkin would not come back again, but the show would feature him in a flashback if he were ever to return in the future.[13] Following the conclusion of season 10, Hewitt and Cook announced that they will both be on hiatus from the show due to their pregnancies. Hewitt did not return for season 11 or any of the following ones,[14] while Cook returned after the first seven episodes of season 11.[15] Aisha Tyler, who plays Dr. Tara Lewis, joined the show at the start of season 11 in a recurring role, though she appeared in most episodes.

Later that season, Shemar Moore, who plays Derek Morgan, left the show after 11 seasons. He had thought to leave in the previous season when his contract ended but was persuaded to stay to give his character a proper sendoff.[16][17] Messer said the initial thought was for Moore to do six episodes, but when that didn't feel like enough, they settled on Moore doing the first 18 episodes of that season, and he departed in March 2016.[18] He is replaced in the twelfth season by former CSI: Miami star Adam Rodriguez, who plays Luke Alvez, a Fugitive Task Force Agent.[19] A week after Moore left, Paget Brewster made her second special guest appearance. In season 12, Brewster once again became a series regular.[20][21][22][23]

On August 10, 2016, it was announced that Aisha Tyler would be promoted to series regular for the 12th season.[24] The next day, it was reported that Thomas Gibson, who portrays Aaron Hotchner, had been suspended from and written off the show for at least one, most likely two, episodes in the 12th season owing to an on-set altercation with one of the producers.[25] The day after that, Gibson was fired from the program due to this incident.[26] On September 30, 2016, it was announced that Gibson's character would be replaced by Damon Gupton, who will play Special Agent Stephen Walker, a seasoned profiler from the Behavioral Analysis Program (the counterintelligence division of the FBI) who will bring his spy-hunting skills to the BAU.[27] On June 11, 2017, it was announced that Gupton had been fired from the show after one season. CBS said his departure was "part of a creative change on the show."[28]

On June 20, 2017, CBS announced that Daniel Henney, who was a series regular on Criminal Minds: Beyond Borders as Matt Simmons, would join the main show as a series regular for the 13th season.[29]

Characters[edit]

Main article: List of Criminal Minds characters

Cast members in 2011–12: (left to right) Gibson, Cook, Gubler, Mantegna, Brewster, and Moore. Absent: Kirsten Vangsness

Cast and crew at a Paley Centre discussion of the show

Main[edit]

Jason Gideon (Mandy Patinkin), senior supervisory special agent and former BAU unit chief (seasons 1–3)

Gideon is widely known as the BAU's best profiler. After a series of emotionally troubling cases and the murder of his friend Sarah by fugitive serial killer Frank Breitkopf (Keith Carradine), he begins to feel burned out. The last straw occurs when Unit Chief Aaron Hotchner is suspended for two weeks by the team's boss—an action for which Jason feels responsible. He retreats to his cabin and leaves a letter for Dr. Spencer Reid, who he knows will be the one to look for him. When Spencer arrives at the cabin, it is empty except for the letter and Jason's badge and firearm. Jason is last seen remarking to a Nevada diner waitress that he does not know where he is going or how he will know when he gets there, leaving the diner and driving off. In season 10, he is killed (off-screen) by a suspect he had tracked down from one of his first cases.

Aaron Hotchner (Thomas Gibson), Former BAU unit chief and senior supervisory special agent (seasons 1–12)

Hotch is a former prosecutor and was originally assigned to the FBI field office in Seattle. He is one of the most experienced agents in the BAU. He struggles to balance the demands of his job with his family life, but his wife, Haley Brooks (Meredith Monroe), divorces him in season 3. In the episode "100" (season 5), Haley is killed by fugitive serial killer George Foyet (C. Thomas Howell), also known as "The Boston Reaper," whom Aaron fights and beats to death. He also has a son named Jack (Cade Owens) and a brother named Sean. After Haley is murdered, he has custody of Jack, and Haley's sister, Jessica Brooks (Molly Baker), helps him take care of Jack. When SSA Jennifer Jareau leaves the BAU, Aaron and technical analyst Penelope Garcia take over her job as communications liaison. Aaron dated a woman named Beth Clemmons (Bellamy Young), who first appeared in the episode "The Bittersweet Science" (season 7), before the couple separated after Clemmons accepted a job in Hong Kong. Following an on-set altercation, Thomas Gibson was removed from the main cast after season 12, episode 2, at which point it's claimed that Gibson's character took a consulting job off screen. In a later episode, it's revealed that the consulting job was a ruse and that Jack was being stalked by a serial killer from a previous BAU case. Therefore, Aaron and Jack went into the witness protection program.

Elle Greenaway (Lola Glaudini), Supervisory Special Agent (seasons 1–2)

Greenaway is assigned to the FBI field office in Seattle and assigned to the BAU as an expert in sexual offense crimes. Elle suffers extreme emotional trauma after being shot by an unsub in the season 1 finale ("The Fisher King (Part 1)"). In the season 2 premiere ("The Fisher King (Part 2)"), Elle survives and returns to duty sooner than SSA Jason Gideon and Unit Chief Aaron Hotchner would like. Several episodes later, while alone on stakeout of a suspected serial rapist, she murders the suspect by shooting in cold blood and planting her gun on the unarmed victim. The local police deem it self-defense, but Jason and Aaron question her ability as a profiler after this. Elle resigns, turning in her badge and gun to Aaron, declaring that it is "not an admission of guilt."

Derek Morgan (Shemar Moore), supervisory special Agent (seasons 1–11; guest star seasons 12–13)

Morgan is a confident, assertive, and often hot-tempered character. He was raised by his mother, Fran, along with his two sisters, Sarah Morgan and Desiree Benita, after the death of his police officer father right in front of him, Derek was a troubled Chicago youth headed for juvenile delinquency. He was rescued and mentored by Carl Buford (Julius Tennon). Buford turned out to be a sexual predator who molested Derek and other young boys; he was eventually arrested for murder. After developing an interest in football, Derek attended Northwestern University on a scholarship. After a football injury left him unable to play, he joined the Chicago Police Department's bomb squad and later joined the FBI and the BAU. He has an emotionally intimate, but platonic, relationship with technical analyst Penelope Garcia; the two have a unique shorthand and banter. In the season 7 premiere ("It Takes a Village"), Derek shows utter hatred toward Ian Doyle (Timothy V. Murphy) for killing SSA Emily Prentiss, but when Emily returns alive, he has mixed feelings. In season 11, Derek is kidnapped and tortured by the father of Giuseppe Montolo, a hitman whom Derek put away and who later died while in custody. Derek escapes and when he learns his girlfriend Savannah is pregnant, he realizes that he doesn't want to put his family through something like this again. Derek leaves the BAU in the episode "A Beautiful Disaster" to care for his now-wife and newborn son.

Spencer Reid, Ph.D., (Matthew Gray Gubler), supervisory special agent (seasons 1–present)

Reid is a genius who graduated from Las Vegas High School at age 12 and holds Ph.D.s in mathematics, chemistry, and engineering as well as bachelor of arts degrees in psychology and sociology and, as of season 4, is working on a B.A. in philosophy. It has been revealed that he has an IQ of 187, can read a dizzying 20,000 words per minute, and has an eidetic memory. Most of the members on the team are intimidated by his profound knowledge. He is habitually introduced as "Dr. Spencer Reid" in contrast to the other agents, who are introduced as "supervisory special agent." The purpose of this, as explained by Unit Chief Aaron Hotchner in the pilot episode ("Extreme Aggressor"), is to create a respectable first impression of Spencer, deflecting judgments about his age. His mother, Diana Reid (Jane Lynch), suffers from schizophrenia and is currently committed to a mental institution. In season 6 Reid starts suffering from cluster headaches and when doctors can't diagnose why, Reid thinks he might be in the early stages of schizophrenia himself. Reid takes SSA Emily Prentiss' death very hard and when it was revealed the death was faked was distrustful of both Prentiss and SSA Jennifer Jareau (who helped in the cover-up). During season 8, Reid becomes involved with a woman who was being stalked. In the episode "Zugzwang," her stalker ultimately kidnaps her and kills her, devastating Reid. In season 11 he is deeply affected by Derek Morgan's decision to leave the BAU but understands and supports his reasons. Initially Reid had a crush on JJ, even going as far as taking her on a date to a football game. As the series progresses, their relationship becomes more of the brother–sister kind. Morgan and Reid maintained a brotherly relationship and Morgan refers to Reid as his "little brother" prior to his departure in season 11. Spencer is also the godfather of Jennifer's son, Henry, and Derek's son, Hank.

Jennifer "JJ" Jareau (A. J. Cook), former BAU communications liaison and current supervisory special agent (seasons 1–5, 7–present; recurring season 6)

JJ served as the communications liaison on the team to local police agencies in seasons 1–5. She dates and marries William LaMontagne (Josh Stewart), a New Orleans Police Department detective. They have two sons, Henry LaMontagne (Mekhai Andersen) and Michael LaMontagne (Phoenix Sky Andersen). Both boys are played by A.J. Cook's real-life sons. In the episode "JJ" (season 6), Jennifer is forced to accept a promotion at the Pentagon, causing her departure from the team, although Unit Chief Aaron Hotchner expresses his hope that she will return to the BAU in the future. Jennifer returns in the episode "Lauren" (season 6) to assist the team in finding SSA Emily Prentiss (Paget Brewster). Jennifer returns as a series regular in the season 7 premiere as a legitimate profiler and admits to helping fake Prentiss's death, much to dismay of her colleagues. In the 200th episode, JJ is kidnapped because of a secret mission she performed while at the Pentagon. At the end of season 10, JJ reveals she is pregnant with her second child and consults over the phone for the few episodes of season 11 before rejoining the team in the field in the episode "Target Rich."

Penelope Garcia (Kirsten Vangsness), BAU technical analyst and BAU communications liaison (seasons 2–present; recurring season 1)

Garcia joined the BAU after bringing attention to herself by illegally accessing some of their equipment; she is offered a job in lieu of a jail sentence. She submitted her resume to Hotch on pink stationery. She usually supports the team from her computer lab at Quantico but occasionally joins them on location when her skills can be used in the field. She is a leader in a support group for those who have lost someone in their lives. Her parents were killed by a drunk driver when they were out looking for her when she was a teen and had missed her curfew. She enjoys a flirtatious relationship with SSA Derek Morgan, often engaging in comical banter of a sexually suggestive nature when he calls in for information. He calls her "Baby Girl." She was once shot and almost killed by Jason Clark Battle, who lured her on a date in the episode "Lucky" (season 3). When SSA Jennifer Jareau leaves the BAU, Penelope and Unit Chief Aaron Hotchner take over her job as communications liaison. SSA Sam Cooper (Criminal Minds: Suspect Behavior) often calls when his team needs her computer skills. Penelope is the godmother of Jennifer's son, Henry, and the godmother of Morgan's son.

Emily Prentiss (Paget Brewster), supervisory special agent and BAU Unit Chief[30] (seasons 2–7, 12–present; guest seasons 9, 11)

Prentiss is the daughter of Ambassador Elizabeth Prentiss (Kate Jackson). After SSA Elle Greenaway leaves the BAU, Assistant Director Strauss approves Emily to join the BAU. The plan was for Emily to report any problems within the BAU, but Emily remained loyal to the team and refused to report any problems, going so far as threatening resignation. Emily is also fluent in several languages, such as Spanish, French, Greek, and Arabic, has a working knowledge in Italian, and was fluent in Russian at one point but has lost comprehension. She is apparently killed while being held hostage by Ian Doyle in the episode "Lauren" (season 6), but in the last scene of the episode, it is revealed that she survived her encounter with Ian and is seen with SSA Jennifer Jareau in Paris passing her passports and bank accounts for protection. In the season 7 premiere ("It Takes a Village"), she returns alive and well, much to the team's surprise. In the season 7 finale ("Run"), Emily decides to leave the BAU after accepting a position running and returning to the Interpol office in London. She returns for the 200th episode to help rescue a kidnapped SSA Jennifer Jareau and again in the episode "Tribute" (season 11), where she enlists the help of the BAU in catching a serial killer who had originally killed in Europe before killing in the United States. Paget Brewster was confirmed to return for a several episode arc in season 12. Following the dismissal of Thomas Gibson, Brewster was promoted to a series regular again starting from season 12, episode 3; later Prentiss is promoted to Hotch's position of unit chief.

David Rossi (Joe Mantegna), senior supervisory special agent (seasons 3–present)

Rossi is a highly experienced profiler who once worked the BAU in its origins, then took early retirement in 1997 to write books and go on lecture tours about criminal analysis, until volunteering to return shortly after SSA Jason Gideon's departure in 2007. He has been married three times and is quite wealthy because of his successful writing career. In the episode "From Childhood's Hour" (season 7), David reconnects with his first wife, Carolyn Baker, who has shocking news for him. It is revealed that she came to him because she was diagnosed with ALS (Lou Gehrig's disease) and wants David to assist in her suicide. In the next episode ("Epilogue"), Carolyn dies after taking a drug overdose. It is also revealed in this episode that David had a son who died at birth. In the season 8 episode "The Fallen," it is revealed that David was a Marine in Vietnam. The season 7 finale ("Hit") reveals SSA David Rossi may be having a secret relationship with Section Chief Erin Strauss; this was discovered when technical analyst Penelope Garcia and SSA Dr. Spencer Reid spot them both leaving a hotel. In the last season 8 episode ("The Replicator") we see their relationship has been known to the entire team. The episode is an emotional one for SSA David Rossi since Unit Chief Erin Strauss is murdered by The Replicator. She was taken from her hotel room, where he had planned to meet her that night, drugged and put on the streets of New York disoriented for Unit Chief Aaron Hotchner to find her. The episode's last scene is SSA David Rossi eulogizing her to the team after her funeral, at a gathering at his home. In season 10 we learn that David has a daughter by his second wife. Since then, he is shown to have a strong relationship with his daughter, son-in-law, and grandson, even approving of her husband's Italian heritage. In season 11 Rossi reunites with his second wife, and they give their relationship a second chance.

Ashley Seaver (Rachel Nichols), FBI cadet and special agent (season 6)

Seaver replaces SSA Jennifer Jareau after she is forced to accept a promotion at the Pentagon. She was chosen for her unique background; her father, Charles Beauchamp, was a horrific serial killer known as the "Redmond Ripper," who murdered dozens of women before being caught by the BAU, incidentally. At first, Unit Chief Aaron Hotchner was going to make her a special one-time consultant to the BAU, but SSA David Rossi allowed her to finish her remedial training with the team, under the supervision of SSA Emily Prentiss. In the episode "... With Friends Like These" (season 6), she graduated from the Academy and had been added to the team as a "probationary agent." In the season 7 premiere ("It Takes a Village"), Jennifer reveals to Emily that Ashley transferred to the domestic trafficking task force, which is led by Andi Swann.

Alex Blake, Ph.D., (Jeanne Tripplehorn), FBI linguistics expert, supervisory special agent, and professor at Georgetown University (seasons 8–9)

Blake once worked for the BAU during the 2001 anthrax attacks but retired after a conflict with Chief Erin Strauss and rejoins the BAU after SSA Emily Prentiss transfers to the Interpol office in London. Alex first appears in the season 8 premiere ("The Silencer"). She makes a personal connection with Spencer Reid after he reveals to her that he has begun a romantic relationship with a woman whom he has never met. In the season 9 finale, after a difficult case in Texas in which the team is targeted by a group of corrupt sheriff deputies and Reid is shot, she escorts Reid to his apartment, explaining that the experience brought back memories of her son's death and that Reid reminds her of him. She leaves behind her credentials, which Reid finds in his bag before seeing Blake leave in a taxi, saddened but understanding.

Kate Callahan (Jennifer Love Hewitt), Former FBI undercover agent and supervisory special agent (season 10)

Callahan, as mentioned in the season 10 premiere, previously worked under Andi Swann's team, which is also Ashley Seaver's team since she left the BAU. She is a "seasoned undercover agent whose stellar work at the FBI has landed her a coveted position with the Behavioral Analysis Unit." She and her husband, Chris, have been the guardians of Kate's teenage niece, Meg, since Meg was a baby following her parents' deaths in the September 11, 2001, attacks. Kate and Chris discover they are expecting a baby in the middle of season 10, coinciding with the actress's real-life pregnancy. At the end of season 10 she decides to take a year off and raise her baby.[31] As of season 12, she has not returned, but producer Erica Messer has stated the door was open should Hewitt choose to return to the show.

Dr. Tara Lewis (Aisha Tyler), forensic psychologist and supervisory special agent (seasons 12–present; recurring season 11)

Lewis is a psychologist with an eye on forensic psychology and its application toward the criminal-justice system. Her dream was to study psychopaths up close and personal—and her psychology background, combined with her experience in the FBI, brought her face to face with monsters. Her job was to stare them down and interview them, to determine if they were fit to stand trial. In the process, she made herself find the humanity inside these broken men (and, sometimes, women) in order to learn if there was a conscience behind their brutal crimes. Lewis replaced both JJ (A.J. Cook) and Kate (Jennifer Love Hewitt) while they were on maternity leave in the 11th season.

Luke Alvez (Adam Rodriguez), fugitive task force agent and supervisory special agent (seasons 12–present)

Alvez is a member of the FBI fugitive task force that partners with the BAU to catch the serial killers that escaped in the season 11 finale.[19] In the season 12 premiere, he works with the BAU to catch the "Crimson King," one of the escapees that attacked Alvez's old partner. The team discovers the real killer is "Mr. Scratch," who taunts the team by turning over the real "Crimson King," who was tortured to the point he no longer remembers who he was. After that, Alvez decides to join the BAU full time. Alvez has a dog, a Belgian Tervuren named Roxy (whom Garcia thought at first was his human girlfriend) and served in Iraq as an Army Ranger prior to joining the FBI.

Stephen Walker (Damon Gupton), supervisory special agent (season 12)[32]

Walker is a supervisory special agent with the BAU. Walker was a member of the Behavioral Analysis Program. He was contacted by Emily Prentiss (Paget Brewster) about joining the BAU to assist in the manhunt for Peter Lewis, a k a "Mr. Scratch." Walker is an experienced profiler with about 20 years under his belt and a member of the FBI's Behavioral Analysis Program before his transfer to the BAU. He is married to a woman named Monica and has two children with her, Maya and Eli. He met Emily Prentiss, then the chief of Interpol's London office, during his line of work. He was also mentored by David Rossi (Joe Mantegna). Stephen's first case concerned a terrorist cell in Belgium, and three agents were sent undercover to infiltrate it. However, Stephen's profile was wrong, and this resulted in the deaths of the undercover agents. He eventually moved on from the trauma and improved as he went along in his career. He and other BAP agents, including his longtime friend Sam Bower, were sent undercover to investigate corruption in the Russian government. Walker's skills include being fluent in Russian and playing the trombone. In the season 13 premiere, it is revealed he had died in the car crash after Mr. Scratch laid spike strips down in the end of season 12.

Matt Simmons (Daniel Henney) (season 13; guest seasons 10, 12) is a former member of the International Response Team.[29]

Simmons is a special operations agent and formerly worked with the IRT. Simmons as wife, Kristy, (Kelly Frye) and has a total of four children, including two boys (Jake and David) and twin daughters, all of them under the age of 3. He was a former member of a special ops unit, and his experience with the unit allowed him to hone his profiling skills.

Recurring[edit]

Erin Strauss (portrayed by Jayne Atkinson; seasons 2–3, 5–9; 23 episodes), an assistant director and the BAU Unit Chief's direct superior. While her FBI experience was primarily in administration, SSA Derek Morgan remarked on her masterly marksmanship, after observing her at a firing range. In early episodes, Strauss appeared only concerned with herself and appearances within the Bureau, going so far as to force SSA Jennifer Jareau to accept a promotion to the Pentagon in the episode "JJ" (season 6). Further character development revealed her alcohol abuse. After being confronted by Morgan and Hotchner, Strauss accepts help and achieves sobriety. In the season 8 finale, the Replicator breaks into Strauss's hotel room in New York, drugs her, and forces her—at gunpoint—to drink alcohol from her room's minibar. Hotchner finds her on a bench near the hotel, where Strauss dies in his arms. Her death is avenged when Rossi traps the Replicator in an exploding house. Fittingly, Strauss's sobriety helps defeat the Replicator as Rossi uses her sobriety chip to escape the Replicator's trap and taunts him with it. After attending her funeral, the members of the BAU gather in a still-emotional Rossi's backyard, reminisce, and toast her memory. Showrunner Erica Messer chose to kill Strauss off because she felt that the character had come full circle since she was first introduced.[33]

Haley Hotchner (portrayed by Meredith Monroe; seasons 1–3, 5, 9; 14 episodes) is Agent Aaron Hotchner's wife and the mother of his only son, Jack Hotchner, born in late 2005. The couple's marriage was troubled, as clues were revealed in season 3 that she may have been having an affair and walked out on him. She later appeared with divorce papers, and he accepted reluctantly so as not to cause any trouble for his son with the divorce. In the episode "100" (season 5), Haley and Jack were captured by a killer known as "The Reaper"; though Jack was saved, Haley was shot and died before Aaron could save her. Aaron later beat The Reaper to death. In the episode "Route 66," Hotch collapses from internal bleeding and dreams about Haley. She tells him that he should stop blaming himself for her death and to make sure Jack knows that he can talk about his mother's death. Haley leaves Hotch by telling him that he and Beth have a good relationship and he shouldn't mess it up by not telling her how he feels.

Jessica Brooks (portrayed by Molly Baker; seasons 1, 3, 5, 9–11), is Agent Aaron Hotchner's sister-in-law, Jack's aunt, and Haley's sister.

Jordan Todd (portrayed by Meta Golding; season 4; 8 episodes) is SSA Jennifer Jareau's handpicked replacement to serve as the BAU's media director during Jennifer's maternity leave, from late 2008 through early 2009. Jordan had formerly served in the FBI counterterrorism division, but follows Jennifer for only day of shadowing before Jennifer goes into labor. Jordan seemed to get along well with most of the team, even flirting platonically with SSA Derek Morgan. She is especially close with SSA David Rossi, who is seen to counsel her while they are on cases. However, Jordan has clashed several times with Unit Chief Aaron Hotchner. She eventually leaves when she decides she can't handle the stress that comes with her job.

Diana Reid (portrayed by Jane Lynch; seasons 1–2, 4, 12; 8 episodes) is the mother of BAU team member Dr. Spencer Reid. Like her son, she has a high IQ. She was once a university professor of literature, but suffers from schizophrenia and is hospitalized in a Las Vegas sanitarium, where Spencer committed her when he was 18. Her husband, William Reid, left prior to her diagnosis, because of his inability to cope with her illness, and he could not deal with protecting her after she witnessed a murder. She is functional when on her medication, but frequently lapses into regression to her university career. Diana spent much time reading aloud to Spencer while he was growing up, and he continues to write her a letter every day. She is proud of her son but disapproves of the FBI, as it is a government-run organization; she refers to his colleagues as "fascists." She seems to be showing signs of improvement in later episodes, when Reid states that she went on a supervised field trip to the Grand Canyon without feeling the need to notify Reid. However, she did not forget him, as Reid later receives a postcard and a gift from her.

William LaMontagne Jr. (portrayed by Josh Stewart; season 2–5, 7–9, 11–present) is SSA Jennifer Jareau's husband and the father of Jennifer's son, Henry LaMontagne. Will and Jennifer met while she was working a case in his hometown. As of early season 4, Will had moved to Virginia and is a stay-at-home dad for Henry until he became a detective for the Metropolitan Police Department (Washington D.C.) as shown in the season 7 finale ("Run"). It is also stated that the couple had made a deal that in a life-threatening situation, they would do everything so that one of them could live to look after Henry. Jennifer accepted his marriage proposal and they were married officially; however, when their son was born, they exchanged rings with insets of Henry's birthstone, citrine. He is seen briefly in the 100th episode getting medicine for Henry with Jennifer, as well as the episode "The Slave of Duty" (season 5), accompanying Jennifer and the team at Haley Hotchner's funeral. In the season 7 finale, Will works alongside JJ to stop the bank robbers and is eventually taken hostage. Afterward, they agree to get married and unknowingly attend a surprise wedding ceremony thrown by Rossi and Will.

Kevin Lynch (portrayed by Nicholas Brendon; season 3–10) first appears in the episode "Penelope" (season 3), in which he is required to search Penelope Garcia's computer to learn who shot her. Kevin sends the team live video alerting that the unsub (unknown subject) is in the BAU headquarters. He is intensely impressed by Penelope's computer skills, and the feeling is mutual. At the end of the episode, Penelope is introduced to Kevin, and the two become romantically involved. In the episode "I Love You, Tommy Brown" (season 7), Kevin proposes to Penelope, but she turns him down, saying that "things are going too fast," and ultimately the couple break up.

Mateo Cruz (portrayed by Esai Morales; season 9–10) takes over from the late Erin Strauss as the new BAU section chief in season 9. He has a past working relationship with JJ. It was revealed in "200" that the two had worked on a task force together in the Middle East. He was the only person to know of her pregnancy and miscarriage during her time on the task force. In the same episode, they are both kidnapped by Tivon Askari (Faran Tahir), who was a traitor within the task force. They are both physically and mentally tortured into giving the access codes given to them during the mission. He is shocked to discover that Michael Hastings (Tahmoh Penikett), one of the men with whom they had worked on the task force, was the mastermind behind the plan and threatened to rape JJ to give him the access codes. He gives in and is later stabbed by Askari, who is quickly killed by Hotch. Cruz is taken to the hospital following the incident and is believed to be alive.[34] Several episodes later, he reappears in the season 9 finale, "Angels" and "Demons," when he asks the team to investigate a case brought to him by his friend Peter Coleman, the sheriff of Briscoe County, Texas. They first arrive to investigate a series of murders involving prostitutes, but as they investigate, the team soon finds that they are caught in a ring of corrupt deputies—ironically the only officer not involved being Sheriff Coleman—and find their lives in danger. After a fatal shootout with the corrupt, drug-peddling Preacher Mills (Brett Cullen), Sheriff Coleman is killed, Morgan is wounded, and Reid is critically wounded and hospitalized as a result. Distraught by this turn of events, Cruz travels to Texas with Garcia to help the team investigate and apprehend the ring leader, Deputy Owen McGregor (Michael Trucco). He is not seen again until late in season 10 (episode 19, "Beyond Borders") when he needs the BAU to help the FBI's international team, led by Jack Garrett (Gary Sinise), to catch an unsub who has kidnapped a family while on vacation in Barbados. The case is especially critical because this unsub has eluded both the domestic and international BAU teams by killing a family in Aruba, then in Florida one year later. This episode was the backdoor pilot for the upcoming spinoff, titled Criminal Minds: Beyond Borders.[35][36]

Dr. Savannah Hayes (portrayed by Rochelle Aytes; season 9–11; 10 episodes) Savannah Morgan (née Hayes) is Derek Morgan's wife. She works as a doctor at Bethesda General Hospital. Savannah first appeared in Season 9’s “The Return,” and it is presumed Morgan and Savannah started dating prior to Season 9, and first met after she approached him when he was depressed over a case that ended badly. Before they started dating they used to be neighbors. She was introduced to the show because Shemar Moore, the actor who portrays Morgan, had requested that his character should get a romantic partner.

Joy Struthers (portrayed by Amber Stevens; season 10–11) is Rossi's daughter from his short-lived second marriage to French diplomat Hayden Montgomery. When they divorced, Hayden didn't tell him she was pregnant, and Joy thought her father was her mother's second husband, who finally told her the truth before dying from cancer. In the episode "Fate" (10x09), Joy seeks Rossi out and they're getting to know each other. Joy is a reporter and true-crime writer and is married. She has a 2-year-old son called Kai.

Episodes[edit]

Main article: List of Criminal Minds episodes

As of April 18, 2018,[update] 299 episodes of Criminal Minds have aired, concluding the thirteenth season.

| Season | Episodes | Originally aired | Nielsen ratings[37][38] |

| First aired | Last aired | Rank | Rating |

| 1 | 22 | September 22, 2005 (2005-09-22) | May 10, 2006 (2006-05-10) | 27 | 8.2 |

| 2 | 23 | September 20, 2006 (2006-09-20) | May 15, 2007 (2007-05-15) | 18 | 8.8 |

| 3 | 20 | September 26, 2007 (2007-09-26) | May 21, 2008 (2008-05-21) | 18 | 8.2 |

| 4 | 26 | September 24, 2008 (2008-09-24) | May 20, 2009 (2009-05-20) | 11 | 9.4 |

| 5 | 23 | September 23, 2009 (2009-09-23) | May 26, 2010 (2010-05-26) | 14 | 8.5 |

| 6 | 24 | September 22, 2010 (2010-09-22) | May 18, 2011 (2011-05-18) | 10 | 8.7 |

| 7 | 24 | September 21, 2011 (2011-09-21) | May 16, 2012 (2012-05-16) | 13 | 8.6 |

| 8 | 24 | September 26, 2012 (2012-09-26) | May 22, 2013 (2013-05-22) | 16 | 8.0 |

| 9 | 24 | September 25, 2013 (2013-09-25) | May 14, 2014 (2014-05-14) | 13 | 8.2 |

| 10 | 23 | October 1, 2014 (2014-10-01) | May 6, 2015 (2015-05-06) | 8 | 9.0 |

| 11 | 22 | September 30, 2015 (2015-09-30) | May 4, 2016 (2016-05-04) | 13 | 7.8 |

| 12 | 22 | September 28, 2016 (2016-09-28) | May 10, 2017 (2017-05-10) | 17 | 6.9 |

| 13 | 22 | September 27, 2017 (2017-09-27) | April 18, 2018 (2018-04-18) | TBA | TBA |

Reception[edit]
Critical reception[edit]

| This section needs expansion with: inclusion of more reviews and summaries, for all seasons. You can help by adding to it. (April 2016) |

The first season of Criminal Minds received mixed reviews from critics.[39] It has a Metacritic score of 42 based on 21 reviews, indicating "mixed or average reviews."[39]

Dorothy Rabinowitz said, in her review for The Wall Street Journal, "From the evidence of the first few episodes, Criminal Minds may be a hit, and deservedly" and gave particular praise to Gubler and Patinkin's performance.[40] Ned Martel in The New York Times was less positive, saying, "The problem with "Criminal Minds" is its many confusing maladies, applied to too many characters." The reviewer felt that "as a result, the cast seems like a spilled trunk of broken toys, with which the audience—and perhaps the creators—may quickly become bored."[41] The Chicago Tribune reviewer, Sid Smith, felt that the show "may well be worth a look," though he too criticized the "confusing plots and characters."[42] Writing in PopMatters, Marco Lanzagorta criticized the show after its premiere, saying it "confuses critical thinking with supernatural abilities" and that its characters conform to stereotypes.[43] In the Los Angeles Times, Mary McNamara gave a similar review, and praised Patinkin and Gubler's performances.[44]

American ratings[edit]

In 2016 a New York Times study of the 50 TV shows with the most Facebook Likes found that "like several of the other police procedurals," Criminal Minds "is more popular in rural areas, particularly in the southeastern half of the country. It hits peak popularity in Alabama and rural Tennessee and is least popular in Santa Barbara, Calif."[45]

Broadcast[edit]

| Season | Timeslot (ET) | Episodes | First aired | Last aired | TV season | Rank | Avg. viewers (millions) |

| Date | Viewers (millions) | Date | Viewers (millions) |

| 1 | Wednesday 9:00 pm | 22 | September 22, 2005 (2005-09-22) | 19.57[46] | May 10, 2006 (2006-05-10) | 12.67[47] | 2005–06 | 28 | 12.63[48] |

| 2 | 23 | September 20, 2006 (2006-09-20) | 15.65[49] | May 16, 2007 (2007-05-16) | 13.21[50] | 2006–07 | 24 | 14.05[51] |

| 3 | 20 | September 26, 2007 (2007-09-26) | 12.66[52] | May 21, 2008 (2008-05-21) | 13.15[53] | 2007–08 | 24 | 12.78[54] |

| 4 | 26 | September 24, 2008 (2008-09-24) | 17.01[55] | May 20, 2009 (2009-05-20) | 13.99[56] | 2008–09 | 11 | 14.95[57] |

| 5 | 23 | September 23, 2009 (2009-09-23) | 15.85[58] | May 26, 2010 (2010-05-26) | 12.97[59] | 2009–10 | 16 | 13.70[60] |

| 6 | 24 | September 22, 2010 (2010-09-22) | 14.13[61] | May 18, 2011 (2011-05-18) | 12.84[62] | 2010–11 | 10 | 14.11[63] |

| 7 | 24 | September 21, 2011 (2011-09-21) | 14.14[64] | May 16, 2012 (2012-05-16) | 13.68[65] | 2011–12 | 15 | 13.20[66] |

| 8 | 24 | September 26, 2012 (2012-09-26) | 11.73[67] | May 22, 2013 (2013-05-22) | 11.01[68] | 2012–13 | 20 | 12.15[69] |

| 9 | 24 | September 25, 2013 (2013-09-25) | 11.27[70] | May 14, 2014 (2014-05-14) | 12.03[71] | 2013–14 | 12 | 12.66[72] |

| 10 | 23 | October 1, 2014 (2014-10-01) | 11.74[73] | May 6, 2015 (2015-05-06) | 9.61[74] | 2014–15 | 11 | 14.11[75] |

| 11 | 22 | September 30, 2015 (2015-09-30) | 10.08[76] | May 4, 2016 (2016-05-04) | 8.84[77] | 2015–16 | 16 | 12.20[78] |

| 12 | 22 | September 28, 2016 (2016-09-28) | 8.92[79] | May 10, 2017 (2017-05-10) | 8.12[80] | 2016–17 | 20 | 10.86[81] |

| 13 | Wednesday 10:00 pm | 22 | September 27, 2017 (2017-09-27) | 7.00[82] | April 18, 2018 (2018-04-18) | 5.65[83] | 2017–18 | TBD | TBD |

DVR[edit]

The show ranked number nine in DVR playback (2.35 million viewers), according to Nielsen prime DVR lift data from September 22& to November 23, 2008.[84]

For the week of October 10, 2010, Criminal Minds ranked sixth in DVR playback (2.40 million viewers), and seventh in the demo playback (1.0 demo) according to Nielsen prime DVR lift data.[85]

Syndication[edit]

The series is in syndication on A&E Network and Ion Television[86] We TV and Sundance TV.

Early seasons of Criminal Minds have begun airing on Rewind Networks's HITS TV channel in South East Asia, Hong Kong and Taiwan.[87]

Franchise[edit]

Criminal Minds has produced two spin-offs: Criminal Minds: Suspect Behavior and Criminal Minds: Beyond Borders, as well as a video game.

Criminal Minds: Suspect Behavior[edit]

The season five episode "The Fight" introduced a second BAU team and launched a new series called Criminal Minds: Suspect Behavior. The spin-off series debuted February 16, 2011, on CBS[88] but was canceled after a short 13-episode season owing to low ratings.[89] On September 6, 2011, CBS DVD released The Complete Series on a four-disc set. It was packaged as "The DVD Edition".

The cast features Forest Whitaker as the lead role of Sam Cooper; including Janeane Garofalo, Michael Kelly, Beau Garrett, Matt Ryan, Richard Schiff, and Kirsten Vangsness, who reprises her role as Penelope Garcia from the original series.

Criminal Minds: Beyond Borders[edit]

A proposed new series in the Criminal Minds franchise to be named Criminal Minds: Beyond Borders was announced in January 2015. Former CSI: NY star Gary Sinise (who is also a producer on the show) and Anna Gunn were cast in the lead roles of Jack Garrett and Lily Lambert, though the latter departed after the backdoor pilot.[90] Tyler James Williams has been cast as Russ "Monty" Montgomery and Daniel Henney as Matt Simmons, with Alana de la Garza as Clara Seger and Annie Funke as Mae Jarvis further being cast as series regulars.[91]

The series follows the FBI agents of the International Response Team (IRT) helping American citizens who find themselves in trouble abroad.[35][92] CBS aired a backdoor pilot on April 8, 2015 in the Criminal Minds slot, with a crossover episode titled "Beyond Borders".[35][36] The second spin-off series debuted March 16, 2016, on CBS.[93] On May 16, 2016, CBS renewed the series for a second season.[94] On May 14, 2017, CBS canceled the series after two seasons due to low ratings.[95]

크리미널 마인드 (Criminal Minds Korea)[edit]

In 2017 tvN launched their own Korean version of Criminal Minds. The episodes are based on the original American version after its third season. On the cast is Lee Joon-gi as Kim Hyun-joon (Derek Morgan), Moon Chae Won as Ha Sun-woo (Emily Prentiss), Son Hyun-joo as Kang Ki-hyung (Aaron Hotchner), Yoo Sun as Nana Hwang (Penelope Garcia), Lee Sun-bin as Yoo Min-young (Jennifer Jareau), and Go Yoon as Lee Han (Spencer Reid). The episodes are 1 hour long.[citation needed]

Video game[edit]

CBS announced in October 2009 that Legacy Interactive would develop a video game based on the show. The game would require players to examine crime scenes for clues to help solve murder mysteries. The interactive puzzle game was released in 2012, but the show's cast was not involved with the project so it did not feature any of their voices.[96][97][98]

Awards and nominations[edit]

Awards and nominations for Criminal Minds

| Year | Award | Category | Nominee(s) | Result |

| 2006 | People's Choice Awards | Favorite New Television Drama | Criminal Minds | Nominated |

| Hollywood Post Alliance | Outstanding Editing – Television | Jimmy Giritlian | Nominated |

| ASCAP Film and Television Music Awards | Top TV Series | Marc Fantini, Steffan Fantini, Scott Gordon | Won |

| 2007 | Top TV Series | Marc Fantini, Steffan Fantini, Scott Gordon | Won |

| 2008 | Motion Picture Sound Editors | Best Sound Editing – Music for Short Form Television | Lisa A. Arpino For episode "True Night" | Nominated |

| BMI Film & TV Awards | BMI TV Music Award | Mark Mancina | Won |

| Primetime Emmy Awards | Outstanding Stunt Coordination | Tom Elliott For episode "Tabula Rasa" | Nominated |

| 2009 | BMI Film & TV Awards | BMI TV Music Award | Mark Mancina | Won |

| Primetime Emmy Awards | Outstanding Stunt Coordination | Tom Elliott For episode "Normal" | Nominated |

| 2010 | Hollywood Music In Media Awards (HMMA) | Best Score in a TV Show | Marc Fantini, Steffan Fantini, Scott Gordon | Won |

| ASCAP Film and Television Music Awards | Top Television Series | Steffan Fantini | Won |

| 2011 | People's Choice Awards | Favorite TV Crime Drama | Criminal Minds | Nominated |

| Image Awards | Outstanding Writing in a Dramatic Series | Janine Sherman Barrois For episode "Remembrance of Things Past" | Nominated |

| ASCAP Film and Television Music Awards | Top Television Series | Steffan Fantini | Won |

| 2012 | People's Choice Awards | Favorite TV Crime Drama | Criminal Minds | Nominated |

| Image Awards | Outstanding Writing in a Dramatic Series | Janine Sherman Barrois For episode "The Bittersweet Science" | Nominated |

| ASCAP Film and Television Music Awards | Top Television Series | Steffan Fantini | Won |

| Primetime Emmy Awards | Outstanding Stunt Coordination | Tom Elliott For episode "The Bittersweet Science" | Nominated |

| 2013 | People's Choice Awards | Favorite TV Crime Drama | Criminal Minds | Nominated |

| MovieGuide Awards | Faith and Freedom Award | Criminal Minds For episode "The Fallen" | Nominated |

| Image Awards | Outstanding Writing in a Dramatic Series | Janine Sherman Barrois For episode "The Pact" | Nominated |

| BMI Film & TV Awards | BMI TV Music Award | Mark Mancina | Won |

| ASCAP Film and Television Music Awards | Top Television Series | Marc Fantini, Steffan Fantini, Scott Gordon | Won |

| 2014 | People's Choice Awards | Favorite TV Crime Drama | Criminal Minds | Nominated |

| Image Awards | Outstanding Writing in a Dramatic Series | Janine Sherman Barrois For episode "Strange Fruit" | Won |

| Outstanding Actor in a Drama Series | Shemar Moore | Nominated |

| Outstanding Directing in a Drama Series | Rob Hardy For episode "Carbon Copy" | Nominated |

| 2015 | People's Choice Awards | Favorite TV Crime Drama | Criminal Minds | Nominated |

| Favorite TV Crime Drama Actor | Shemar Moore | Nominated |

| Prism Awards | Drama Episode – Mental Health | Criminal Minds For episode "The Edge of Winter" | Nominated |

| Monte-Carlo TV Festival | International TV Audience Award – Best Drama TV Series | Touchstone Television, The Mark Gordon Company | Nominated |

| Image Awards | Outstanding Actor in a Drama Series | Shemar Moore | Won |

| Outstanding Directing in a Drama Series | Hanelle Culpepper For episode "The Edge of Winter" | Nominated |

| 2016 | People's Choice Awards | Favorite TV Crime Drama | Criminal Minds | Nominated |

| Favorite TV Crime Drama Actor | Shemar Moore | Nominated |

| 2017 | People's Choice Awards | Favorite TV Crime Drama | Criminal Minds | Won |

References[edit]

Jump up ^ Petski, Denise (March 16, 2017). "'Criminal Minds': Shemar Moore To Reprise Derek Morgan Role In Season 12 Finale". Deadline.com. Retrieved March 16, 2017. 

Jump up ^ Andreeva, Nellie (April 7, 2017). "'Criminal Minds' Renewed For Season 13 By CBS". Deadline Hollywood. Retrieved April 7, 2017. 

Jump up ^ Criminal Minds Fan. "Criminal Minds Fanatic's Favorite Things". Criminal Minds Fanatic. Mountain View, California: Blogger. Retrieved November 8, 2015. 

Jump up ^ Witchel, Alex. "Mandy Patinkin: 'I Behaved Abominably'". The New York Times. New York City: The New York Times Company. Retrieved 2013-08-21. 

Jump up ^ Nellie Andreeva. "Fans And Co-Stars Back 'Minds' Actresses". Deadline.com. United States: Penske Media Corporation. Retrieved October 22, 2016. 

Jump up ^ Nellie Andreeva. "JJ Is Back! AJ Cook Inks 2-Year Deal To Return To 'Criminal Minds'". Deadline.com. United States: Penske Media Corporation. Retrieved November 8, 2015. 

Jump up ^ Andreeva, Nellie. "It's Official: Criminal Minds Welcomes Back Paget Brewster, Bids Farewell to Rachel Nichols". TVLine. United States: Penske Media Corporation. Retrieved November 8, 2015. 

Jump up ^ Andreeva, Nellie (February 15, 2012). "Paget Brewster To Leave 'Criminal Minds'". Deadline.com. United States: Penske Media Corporation. Retrieved February 15, 2012. 

Jump up ^ "Big Love Jeanne Tripplehorn becomes Criminal Minds series regular". Digital Spy. New York City: Hearst Magazines UK. Retrieved June 18, 2012. 

Jump up ^ Alexandria Ingham. "Criminal Minds Shares Details on Alex Blake's Departure". Guardian Liberty Voice. Las Vegas. Retrieved November 8, 2015. 

Jump up ^ Joyce Eng (May 15, 2014). "Criminal Minds Finale Postmortem: Boss on 'Emotional Exit,' Replacements and Season 10". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). Retrieved November 8, 2015. 

Jump up ^ "Jennifer Love Hewitt joins 'Criminal Minds' as series regular". Entertainment Weekly. New York City: Time Inc. Retrieved November 8, 2015. 

Jump up ^ Eng, Joyce (January 29, 2015). "Postmortem: Criminal Minds Boss on That Big Death and Why It Had to Happen". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). Retrieved February 8, 2015. 

Jump up ^ "Jennifer Love Hewitt not returning for 'Criminal Minds' season 11". Entertainment Weekly. New York City: Time Inc. Retrieved November 8, 2015. 

Jump up ^ Huggins, Sarah (May 7, 2015). "How 'Criminal Minds' Season 11 will handle A.J. Cook's pregnancy". Zap2it. Chicago: Tribune Digital Ventures. Retrieved June 28, 2015. 

Jump up ^ Eng, Joyce (March 23, 2016). "Shemar Moore on His Criminal Minds Exit: "I'm Proud of the Way Things Ended for Derek Morgan"". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). Retrieved March 24, 2016. 

Jump up ^ Webb Mitovich, Matt (March 23, 2016). "Criminal Minds: Shemar Moore Hails the 'Exclamation Point' on Derek's 'Hero Ride,' Says 'I Left It All on the Field'". TVLine. United States: Penske Media Corporation. Retrieved March 24, 2016. 

Jump up ^ Eng, Joyce (March 24, 2016). "Criminal Minds Boss on Shemar Moore's Exit: "There Is No Replacing Derek Morgan"". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). Retrieved March 24, 2016. 

^ Jump up to: a b Hibberd, James. "Criminal Minds adds Adam Rodriguez as series regular". Entertainment Weekly. New York City: Time Inc. Retrieved July 15, 2016. 

Jump up ^ Gonzalez, Sandra (August 31, 2016). "Paget Brewster is once again a series regular on 'Criminal Minds'". CNN News. Atlanta: CNN. Retrieved October 2, 2016. 

Jump up ^ Andreeva, Nellie (July 21, 2016). "'Criminal Minds': Paget Brewster To Return For Arc In Season 12". Deadline.com. United States: Penske Media Corporation. Retrieved July 22, 2016. 

Jump up ^ Eng, Joyce (July 21, 2016). "Paget Brewster Is Returning to Criminal Minds in Season 12". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). Retrieved July 22, 2016. 

Jump up ^ Bring, Harry [@LLPOS] (August 2, 2016). "Well, look who joined us for the table read on 1203!" (Tweet). Retrieved August 2, 2016 – via Twitter. 

Jump up ^ Webb Mitovich, Matt (August 10, 2016). "Criminal Minds: Aisha Tyler Promoted to Series Regular for Season 12". TVLine. United States: Penske Media Corporation. Retrieved August 10, 2016. 

Jump up ^ Andreeva, Nellie (August 11, 2016). "Thomas Gibson Suspended From 'Criminal Minds' Over On-Set Altercation". Deadline.com. United States: Penske Media Corporation. Retrieved August 11, 2016. 

Jump up ^ Goldberg, Lesley (August 12, 2016). "Thomas Gibson Fired From CBS' 'Criminal Minds'". The Hollywood Reporter. United States: Penske Media Corporation. Retrieved August 12, 2016. 

Jump up ^ Webb Mitovich, Matt (September 30, 2016). "Criminal Minds: New Series Regular Cast in Wake of Thomas Gibson's Exit". TVLine. Retrieved September 30, 2016. 

Jump up ^ Andreeva, Nellie (June 11, 2017). "'Criminal Minds': Damon Gupton Leaving CBS Series After One Season". TVLine. Retrieved June 11, 2017. 

^ Jump up to: a b "Criminal Minds Adds Beyond Borders ' Daniel Henney as Series Regular". TVLine.com. Retrieved June 20, 2017. 

Jump up ^ Steinberg, Lisa (September 14, 2016). "Kirsten Vangsness – Diani & Devine Meet The Apocalypse". Starry Mag. Retrieved September 16, 2016. 

Jump up ^ Harnick, Chris. "Jennifer Love Hewitt Joins Criminal Minds as Series Regular". E! Online. Los Angeles: NBCUniversal Cable. Retrieved 2 July 2014. 

Jump up ^ Andreeva, Nellie (June 11, 2017). "'Criminal Minds': Damon Gupton Leaving CBS Series After One Season". Deadline. Retrieved June 12, 2017. 

Jump up ^ Eng, Joyce (May 23, 2013). "Criminal Minds Boss on The Replicator Reveal, the Finale Death and What's Next in Season 9". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). Retrieved May 23, 2013. 

Jump up ^ Eng, Joyce (July 25, 2013). "Exclusive: Esai Morales Joins Criminal Minds as New Section Chief". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). Retrieved July 26, 2013. 

^ Jump up to: a b c "'Criminal Minds' doing new spinoff". Entertainment Weekly. New York City: Time Inc. Retrieved November 8, 2015. 

^ Jump up to: a b Mitovich, Matt Webb. "'Criminal Minds' Spin-Off 2015 — Globe-Trotting Team Of Profilers". TVLine. United States: Penske Media Corporation. Retrieved November 8, 2015. 

Jump up ^ Brooks, Tim; Marsh, Earle (2007). The Complete Directory to Prime Time Network and Cable TV Shows 1946-Present (Ninth Edition). Ballantine Books. p. 1697-1698. ISBN 978-0-345-49773-4. 

Jump up ^ Top Rated TV Programs By Season (2007-Present)

^ Jump up to: a b "Critic Reviews for Criminal Minds Season 1". Metacritic. Retrieved May 11, 2017. 

Jump up ^ Rabinowitz, Dorothy (October 7, 2005). "Circle of Genius". The Wall Street Journal. New York City: News Corp. Retrieved November 8, 2015. 

Jump up ^ Martel, Ned (September 28, 2015). "On the Case, a Crack Team of Tic-Ridden F.B.I. Agents". The New York Times. Retrieved April 3, 2016. 

Jump up ^ Topic Galleries – chicagotribune.com[verification needed]

Jump up ^ Lanzagorta, Marco. "Criminal Minds". PopMatters. Retrieved November 8, 2015. 

Jump up ^ McNamara, Mary (February 16, 2011). "TV Review: 'Criminal Minds: Suspect Behavior' Goes with Its Gut". Los Angeles Times. Chicago: Tronc, Inc. Retrieved May 18, 2012. 

Jump up ^ Katz, Josh (2016-12-27). "'Duck Dynasty' vs. 'Modern Family': 50 Maps of the U.S. Cultural Divide". The New York Times. 

Jump up ^ "Weekly Program Rankings". ABC Medianet. September 27, 2005. Archived from the original on June 1, 2009. Retrieved March 15, 2010. 

Jump up ^ "Weekly Program Rankings". ABC Medianet. May 16, 2006. Archived from the original on May 28, 2010. Retrieved March 15, 2010. 

Jump up ^ "ABC Television Network 2005–2006 Primetime Ranking Report" Archived October 11, 2014, at the Wayback Machine.. (May 31, 2006). ABC Medianet. Retrieved November 6, 2007.

Jump up ^ "Weekly Program Rankings". ABC Medianet. September 26, 2006. Archived from the original on March 29, 2012. Retrieved March 15, 2010. 

Jump up ^ "Weekly Program Rankings". ABC Medianet. May 22, 2007. Archived from the original on May 28, 2010. Retrieved March 15, 2010. 

Jump up ^ "ABC Television Network 2006–2007 Primetime Ranking Report" Archived March 23, 2012, at the Wayback Machine.. (May 30, 2007). ABC Medianet. Retrieved May 31, 2011.

Jump up ^ "Weekly Program Rankings". ABC Medianet. October 2, 2007. Archived from the original on May 1, 2011. Retrieved March 15, 2010. 

Jump up ^ Gorman, Bill (May 28, 2008). "Top CBS Primetime Shows, May 19–25". TV by the Numbers. Chicago: Tribune Digital Ventures. Archived from the original on September 25, 2008. Retrieved March 15, 2010. 

Jump up ^ "ABC Television Network 2007–2008 Primetime Ranking Report" Archived April 13, 2010, at the Wayback Machine.. (May 28, 2008). ABC Medianet. Retrieved July 3, 2009.

Jump up ^ Gorman, Bill (September 30, 2008). "Top CBS Primetime Shows, September 22–28". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved March 15, 2010. 

Jump up ^ Seidman, Robert (May 27, 2009). "Top CBS Primetime Shows, May 18–24". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved March 15, 2010. 

Jump up ^ "ABC Television Network 2008–2009 Primetime Ranking Report" Archived June 19, 2009, at the Wayback Machine.. (June 2, 2009). ABC Medianet. Retrieved May 31, 2011.

Jump up ^ TV by the Numbers Staff (October 12, 2009). "Dollhouse Premiere 18–49 Rating Increases To A 1.5 Via DVR; Hopeful or Futile?". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved August 12, 2016. 

Jump up ^ Gorman, Bill (June 2, 2010). "TV Ratings Top 25: American Idol, Big Bang Theory, Two And A Half Men Top 18–49 Ratings". Archived from the original on June 5, 2010. Retrieved June 29, 2010. 

Jump up ^ "Final 2009–10 Broadcast Primetime Show Average Viewership". TV by the Numbers. Chicago: Tribune Digital Ventures. June 16, 2010. Archived from the original on June 19, 2010. Retrieved July 29, 2010. 

Jump up ^ Seidman, Robert (September 28, 2010). "TV Ratings Broadcast Top 25: 'Sunday Night Football', 'Glee,' 'Grey's Anatomy,' 'Dancing with the Stars' Top Premiere Week". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved September 22, 2011. 

Jump up ^ Seidman, Robert (May 19, 2011). "Wednesday Final Ratings: 'American Idol,' 'Modern Family,' 'Law & Order: SVU' Adjusted Up; 'Happy Endings' Adj. Down". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved May 19, 2011. 

Jump up ^ "2010–11 Season Broadcast Primetime Show Viewership Averages". TV by the Numbers. Chicago: Tribune Digital Ventures. June 1, 2011. Retrieved June 1, 2011. 

Jump up ^ Gorman, Bill (September 27, 2011). "TV Ratings Broadcast Top 25: 'Two And A Half Men' Tops 'Sunday Night Football' For Week Ending September 25, 2011". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved September 27, 2011. 

Jump up ^ Kondolojy, Amanda (May 22, 2012). "TV Ratings Broadcast Top 25: 'American Idol', 'NCIS' Top Week 35 Viewing". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved May 22, 2012. 

Jump up ^ Gormam, Bill (May 25, 2012). "Complete List Of 2011–12 Season TV Show Viewership: 'Sunday Night Football' Tops, Followed By 'American Idol,' 'NCIS' & 'Dancing With The Stars'". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved May 25, 2012. 

Jump up ^ Bibel, Sara (October 2, 2012). "TV Ratings Broadcast Top 25: Sunday Night Football Tops Week 1 Viewing Among Adults 18–49 and With Total Viewers". TV by the Numbers. Chicago: Tribune Digital Ventures. Archived from the original on October 4, 2012. Retrieved October 2, 2012. 

Jump up ^ Bibel, Sara (May 29, 2013). "TV Ratings Broadcast Top 25: 'Modern Family' Tops Week 35 Viewing Among Adults 18–49, 'Dancing With the Stars' on Top With Total Viewers". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved June 2, 2013. 

Jump up ^ Bibel, Sara (May 29, 2013). "Complete List Of 2012–13 Season TV Show Viewership: 'Sunday Night Football' Tops, Followed By 'NCIS,' 'The Big Bang Theory' & 'NCIS: Los Angeles'". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved May 29, 2013. 

Jump up ^ Kondolojy, Amanda (September 26, 2013). "Wednesday Final Ratings: 'The Middle', 'Modern Family' and 'Survivor' Adjusted Up; 'Nashville' & 'CSI' Adjusted Down". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved September 26, 2013. 

Jump up ^ Bibel, Sara (May 15, 2014). "Wednesday Final Ratings: 'Revolution', 'Arrow', 'Survivor', 'Suburgatory', 'Modern Family' & 'Law & Order: SVU' Adjusted Up; 'Chicago P.D.' Adjusted Down". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved May 15, 2014. 

Jump up ^ "Full 2013–14 TV Season Series Rankings". Deadline.com. United States: Penske Media Corporation. May 22, 2014. Retrieved May 16, 2015. 

Jump up ^ Kondolojy, Amanda (October 20, 2014). "'How to Get Away With Murder' Has Biggest Adults 18–49 Ratings Increase; 'Parenthood' Tops Percentage Gains & 'The Blacklist' Tops Viewer Gains in Live +7 Ratings for Week Ending October 5". TV by the Numbers. Archived from the original on October 22, 2014. Retrieved October 20, 2014. 

Jump up ^ Kondolojy, Amanda (May 7, 2015). "Wednesday Final Ratings: 'Arrow', 'Nashville', & 'The Goldbergs' Adjusted Up; 'American Idol', 'Criminal Minds' 'Supernatural' & 'Blacki-ish' Adjusted Down". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved May 7, 2015. 

Jump up ^ de Moraes, Lisa (May 21, 2015). "Full 2014–15 TV Season Series Rankings: Football & 'Empire' Ruled". Deadline.com. United States: Penske Media Corporation. Retrieved May 25, 2015. 

Jump up ^ Dixon, Dani (October 1, 2015). "Wednesday Final Ratings: 'Empire', 'Survivor', 'Modern Family' & 'Rosewood' Adjusted Up; 'Nashville' & 'Code Black' Adjusted Down". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved October 1, 2015. 

Jump up ^ Porter, Rick (May 5, 2016). "Wednesday final ratings: 'Chicago PD' and 'Heartbeat' adjust up, 'Nashville' adjusts down". TV by the Numbers. Chicago: Tribune Digital Ventures. Retrieved May 5, 2016. 

Jump up ^ "Full 2015–16 TV Season Series Rankings". Deadline.com. United States: Penske Media Corporation. May 26, 2015. Retrieved May 26, 2015. 

Jump up ^ Porter, Rick (September 29, 2016). "Wednesday final ratings: 'Empire,' 'Lethal Weapon,' 'Criminal Minds,' 'SVU' & 'Blindspot' all adjust up". TV by the Numbers. Retrieved September 29, 2016. 

Jump up ^ Porter, Rick (May 11, 2017). "'Empire,' 'Modern Family,' 'Criminal Minds' finale, 'Chicago PD' & 'Speechless' all adjust up: Wednesday final ratings". TV by the Numbers. Retrieved May 11, 2017. 

Jump up ^ "Final 2016–17 TV Rankings: 'Sunday Night Football' Winning Streak Continues". Deadline Hollywood. May 26, 2017. Retrieved May 26, 2017. 

Jump up ^ Porter, Rick (September 28, 2017). "'Survivor' premiere adjusts up: Wednesday final ratings". TV by the Numbers. Retrieved September 28, 2017. 

Jump up ^ Porter, Rick (April 19, 2018). "'Empire' and 'The Voice' adjust up: Wednesday final ratings". TV by the Numbers. Retrieved April 19, 2018. 

Jump up ^ "Breaking News – Cbs Number One Live – And In Playback". The Futon Critic. June 29, 2010. Retrieved July 6, 2010. 

Jump up ^ Gorman, Bill (November 1, 2010). "Live+7 DVR Ratings: Grey's Anatomy, Fringe, The Mentalist Top Week's Rankings". TV by the Numbers. Retrieved February 25, 2011. 

Jump up ^ "Adweek – Breaking News in Advertising, Media and Technology". AdWeek. New York City: Mediabistro Holdings. Retrieved November 8, 2015. 

Jump up ^ "HITS". hitstv.com. Retrieved November 8, 2015. 

Jump up ^ Andreeva, Nellie (May 17, 2010). "CBS Picks Up 'Criminal Minds' Spinoff To Series". Deadline.com. United States: Penske Media Corporation. Retrieved May 17, 2010. 

Jump up ^ Andreeva, Nellie (May 17, 2011). "CBS renews 'CSI:NY', cancels 'Criminal Minds: Suspect Behavior'". Deadline.com. United States: Penske Media Corporation. Retrieved May 17, 2011. 

Jump up ^ "How The Criminal Minds Spinoff Will Replace Anna Gunn". Cinema Blend. 

Jump up ^ "Alana De La Garza & Annie Funke Join 'Criminal Minds: Beyond Borders'". Deadline.com. United States: Penske Media Corporation. July 17, 2015. Retrieved July 22, 2015. 

Jump up ^ Mitovich, Matt Webb. "'Criminal Minds' Spin-Off 2015 — Globe-Trotting Team Of Profilers". TVLine. United States: Penske Media Corporation. Retrieved November 8, 2015. 

Jump up ^ "'Rush Hour' Series Sets Premiere Date, CBS Shifts 'Criminal Minds: Beyond Borders'". The Wrap. Santa Monica, California: The Wrap News Inc. 

Jump up ^ Andreeva, Nellie. "'Code Black', 'Criminal Minds: Beyond Borders', 'The Odd Couple' & 'Undercover Boss' Renewed By CBS". Deadline.com. United States: Penske Media Corporation. 

Jump up ^ Goldberg, Lesley. "'Criminal Minds: Beyond Borders' Canceled at CBS7". hollywoodreporter.com. 

Jump up ^ "Criminal Minds Game Blog" (Press release). November 1, 2011. 

Jump up ^ "CBS Consumer Products Announces Eight New Video Games Based on Popular TV Shows" (Press release). CBS Interactive. October 29, 2009. 

Jump up ^ "Interview: Thomas Gibson". ShaveMagazine.com. Retrieved May 10, 2012. 

External links[edit]

Find more aboutCriminal Mindsat Wikipedia's sister projects

Media from Wikimedia Commons

Quotations from Wikiquote

Data from Wikidata

Official website

Criminal Minds on IMDb

Criminal Minds at TV.com

A&E's Criminal Minds site

AXN's Criminal Minds site

"List of Criminal Minds Episodes". TV Guide. Radnor, Pennsylvania: NTVB Media CBS Interactive (CBS Corporation) (digital assets). 

Gamespy Article On The Game

| Preceded by Grey's Anatomy 2006 | Criminal Minds Super Bowl lead-out program 2007 | Succeeded by House 2008 |

| [show] v t e Criminal Minds |

| Episodes | Season 1 2 3 4 5 6 7 8 9 10 11 12 13 |

| Characters | Jason Gideon Aaron Hotchner Elle Greenaway Derek Morgan Spencer Reid Jennifer Jareau Penelope Garcia Emily Prentiss David Rossi Alex Blake |

| Video game |

| Suspect Behavior | Sam Cooper |

| Episodes | Season 1 2 |

| Characters | Jack Garrett Clara Seger Russ Montgomery Matt Simmons Mae Jarvis |

| International | South Korean |

| [show] v t e CBS programming (current and upcoming) |

| Primetime | 48 Hours (since 1988) 60 Minutes (since 1968) The Amazing Race (since 2001) The Big Bang Theory (since 2007) Big Brother (since 2000) Blue Bloods (since 2010) Bull (since 2016) Celebrity Big Brother (since 2018) Code Black (since 2015) Criminal Minds (since 2005) Elementary (since 2012) Hawaii Five-0 (since 2010) Hunted (since 2017) Instinct (since 2018) Kevin Can Wait (since 2016) Life in Pieces (since 2015) Living Biblically (since 2018) MacGyver (since 2016) Madam Secretary (since 2014) Man with a Plan (since 2016) Mom (since 2013) NCIS (since 2003) NCIS: Los Angeles (since 2009) NCIS: New Orleans (since 2014) Ransom (since 2017) Salvation (since 2017) Scorpion (since 2014) SEAL Team (since 2017) Superior Donuts (since 2017) Survivor (since 2000) S.W.A.T. (since 2017) Undercover Boss (since 2010) Young Sheldon (since 2017) |

| Daytime | The Bold and the Beautiful (since 1987) Let's Make a Deal (since 2009) The Price Is Right (since 1972) The Talk (since 2010) The Young and the Restless (since 1973) |

| Late night | The Late Show with Stephen Colbert (since 2015) The Late Late Show with James Corden (since 2015) |

| News | 48 Hours (since 1988) 60 Minutes (since 1968) CBSN: On Assignment (since 2017) CBS Evening News (since 1948) CBS Morning News (since 1982) CBS News Sunday Morning (since 1979) CBS Overnight News (since 2015) CBS This Morning (1987–1999, since 2012) Face the Nation (since 1954) |

| Sports | CBS Sports Spectacular (since 1960) NCAA Basketball/Road to the Final Four (since 1981) NFL on CBS/The NFL Today (1956–1993, since 1998) PGA Tour on CBS SEC on CBS NCAA March Madness (co-produced with Turner Sports) (since 2011) Premier Boxing Champions (since 2015) |

| Saturday morning | Dr. Chris: Pet Vet (since 2013) The Inspectors (since 2015) |

| Upcoming | Murphy Brown (2018) TKO: Total Knock Out (2018) Blood & Treasure (2019) F.B.I. (TBA) The World's Best (TBA) |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Criminal_Minds&oldid=838411856"

Categories:

Criminal Minds

2005 American television series debuts

2000s American crime television series

2000s American drama television series

2000s American mystery television series

2010s American crime television series

2010s American drama television series

2010s American mystery television series

American crime drama television series

CBS network shows

English-language television programs

Federal Bureau of Investigation in fiction

Mental illness in fiction

Police procedural television series

Super Bowl lead-out programs

Television series by ABC Studios

Television series by CBS Television Studios

Television shows set in Virginia

Television shows filmed in Los Angeles

Television shows featuring audio description

Hidden categories:

All pages needing factual verification

Wikipedia articles needing factual verification from May 2012

Webarchive template wayback links

Use mdy dates from August 2012

Articles containing potentially dated statements from April 2018

All articles containing potentially dated statements

Articles to be expanded from April 2016

All articles to be expanded

Articles using small message boxes

All articles with unsourced statements

Articles with unsourced statements from November 2017

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikimedia Commons

Wikiquote

			Languages

العربية

Башҡортса

Български

Bosanski

Català

Čeština

Dansk

Deutsch

Eesti

Español

Euskara

فارسی

Føroyskt

Français

Galego

한국어

हिन्दी

Bahasa Indonesia

Íslenska

Italiano

עברית

Basa Jawa

Latviešu

Lietuvių

Magyar

Nederlands

日本語

Norsk

Polski

Português

Русский

Sardu

Simple English

Slovenščina

Српски / srpski

Srpskohrvatski / српскохрватски

Suomi

Svenska

తెలుగు

ไทย

Türkçe

Українська

中文
				34 more

Edit links

 This page was last edited on 26 April 2018, at 20:58.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews