# Siliguri Junction railway station

Siliguri Junction railway station - Wikipedia

Siliguri Junction railway station

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

| Siliguri Junction |

| Indian Railway Junction Station |

| Siliguri Railway Station |

| Location | Hill Cart Road, Patiram Jote, Pradhan Nagar, Siliguri–734001 Dist: Darjeeling, West Bengal India |

| Coordinates | 26°43′24″N 88°24′50″E﻿ / ﻿26.7234°N 88.4138°E﻿ / 26.7234; 88.4138Coordinates: 26°43′24″N 88°24′50″E﻿ / ﻿26.7234°N 88.4138°E﻿ / 26.7234; 88.4138 |

| Elevation | 120 metres (390 ft) |

| Owned by | Indian Railways |

| Operated by | North East Frontier Railway |

| Line(s) | New Jalpaiguri-Alipurduar-Samuktala Road line, Darjeeling Himalayan Railway |

| Platforms | 4 |

| Tracks | 7 |

| Construction |

| Structure type | Standard on ground |

| Parking | Available |

| Other information |

| Status | Functioning |

| Station code | SGUJ |

| Division(s) | Katihar |

| History |

| Opened | 1949; 69 years ago (1949) |

| Electrified | In Progress |

| Location |

| Siliguri Junction railway station Location in West Bengal |

| [show] [ v t e ] Railways in the Siliguri Area |

| Legend |

| under |

| construction |

)

| New Jalpaiguri–Alipurduar– |

| Samuktala Road Line |

| 21 km |

| 13 mi |

| Sevoke |

| 10 km |

| 6 mi |

| Gulma |

| Darjeeling Himalayan Railway |

| narrow gauge railway to Darjeeling |

| 8 km |

| 5 mi |

| Siliguri Junction |

| 12 km |

| 7 mi |

| Matigara |

| Mahananda River |

| 6 km |

| 4 mi |

| Siliguri Town |

| New Jalpaiguri-New Bongaigaon section |

| and New Jalpaiguri—Haldibari Line |

| 0 | New Jalpaiguri |

| 5 km |

| 3 mi |

| Rangapani |

| New Jalpaiguri—Howrah Line |

| via Barsoi |

| 18 km |

| 11 mi |

| Baghdogra |

| Bagdogra Airport |

| Siliguri—Katihar Line |

| via Thakurganj |

Siliguri Junction is one of the three railway stations that serve Siliguri in Darjeeling district in the Indian state of West Bengal. The other two stations are: Siliguri Town and New Jalpaiguri. It has Broad Gauge and Narrow Gauge tracks. It formerly had the distinction of having three gauges, but the metre-gauge line from Aluabari Road to Alipuarduar was converted later[when?].

Contents
 [hide] 

1 History

2 Amenities

3 Services

4 Siliguri loco shed

5 References

6 External links

History[edit]

With the railway routes badly disturbed by the partition of India in 1947, Siliguri Town railway station suddenly lost its pre-eminence, as the broad gauge link to Calcutta, running across East Pakistan, was lost. With three metre gauge lines, the new Siliguri Junction railway station became the main railway station in the area. The three metre gauge lines were linked to Kishanganj and Barsoi, Assam and Haldibari. The narrow gauge Darjeeling Himalayan Railway was there. The short reign was over in the 1960s when a new broad gauge line linked Siliguri with Calcutta, and subsequently, all railway lines in the area (excepting Darjeeling Himalayan Railway) were converted to broad gauge. The focus shifted in 1961 to a brand new broad gauge station at New Jalpaiguri.[1]

Amenities[edit]

Amenities at Siliguri Junction include: Waiting room, retiring room, tourist information centre, and book stall. West Bengal Tourist Office and Tenzing Norgay central bus terminal are located close to the railway station.[2]Siliguri Junction has three two-bedded retiring rooms and a four-bedded dormitory.[3]

Distance from Siliguri Junction: Bagdogra Airport 14 km, New Jalpaiguri railway station 8 km, Darjeeling 80 km, Gangtok 120 km, Thimphu 350 km.[2]

Services[edit]

Some important train that origins/terminates :

| Train No. | Train Name | Train Type | Arrivals | Arrival Time | Departures | Departure Time |

| 15463 | Balurghat- Siliguri Intercity Express | Express | Daily | 17:55 | Daily | 8:30 |

| 15719 | Katihar - Siliguri Jn InterCity Express | Express | Daily | 11:15 | Daily | 15:00 |

| 15765 | Siliguri Jn. - Dhubri InterCity Express | Express | Daily | 22:00 | Daily | 6:05 |

| 15767 | Siliguri - Alipur Duar Intercity Express | Express | Daily | 10:00 | Daily | 16:45 |

Siliguri loco shed[edit]

A metre gauge diesel loco shed was established at Siliguri in 1961 and a new broad gauge diesel loco shed was established in 2007. WDP-4 and WDG-4 locos were transferred from Hubli. It is home to the WDP-4 loco "Baaz". It also houses YDM-4 and WDM 3A locos.[4][5]

References[edit]

Jump up ^ Alastair Boobyer. "India: the complex history of the junctions at Siliguri and New Jalpaiguri". IRFCA. Retrieved 2011-12-10. 

^ Jump up to: a b "Siliguri railway station". make my trip. Retrieved 2013-03-02. 

Jump up ^ "Retiring rooms in North East Frontier Railway". Indian Railways. Retrieved 2013-03-02. 

Jump up ^ "Diesel Loco Shed – Siliguri Junction" (PDF). NF Railway. Retrieved 14 May 2013. 

Jump up ^ "Sheds and workshops". IRFCA. Retrieved 14 May 2013. 

External links[edit]

Siliguri Junction railway station at the India Rail Info

 Siliguri travel guide from Wikivoyage

| Preceding station | Indian Railway | Following station |

| Siliguri Town | Northeast Frontier Railway zone New Jalpaiguri-Alipurduar-Samuktala Road line | Gulma |

| Siliguri Town | Darjeeling Himalayan Railway Siliguri-Darjeeling light railway | Sukna |

| Terminus | Northeast Frontier Railway zone Katihar-Siliguri line | Matigara |

| Terminus | Northeast Frontier Railway zone Siliguri- Bagdogra Metre Gauge line | Matigara |

| [show] v t e Darjeeling related topics |

| History and government | Darjeeling district History of Sikkim History of Bengal History of Nepal British Raj Gorkha National Liberation Front Gorkhaland Darjeeling Gorkha Hill Council Darjeeling Municipality Darjeeling (Lok Sabha constituency) |

| Geography | Kangchenjunga Darjeeling Himalayan hill region Jore Pokhri Wildlife Sanctuary Katapahar Jalapahar Observatory Hill Sivalik Hills Tiger Hill Darjeeling Sadar Mahananda Wildlife Sanctuary Padmaja Naidu Himalayan Zoological Park Mane Bhanjang Phalut Sandakphu Rock Garden Senchal Wildlife Sanctuary Singalila National Park Demographics of Darjeeling |

| Education | University of North Bengal Mount Hermon School St. Joseph's College Loreto Convent St. Paul's School Southfield (formerly Loreto) College Darjeeling Government College St. Joseph's College Himalayan Mountaineering Institute North Bengal Medical College |

| Economy and Transport | Darjeeling tea Terrace fields Puttabong (Tukvar) Tea Estate Happy Valley Tea Estate Tourism in India Economy of West Bengal Transport in Darjeeling Darjeeling Himalayan Railway Katihar–Siliguri line Bagdogra Airport Darjeeling Ropeway |

| Culture | Sherpa Rai Lepcha Bhutia Yolmo/Yamloo Miji/Damai Kamai Newar Limbu Gorkha Bengali Nepali Hinduism Buddhism Wai-wai Chhurpi Thukpa Momo Chhang Devil Dance Tendong Lho Rumfaat Maghe Sankranti Chotrul Duchen Tibetan Refugee Self Help Center Ghum Monastery Bhutia Busty Monastery Mag-Dhog Yolmowa Monastery Peace Pagoda |

| Darjeeling Sadar subdivision | Darjeeling Pulbazar Jorebunglow Sukhiapokhri Rangli Rangliot |

| Kalimpong subdivision | Kalimpong I Kalimpong II Gorubathan |

| Kurseong subdivision | Mirik Kurseong |

| Siliguri subdivision | Matigara Naxalbari Phansidewa Kharibari |

| Vidhan Sabha constituencies | Kalimpong Darjeeling Kurseong Matigara-Naxalbari Siliguri Phansidewa |

| Template | Cities and towns in Darjeeling district |

| Categories | Darjeeling Cities and towns in Darjeeling district Himalayas Hill stations in India People from Darjeeling district Villages in Darjeeling district |

| [show] v t e Railway stations in West Bengal |

| Eastern Railway | Andal Junction Asansol Junction Azimganj Balarambati Bandel Junction Bangaon Banshlai Bridge Barachak Barasat Junction Barddhaman Junction Barrackpore Baruipara Belur Bolpur Shantiniketan Chatra Dankuni Junction Diamond Harbour Durgapur Garia Gede Hind Motor Hooghly Ghat Hooghly Howrah Junction Janai Road Jaynagar Majilpur Kamarkundu Katwa Khana Kolkata Liluah Majerhat Malda Town Mirzapur-Bankipur Murarai Nalhati Junction New Farakka New Garia Rajgram Rampurhat Junction Ranaghat Raniganj Sainthia Junction Sealdah Sheoraphuli Shrirampur Singhabad Sitarampur Siuri Tarakeswar |

| South Eastern Railway | Abada Adra Junction Bero Bishnupur Burnpur Damodar Digha Gourinathdham Haldia Jhalda Joychandi Pahar Madhukunda Muradi Purulia Ramkanali Santragachi Junction Shalimar Tikiapara Uluberia |

| North East Frontier Railway | Adhikari Alipurduar Junction Balurghat Bamanhat Buniadpur Buxa Road Changrabandha Cooch Behar Dalkolha Darjeeling Dhupguri Daulatpur Halt Gangarampur Ghum Gitaldaha Haldibari Jalpaiguri Junction Jalpaiguri Road Maynaguri Road Malancha Mallickpurhat Mohitnagar New Alipurduar New Cooch Behar Junction New Jalpaiguri New Maynaguri Radhikapur Raiganj Rampur Bazar Raninagar Jalpaiguri Junction Santragachi Junction Samuktala Road Junction Shalimar Siliguri Junction Siliguri Town Sivok |

| See also | Kolkata Suburban Railway stations Kolkata Metro |

| Railways in India |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Siliguri_Junction_railway_station&oldid=831212832"

Categories:

Katihar railway division

Railway stations in Darjeeling district

Railway stations opened in 1949

Railway junction stations in West Bengal

Transport in Siliguri

Hidden categories:

Pages with unresolved properties

Use dmy dates from January 2016

Use Indian English from January 2016

All Wikipedia articles written in Indian English

Coordinates on Wikidata

Articles using Infobox station with map locator

All articles with vague or ambiguous time

Vague or ambiguous time from March 2018

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikimedia Commons

			Languages

বাংলা

Edit links

 This page was last edited on 19 March 2018, at 11:57.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews