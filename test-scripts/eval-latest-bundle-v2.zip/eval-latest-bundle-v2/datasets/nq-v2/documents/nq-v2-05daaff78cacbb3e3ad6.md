# Robin Wright

Robin Wright - Wikipedia

Robin Wright

From Wikipedia, the free encyclopedia

					Jump to:					navigation, 					search

For the journalist, see Robin Wright (author). For the rugby player, see Robin Wright (rugby player).

| Robin Wright |

| Wright in Cannes, 2017 |

| Born | Robin Gayle Wright (1966-04-08) April 8, 1966 (age 52) Dallas, Texas, U.S. |

| Nationality | American |

| Other names | Robin Wright Penn |

| Occupation | Actress, director |

| Years active | 1983–present |

| Spouse(s) | Dane Witherspoon (m. 1986; div. 1988) Sean Penn (m. 1996; div. 2010) |

| Children | Dylan Penn, Hopper Jack Penn |

| Relatives | Charlie Wright (nephew) |

Robin Gayle Wright[1] (born April 8, 1966) is an American actress and director. She is the recipient of seven Primetime Emmy Award nominations and has earned a Golden Globe Award and a Satellite Award for her work in television.

Wright first gained attention for her role in the NBC Daytime soap opera Santa Barbara, as Kelly Capwell from 1984 to 1988. She then made the transition to film, starring in the romantic comedy fantasy adventure film The Princess Bride (1987). This role led Wright to further success in the film industry, with starring roles in films such as the romantic comedy-drama Forrest Gump (1994), the romantic drama Message in a Bottle (1999), the superhero drama-thriller Unbreakable (2000), the historical drama The Conspirator (2010), the biographical sports drama Moneyball (2011), the mystery thriller The Girl with the Dragon Tattoo (2011), the biographical drama Everest (2015), the superhero film Wonder Woman (2017), and the neo-noir science fiction film Blade Runner 2049 (2017).

Wright starred as Claire Underwood in the Netflix political drama web television series House of Cards, for which she won the Golden Globe Award for Best Actress – Television Series Drama in 2013, making her the first actress to win a Golden Globe for a web television series. Wright has also received consecutive Primetime Emmy Award nominations in the Outstanding Lead Actress category for House of Cards between 2013 and 2017 and the Outstanding Drama Series category in 2016 and 2017 as a producer on the show.

Contents
 [hide] 

1 Early life

2 Career

2.1 1980s–2000s: Transition into feature film work

2.2 2013–present: House of Cards, further film work

3 Personal life

4 Philanthropy and activism

5 Filmography

5.1 Film

5.2 Television

6 Awards and nominations

7 See also

8 References

9 External links

Early life[edit]

Wright was born in Dallas, Texas, to Gayle (Gaston), a cosmetics saleswoman, and Freddie Wright, a pharmaceutical company employee.[1][2] Wright was raised in San Diego, California. She attended La Jolla High School and Taft High School in Woodland Hills, Los Angeles.[3]

Career[edit]

Wright at the 2009 Toronto International Film Festival

Wright began her career as a model, when she was 14.[4][5] At the age of 18, she played Kelly Capwell in the NBC Daytime soap opera series Santa Barbara, for which she received several Daytime Emmy Award nominations.[6]

1980s–2000s: Transition into feature film work[edit]

She transitioned into feature film work as Buttercup in the cult film The Princess Bride (1987). She gained critical acclaim in her role as Jenny Curran in Forrest Gump (1994), receiving Golden Globe Award and Screen Actors Guild nominations for Best Supporting Actress.

In 1996 she starred in the lead role of the film adaptation of Daniel Defoe's Moll Flanders (1996), for which she received a Satellite Award Nomination for Best Actress in a Drama. She was nominated for a Screen Actors Guild Award for Best Actress for her role in She's So Lovely (1997), a film in which she co-starred with her then-husband Sean Penn. Wright received her third Screen Actors Guild Award nomination for her role in the television film Empire Falls (2005).

2013–present: House of Cards, further film work[edit]

Wright attending the 2009 Cannes Film Festival

Since 2013, Wright has appeared in the Netflix political drama web television series House of Cards in the role of Claire Underwood, the ruthless wife of political mastermind Frank Underwood. On January 12, 2014, she won a Golden Globe for the role, becoming the first actress to win the award for an online-only web television series;[7] she was nominated for the same award the following year. She also received nominations for the Primetime Emmy Award in 2013 and 2014 for the same role. Following Season 4 in 2016, Wright stated that she felt Claire Underwood was the equal of Frank Underwood and demanded equal pay for her performance as her co-star Kevin Spacey; Netflix acquiesced.[8] In 2017, for her performance in the fifth season, Wright was nominated for her fifth consecutive Primetime Emmy nomination for Outstanding Lead Actress – Drama. For the years 2014, 2016, and 2017, Wright received Best Actress in a Drama Series nominations for the Critics' Choice Television Awards, with her being the only nomination for the show in December 2017. In October 2017, Wright was set as the show's new lead, following sexual misconduct allegations against Spacey, which resulted in him being fired from the sixth and final season.

In 2017, Wright played General Antiope in Wonder Woman (2017), alongside Gal Gadot and Chris Pine. She appears in the Blade Runner sequel Blade Runner 2049 alongside Ryan Gosling, Harrison Ford and Jared Leto.

Personal life[edit]

Wright with then-husband Sean Penn in September 2006

From 1986 to 1988 Wright was married to actor Dane Witherspoon, whom she met in 1984 on the set of the soap opera Santa Barbara.[9]

In 1989, Wright became involved with actor Sean Penn following his divorce from Madonna. Wright was offered the role of Maid Marian in the film Robin Hood: Prince of Thieves, but turned it down because she was pregnant.[10] Wright and Penn's daughter, Dylan Frances, was born in April 1991.[11] She backed out of the role of Abby McDeere in The Firm (1993) due to her pregnancy with her second child.[3] Wright and Penn's son, Hopper Jack, was born in August 1993.[12]

After breaking up and getting back together,[13]Wright and Penn married in 1996, and she changed her name to Robin Wright Penn.[14] Their on-and-off relationship seemingly ended in divorce plans, announced in December 2007,[14] but the divorce petition was withdrawn four months later at the couple's request.[15] In February 2009, Wright and Penn attended the 81st Academy Awards together, at which Penn won Best Actor. Penn filed for legal separation in April 2009,[16] but withdrew the petition in May.[17] On August 12, 2009, Wright filed for divorce declaring she had no plans to reconcile.[18][19] At that time she dropped "Penn" from her professional name.[20] The divorce was finalized on July 22, 2010.[21]

In February 2012, Wright began dating actor Ben Foster,[22] and their engagement was announced in January 2014.[23][24] The couple called off their engagement in November 2014,[25] but reunited in January 2015.[26] On August 29, 2015, they announced they were ending their second engagement.[27]

Philanthropy and activism[edit]

Wright is the Honorary Spokesperson for the Dallas, Texas-based non-profit The Gordie Foundation.[28]

In 2014, Wright co-partnered with two California based companies; Pour Les Femmes[29] and The SunnyLion.[30] The SunnyLion donates a portion of its profits to the Raise Hope For Congo movement.

Wright is an activist for human rights in the Democratic Republic of the Congo. She is the narrator and executive producer of the documentary When Elephants Fight[31] which highlights how multinational mining corporations and politicians in the Democratic Republic of Congo threaten human rights, and perpetuate conflict in the region.[32] Wright is a supporter of Stand With Congo, the human rights campaign behind the film.[33] In 2016, she spoke publicly in support of the campaign at a film screening at the TriBeCa Film Institute in New York City,[34] in media interviews,[35][36][37][38] with journalists,[39][40][41] and across her social media accounts.[42][43][44]

Filmography[edit]
Film[edit]

| Year | Title | Role | Notes |

| 1986 | Hollywood Vice Squad | Lori Stanton |

| 1987 | The Princess Bride | Buttercup | Nominated – Saturn Award for Best Actress |

| 1990 | Denial | Sara / Loon |

| 1990 | State of Grace | Kathleen Flannery |

| 1992 | The Playboys | Tara Maguire |

| 1992 | Toys | Gwen Tyler | Nominated – Saturn Award for Best Supporting Actress |

| 1994 | Forrest Gump | Jenny Curran | Nominated – Golden Globe Award for Best Supporting Actress – Motion Picture Nominated – Saturn Award for Best Supporting Actress Nominated – Screen Actors Guild Award for Outstanding Performance by a Female Actor in a Supporting Role |

| 1995 | The Crossing Guard | Jojo |

| 1996 | Moll Flanders | Moll Flanders | Nominated – Satellite Award for Best Actress – Motion Picture |

| 1997 | Loved | Hedda Amerson | Nominated – Independent Spirit Award for Best Female Lead |

| 1997 | She's So Lovely | Maureen Murphy Quinn | Nominated – Screen Actors Guild Award for Outstanding Performance by a Female Actor in a Leading Role |

| 1998 | Hurlyburly | Darlene |

| 1999 | Message in a Bottle | Theresa Osborne | Nominated – Blockbuster Entertainment Award for Favorite Actress – Drama/Romance |

| 2000 | How to Kill Your Neighbor's Dog | Melanie McGowan |

| 2000 | Unbreakable | Audrey Dunn | Nominated – Blockbuster Entertainment Award for Favorite Supporting Actress – Suspense |

| 2001 | The Pledge | Lori |

| 2001 | The Last Castle | Rosalie Irwin | Uncredited |

| 2002 | Searching for Debra Winger | Herself | Documentary |

| 2002 | White Oleander | Starr Thomas |

| 2003 | The Singing Detective | Nicola / Nina / Blonde |

| 2003 | Virgin | Mrs. Reynolds |

| 2004 | A Home at the End of the World | Clare |

| 2005 | Nine Lives | Diana | Locarno International Film Festival Award for Best Actress Nominated – Gotham Independent Film Award for Best Ensemble Performance Nominated – Satellite Award for Best Actress – Motion Picture Nominated – Independent Spirit Award for Best Supporting Female |

| 2005 | Sorry, Haters | Phoebe Torrence | Nominated – Independent Spirit Award for Best Female Lead |

| 2005 | Max | Mother | Short film |

| 2006 | Breaking and Entering | Liv Ullmann | Nominated – British Independent Film Award for Best Actress |

| 2006 | Room 10 | Frannie Jones | Short film |

| 2007 | Hounddog | Stranger Lady |

| 2007 | Beowulf | Queen Wealtheow |

| 2008 | What Just Happened | Kelly |

| 2008 | New York, I Love You | Anna |

| 2009 | State of Play | Anne Collins |

| 2009 | The Private Lives of Pippa Lee | Pippa Lee |

| 2009 | A Christmas Carol | Fan Scrooge / Belle |

| 2010 | The Conspirator | Mary Surratt |

| 2011 | Moneyball | Sharon Beane |

| 2011 | Rampart | Linda Fentress |

| 2011 | The Girl with the Dragon Tattoo | Erika Berger |

| 2013 | The Congress | Robin Wright |

| 2013 | Adore | Roz |

| 2014 | A Most Wanted Man | Martha Sullivan |

| 2015 | Everest | Peach Weathers |

| 2017 | Wonder Woman | General Antiope |

| 2017 | Blade Runner 2049 | Lieutenant Joshi |

| 2017 | Justice League | General Antiope | Uncredited cameo |

| 2018 | André the Giant | Herself |

Television[edit]

| Year | Title | Role | Notes |

| 1983–84 | The Yellow Rose | Barbara Anderson | 2 episodes |

| 1984–88 | Santa Barbara | Kelly Capwell | 538 episodes Soap Opera Digest Award for Outstanding Heroine Nominated – Soap Opera Digest Awards for Outstanding Younger Lead Actress Nominated – Daytime Emmy Award for Outstanding Younger Actress in a Drama Series (1986–1988) |

| 2005 | Empire Falls | Grace Roby | Nominated – Screen Actors Guild Award for Outstanding Performance by a Female Actor in a Miniseries or Television Movie |

| 2011 | Saturday Night Live | Jenny Curran | Episode: "Tina Fey/Ellie Goulding" |

| 2011 | Enlightened | Sandy | 2 episodes |

| 2013–present | House of Cards | Claire Underwood | Main role, executive producer (Season 4) and director (9 episodes). Golden Globe Award for Best Actress – Television Series Drama Gold Derby Award for Best Actress in a Drama Series Satellite Award for Best Actress – Television Series Drama Nominated – Critics' Choice Television Award for Best Actress in a Drama Series (2014, 2016, 2018) Nominated – Golden Globe Award for Best Actress – Television Series Drama (2015–2016) Nominated – Gold Derby Award for Best Actress in a Drama Series (2014–2015) Nominated – Online Film and Television Association Award for Best Actress in a Drama Series (2013–2016) Nominated – Primetime Emmy Award for Outstanding Lead Actress in a Drama Series (2013–2017) Nominated – Primetime Emmy Award for Outstanding Drama Series Nominated – Producers Guild of America Award for Best Episodic Drama Nominated – Satellite Award for Best Actress – Television Series Drama (2015–2016) Nominated – Screen Actors Guild Award for Outstanding Performance by a Female Actor in a Drama Series (2015–2017) Nominated – Screen Actors Guild Award for Outstanding Performance by an Ensemble in a Drama Series (2015–2016) |

Awards and nominations[edit]

Main article: List of awards and nominations received by Robin Wright

See also[edit]

List of American film actresses

List of Santa Barbara cast and characters

Biography portal

Film portal

Television portal

References[edit]

^ Jump up to: a b [1] Archived July 21, 2015, at the Wayback Machine.

Jump up ^ "Robin Wright Biography (1966-)". Filmreference.com. Retrieved November 2, 2007. 

^ Jump up to: a b "Robin Wright – Biography". Yahoo! Movies. Retrieved May 21, 2013. 

Jump up ^ "Robin Wright as Claire Underwood". TV3. 

Jump up ^ Broadbent, Lucy (February 9, 2014). "Robin Wright on House of Cards, Botox and getting married again". The Daily Telegraph. Retrieved May 21, 2017. 

Jump up ^ Cameron-Wilson, James (1994). Young Hollywood. Batsford. p. 218. ISBN 978-0-7134-7266-0. 

Jump up ^ Hyman, Vicki (January 12, 2014). "2014 Golden Globes: Robin Wright wins best actress for online-only 'House of Cards'". The Star-Ledger. NJ.com. Retrieved January 13, 2014. 

Jump up ^ Peck, Emily (May 18, 2016). "Robin Wright Demanded The Same Pay As Kevin Spacey For 'House of Cards'". The Huffington Post. Retrieved May 19, 2016. 

Jump up ^ Grossberg, Josh (December 28, 2007). "Penn, Wright Splitsville". Yahoo! News. Archived from the original on January 1, 2008. 

Jump up ^ Mell, Eila (2005). Casting Might-Have-Beens: A film by film directory. Jefferson, North Carolina: McFarland & Company, Inc. p. 204. ISBN 978-0786420179. 

Jump up ^ MacMinn, Aleene (April 17, 1991). "Cradle Watch". Los Angeles Times. Archived from the original on March 9, 2012. Retrieved July 27, 2014. Dylan Frances Penn was born Saturday [April 13] at 10:49 p.m. at UCLA Medical Center. 

Jump up ^ Kelly, Richard T. (2004). Sean Penn: His Life and Times. Canongate U.S. p. 274. ISBN 978-1841956237. 

Jump up ^ "The Insider – Vol. 45 No. 12". PEOPLE.com. 25 March 1996. 

^ Jump up to: a b White, Nicholas (December 27, 2007). "Sean Penn and Robin Wright Penn Divorcing". People. Retrieved July 30, 2017. 

Jump up ^ Orloff, Brian (April 9, 2008). "Sean Penn & Robin Wright Stop Divorce Action". People. Retrieved April 8, 2017. 

Jump up ^ Laudadio, Marisa; Lee, Ken (April 29, 2009). "Sean Penn Files for Legal Separation". People. Retrieved February 26, 2017. 

Jump up ^ "Sean Penn withdraws separation filing". USA Today. May 22, 2009. 

Jump up ^ Lee, Ken (August 18, 2009). "Robin Wright Penn Files for Divorce". People. Retrieved May 4, 2017. 

Jump up ^ Breslau, Karen (September 2009). "Robin Wright Penn Goes It Alone". More. Archived from the original on March 27, 2016. Retrieved September 16, 2009. 

Jump up ^ Derschowitz, Jessica (November 16, 2009). "Big changes for Robin Wright". CBS News. Retrieved December 8, 2016. 

Jump up ^ Oh, Eunice (August 4, 2010). "Sean Penn and Robin Wright Finalize Their Divorce". People. Retrieved February 26, 2017. 

Jump up ^ "Robin Wright and Ben Foster Get Cozy". People. Retrieved February 10, 2012. 

Jump up ^ "Robin Wright 47 gets engaged boyfriend Ben Foster 33 flashes sparkler fashion bash". Daily Mail. Retrieved January 23, 2014. 

Jump up ^ Loinaz, Alexis L. (January 11, 2014). "Robin Wright and Ben Foster are engaged". People. Retrieved January 11, 2014. 

Jump up ^ Marquina, Sierra (November 12, 2014). "Robin Wright and Ben Foster Split, Call Off 10-Month Engagement – Find Out What Went Wrong". Us Weekly. Retrieved November 13, 2014. 

Jump up ^ Lee, Esther (March 10, 2015). "Robin Wright Talks Sex Life With Ben Foster After Sean Penn Divorce: "I've Never Been Happier"". Us Weekly. Retrieved July 4, 2015. 

Jump up ^ Webber, Stephanie (August 29, 2015). "Robin Wright, Ben Foster Call Off Engagement For the Second Time". Us Weekly. Retrieved August 29, 2015. 

Jump up ^ [2] Archived April 2, 2015, at the Wayback Machine.

Jump up ^ "Pour Les Femmes". Plfdreams.tilt.com. Archived from the original on April 2, 2015. Retrieved May 8, 2015. 

Jump up ^ "Giving Back – The SunnyLion and Raise Hope for Congo". TheSunnyLion.com. June 20, 2014. Retrieved May 8, 2015. 

Jump up ^ "When Elephants Fight (2015)". IMDb. Retrieved July 27, 2016. 

Jump up ^ "Mortality in the Democratic Republic of Congo: An Ongoing Crisis" (PDF). International Rescue Committee. Retrieved July 27, 2016. 

Jump up ^ "#StandWithCongo | A Stier Forward Campaign". Stand With Congo. Retrieved July 27, 2016. 

Jump up ^ "LIVE NYC Screening4Action at TriBeCa". Facebook.com/StandWithCongo. Retrieved July 27, 2016. 

Jump up ^ "Live with Robin Wright". Facebook.com/MicMedia. Retrieved July 27, 2016. 

Jump up ^ "Congo: The High Cost of Mineral Riches". WNYC (NPR). Retrieved July 27, 2016. 

Jump up ^ "Actress Robin Wright Talks About Her New Documentary". Facebook.com/HuffPostEntertainment. Retrieved July 27, 2016. 

Jump up ^ "'Making Noise': The Path Towards Global Equality". Rockefeller Foundation. Retrieved July 27, 2016. 

Jump up ^ "The Paradox Of Congo: How The World's Wealthiest Country Became Home To The World's Poorest People". ThinkProgress.org. Retrieved July 27, 2016. 

Jump up ^ "Robin Wright Makes a Powerful Political Statement — It's Not Related to 'House of Cards'". Mic.com. Retrieved July 27, 2016. 

Jump up ^ "Robin Wright: A-lister who's playing for high stakes off screen". The Guardian. May 22, 2016. Retrieved July 27, 2016. 

Jump up ^ "Robin Wright Twitter". Twitter. Retrieved July 27, 2016. 

Jump up ^ "Robin Wright Twitter". Twitter. Retrieved July 27, 2016. 

Jump up ^ "Robin Wright Instagram". Instagram. March 13, 2016. Retrieved July 27, 2016. 

External links[edit]

| Wikimedia Commons has media related to Robin Wright Penn. |

Robin Wright on IMDb

Robin Wright at the TCM Movie Database

Robin Wright at AllMovie

Robin Wright Fansite

| [show] Awards for Robin Wright |

| [show] v t e Golden Globe Award for Best Actress – Television Series Drama |

| Linda Cristal (1969) Peggy Lipton (1970) Patricia Neal (1971) Gail Fisher (1972) Lee Remick (1973) Angie Dickinson (1974) Lee Remick (1975) Susan Blakely (1976) Lesley Ann Warren (1977) Rosemary Harris (1978) Natalie Wood (1979) Yoko Shimada (1980) Linda Evans/Barbara Bel Geddes (1981) Joan Collins (1982) Jane Wyman (1983) Angela Lansbury (1984) Sharon Gless (1985) Angela Lansbury (1986) Susan Dey (1987) Jill Eikenberry (1988) Angela Lansbury (1989) Sharon Gless/Patricia Wettig (1990) Angela Lansbury (1991) Regina Taylor (1992) Kathy Baker (1993) Claire Danes (1994) Jane Seymour (1995) Gillian Anderson (1996) Christine Lahti (1997) Keri Russell (1998) Edie Falco (1999) Sela Ward (2000) Jennifer Garner (2001) Edie Falco (2002) Frances Conroy (2003) Mariska Hargitay (2004) Geena Davis (2005) Kyra Sedgwick (2006) Glenn Close (2007) Anna Paquin (2008) Julianna Margulies (2009) Katey Sagal (2010) Claire Danes (2011) Claire Danes (2012) Robin Wright (2013) Ruth Wilson (2014) Taraji P. Henson (2015) Claire Foy (2016) Elisabeth Moss (2017) |

| [show] v t e Locarno Film Festival Best Actress Award |

| 2000s–2010s | Sabine Timoteo (2000) Ho-jung Kim (2001) Taraneh Alidoosti (2002) Holly Hunter / Diana Dumbrava / Kiron Kher (2003) Maria Kwiatkowsky/ Pinar Erincin (2004) Robin Wright / Sissy Spacek/Holly Hunter / LisaGay Hamilton / Glenn Close / Elpidia Carrillo / Amy Brenneman / Kathy Baker (2005) Amber Tamblyn (2006) Marian Álvarez (2007) Ilaria Occhini (2008) Lotte Verbeek (2009) WiAna Ularu (2010) María Canale (2011) Nai An (2012) Brie Larson (2013) Ariane Labed (2014) Sachie Tanaka / Hazuki Kikuchi / Maiko Mihara / Rira Kawamura (2015) Irena Ivanova (2016) Isabelle Huppert (2017) |

| [show] v t e Satellite Award for Best Actress – Television Series Drama |

| Christine Lahti (1996) Kate Mulgrew (1997) Jeri Ryan (1998) Camryn Manheim (1999) Allison Janney (2000) Edie Falco (2001) CCH Pounder (2002, 2003) Laurel Holloman (2004) Kyra Sedgwick (2005, 2006) Ellen Pompeo (2007) Anna Paquin (2008) Glenn Close (2009) Connie Britton (2010) Claire Danes (2011, 2012) Robin Wright (2013) Keri Russell (2014) Claire Danes (2015) Evan Rachel Wood (2016) Elisabeth Moss (2017) |

| Authority control | WorldCat Identities VIAF: 5130073 LCCN: n92090902 ISNI: 0000 0001 2020 1940 GND: 122405609 SUDOC: 069283176 BNF: cb14014561g (data) MusicBrainz: 5c2c3d4c-17ad-42df-bbde-c9b371219123 NLA: 35088926 NKC: xx0150756 BNE: XX4579570 SNAC: w67q337r |

						Retrieved from "https://en.wikipedia.org/w/index.php?title=Robin_Wright&oldid=838439094"

Categories:

1966 births

Living people

20th-century American actresses

21st-century American actresses

Actresses from Dallas

Actresses from San Diego

American film actresses

American soap opera actresses

American television actresses

American television directors

Best Drama Actress Golden Globe (television) winners

Women television directors

William Howard Taft High School (Los Angeles, California) alumni

Hidden categories:

Webarchive template wayback links

Use American English from April 2018

All Wikipedia articles written in American English

Use mdy dates from April 2018

Articles with hCards

Turner Classic Movies person ID same as Wikidata

Wikipedia articles with VIAF identifiers

Wikipedia articles with LCCN identifiers

Wikipedia articles with ISNI identifiers

Wikipedia articles with GND identifiers

Wikipedia articles with BNF identifiers

Wikipedia articles with MusicBrainz identifiers

Wikipedia articles with NLA identifiers

Wikipedia articles with SNAC-ID identifiers

			Navigation menu

						Personal tools

Not logged in

Talk

Contributions

Create account

Log in

						Namespaces

Article

Talk

							Variants

						Views

Read

Edit

View history

						More

							Search

			Navigation

Main page

Contents

Featured content

Current events

Random article

Donate to Wikipedia

Wikipedia store

			Interaction

Help

About Wikipedia

Community portal

Recent changes

Contact page

			Tools

What links here

Related changes

Upload file

Special pages

Permanent link

Page information

Wikidata item

Cite this page

			Print/export

Create a book

Download as PDF

Printable version

			In other projects

Wikimedia Commons

			Languages

العربية

Aragonés

Asturianu

تۆرکجه

Bân-lâm-gú

Български

Brezhoneg

Català

Čeština

Corsu

Cymraeg

Dansk

Deutsch

Ελληνικά

Español

Esperanto

Euskara

فارسی

Français

Galego

한국어

Հայերեն

Hrvatski

Bahasa Indonesia

Italiano

עברית

ქართული

Кыргызча

Македонски

മലയാളം

მარგალური

Bahasa Melayu

Nederlands

日本語

Norsk

Polski

Português

Română

Русский

Scots

Simple English

Српски / srpski

Srpskohrvatski / српскохрватски

Suomi

Svenska

Türkçe

Українська

اردو

粵語

中文
				41 more

Edit links

 This page was last edited on 27 April 2018, at 01:19.

Text is available under the Creative Commons Attribution-ShareAlike License;
additional terms may apply.  By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.

Privacy policy

About Wikipedia

Disclaimers

Contact Wikipedia

Developers

Cookie statement

Mobile view

Enable previews