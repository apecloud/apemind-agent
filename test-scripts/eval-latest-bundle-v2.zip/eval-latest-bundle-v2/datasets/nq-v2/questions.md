# NQ V2 questions

118 题。

## nq-none-001

who discovered africa and what is the meaning of africa

标准答案：(none)

## nq-long_only-002

in passing the all writs act congress gave courts a means of ensuring that

标准答案：The All Writs Act is a United States federal statute, codified at 28 U.S.C. § 1651, which authorizes the United States federal courts to "issue all writs necessary or appropriate in aid of their respective jurisdictions and agreeable to the usages and principles of law."

## nq-long_only-003

who does fiona end up with adventure time

标准答案：Enraged by the deception, Fionna takes out the crystal sword to fight. The sword turns out to be another one of Ice Queen’s tricks and turns into a ball of ice around Fionna’s hands. Cake hears noises from downstairs and senses Fionna is in trouble. Undaunted, Fionna uses the ice to beat Ice Queen over the head. Ice Queen pushes her off with a burst of snow which allows Fionna to get close to enough to break Prince Gumball free and knock out the Ice Queen with a broken icicle. Cake bursts in and

## nq-short-004

who is directly elected according to the constitution

标准答案：senators

## nq-long_only-005

what types of organisms go through anaerobic respiration

标准答案：| Type | Lifestyle | Electron acceptor | Products | Eo' [V] | Example organisms |

| aerobic respiration | obligate aerobes and facultative anaerobes | O2 | H2O, CO2 | + 0.82 | eukaryotes and aerobic prokaryotes |

| iron reduction | facultative anaerobes and obligate anaerobes | Fe(III) | Fe(II) | + 0.75 | Organisms within the order Desulfuromonadales (such as Geobacter, Geothermobacter, Geopsychrobacter, Pelobacter) and Shewanella species [8] |

| manganese | facultative anaerobes and obligate

## nq-long_only-006

what does the number represent in the middle of the wind rose

标准答案：Presented in a circular format, the modern wind rose shows the frequency of winds blowing from particular directions over a specified period. The length of each "spoke" around the circle is related to the frequency that the wind blows from a particular direction per unit time. Each concentric circle represents a different frequency, emanating from zero at the center to increasing frequencies at the outer circles. A wind rose plot may contain additional information, in that each spoke is broken d

## nq-short-007

when did the lion king start on broadway

标准答案：November 13, 1997

## nq-short-008

when was the movie the wizard of oz made

标准答案：1939

## nq-short-009

when does the next apollo book come out

标准答案：May 1, 2018

## nq-yesno-010

are hash browns and tater tots the same

标准答案：no

## nq-short-011

what kind of dog is nana in snow dogs

标准答案：a Border Collie

## nq-none-012

describe any three features of bretton woods agreement

标准答案：(none)

## nq-short-013

who has won the most college football national champions

标准答案：Princeton

## nq-short-014

who ruled the ottoman empire in the 1500s

标准答案：a line of committed and effective Sultans

## nq-long_only-015

jama otolaryngology head and neck surgery impact factor

标准答案：According to the Journal Citation Reports, the journal has a 2016 impact factor of 2.915, ranking it 3rd out of 42 journals in the category "Otorhinolaryngology".[2]

## nq-long_only-016

where does the boston post road start and end

标准答案：| Boston Post Road |

| Routes of the Boston Post Road |

| Major junctions |

| South end | US 1 in New York City |

| North end | Route 1A in Boston |

## nq-short-017

is aluminium a ferrous or non ferrous metal

标准答案：non-ferrous

## nq-short-018

who won the king of dance season 2

标准答案：LAAB Crew From Team Sherif

## nq-none-019

what type of aircraft does the navy fly

标准答案：(none)

## nq-long_only-020

what is the main premise behind the marketing concept

标准答案：Concept testing (to be distinguished from pre-test markets and test markets which may be used at a later stage of product development research)[1] is the process of using surveys (and sometimes qualitative methods) to evaluate consumer acceptance of a new product idea prior to the introduction of a product to the market.[2] It is important not to confuse concept testing with advertising testing, brand testing and packaging testing; as is sometimes done. Concept testing focuses on the basic produ

## nq-short-021

where is lord's prayer found in bible

标准答案：the long form in the Gospel of Matthew in the middle of the Sermon on the Mount, and the short form in the Gospel of Luke

## nq-yesno-022

did mary kate and ashley share the role of michelle

标准答案：yes

## nq-short-023

how are leaders of the two parties in congress chosen

标准答案：Senate Democratic Caucus | Senate Republican Conference

## nq-yesno-024

the shrine dedicated to the god susa-no-o is located in ise

标准答案：yes

## nq-long_only-025

2003 world series of poker main event results

标准答案：| Place | Name | Prize |

| 1st | Chris Moneymaker | $2,500,000 |

| 2nd | Sam Farha | $1,300,000 |

| 3rd | Dan Harrington | $650,000 |

| 4th | Jason Lester | $440,000 |

| 5th | Tomer Benvenisti | $320,000 |

| 6th | Amir Vahedi | $250,000 |

| 7th | Young Pak | $200,000 |

| 8th | David Grey | $160,000 |

| 9th | David Singer | $120,000 |

## nq-none-026

what is the name of the oldest recessional moraine in the huron erie lobe

标准答案：(none)

## nq-none-027

where did the last name locklear come from

标准答案：(none)

## nq-short-028

three act puccini opera first performed in 1900

标准答案：Tosca

## nq-short-029

who has a ring of power in lotr

标准答案：Sauron

## nq-none-030

age of war 2 hands tied behind my back

标准答案：(none)

## nq-short-031

philadelphia is known as the city of what

标准答案：Brotherly Love

## nq-short-032

who is currently serving as president of the senate

标准答案：Orrin Hatch

## nq-none-033

the scorpion king 2 tamil dubbed movie download

标准答案：(none)

## nq-none-034

how many mla and mp seats in telangana

标准答案：(none)

## nq-none-035

who's running for attorney general in michigan

标准答案：(none)

## nq-short-036

what's the largest city park in the united states

标准答案：Franklin Mountains State Park

## nq-none-037

a wrongful or guilty mental state includes the categories of all of the following except

标准答案：(none)

## nq-none-038

lemony snicket's a series of unfortunate events hindi

标准答案：(none)

## nq-short-039

what year is it for the jewish calendar

标准答案：AM 5778

## nq-long_only-040

what is the difference between a janitor and a cleaner

标准答案：A janitor (American English, Scottish English), janitress (female), custodian, porter, cleaner or caretaker is a person who cleans and maintains buildings such as hospitals, schools, and residential accommodation. Janitors' primary responsibility is as a cleaner. In some cases, they will also carry out maintenance and security duties. A similar position, but usually with more managerial duties and not including cleaning, is occupied by building superintendents in the United States (and occasiona

## nq-none-041

how do chemists use systems and order in their work

标准答案：(none)

## nq-none-042

which of the follow statements is true of the eastern orthodox churches

标准答案：(none)

## nq-yesno-043

dutch settlers in south africa were known as boers

标准答案：yes

## nq-short-044

first dynasty to issue gold coins in india

标准答案：The Gupta Empire

## nq-short-045

who played bubba in the heat of the night

标准答案：Carlos Alan Autry Jr.

## nq-short-046

when was the last bear killed in the uk

标准答案：c. 1000 AD

## nq-none-047

baby please don't go because i love you so

标准答案：(none)

## nq-short-048

who is the singer of kal ho na ho

标准答案：Sonu Nigam

## nq-short-049

who is the minister of youth in namibia

标准答案：Erastus Utoni

## nq-none-050

who got their start at the comedy store

标准答案：(none)

## nq-long_only-051

why was it important to have illustrated manuscripts of the bible

标准答案：Displaying the amazing detail and richness of a text, the addition of illumination was never an afterthought. The inclusion of illumination is twofold, it added value to the work, but more importantly it provides pictures for the illiterate members of society to "make the reading seem more vivid and perhaps more credible.”[18]

## nq-short-052

where is the diaphragm located on the human body

标准答案：the inferior thoracic border

## nq-short-053

where did the crown of thorns starfish come from

标准答案：Indo-Pacific

## nq-none-054

how many double doubles does lebron james have this season

标准答案：(none)

## nq-short-055

when does the movie the star come out

标准答案：November 17, 2017

## nq-none-056

what are the provisions of companies act 2013

标准答案：(none)

## nq-long_only-057

where is emma once upon a time season 7

标准答案：| No. overall | No. in season | Title | Directed by | Written by | Original air date [51] | U.S. viewers (millions) |

| 134 | 1 | "Hyperion Heights" | Ralph Hemecker | Edward Kitsis & Adam Horowitz | October 6, 2017 (2017-10-06) | 3.26[52] |

| In a flashback, an 18-year-old Henry says goodbye to Regina as he departs Storybrooke on a trip to new realms, in hopes of finding his own story. Many years later, Henry runs into Cinderella's carriage in the New Enchanted Forest and after a string of ev

## nq-short-058

who did bette midler portray in the rose

标准答案：Mary Rose Foster

## nq-short-059

what is the setting of the story sorry wrong number

标准答案：Manhattan

## nq-short-060

where do they get the hair for a hair transplant

标准答案：back of the head | chest | back | shoulders | torso | legs

## nq-short-061

when was the last time anyone was on the moon

标准答案：December 1972

## nq-short-062

where does what in the sam hill come from

标准答案：simple bowdlerization

## nq-none-063

how old were jersey shore cast first season

标准答案：(none)

## nq-short-064

the vast interior rural area of australia is known as the

标准答案：The Outback

## nq-long_only-065

when did they knock down the berlin wall

标准答案：The Berlin Wall (German: Berliner Mauer, pronounced [bɛʁˈliːnɐ ˈmaʊ̯ɐ] ( listen)) was a guarded concrete barrier that physically and ideologically divided Berlin from 1961 to 1989.[1] Constructed by the German Democratic Republic (GDR, East Germany), starting on 13 August 1961, the Wall cut off (by land) West Berlin from virtually all of surrounding East Germany and East Berlin until government officials opened it in November 1989.[2] Its demolition officially began on 13 June 1990 and finished 

## nq-short-066

where did the battle of freeman's farm take place

标准答案：Stillwater, Saratoga County, New York

## nq-short-067

where does the last name fisher originate from

标准答案：an English occupational name for one who obtained his living by fishing or living by a fishing weir

## nq-none-068

which of the following words have indian roots

标准答案：(none)

## nq-short-069

where is the love meaning of the song

标准答案：lament on various worldwide problems

## nq-none-070

bee gee new york mining disaster 1941 lyrics

标准答案：(none)

## nq-short-071

what type of reaction occurs to form a dipeptide

标准答案：peptide bond

## nq-long_only-072

who is the masked magician in breaking the magician code

标准答案：For a span of two years (1997–1999), Valentino performed, unbilled and disguised, as the "Masked Magician" in four Fox Network television specials called Breaking the Magician's Code: Magic's Biggest Secrets Finally Revealed which exposed long-guarded trade secrets.[4] The Masked Magician was also shown in the UK on the ITV network during the late 1990s and is still occasionally repeated on ITV4. In the US, UK, Canada, and Australia, the show can be seen on Netflix called "Breaking The Magicians

## nq-short-073

when did india win their first cricket match

标准答案：1952

## nq-short-074

when does the chinese new year begin and end

标准答案：at the new moon that falls between 21 January and 20 February

## nq-long_only-075

where did the word john doe come from

标准答案：The name "John Doe" (or "John Doo"), "Richard Roe," along with "John Roe", were regularly invoked in English legal instruments to satisfy technical requirements governing standing and jurisdiction, beginning perhaps as early as the reign of England's King Edward III (1327–1377).[6] Other fictitious names for a person involved in litigation in medieval English law were "John Noakes" (or "Nokes") and "John-a-Stiles" (or "John Stiles").[7]

## nq-long_only-076

who played in the hunchback of notre dame

标准答案：Charles Laughton as Quasimodo[5]

Cedric Hardwicke as Frollo[5]

Thomas Mitchell as Clopin[5]

Maureen O'Hara as Esmeralda[5]

Edmond O'Brien as Gringoire[5]

Alan Marshal as Phoebus[5]

Walter Hampden as Archbishop[5]

Harry Davenport as King Louis XI[5]

Katharine Alexander as Fleur's mother[5]

George Zucco as Procurator[5]

Fritz Leiber as Old nobleman

Etienne Girardot as Doctor[5]

Helene Whitney as Fleur[5]

Mina Gombell as Queen of beggars[5]

Arthur Hohl as Olivier[5]

Curt Bois as Stud

## nq-long_only-077

who is signed to death row records 2017

标准答案：Death Row Records (formerly Tha Row Records) was an American record company founded in 1991 by Dr. Dre, Suge Knight, The D.O.C., and Michael “Harry-O” Harris. Many West Coast artists were on the label, such as: Dr. Dre, Snoop Dogg, Tupac Shakur, The Outlawz, MC Hammer, Young Soldierz, Sam Sneed, Michel'le, Jewell, RBX, The Lady of Rage, Danny Boy, DJ Quik, O.F.T.B., LBC Crew, and the rap group Tha Dogg Pound consisting of Kurupt, Daz Dillinger, Nate Dogg, Soopafly, and many others. Death Row Rec

## nq-short-078

the era of the great mughals began with the accession of

标准答案：Babur

## nq-short-079

distributes the powers between union and state government in federation

标准答案：Part XI of the Indian constitution

## nq-short-080

which financial statement involves all aspects of the accounting​ equation

标准答案：The balance sheet

## nq-long_only-081

who plays claire underwood on house of cards

标准答案：Wright starred as Claire Underwood in the Netflix political drama web television series House of Cards, for which she won the Golden Globe Award for Best Actress – Television Series Drama in 2013, making her the first actress to win a Golden Globe for a web television series. Wright has also received consecutive Primetime Emmy Award nominations in the Outstanding Lead Actress category for House of Cards between 2013 and 2017 and the Outstanding Drama Series category in 2016 and 2017 as a produce

## nq-none-082

what is bound in heaven will be bound on earth

标准答案：(none)

## nq-none-083

how old are the cast of criminal minds

标准答案：(none)

## nq-short-084

where did the world's largest recorded wave occur

标准答案：Lituya Bay in Alaska

## nq-short-085

when did hyderabad became a part of india

标准答案：24 November 1949

## nq-short-086

what does it mean groundhog sees his shadow

标准答案：winter will persist for six more weeks

## nq-short-087

who plays bianca in that's so raven

标准答案：Erica Rivera

## nq-short-088

where does the last name roberts come from

标准答案：Norman

## nq-long_only-089

where did the idea of mickey mouse come from

标准答案：In the spring of 1928, Disney asked Ub Iwerks to start drawing up new character ideas. Iwerks tried sketches of various animals, such as dogs and cats, but none of these appealed to Disney. A female cow and male horse were also rejected. They would later turn up as Clarabelle Cow and Horace Horsecollar. A male frog was also rejected. It would later show up in Iwerks' own Flip the Frog series.[5] Walt Disney got the inspiration for Mickey Mouse from a tame mouse at his desk at Laugh-O-Gram Studio

## nq-short-090

where are the spore containing sori of a fern found

标准答案：on the edge or underside of a fertile frond

## nq-short-091

who dies in transformers revenge of the fallen

标准答案：Ravage and the Decepticon Rampage

## nq-short-092

who are the leaders of the jehovah witnesses

标准答案：Kenneth Cook | Samuel F. Herd | Geoffrey Jackson | Mark Stephen Lett | Gerrit Lösch | Anthony Morris III | Mark Sanderson | David H. Splane

## nq-none-093

where is the word bible written in the bible

标准答案：(none)

## nq-none-094

who played aragorn's son in return of the king

标准答案：(none)

## nq-short-095

which church was given a letter in the book of revelation

标准答案：Ephesus | Smyrna | Pergamum | Thyatira | Sardis | Philadelphia | Laodicea

## nq-yesno-096

do you have to be british to get a cbe

标准答案：no

## nq-long_only-097

mandal wise villages list in east godavari district

标准答案：| # | Amalapuram Division | Etapaka Division[14] | Kakinada Division | Peddapuram Division | Rajahmundry Division | Ramachandrapuram Division[19] | Rampachodavaram division |

| 1 | Atreyapuram | Chinturu | Gollaprolu | Addateegala | Alamuru | Anaparthy | Devipatnam |

| 2 | Ainavilli | Kunavaram | Kakinada (Rural) | Gandepalle | Gokavaram | Biccavolu | Gangavaram |

| 3 | Allavaram | Nellipaka | Kakinada (Urban) | Jaggampeta | Kadiam | K.Gangavaram | Maredumilli |

| 4 | Amalapuram | V.R.Puram 

## nq-short-098

what parts make up the peripheral nervous system

标准答案：nerves and ganglia outside the brain and spinal cord

## nq-short-099

what is the source of electrons during photosynthesis

标准答案：suitable substances, such as water

## nq-none-100

the radiographic term used to describe the more radiopaque bone of the socket and septal crest is

标准答案：(none)

## nq-none-101

what was life like in canada in 1867

标准答案：(none)

## nq-short-102

how long is a uk mobile phone number

标准答案：9 or 10 national (significant) numbers after the "0" trunk code

## nq-none-103

where does the formation of gametes take place

标准答案：(none)

## nq-none-104

which superheroes is not a member of the avengers

标准答案：(none)

## nq-short-105

who were the two mathematicians that invented calculus

标准答案：Isaac Newton | Gottfried Leibniz

## nq-long_only-106

when can a noun be used as an adjective

标准答案：In grammar, a noun adjunct or attributive noun or noun (pre)modifier is an optional noun that modifies another noun; it is a noun functioning as a pre-modifier in a noun phrase. For example, in the phrase "chicken soup" the noun adjunct "chicken" modifies the noun "soup". It is irrelevant whether the resulting compound noun is spelled in one or two parts. "Field" is a noun adjunct in both "field player" and "fieldhouse".[1]

## nq-short-107

where do red ear slider turtles lay eggs

标准答案：a hole

## nq-short-108

when is the new season of wentworth coming out

标准答案：19 June 2018

## nq-short-109

what is the idle line voltage in australia

标准答案：a direct current (DC) potential of −48V to −52V with respect to the tip conductor

## nq-short-110

who challenged the aristotelian model of a geocentric universe

标准答案：Copernicus

## nq-short-111

when was the miraculous journey of edward tulane published

标准答案：March 30, 2006

## nq-short-112

character in macbeth who is murdered and appears as a ghost

标准答案：Lord Banquo

## nq-short-113

when was as you like it first performed

标准答案：uncertain, though a performance at Wilton House in 1603 has been suggested as a possibility

## nq-none-114

when did the ottoman empire start and end

标准答案：(none)

## nq-none-115

which of the following stations has all the three gauges viz. broad metre and narrow

标准答案：(none)

## nq-short-116

when did computer become widespread in homes and schools

标准答案：1980s

## nq-none-117

who sings the 80 song stay with me

标准答案：(none)

## nq-none-118

how many goals have arsenal scored in the premier league

标准答案：(none)
