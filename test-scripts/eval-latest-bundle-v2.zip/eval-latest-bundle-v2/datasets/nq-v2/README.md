NQ V2 冻结测评包

- 题目：118
- 文档：documents/ 118 篇
- 来源：nq-en-v2-source-grounded-20260817
- 建库时上传 documents/ 全部文件
- 按 questions.csv 原文逐题问，一题一次新对话
- 交回答时保留 case_key + answer
