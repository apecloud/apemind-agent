MuSiQue V3 实验集测评包

- 题目：100（2-hop 51 / 3-hop 43 / 4-hop 6）
- 文档：documents/ 1,697 篇（含干扰项，请全部上传）
- 来源：musique-en-v3-experimental-20260818
- 建库时上传 documents/ 全部文件
- 按 questions.csv 原文逐题问，一题一次新对话
- 交回答时保留 case_key + answer
