# MuSiQue V3 questions

100 题。2-hop 51 / 3-hop 43 / 4-hop 6。

## musique-v3-2hop__698577_851686

What is a notable work written by the author of The Timothy files?

标准答案：Anderson Tapes

## musique-v3-2hop__142699_67465

When did the rapper on On and On and Beyond release Best day Ever?

标准答案：March 11, 2011

## musique-v3-2hop__39954_80940

What is the largest national park in the country where hunters are estimated to spend fifty to one hundred times that of the average ecotourist?

标准答案：Ruaha National Park

## musique-v3-2hop__575282_114648

What year did Allegory of Isabella d'Este's Coronation's creator the Younger die?

标准答案：1583

## musique-v3-2hop__124592_402641

Who is the other child of Chian Hsiao-chang's father?

标准答案：Chiang Hsiao-wu

## musique-v3-2hop__36269_63853

What is the source of the river Orlam clans crossed to migrate to Namibia?

标准答案：Thaba Putsoa

## musique-v3-2hop__157737_46621

When was the celestial body that all objects focus on according to Kepler's laws discovered to be the center of the solar system?

标准答案：as early as the 3rd century BC

## musique-v3-2hop__821368_14251

What line by a cast member of Doing His Bit is believed to have started the archie nickname?

标准答案："Archibald, certainly not!"

## musique-v3-2hop__10620_49084

Who plays the legendary figure featured in Historia Regum Britanniae in the show Once Upon a Time?

标准答案：Liam Thomas Garrigan

## musique-v3-2hop__695432_18803

The operator of Brent field announced it was in the process of doing what in April 2010?

标准答案：trying to find a potential buyer for all of its operations in Finland

## musique-v3-2hop__293131_110222

What is the date of birth of the 'Woman with a Parrot' creator?

标准答案：10 June 1819

## musique-v3-2hop__32887_235620

Who fathered Emperor Ai of the Chinese dynasty with the oldest remaining wooden buildings?

标准答案：Emperor Zhaozong of Tang

## musique-v3-2hop__129499_85379

When did the region where Poachie Range is located achieve U.S. statehood?

标准答案：February 14, 1912

## musique-v3-2hop__31585_61048

Who was the US physicist who directed the project that developed the first atomic bomb at the same place where Feynman worked on Water Boiler?

标准答案：Robert Oppenheimer

## musique-v3-2hop__556426_9237

When did the first mosque open where Air Marshall Islands is headquartered?

标准答案：September 2012

## musique-v3-2hop__569582_304416

What record label is the performer of Almost Made Ya signed to?

标准答案：Derrty Entertainment

## musique-v3-2hop__491195_265959

Who is the mother of the composer of Jag tror på sommaren?

标准答案：Lena Olin

## musique-v3-2hop__80637_19033

Where did the wrestler who created the Money in the Bank Ladder Match win in 2008?

标准答案：Great American Bash

## musique-v3-2hop__481349_302087

Which company owns the manufacturer of Learjet 60?

标准答案：Bombardier Inc.

## musique-v3-2hop__249867_557232

Which country is the Desert Forest Golf Club located in?

标准答案：Maricopa County

## musique-v3-2hop__128945_47686

From where do buses leave the city CKIS-FM serves?

标准答案：Toronto Coach Terminal

## musique-v3-2hop__367318_7292

What artist was featured on Smooth Jazz Stations, along with Kenny G and the performer of The Dance?

标准答案：George Benson

## musique-v3-2hop__24976_161105

By how many votes did the person the organizers wanted to arrest survive impeachment?

标准答案：72

## musique-v3-2hop__827995_159109

Where is Amílcar Cabral International Airport?

标准答案：central Atlantic Ocean

## musique-v3-2hop__726892_131968

Which is the body of water by Leo Bennett's place of death?

标准答案：River Thames

## musique-v3-2hop__455392_40315

How many campuses are there in the institution that Desert Studies Center is a part of?

标准答案：12

## musique-v3-2hop__175175_347233

In which county did Snappy Tomato Pizza form?

标准答案：Kenton County

## musique-v3-2hop__263728_705527

Who is the father of the father of Anwer Ali?

标准答案：Ahmad Shah Bahadur

## musique-v3-2hop__200391_44187

In the Tom Hanks movie Castaway, what is the object with the same name as Vance Page's place of death?

标准答案：a Wilson volleyball

## musique-v3-2hop__88834_425488

Who is the mother of the person who plays Nim in Return to Nim's Island?

标准答案：Terri Irwin

## musique-v3-2hop__130867_54221

What time of day can you start purchasing alcohol in the state that includes Narraguagus High School?

标准答案：5am

## musique-v3-2hop__580231_162399

When did the father of Dahyabhai Patel die?

标准答案：15 December 1950

## musique-v3-2hop__423972_540249

Who was the sibling of Nannina de' Medici?

标准答案：Giuliano de' Medici

## musique-v3-2hop__129721_40482

From whom did the Huguenots in the state encompassing Zubly Cemetery purchase land from?

标准答案：Edmund Bellinger

## musique-v3-2hop__35137_22940

What is the Book of Healing by the writer of The Canon of Medicine referred to in Arabic?

标准答案：Kitab al-shifa

## musique-v3-2hop__66_59409

Who was the artist that was featured in Beyonce's first solo album's lead single talking about in the song "Cry"?

标准答案：three different relationships he had in the past

## musique-v3-2hop__286268_97805

Which war did the operator of the R class patrol boat serve in?

标准答案：Winter War

## musique-v3-2hop__1845_38366

What is the population of the borough that contains the neighborhood of Riverdale?

标准答案：1,438,159

## musique-v3-2hop__158275_35739

When was one internet browser's version of Windows 8 made accessible?

标准答案：September 2013

## musique-v3-2hop__41158_35124

How many books were said to have been written by the person who proposed explanations for the origins of earthquakes and the formation of mountains?

标准答案：450

## musique-v3-2hop__819974_129669

In which state is Póvoa de Santa Iria's municipality located?

标准答案：Lisbon District

## musique-v3-2hop__69765_43945

Why is Common Sense, which was written by an author who encouraged revolt, an important work?

标准答案：crystallized the rebellious demand for independence from Great Britain

## musique-v3-2hop__39954_65371

Who is the permanent representative to the united nations of the country where it is estimated that a hunter spends fifty to one hundred times that of the average ecotourist?

标准答案：Modest Jonathan Mero

## musique-v3-2hop__726717_610238

What is the network which National Cycle Route 57 is part of an example of?

标准答案：national cycling route network

## musique-v3-2hop__629030_56873

When did the 1979-80 European Cup winner win the FA Cup?

标准答案：1898 and 1959

## musique-v3-2hop__22885_36240

What specific part of the religious scripture that can be fit into a large, loose definition of legal literature does this document reference for Mary?

标准答案：Genesis 3:15

## musique-v3-2hop__21103_16335

Italians and the group of Jews representing the bulk of modern Jewry may be genetically similar due to what two factors?

标准答案：inter-marriage and conversions in the time of the Roman Empire

## musique-v3-2hop__805610_392181

What did the director of "A Stitch for Time" win at the 54th Academy Awards?

标准答案：Academy Award for Best Documentary (Short Subject)

## musique-v3-2hop__26642_66233

When does the new season of the league where most members of the Buffalo Sabres Alumni Hockey Team are from start?

标准答案：October 3, 2018

## musique-v3-2hop__525581_161450

Where is the province of Aqqala County located?

标准答案：in the north-east of the country south of the Caspian Sea

## musique-v3-2hop__61714_80069

When does Pam and the person Pam marries on The Office get together?

标准答案：in the fourth season

## musique-v3-3hop1__136852_30587_83479

What was the main goal of Germany in the battle of the ocean region adjacent to the city where The Golden Palace is set?

标准答案：to stem the flow of merchant shipping that enabled Britain to keep fighting

## musique-v3-3hop1__857_846_7798

What was the overwhelming ethnic majority in the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：Han nationality

## musique-v3-3hop1__30390_36635_87083

Who holds veto power in the organization that the victors of the conflict active when Hayek began "Abuse of power" were given permanent seats in.

标准答案：permanent members of the United Nations Security Council

## musique-v3-3hop1__131820_59747_43101

The Real Housewives series from the largest city of the state where WEKL transmits started when?

标准答案：October 7, 2008

## musique-v3-3hop1__19768_19788_10117

Widely practiced in the region having the second largest rain-forest in the world, how long ago did this religion arrive in Zhejiang?

标准答案：1,400 years

## musique-v3-3hop1__104762_24918_24991

What went down after the Soviet president visiting the country of citizenship of Yasyn Khamid while the protests were taking place departed from the Kremlin?

标准答案：Soviet flag

## musique-v3-3hop1__68732_39743_24526

What is the average winter daytime temperature in the region where Richmond is found, in the state where the Battle of Fredericksburg was fought?

标准答案：upper 40s–lower 50s °F

## musique-v3-3hop2__92991_28727_76291

When did the political party Alaska generally supports take control of the determiner of rules of the US House and US Senate?

标准答案：January 2015

## musique-v3-3hop1__857_846_7846

Which opera company is based in the city where the Yongle Emperor greeted the leader that the edict was addressed to?

标准答案：Jiangsu Peking Opera Institute

## musique-v3-3hop1__857_846_7888

What are three natural attractions in the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：lush green parks, natural scenic lakes, small mountains

## musique-v3-3hop1__857_846_7877

Who many major sports centers are located in where the Yongle Emporer did great who the edict was addressed to?

标准答案：two

## musique-v3-3hop2__103889_30152_20999

How were the people that the Ajuran Empire declared independence from by minting coins expelled from Zaw Win Thet's country?

标准答案：The dynasty regrouped and defeated the Portuguese

## musique-v3-3hop1__857_846_7794

In 2010, what was the population of the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：8.005 million

## musique-v3-3hop1__857_846_7791

How many parties rule the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：one-party

## musique-v3-3hop1__635099_131926_13165

What treaty ceded territory to the US extending west to the body of water by the city where Write This Down was formed?

标准答案：Treaty of Paris

## musique-v3-3hop1__622497_160088_821792

Who wrote a book about growing up in the same nationality as the man who produced The Wild Women of Chastity Gulch?

标准答案：Min Zhou

## musique-v3-3hop1__857_846_7887

How many tourists does visit annually the city where the Yongle Emperor greeted the one seen addressed on an preserved edict.

标准答案：thousands

## musique-v3-3hop1__857_846_7770

Where does the Yangtze River flow in the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：past the west side and then north side

## musique-v3-3hop1__857_846_7769

How many square miles is the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：2,548 sq mi

## musique-v3-3hop1__857_846_7701

When did the city where the Yongle emperor greeted the person to whom the edict was addressed become the Chinese national capital?

标准答案：Jin dynasty

## musique-v3-3hop1__635099_131926_87157

What is the direction of flow of the body of water by the city where Write This Down was formed?

标准答案：rises in northern Minnesota and meanders slowly southwards

## musique-v3-3hop1__157807_19788_15107

What percentage of Eritrea is estimated to adhere to the religion widely practiced in the region that the tentacled snake is native to?

标准答案：48%

## musique-v3-3hop1__564628_42197_18397

Where did the person who argued that the country where Autograph formed had become an imperialist power declare he would intervene in the Korean conflict?

标准答案：the Politburo

## musique-v3-3hop1__131820_59747_48534

Who is Grant Park, in the largest city by population in the state where WEKL is found, named after?

标准答案：Lemuel P. Grant, a successful engineer and businessman

## musique-v3-3hop1__857_846_7795

In 2011, what was the estimated population of the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：8.11 million

## musique-v3-3hop1__374018_160713_77246

What is the meaning of the word that is also the majority religion in India when the country where Dubbi is located was created in the Arabic dictionary?

标准答案：the country of India

## musique-v3-3hop1__857_846_7890

How many places of higher learning are in the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：75

## musique-v3-3hop1__857_846_7874

What is the name of the major basketball team from the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：Jiangsu Nangang Basketball Club

## musique-v3-3hop1__86965_488922_4093

What is the term for the prime minister in the country where legislators are elected for six year terms?

标准答案：Wazir-e-Azam

## musique-v3-3hop1__857_846_7849

What other types of theater performance are seen in the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：Suzhou pingtan, spoken theatre and puppet theatre

## musique-v3-3hop2__131820_132454_61019

What was the capital of the state where WEKL operates, before the city where Blackberry Smoke was formed?

标准答案：Milledgeville

## musique-v3-3hop1__857_846_7702

What is the meaning of the name of the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案："Southern Capital"

## musique-v3-3hop1__23058_20608_36327

What did Bloomberg name the country formerly known as the region where the Spanish and Portuguese took most of their slaves from?

标准答案：top emerging market economy in Africa

## musique-v3-3hop1__135659_87694_64412

When did the place where St for whom the Mantua Cathedral was named for basilica the head of the catholic religion is located in become its own country?

标准答案：11 February 1929

## musique-v3-3hop2__222979_132957_40768

When did the maker of Acura Legend, the owner of Scion, and Nissan open US assembly plants?

标准答案：1981

## musique-v3-3hop1__79462_91850_685675

What team is the person who hit the first home run at the new stadium where the american league Wildcard game will be played a member of?

标准答案：New York Yankees

## musique-v3-3hop1__857_846_7821

How many miles of highways are in the city where the Yongle emperor greeted the person to whom the edict was addressed?

标准答案：140 mi

## musique-v3-3hop1__139862_2053_52946

When is Celebrity Big Brother coming to the network which, along with ABC and the network which broadcasted Highway to Heaven, is the other major broadcaster based in NY?

标准答案：February 7, 2018

## musique-v3-3hop1__285585_538202_84283

Who is the owner of the record label of the performer of Groovy Little Summer Song?

标准答案：Warner Music Group

## musique-v3-3hop2__573858_326964_7713

How long had the headquarters location of China Sunergy been the capitol city of the headquarters location of Yaxing Coach?

标准答案：about 400 years

## musique-v3-3hop2__565959_223623_162182

In what region of the country containing Mount Can is the birthplace of John Phan located?

标准答案：South Central Coast

## musique-v3-3hop1__140855_2053_5289

What UK label was bought by the company which, along with ABC and the original broadcaster of Then Came Bronson, is the other major broadcaster based in NY?

标准答案：Oriole Records.

## musique-v3-3hop1__239036_15840_36002

What were the Genesis's advantages over the platform of Xexys?

标准答案：built on 16-bit architectures and offered improved graphics and sound

## musique-v3-4hop1__525129_315334_131926_90707

Where does the body of water by the city where the Lots More Blues, Rags and Hollers performer was formed and the Ohio River meet?

标准答案：at the city of Cairo, Illinois

## musique-v3-4hop3__275416_24325_156850_10557

Despite being located in East Belgium, the Carnival of the birth place of Guido Maus harks purely to an area. What was the language having the same name as this area of the era with Fastrada's spouse's name later known as?

标准答案：Medieval Latin

## musique-v3-4hop1__9007_698949_157828_162309

When did the country with a co-official language used in the film titled after the city that is the final resting place of Tito first attend the Olympics games?

标准答案：2016

## musique-v3-4hop1__571599_49925_13759_736921

Where is the district that the person who wanted to reform and address Medardo Joseph Mazombwe's religion preached a sermon on Marian devotion before his death located?

标准答案：Saxony-Anhalt

## musique-v3-4hop3__129456_29339_508306_70744

Between the state university in the state without North Point Mall and where Edwards won the primary and the university in Fort Hill's town which has the more national championships?

标准答案：University of South Carolina

## musique-v3-4hop1__72247_497223_15840_36014

There is a video game named after the sports association that chooses where the super bowl is held. What was Nintendo's limit on games per developer per year on that game's platform?

标准答案：five
