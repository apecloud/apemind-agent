# Lee Sung-min (singer)

Lee Sung-min (born January 1, 1986) is a South Korean singer and actor. He is a member of the South Korean boy band Super Junior and its sub-groups Super Junior-T, Super Junior-H and Super Junior-M.
