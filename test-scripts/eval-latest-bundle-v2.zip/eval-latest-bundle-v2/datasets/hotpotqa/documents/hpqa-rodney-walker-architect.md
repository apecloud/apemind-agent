# Rodney Walker (architect)

Rodney Walker (1910–1986) was a midcentury American modern designer and builder who specialized in residential architecture in the Southern California area. He contributed three designs to Arts & Architecture magazine's Case Study House program during the late 1940s (Case Study House #16, #17, and #18). Many of his homes were photographed by Julius Shulman for "Arts & Architecture" magazine, "Better Homes and Gardens", "Architectural Record", "Sunset", and the "Los Angeles Times Home" magazine.
