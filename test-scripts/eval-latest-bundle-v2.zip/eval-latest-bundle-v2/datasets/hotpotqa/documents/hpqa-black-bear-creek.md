# Black Bear Creek

Black Bear Creek is a 116 mi creek in northern Oklahoma. Black Bear Creek drains an area of 538 sqmi in Garfield County, Noble County and Pawnee County, Oklahoma. It takes on a red color from the red clay of this area. The creek gets its name from the black bear. Though the area is outside of the range of the black bear, sightings have been rumored.
