# Calyptocephalellidae

The Calyptocephalellidae are a family of toads found in Chile containing two genera, "Calyptocephalella" and "Telmatobufo". The "Calyptocephalella" genus contains one species, "C. gayi", the helmeted water toad, which is a large aquatic toad weighing up to 0.5 kg . The "Telmatobufo" genus contains four species, "T. australis", "T. bullocki", "T. ignotus", and "T. venustus". All species within the family are considered threatened, with "T. bullocki" and "T. venustus" being classified as critically endangered.
