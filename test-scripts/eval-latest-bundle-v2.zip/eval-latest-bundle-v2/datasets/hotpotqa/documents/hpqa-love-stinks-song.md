# Love Stinks (song)

"Love Stinks" is a song written by Peter Wolf and Seth Justman that was the title track of the J. Geils Band's 1980 album "Love Stinks". The song was released as a single and peaked in the US at #38, spending three weeks in the Top 40. In Canada, the song reached number 15. Joan Jett covered the song for the soundtrack of the 1996 movie "Mr. Wrong". The song was also featured in the film "Opie Gets Laid". It was also covered by Adam Sandler in the movie "The Wedding Singer" and by Himalayaz with Ms. Toi for the movie "Love Stinks".
