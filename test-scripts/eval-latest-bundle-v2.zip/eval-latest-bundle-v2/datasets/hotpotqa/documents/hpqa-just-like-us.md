# Just Like Us!

Just Like Us! is the fourth studio album by American pop rock group Paul Revere & the Raiders. Produced by Terry Melcher and released on January 3, 1966, by Columbia Records, it featured the U.S. hit single "Just Like Me". Unlike their later albums, on which Mark Lindsay was the primary lead singer, the lead vocal duties on "Just Like Us!" were split among him and the other band members, guitarist Drake Levin, bassist Phil Volk, and drummer Mike Smith.
