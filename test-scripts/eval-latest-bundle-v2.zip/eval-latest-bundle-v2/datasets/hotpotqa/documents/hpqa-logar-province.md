# Logar Province

Logar (Pashto: لوګر‎ ; Dari: لوگَر‎ ‎ ) is one of the 34 provinces of Afghanistan, located in the eastern section of the country. It is divided into seven districts and contains hundreds of villages. Puli Alam is the capital of the province.
