# Battle of La Motta (1513)

The Battle of La Motta, also known as the Battle of Schio, Battle of Vicenza or Battle of Creazzo, took place at Schio, in the Italian region of Veneto, Republic of Venice, on 7 October 1513, between the forces of the Republic of Venice and a combined force of Spain and the Holy Roman Empire, and was a significant battle of the War of the League of Cambrai. A Venetian army under Bartolomeo d'Alviano was decisively defeated by the Spanish/Imperial army commanded by Ramón de Cardona and Fernando d'Avalos.
