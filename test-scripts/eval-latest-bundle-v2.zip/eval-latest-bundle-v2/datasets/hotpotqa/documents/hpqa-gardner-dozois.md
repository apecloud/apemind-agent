# Gardner Dozois

Gardner Raymond Dozois ( ) (born July 23, 1947) is an American science fiction author and editor. He is the founding editor of "The Year's Best Science Fiction" anthologies (1984–present) and was editor of "Asimov's Science Fiction" magazine (1984–2004), garnering multiple Hugo and Locus Awards for those works almost every year. He has also won the Nebula Award for Best Short Story twice. He was inducted by the Science Fiction Hall of Fame on June 25, 2011.
