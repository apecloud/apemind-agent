# Zulu royal family

The Zulu royal family consists of the reigning monarch of the Zulus of South Africa, King Goodwill Zwelithini kaBhekuzulu, his consorts, legitimate descendants, near relatives and male-line descendants of his great-grandfather, King Mpande who, as a half-brother of the Zulu "Pater Patriae", King Shaka, reigned from 1840 to 1872. Shaka's policies and conquests transformed a small clan into one of South Africa's most influential pre-colonial realms, extending over much of what is now KwaZulu-Natal.
