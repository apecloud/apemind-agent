# Behind Enemy Lines II: Axis of Evil

Behind Enemy Lines II: Axis of Evil is a 2006 American war film and the sequel to "Behind Enemy Lines". The film was written and directed by James Dodson, starring Nicholas Gonzalez, Matt Bushell, Keith David, Denis Arndt, Ben Cross, Bruce McGill and Peter Coyote. Justifying its title, the film follows the first part, and was released direct-to-video on October 17, 2006.
