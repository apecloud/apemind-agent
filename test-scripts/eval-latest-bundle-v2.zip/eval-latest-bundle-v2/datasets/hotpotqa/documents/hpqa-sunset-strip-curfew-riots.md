# Sunset Strip curfew riots

The Sunset Strip curfew riots, also known as the "hippie riots", were a series of early counterculture-era clashes that took place between police and young people on the Sunset Strip in Hollywood, California, beginning in the mid-1966 and continuing on and off through the early 1970s.
