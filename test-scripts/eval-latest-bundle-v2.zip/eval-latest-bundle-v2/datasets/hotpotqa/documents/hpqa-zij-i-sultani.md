# Zij-i Sultani

Zīj-i Sultānī (Persian: زیجِ سلطانی‎ ‎ ) is a Zij astronomical table and star catalogue that was published by Ulugh Beg in 1438-1439. It was the joint product of the work of a group of Muslim astronomers working under the patronage of Ulugh Beg at Samarkand's Ulugh Beg Observatory. These astronomers included Jamshīd al-Kāshī and Ali Qushji, among others.
