# 420th Flight Test Flight

The 420th Flight Test Flight is an inactive United States Air Force Reserve squadron. It was last assigned to the 413th Flight Test Group of Air Force Reserve Command at Phoenix-Mesa Gateway Airport, Arizona, where it was inactivated on 31 October 2007.
