# Express Live!

Express Live! (originally the PromoWest Pavilion) is a multi-purpose concert venue located in the Arena District of Columbus, Ohio. Opening in 2001, the venues operates year-round with indoor and outdoor facilities: the Indoor Music Hall and Outdoor Amphitheater. The venue was modeled after the House of Blues and described as the "Newport Music Hall on steroids". It features state-of-the-art lighting, acoustical systems and a reversible stage. In 2001, the venue was nominated for a Pollstar Awards for "Best New Major Concert Venue".
