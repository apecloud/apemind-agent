# The Smoke (TV series)

The Smoke is a British drama that debuted on Sky1 on 20 February 2014. The show is written by Lucy Kirkwood and stars Jamie Bamber, Taron Egerton, Jodie Whittaker and Rhashan Stone.
