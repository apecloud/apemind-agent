# R-Point

R-Point () is a 2004 Korean horror film written and directed by Kong Su-chang. Set in 1972 Vietnam, during the Vietnam War, it stars Kam Woo-sung and Son Byong-ho as members of the South Korean military in Vietnam. Most of the movie was shot in Cambodia. Bokor Hill Station plays a prominent part of the movie, in this case doubling as a colonial French plantation.
