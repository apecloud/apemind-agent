# Maha Kali Mandir

The Maha Kali Mandir is a temple situated on the national highway near the Majitha bypass on the Jalandhar-Rajasansi airport road, in the state of Punjab, India. The temple was built by the late Sh. Ramesh Chander Sharma, and is run by the Mahakali Mandir Trust, currently headed by Mr. Ritesh Kumar Sharma, who runs the trust and organises the events.
