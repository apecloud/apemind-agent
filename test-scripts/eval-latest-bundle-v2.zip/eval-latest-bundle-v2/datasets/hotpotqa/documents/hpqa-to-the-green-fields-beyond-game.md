# To the Green Fields Beyond (game)

To the Green Fields Beyond is a game created in 1978 by SPI, or Simulations Publications Incorporated. It is about the battle of Cambrai, which took place from November 20 to December 7, 1917. At Cambrai, the British and the French tried to use the newly invented tank (land ship as it was called at the time) to break through German front lines.
