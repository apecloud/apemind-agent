# Motherland (2010 film)

Motherland (እናት ሀገር "ˀənatə hägär ") is a 2010 independent documentary film directed and written by Owen 'Alik Shahadah. "Motherland" is the sequel to the 2005 documentary "500 Years Later".
