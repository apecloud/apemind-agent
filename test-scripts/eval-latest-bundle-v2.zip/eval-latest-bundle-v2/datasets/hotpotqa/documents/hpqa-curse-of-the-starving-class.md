# Curse of the Starving Class

Curse of the Starving Class is a play by Sam Shepard, considered the first of a series on family tragedies. Some critics consider it part of a Family Trilogy that includes "Buried Child" (1979) and "True West" (1980). Others consider it part of a quintet that includes "Fool for Love" (1983) and "A Lie of the Mind" (1985). The play was commissioned by Joseph Papp and premiered in London in 1977 before playing at Papp's New York Shakespeare Festival in 1978.
