# Alex Clark

Republican Alex M. Clark (March 22, 1916 – February 14, 1991) was an American politician. He became the youngest mayor of Indianapolis in 1951. He served one term and later ran again in 1967, losing in the primary to eventual winner Richard Lugar. He was a World War II veteran, and a former POW. In 1956 he and a number of friends formed the Wyoming Antelope Hunters Club in Indianapolis, which is still an active social club today. Prior to being mayor, Clark was a deputy prosecutor and judge in Marion County, Indiana.
