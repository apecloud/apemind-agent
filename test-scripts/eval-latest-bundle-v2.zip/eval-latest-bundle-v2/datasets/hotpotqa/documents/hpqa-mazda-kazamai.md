# Mazda Kazamai

The Mazda Kazamai is a concept car made by the Japanese car manufacturer Mazda. It was first introduced at the 2008 Moscow International Motor Show in August.
