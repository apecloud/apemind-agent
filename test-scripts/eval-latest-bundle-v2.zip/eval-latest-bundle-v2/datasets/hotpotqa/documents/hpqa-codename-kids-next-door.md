# Codename: Kids Next Door

Codename: Kids Next Door, commonly abbreviated to Kids Next Door or KND, is an American animated television series created by Tom Warburton for Cartoon Network, and the 13th of the network's "Cartoon Cartoons". The series centers on the adventures of five children who operate from a high-tech tree house, fighting against adult and teen villains with advanced 2×4 technology. Using their codenames (Numbuh 1, Numbuh 2, Numbuh 3, Numbuh 4, and Numbuh 5), they are Sector V, part of a global organization called the Kids Next Door.
