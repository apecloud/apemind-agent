# Shakespeare in the Park (New York City)

Shakespeare in the Park (or Free Shakespeare in the Park) is a theatrical program that stages productions of Shakespearean plays at the Delacorte Theater, an open-air theater in New York City's Central Park. The theater and the productions are managed by the Public Theater and tickets are distributed free of charge on the day of the performance. Originally branded as the New York Shakespeare Festival (NYSF) under the direction of Joseph Papp, the institution was renamed in 2002 as part of a larger reorganization by the Public Theater.
