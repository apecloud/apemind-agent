# Kunturi (Condesuyos)

Kunturi (Aymara for condor, hispanicized spelling "Condori") is a mountain in the Wansu mountain range in the Andes of Peru, about 5208 m high. It is situated in the Arequipa Region, Condesuyos Province, Cayarani District, and in the La Unión Province, Puyca District, northeast of the mountain Hatunpata "(Atunpata)". Kunturi lies south of the river Uqururu (Aymara and Quechua for "Mimulus glabratus", hispanicized "Ojoruro"), also known as Sumana or Cotahuasi, which flows to the Cotahuasi Canyon in the southwest.
