# Palm Springs, Florida

Palm Springs is a village in Palm Beach County, Florida, United States, situated between Greenacres, Lake Clarke Shores, Lake Worth, and West Palm Beach. As of the 2010 United States Census, had a population of 18,928. It is a minor city of the Miami metropolitan area, which was home to an estimated 6,012,331 people at the 2015 census.
