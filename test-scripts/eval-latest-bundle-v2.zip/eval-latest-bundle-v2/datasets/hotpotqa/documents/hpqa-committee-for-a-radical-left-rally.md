# Committee for a Radical Left Rally

ERAS (Committee for a Radical Left Rally, "Επιτροπή για μια Ριζοσπαστική Αριστερή Συσπείρωση") was a far-left organisation in the Republic of Cyprus. It was founded in 2011 by communist and socialist activists in an attempt to organise the people of the radical left in Cyprus. Due to internal disagreement between its various factions ERAS was eventually dissolved in 2014, with one faction forming the bi-communal group "ΔΡΑΣυ-Eyelem" and participating in the Cypriot European Elections of the same year.
