# Arak (drink)

Arak or araq (Arabic: عرق‎ ‎ ) is a Levantine alcoholic spirit (~40–63% Alc. Vol./~80–126 proof, commonly 50% Alc. Vol./100 proof) in the anis drinks family. It is a clear, colorless, unsweetened anise-flavored distilled alcoholic drink. The Persian (Iranian) version of Arak (commonly called Arak Saggi) does not contain anise, as it is usually produced from ‌raisins, dates or saccharum plant. Arak is the traditional alcoholic beverage in the Arab world, especially in the Levant/Mashriq and also in the Maghreb, as well in Iran and Turkey.
