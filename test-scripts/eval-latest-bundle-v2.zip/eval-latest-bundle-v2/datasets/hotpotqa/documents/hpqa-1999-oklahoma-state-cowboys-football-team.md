# 1999 Oklahoma State Cowboys football team

The 1999 Oklahoma State Cowboys football team represented Oklahoma State University during the 1999 NCAA Division I-A football season. They participated as members of the Big 12 Conference in the South Division. They played their home games at Lewis Field in Stillwater, Oklahoma. They were coached by head coach Bob Simmons.
