# Yazidi Book of Revelation

The Yazidi Book of Revelation ("Kitêba Cilwe" in Kurdish; also transliterated as "Kitab Al Jilwah") is one of two books on the Yazidi religion written in the style of a holy book in the Kurmanji dialect of the Northern Kurdish language, the other being the "Yazidi Black Book" ("Mishefa Reş" in Kurdish). It is claimed that the original text of the "Book of Revelation" is kept in the Yazidi village of Ba'idn and the original text of the "Yazidi Black Book" is kept in the village of Qasr 'tzz at-Din.
