# Patrick R. Manning

Patrick R. Manning (born June 9, 1965) is a former New York State Assemblyman. Manning was first elected to the New York State Assembly in 1994.
