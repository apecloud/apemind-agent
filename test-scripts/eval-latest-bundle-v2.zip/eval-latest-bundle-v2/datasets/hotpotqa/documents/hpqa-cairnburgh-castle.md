# Cairnburgh Castle

Cairnburgh Castle is a ruined castle that is located on the islands of Cairn na Burgh Mòr and Cairn na Burgh Beag, Argyll and Bute, Scotland. These islands are at the northern extremity of the Treshnish Isles at the mouth of Loch Tuath, Mull north of Iona. 1991's "The Changing Scottish Landscape" characterizes it as "one of the most isolated fortifications in Britain...[and] also one of the strangest."
