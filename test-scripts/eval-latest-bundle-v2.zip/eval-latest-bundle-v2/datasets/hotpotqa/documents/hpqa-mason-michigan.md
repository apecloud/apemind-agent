# Mason, Michigan

Mason is a city in the U.S. state of Michigan. It is named after the state's first governor, Stevens T. Mason. As of the 2010 census, the city population was 8,252. It is the county seat of Ingham County. Mason is the only city in the U.S. that serves as a county seat ahead of a state capital, with the capital of Lansing also in Ingham County. Despite Mason being the county seat, many county offices and courtrooms are located in Lansing.
