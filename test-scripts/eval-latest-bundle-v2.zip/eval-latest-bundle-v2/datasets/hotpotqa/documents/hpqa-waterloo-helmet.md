# Waterloo Helmet

The Waterloo Helmet (also known as the Waterloo Bridge Helmet) is a pre-Roman Celtic bronze ceremonial horned helmet with repoussé decoration in the La Tène style, dating to circa 150–50 BC, that was found in 1868 in the River Thames by Waterloo Bridge in London, England. It is now on display at the British Museum in London.
