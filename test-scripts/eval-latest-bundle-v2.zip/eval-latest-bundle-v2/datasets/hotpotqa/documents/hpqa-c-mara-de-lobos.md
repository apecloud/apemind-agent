# Câmara de Lobos

Câmara de Lobos (] ; literally, Portuguese: "chamber of the sealions" ) is a municipality, parish and town in the south-central coast of the island of Madeira. Technically a suburb of the much larger capital city of Funchal, it is one of the larger population centres and an extension of the Funchal economy.
