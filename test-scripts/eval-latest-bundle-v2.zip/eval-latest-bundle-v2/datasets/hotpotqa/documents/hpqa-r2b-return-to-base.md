# R2B: Return to Base

R2B: Return to Base () is a 2012 South Korean aviation action drama film loosely based on the critically acclaimed 1986 film Top Gun. The film stars Rain, Shin Se-kyung and Yoo Jun-sang in lead roles. It was directed by Kim Dong-won and is a remake of Shin Sang-ok's 1964 film "Red Scarf". It is about a talented, yet troublemaking, elite air force pilot who is demoted to a combat flying unit. It was released on 15 August 2012. Republic of Korea Air Force was heavily involved to support filming.
