# Klemens von Metternich

Klemens Wenzel Nepomuk Lothar, Prince von Metternich-Winneburg zu Beilstein (15 May 1773 – 11 June 1859) was a German diplomat and statesman and one of the most important of his era, serving as the Austrian Empire's Foreign Minister from 1809 and Chancellor from 1821 until the liberal revolutions of 1848 forced his resignation.
