# Bo Diddley

Ellas McDaniel (born Ellas Otha Bates, December 30, 1928 – June 2, 2008), known as Bo Diddley, was an American R&B singer, guitarist, songwriter and music producer who played a key role in the transition from the blues to rock and roll, and influenced artists including Elvis Presley, Buddy Holly, the Beatles, the Rolling Stones, the Yardbirds, Eric Clapton, the Who, Jimi Hendrix, George Thorogood, Parliament-Funkadelic, and The Clash.
