# Mr. Nepal

The Mr Nepal competition is a male beauty pageant sponsored by the Expose Nepal. It was founded in 2002. The entrants compete in various activities including swimming, mountain climbing, and marathon running. The current Mr Nepal is Sandeep Pokharel of Morang who was crowned on 5 April 2015 in Kathmandu, Nepal. Traditionally, Mr Nepal lives in Kathmandu during his reign.
