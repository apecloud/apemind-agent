# Nain Abidi

Syeda Nain Fatima Abidi (born 23 May 1985 in Karachi; Urdu: ) is an international cricketer from Pakistan. She is a right-handed batsman with good footwork and can bowl too. Abidi holds the all-time record of being first Pakistani player to score a century in women’s one-day internationals. Abidi is a Syed. Abidi was vice captain of the Pakistan women cricket team and is vice captain of her club Ztbl from 2008.
