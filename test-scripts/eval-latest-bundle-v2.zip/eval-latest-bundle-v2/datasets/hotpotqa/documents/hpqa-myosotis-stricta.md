# Myosotis stricta

Myosotis stricta is a plant species of the genus "Myosotis". Common names include strict forget-me-not and blue scorpion grass.
