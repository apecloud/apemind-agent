# SS Ionic (1902)

SS Ionic was a steam-powered ocean liner built in 1902 by Harland and Wolff in Belfast for the White Star Line. She was the second White Star Liner to be named "Ionic" and served on the United Kingdom – New Zealand route. Her sister ships were  and SS "Corinthic" .
