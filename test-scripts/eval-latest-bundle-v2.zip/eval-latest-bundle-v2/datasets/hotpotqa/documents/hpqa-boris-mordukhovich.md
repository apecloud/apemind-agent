# Boris Mordukhovich

Boris Mordukhovich is an American mathematician recognized for his research in the areas of nonlinear analysis, optimization, and control theory. Mordukhovich is one of the founders of modern variational analysis and generalized differentiation. Currently he is Distinguished University Professor and Lifetime Scholar of the Academy of Scholars at Wayne State University (Vice President, 2009-2010 and President, 2010-2011).
