# Dee Ann Story

Dee Ann Story (neé Suhm; December 12, 1931 – December 26, 2010) was an American archaeologist. Story lived in Wimberley, Texas and was a professor at the University of Texas at Austin. Story's best-known excavations were the George C. Davis and Deshazo sites. Story's work with Caddo Mounds State Historic Site, took place in the 1960s and 1970s and pinpointed the timeline of the area. She brought more advanced techniques to the dig, such as radiocarbon dating. Story was also the first woman hired to work as a professional archaeologist for the state of Texas.
