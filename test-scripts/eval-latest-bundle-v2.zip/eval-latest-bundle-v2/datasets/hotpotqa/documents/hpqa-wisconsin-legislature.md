# Wisconsin Legislature

The Wisconsin Legislature is the state legislature of the U.S. state of Wisconsin. The Legislature is a bicameral body composed of the upper house Wisconsin State Senate and the lower Wisconsin State Assembly, both of which have had Republican majorities since January 2011. With both houses combined, the legislature has 132 members representing an equal number of constituent districts. The Legislature convenes at the state capitol in Madison.
