# Phyteuma

Phyteuma is a genus of flowering plants in the family Campanulaceae, native to Europe and Morocco.
