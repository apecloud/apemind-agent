# Shinee World 2013

Shinee World 2013 (promoted as JAPAN ARENA TOUR SHINee WORLD 2013 ～Boys Meet U～) is the second Japan nationwide concert tour by South Korean boy group Shinee to promote their second Japanese studio album, "Boys Meet U". The tour kicked off in Saitama on June 28, 2013 and ended in Nagoya on December 11, 2013 with a total of 15 concerts in 9 cities.
