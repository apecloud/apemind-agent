# Brady Seals (album)

Brady Seals is the self-titled second album by American country music singer Brady Seals. It is his second release independently of the band Little Texas, of which he was a member until 1995. The album includes the singlse "I Fell", "Whole Lotta Hurt" and "The Best Is Yet to Come". All three singles charted on the "Billboard" country charts, although they all missed Top 40.
