# What I Meant to Say

"What I Meant to Say" is a song written by Sam Hogin, Jim McBride and Don Cook, and recorded by American country music artist Wade Hayes. It was released in October 1995 as the fourth and final single from Hayes' debut album "Old Enough to Know Better". The song reached #5 on the "Billboard" Hot Country Songs chart and #15 on the Canadian "RPM" country singles chart. It even charted on the Billboard Hot 200, peaking at #116.
