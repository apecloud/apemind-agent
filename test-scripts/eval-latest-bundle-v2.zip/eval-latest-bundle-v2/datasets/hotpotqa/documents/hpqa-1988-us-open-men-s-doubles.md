# 1988 US Open – Men's Doubles

The Men's Doubles tournament at the 1988 US Open was held from August 29 to September 11, 1988, on the outdoor hard courts at the USTA National Tennis Center in New York City, United States. Sergio Casal and Emilio Sánchez won the title, defeating Rick Leach and Jim Pugh by walkover in the final.
