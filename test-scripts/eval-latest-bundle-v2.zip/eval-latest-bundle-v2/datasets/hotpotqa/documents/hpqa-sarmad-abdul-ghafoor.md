# Sarmad Abdul Ghafoor

Sarmad Ghafoor (born November 5, 1975 in London, United Kingdom) is a Pakistani record producer, guitarist, vocalist, and songwriter. He has released two albums, one with Rungg (his former band), and one with Qayaas (his current band). He has also produced albums for a wide variety of artists, including Atif Aslam, Bilal Khan, Nusrat Hussain, Abbas Ali Khan, and Overload. Sarmad is best known for his work producing two platinum albums for Atif Aslam, including "Jal Pari".
