# Astellas Pharma

Astellas Pharma Inc. (アステラス製薬株式会社 , Asuterasu Seiyaku Kabushiki-gaisha ) is a Japanese pharmaceutical company, formed on 1 April 2005 from the merger of Yamanouchi Pharmaceutical Co., Ltd. (山之内製薬株式会社 , Yamanouchi Seiyaku Kabushiki-gaisha ) and Fujisawa Pharmaceutical Co., Ltd. (藤沢薬品工業株式会社 , Fujisawa Yakuhin Kōgyō Kabushiki-gaisha ) .
