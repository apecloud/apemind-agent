# Collide (film)

Collide is a 2016 action film directed by Eran Creevy and written by Eran Creevy and F. Scott Frazier. The film stars Nicholas Hoult, Felicity Jones, Marwan Kenzari, Ben Kingsley, and Anthony Hopkins. The film was released in the United States on February 24, 2017, by Open Road Films and grossed just $4 million against its $21.5 million budget.
