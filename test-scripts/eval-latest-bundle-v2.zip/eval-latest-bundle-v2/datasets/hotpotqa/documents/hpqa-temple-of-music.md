# Temple of Music

The Temple of Music was a concert hall and auditorium built for the Pan-American Exposition which was held in Buffalo, New York in 1901. U.S. President William McKinley was assassinated inside the building on September 6, 1901. The structure, like most of the other buildings at the exposition, was demolished when the fair ended.
