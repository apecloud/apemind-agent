# Le Grand Chef 2: Kimchi Battle

Le Grand Chef 2: Kimchi Battle (, also known as Le Grand Chef 2: Kimchi Wars) is a 2010 South Korean film starring Kim Jung-eun and Jin Goo. It was released on January 28, 2010.
