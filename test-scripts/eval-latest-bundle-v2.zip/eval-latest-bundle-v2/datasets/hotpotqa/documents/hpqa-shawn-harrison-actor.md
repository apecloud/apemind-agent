# Shawn Harrison (actor)

Shawn Harrison (born December 28, 1973) is an American actor best known for having played Waldo Faldo on the sitcom "Family Matters". He appeared on the ABC series from 1990-1996 as the dim-witted but lovable best friend to characters Eddie Winslow and Steve Urkel and he was also a chef in training on the show as well.
