# Dover Street

Dover Street is a street in Mayfair, London. The street is notable for its Georgian architecture as well as the location of historic London clubs and hotels, which have been frequented by world leaders and historic figures in the arts. It also hosts a number of contemporary art galleries. An equestrian sculpture by Elisabeth Frink stands on the junction of Dover Street and Piccadilly, opposite the Ritz Hotel.
