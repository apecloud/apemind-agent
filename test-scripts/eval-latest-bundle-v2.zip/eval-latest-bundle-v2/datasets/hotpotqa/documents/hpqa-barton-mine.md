# Barton Mine

Barton Mine, also known as Net Lake Mine, is an abandoned surface and underground mine in Northeastern Ontario, Canada. It is located about 0.50 km north of the Temagami Arena in Temagami North and just east of the Ontario Northland Railway in northwestern Strathy Township. Dating back to the early 1900s, it is one of the oldest mines in Temagami. Barton was the site of a fire in the early 1900s, after which it never had active mining again.
