# Melodramma (song)

"Melodramma" is the lead single from Italian pop tenor Andrea Bocelli's 2001 album, "Cieli di Toscana". The song was written by Pierpaolo Guerrini and Paolo Luciani, and is among Bocelli's most popular and well-known songs.
