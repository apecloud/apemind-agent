# Ruskin College

Ruskin College, originally known as Ruskin Hall, Oxford, is an independent educational institution in Oxford, England. It is named after the essayist and social critic John Ruskin (1819–1900) and specialises in providing educational opportunities for adults with few or no qualifications.
