# Istanbul International Music Festival

The Istanbul International Music Festival, formerly Istanbul Festival, (Turkish: Uluslararası İstanbul Müzik Festivali ) is a cultural event held every June and July in Istanbul, Turkey. It offers a selection of European classical music, ballet, opera and traditional music performances with the participations of famous artists from all over the world. The festival was first held in 1973 and is organized by the Istanbul Foundation of Culture and Arts. In 2006, Borusan Holding took over its main sponsorship from Eczacıbaşı Holding.
