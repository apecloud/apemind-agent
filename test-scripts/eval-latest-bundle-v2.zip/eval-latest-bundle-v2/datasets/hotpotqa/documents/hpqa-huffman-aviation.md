# Huffman Aviation

Huffman Aviation was a flight-training school in Venice, Florida at Venice Municipal Airport This flight school has no affiliation with a flight school in Texas with the same name.
