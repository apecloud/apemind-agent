# 1991 Saint Louis Billikens men's soccer team

The 1991 Saint Louis Billikens men's soccer team represented Saint Louis University during the 1991 NCAA Division I men's soccer season. The Billikens played their first season in the now-defunct Great Midwest Conference, where they were the inaugural regular-season and tournament champions. Saint Louis earned an automatic bid to the 1991 NCAA Division I Men's Soccer Tournament, where they had their best NCAA tournament appearance since 1974. Saint Louis reached the College Cup before losing to the eventual national champions, Virginia.
