# Beatties of London

Beatties of London (commonly known as Beatties) was a model retail company of the United Kingdom, not to be confused with the Beatties department store group.
