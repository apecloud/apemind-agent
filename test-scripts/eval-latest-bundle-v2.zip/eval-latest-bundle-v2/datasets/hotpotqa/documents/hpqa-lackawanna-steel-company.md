# Lackawanna Steel Company

The Lackawanna Steel Company was an American steel manufacturing company that existed as an independent company from 1840 to 1922, and as a subsidiary of the Bethlehem Steel company from 1922 to 1983. Founded by the Scranton family, it was once the second-largest steel company in the world (and the largest company outside the U.S. Steel trust). Scranton, Pennsylvania developed around the company's original location. When the company moved to a suburb of Buffalo, New York, in 1902, it stimulated the founding of the city of Lackawanna.
