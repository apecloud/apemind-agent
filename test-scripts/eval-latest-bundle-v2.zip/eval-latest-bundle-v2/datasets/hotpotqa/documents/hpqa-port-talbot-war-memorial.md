# Port Talbot War Memorial

The war memorial at Port Talbot, Wales, commemorates local men killed in the First World War and Second World War. It is located in the Talbot Memorial Park, where it was erected in 1925; the names from the Second World War were added later. It was sculpted by Louis Frederick Roslyn, and was unveiled on 4 July 1925 by Sir William R. Robertson. The park in which it stands was donated to the town by Miss Emily Charlotte Talbot of Margam Castle, and opened to the public in 1926. The memorial has been Grade II* listed since the year 2000.
