# X-cite by Alghanim Electronics

X-cite by Alghanim Electronics (part of Alghanim Industries) is an electronics store currently based in Kuwait. Their product line includes computers & tablets, mobile phones, cameras, TVs, audio & MP3, games & toys, major appliances, small housewares, watches, fitness gear, and home furnishing.
