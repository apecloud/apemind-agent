# Wong Shun Leung

Wong Shun Leung (; 8 May 1935 – 28 January 1997) was a Chinese martial artist from Hong Kong who studied Wing Chun kung fu under Ip Man (葉問) and was credited with training Bruce Lee. In interviews, Wong claimed to have won at least 60, and perhaps over 100, street fights against martial artists of various styles, though these numbers cannot be independently confirmed. Due to his reputation, his students and admirers referred to him as 'Gong Sau Wong' (講手王 or 'King of Talking Hands'). Wong recorded one instructional film entitled "Wing Chun: The science of in-fighting".
