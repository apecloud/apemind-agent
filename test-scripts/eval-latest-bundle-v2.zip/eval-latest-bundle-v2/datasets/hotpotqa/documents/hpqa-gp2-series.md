# GP2 Series

The GP2 Series was a form of open wheel motor racing introduced in 2005 following the discontinuation of the long-term Formula One feeder series, Formula 3000. The GP2 format was conceived by Bernie Ecclestone and Flavio Briatore, while Ecclestone also has the rights to the name GP1. In 2010, the GP3 Series class was launched, as a feeder class for the GP2 series. In 2017, the series was rebranded as the FIA Formula 2 Championship.
