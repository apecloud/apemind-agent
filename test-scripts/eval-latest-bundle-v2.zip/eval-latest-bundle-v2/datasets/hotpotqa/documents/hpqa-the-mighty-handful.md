# The Mighty Handful

The Mighty Handful (Russian: Могучая кучка ), also known as The Five and The New Russian School, were five prominent 19th-century Russian composers who worked together to create a distinctly Russian classical music. Mily Balakirev (the leader), César Cui, Modest Mussorgsky, Nikolai Rimsky-Korsakov and Alexander Borodin all lived in Saint Petersburg, and collaborated from 1856 to 1870.
