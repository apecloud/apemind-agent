# Stewart Spiers

Stewart Spiers was a small but innovative firm of plane-makers in Scotland, founded first of all in Ayr in Ayrshire and continuing under the registered name of Stewart Speirs Ltd ["sic"] in Paisley, Renfrewshire, from c. 1933 until its demise in the mid to late 1930s. Like the Glasgow firm of Alexander Mathieson & Sons, Spiers benefited hugely from the thriving industries on the Firth of Clyde in the latter half of the nineteenth century.
