# Duncan v. Kahanamoku

Duncan v. Kahanamoku, 327 U.S. 304 (1946), was a decision by the United States Supreme Court. It is often associated with the Japanese exclusion cases ("Hirabayashi v. United States", "Korematsu v. United States" and "Ex parte Endo") because it involved wartime curtailment of fundamental civil liberties under the aegis of military authority, though in this case neither the plaintiff nor the nominal defendant were Japanese.
