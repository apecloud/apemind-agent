# Kelsall

Kelsall is a medium-sized agricultural/commuter village and civil parish in the unitary authority of Cheshire West and Chester and the ceremonial county of Cheshire, England. It is located around 8 mi east of Chester, 8 mi west of Northwich and 4 mi north west of Tarporley. The village is situated on Kelsall Hill, a part of the Mid-Cheshire Ridge, the broken line of sandstone hills that divide the west Cheshire Plain from its eastern counterpart. The ridge includes other hills including Peckforton, Beeston, Frodsham and Helsby.
