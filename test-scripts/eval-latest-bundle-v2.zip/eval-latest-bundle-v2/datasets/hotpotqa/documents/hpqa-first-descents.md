# First Descents

First Descents is a charitable non-profit organization that gives a free outdoor adventure experience trip to young adults who are fighting cancer. Brad Ludden, a professional kayaker, founded First Descents in 2001 at age 20.
