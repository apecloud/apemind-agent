# Vada Nobles

Vada Nobles is a record producer and songwriter. He provided production for "Lost Ones" on Lauryn Hill's debut solo album, "The Miseducation of Lauryn Hill" (1998). He co-wrote and co-produced the Rihanna song "Pon de Replay." He co-wrote and co-produced the Hilary Duff singles "With Love" and "Stranger" in addition to the album track "Danger" on her 2007 album "Dignity". He also produced remixes for the Hilary Duff singles "Play with Fire" and "Stranger."
