# Castillo de Tabernas

Castillo de Tabernas is a ruined castle on the outskirts of the municipality of Tabernas, Almería province, in the autonomous community of Andalusia, Spain. It was built in the 11th century during the time of Arab domination. It is of Moorish style and is situated on top of a hill. When it was built, it occupied the entire hill, though currently only a part is preserved. In 1993, it was declared a Bien de Interés Cultural monument. During the siege of Almeria, Ferdinand and Isabella ensconced themselves in the castle.
