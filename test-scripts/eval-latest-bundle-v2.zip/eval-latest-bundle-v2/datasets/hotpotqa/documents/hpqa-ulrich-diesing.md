# Ulrich Diesing

Ulrich Diesing (12 March 1911 – 17 April 1945) was a German pilot in the Luftwaffe during World War II. He was a recipient of the Knight's Cross of the Iron Cross of Nazi Germany. 17 April 1945, Ulrich Diesing was killed in an accident near Boizenburg, Nazi Germany. During his career he was credited with 15 aerial victories.
