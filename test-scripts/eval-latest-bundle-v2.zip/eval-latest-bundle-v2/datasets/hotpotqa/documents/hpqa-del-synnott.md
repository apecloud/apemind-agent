# Del Synnott

Del Synnott (born 1977) is an Irish actor, perhaps best known for playing Froderick in "Princess of Thieves" and DC Alan Carter in "Murphy's Law". He was born and raised in Dublin, Ireland and when he was 11 years old, he and his family moved to Essex, England. He has also appeared in the TV version of "Lock Stock and Two Smoking Barrels" titled "Lock Stock" and the Samuelson Productions feature "Stormbreaker". In 2013, he appeared in "The Great Train Robbery" as Brian Field.
