# Michelle Terry

Michelle Terry is an Olivier award winning English actress and writer, known for extensive work for Shakespeare’s Globe, RSC, National Theatre and television work, notably writing and starring in Sky's "The Café". Terry will take up the role of artistic director at Shakespeare's Globe in April 2018 .
