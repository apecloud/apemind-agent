# Izara Aishah

Izara Aishah binti Hisham (born 28 September 1992) or professionally known as Izara Aishah is a Malaysian actress and model. She debuted in 2011 and since then has starred in dramas, telemovies, television and movies.
