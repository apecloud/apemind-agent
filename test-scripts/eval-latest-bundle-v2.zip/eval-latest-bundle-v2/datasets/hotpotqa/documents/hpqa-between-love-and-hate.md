# Between Love and Hate

Between Love and Hate (also known as The Unbearable Lightness of Dating) is a 2006 South Korean film starring Kim Seung-woo and Jang Jin-young, and is the directorial debut of screenwriter Kim Hae-gon. Jang's performance won her Best Actress at the 2006 Korean Film Awards. This would be Jang Jin-young's final film before her death almost 3 years later.
