# Plácido Domingo Ferrer

Plácido Domingo Ferrer (8 March 1907 – 22 November 1987) was a Spanish zarzuela baritone and father of popular operatic tenor Plácido Domingo. Half Catalan and half Aragonese, he grew up and made his early career in Zaragoza, the capital of Aragon. He frequently toured Spain with his soprano wife Pepita Embil. In late 1948, they permanently moved to Mexico, where they successfully ran their own zarzuela company. He also appeared in recordings and on Mexican television.
