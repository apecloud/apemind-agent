# Tetrastigma

Tetrastigma is a genus of plants in the grape family, Vitaceae. The plants are lianas that climb with tendrils and have palmately compound leaves. The species are found in subtropical and tropical regions of Asia, Malaysia, and Australia, where they grow in primary rainforest, gallery forest and monsoon forest and moister woodland. Species of this genus are notable as being the sole hosts of parasitic plants in the family Rafflesiaceae, one of which, "Rafflesia arnoldii", produces the largest single flower in the world.
