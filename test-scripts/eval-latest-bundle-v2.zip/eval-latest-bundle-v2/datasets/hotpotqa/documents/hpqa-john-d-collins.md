# John D. Collins

John Christopher Dixon (born 2 December 1942 in London) billed as John D. Collins, is an English actor and narrator, perhaps best known for appearing in the BBC sitcom "'Allo 'Allo!" in which he played Flt. Lt. Fairfax, a stranded British airman in occupied France during World War II. He is the actor to have been cast most frequently in writer/producer David Croft's hit sitcoms: a total of six different series and ten characters.
