# The Many Adventures of Winnie the Pooh

The Many Adventures of Winnie the Pooh is a 1977 American animated film produced by Walt Disney Productions and distributed by Buena Vista Distribution. It is the 22nd Disney animated feature film and was first released on March 11, 1977 on a double bill with "The Littlest Horse Thieves".
