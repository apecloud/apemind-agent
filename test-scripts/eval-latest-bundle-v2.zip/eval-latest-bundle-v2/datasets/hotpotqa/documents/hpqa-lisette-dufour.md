# Lisette Dufour

Lisette Dufour (Born 1949) is a Québécoise voice actress who is better known as the French voice of Lisa Simpson on "The Simpsons".
