# Monroe City Regional Airport

Monroe City Regional Airport (FAA LID: K52) is a public use airport located one nautical mile (1.85 km) south of the central business district of Monroe City, in Monroe County, Missouri, United States. It is owned by the City of Monroe and is also known as Capt. Ben Smith Airfield.
