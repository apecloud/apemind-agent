# Buddleja 'White Ball'

Buddleja 'White Ball' is a hybrid cultivar developed by Horticultural Research International, at Boskoop in the Netherlands. One of the parents was the white form of "B. davidii" var. "nanhoensis", 'Alba'.
