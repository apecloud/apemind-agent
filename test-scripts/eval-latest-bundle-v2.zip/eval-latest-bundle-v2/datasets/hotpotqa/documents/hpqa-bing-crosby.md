# Bing Crosby

Harry Lillis "Bing" Crosby Jr. ( ; May 3, 1903 – October 14, 1977) was an American singer and actor. Crosby's trademark warm bass-baritone voice made him the best-selling recording artist of the 20th century, having sold over one billion records, tapes, compact discs and digital downloads around the world.
