# Bioshaft

BioShaft is a Venezuelan alternative funk rock band formed in 2010 by Henry Ollarves (vocals, bass) Andres Blanco (guitar) and Javier Maimone (drums), directly influenced from the rock of the early 90's and the 70's bluesy… it is all about jams, guitar solos and a combination between the dark sounds of grunge and the groove of soul and funk.
