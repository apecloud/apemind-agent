# Betriebsobmann

Betriebsobmann was a political position of the Nazi Party which existed between the years 1939 and 1945. The term first came into being at the start of World War II and was unique only to the local level of the Nazi Party, known as the "Ortsgruppen".
