# Luhan (entertainer)

Lu Han (born (1990--)20 1990 ), also known as Luhan, is a Chinese singer and actor. He was a member of the South Korean-Chinese boy group EXO and its sub-group EXO-M, before leaving the group in October 2014. That year, he was ranked the sixth most popular entertainment star in China by China National Radio.
