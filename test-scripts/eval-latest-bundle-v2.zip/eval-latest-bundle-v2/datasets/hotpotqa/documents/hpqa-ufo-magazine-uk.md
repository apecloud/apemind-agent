# UFO Magazine (UK)

UFO Magazine was a British magazine devoted to the subject of unidentified flying objects (UFOs) and extraterrestrial life. It was founded in 1981 by brothers Graham and Mark Birdsall of Leeds, Yorkshire. The magazine was one of the success stories of ufology, with an international reputation for quality and a peak circulation of 35,000.
