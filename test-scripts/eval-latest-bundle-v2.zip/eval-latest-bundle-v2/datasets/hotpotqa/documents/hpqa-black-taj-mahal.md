# Black Taj Mahal

The Black Taj Mahal ("Black Taj", "Kaala Taj", also "the 2nd Taj") is a legendary black marble mausoleum that is said to have been planned to be built across the Yamuna River opposite the Taj Mahal in Agra, Uttar Pradesh, India. Mughal emperor Shah Jahan is said to have desired a mausoleum for himself similar to that of the one he had built in memory of his third wife, Mumtaz Mahal.
