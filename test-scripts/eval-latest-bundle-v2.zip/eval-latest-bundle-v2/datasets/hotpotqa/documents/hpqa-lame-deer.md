# Lame Deer

Lame Deer (died 1877) (Miniconjou Lakota), was a Wakpokinyan band leader (vice chief). This group of Lakota were opposed to agreeing to the 1868 Treaty of Fort Laramie, which required the Lakota to cede much of their territory to the United States. He was present at the 1876 Battle of the Greasy Grass, also known as the Battle of the Little Bighorn, where the combined Lakota and allied forces dealt an overwhelming defeat to United States forces.
