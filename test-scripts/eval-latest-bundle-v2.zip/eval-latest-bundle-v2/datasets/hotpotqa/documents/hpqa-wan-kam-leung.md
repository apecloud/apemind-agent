# Wan Kam Leung

Wan Kam Leung (; born 1945) is a Chinese martial artist and qigong practitioner who developed and currently teaches Practical Wing Chun in Kowloon, Hong Kong. Wan studied Wing Chun kung fu under Wong Shun Leung
