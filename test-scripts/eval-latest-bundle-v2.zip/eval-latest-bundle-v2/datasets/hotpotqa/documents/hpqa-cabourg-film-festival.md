# Cabourg Film Festival

The Cabourg Film Festival (French: Festival du Film de Cabourg – Journées romantiques or simply Festival du Film de Cabourg ) is an annual film festival held every June in Cabourg, France. Founded in 1983 by writer-journalist Gonzague Saint Bris, the festival is dedicated to films in the romantic genre and films with elements of romanticism.
