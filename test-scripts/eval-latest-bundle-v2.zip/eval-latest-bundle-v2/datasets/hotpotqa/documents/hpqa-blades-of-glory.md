# Blades of Glory

Blades of Glory is a 2007 American comedy film directed by Josh Gordon and Will Speck, written by John Altschuler, Jeff Cox, Craig Cox and Dave Krinskyand and starring Will Ferrell and Jon Heder. The movie was produced by MTV Films, Red Hour and Smart Entertainment and released on March 30, 2007 by DreamWorks Pictures.
