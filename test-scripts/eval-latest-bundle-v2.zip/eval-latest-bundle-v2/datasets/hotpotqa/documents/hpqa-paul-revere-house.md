# Paul Revere House

The Paul Revere House (1680) was the colonial home of American patriot Paul Revere during the time of the American Revolution. A National Historic Landmark, it is located at 19 North Square, Boston, Massachusetts, in the city's North End, and is now operated as a nonprofit museum by the Paul Revere Memorial Association. An admission fee is charged.
