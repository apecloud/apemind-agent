# Gary Oldman

Gary Leonard Oldman (born 21 March 1958) is an English actor, filmmaker, musician and author who has performed in theatre, film and television. He is known for his "big" acting style and on-screen diversity.
