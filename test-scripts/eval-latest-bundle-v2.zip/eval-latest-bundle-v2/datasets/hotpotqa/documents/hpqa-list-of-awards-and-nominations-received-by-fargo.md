# List of awards and nominations received by Fargo

This is a list of awards and nominations for "Fargo", an American black comedy–crime drama anthology television series that debuted on FX on April 15, 2014. The series stars Billy Bob Thornton, Allison Tolman, Colin Hanks, Martin Freeman, Kirsten Dunst, Patrick Wilson, Jesse Plemons, Jean Smart, Ted Danson, Ewan McGregor, Carrie Coon, Mary Elizabeth Winstead, Goran Bogdan, and David Thewlis.
