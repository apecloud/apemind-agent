# Miracle of the White Stallions

Miracle of the White Stallions is a 1963 film released by Walt Disney starring Robert Taylor (playing Alois Podhajsky), Lilli Palmer, and Eddie Albert. It is the story of the evacuation of the Lipizzaner horses from the Spanish Riding School in Vienna during World War II.
