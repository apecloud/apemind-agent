# Giorgio Chiellini

Giorgio Chiellini (] ; born 14 August 1984) is an Italian professional footballer who plays as a defender for Serie A club Juventus and the Italian national team. A physically strong, aggressive, and versatile defender, although he is usually deployed as a centre-back, he is also capable of playing as a left-back, both in a three or four-man defence.
