# The Cellar (Enfield, North Carolina)

The Cellar is a historic home located at Enfield, Halifax County, North Carolina. It dates to the early-19th century, and is a large two-story, five bay, frame dwelling with an attached one-story kitchen. It has exterior brick end chimneys and is covered with a rather steep gable roof. It was the childhood home of Congressman and Confederate General Lawrence O'Bryan Branch (1820-1862). The house was visited by the Marquis de Lafayette during his grand tour.
