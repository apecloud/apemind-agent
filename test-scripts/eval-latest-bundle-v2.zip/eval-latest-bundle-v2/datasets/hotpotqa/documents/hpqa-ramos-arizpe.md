# Ramos Arizpe

Ramos Arizpe (] ) is a city and seat of the surrounding municipality of the same name in the Mexican state of Coahuila. Ramos Arizpe is located 11 km from the state capital of Saltillo. It is part of the Saltillo metropolitan area. The city reported a population of 48,228 in the 2005 census; the municipality had a population of 56,708. Its area is 5,306.6 km² (2,048.9 sq mi).
