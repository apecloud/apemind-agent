# Hotpoint

The Hotpoint Electric Heating Company (generally known simply as Hotpoint) is an American and European brand of domestic appliances. Ownership of the brand is split between the American company Whirlpool, which has European rights, and Chinese company Haier, which has North American rights since its purchase of GE Appliances.
