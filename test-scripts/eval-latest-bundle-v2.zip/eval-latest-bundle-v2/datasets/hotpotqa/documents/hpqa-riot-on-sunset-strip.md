# Riot on Sunset Strip

Riot on Sunset Strip is a 1967 counterculture-era exploitation movie, released by American International Pictures. It was filmed and released within four months of the late-1966 Sunset Strip curfew riots.
