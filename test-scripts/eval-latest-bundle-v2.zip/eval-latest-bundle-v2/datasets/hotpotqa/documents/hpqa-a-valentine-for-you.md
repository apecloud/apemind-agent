# A Valentine for You

Winnie the Pooh: A Valentine for You is a Valentine's Day special based on the Disney television series "The New Adventures of Winnie the Pooh" as well as A. A. Milne's treasured stories, originally broadcast on February 13, 1999. This is the final role of Paul Winchell as Tigger (besides his performance as Tigger for the Many Adventures of Winnie the Pooh attraction at Walt Disney World Resort) before his retirement from the role in the same year and his death six years later. It was released on VHS in 2000 and 2001 also released on DVD in 2004 and 2010.
