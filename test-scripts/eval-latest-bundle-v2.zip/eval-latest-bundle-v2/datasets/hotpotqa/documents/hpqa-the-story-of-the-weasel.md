# The Story of the Weasel

Published in 1976, The Story of the Weasel is author Carolyn Slaughter's debut novel. It won the Geoffrey Faber Memorial Prize the following year. Published as Relations in the United States, it has been praised for its 'sensitive treatment of fraternal incest in Victorian England and for its subtle poetic prose'.
