# It's the Most Wonderful Time of the Year

"It's the Most Wonderful Time of the Year" is a popular Christmas song written in triple time in 1963 by Edward Pola and George Wyle. It was recorded and released that year by pop singer Andy Williams for his first Christmas album, "The Andy Williams Christmas Album". However, the song was not released as a promotional single by Williams' record label (Columbia Records) that year, as they instead opted to promote his cover of "White Christmas" as the official promo single from the album.
