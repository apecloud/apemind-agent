# Ethiopian Legal Information Website

The Ethiopian Legal Information Website is an online database of laws in Ethiopia. It aims to provide the public, researchers, professors, law firms and legal professionals access to the basic laws on the web and other digital formats. It was developed by Mekelle University Law Faculty in Ethiopia in cooperation with the Non-Western Law Department of Ghent University in Belgium. While it contains only the laws of the federal government at this moment, it plans adding state, regional and other laws.
