# Requiem for a Dying Planet

Requiem for a Dying Planet (subtitled Sounds for Two Films by Werner Herzog is an album by cellist Ernst Reijseger featuring music for Werner Herzog's 2004 documentary "The White Diamond" and 2005 film "The Wild Blue Yonder" performed with vocalist/poet/performer Mola Sylla and the Voches de Sardinna. The original tracks were recorded in 2004 in France and Germany and additional recording undertaken in Germany in 2006 before the album was released on the Winter & Winter label.
