# Girolamo da Montesarchio

The Italian Capuchin Girolamo da Montesarchio spent twenty years in the mid-17th century in the Kingdom of Kongo in West Africa. His manuscript account, "Viaggio al Congho", provides modern historians a rich source of information on the region's history and society. The manuscript, preserved in the Archivio Provinciale dei Cappucini di Provincia di Toscana, Montughi Convent, Florence, was first edited and published in 1976. Montesarchio's account supplements the material in Giovanni Cavazzi da Montecuccolo's "Istorica descrizione", printed in 1687.
