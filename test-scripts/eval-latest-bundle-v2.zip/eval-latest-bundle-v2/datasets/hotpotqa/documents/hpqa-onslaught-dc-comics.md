# Onslaught (DC Comics)

The Onslaught (formerly known as the Jihad) are a fictional team of state sponsored super powered Quraci terrorists published by DC Comics. They first appeared in "Suicide Squad" volume 1 #1, and were created by John Ostrander and Luke McDonnell.
