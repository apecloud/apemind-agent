# Stephen R. Donaldson

Stephen Reeder Donaldson (born May 13, 1947) is an American fantasy, science fiction and mystery novelist, most famous for "The Chronicles of Thomas Covenant", his ten-novel fantasy series. His work is characterized by psychological complexity, conceptual abstractness, moral bleakness, and the use of an arcane vocabulary, and has attracted critical praise for its "imagination, vivid characterizations, and fast pace". He earned his bachelor's degree from The College of Wooster and a Master's degree from Kent State University. He currently resides in New Mexico.
