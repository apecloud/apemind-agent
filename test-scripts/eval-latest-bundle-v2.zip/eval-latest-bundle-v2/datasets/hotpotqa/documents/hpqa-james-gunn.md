# James Gunn

James Gunn (born August 5) is an American screenwriter, director, producer, novelist, actor, and musician. He started his career as a screenwriter in the mid-1990s, writing the scripts for "Tromeo and Juliet" (1996), "Scooby-Doo" (2002) and its sequel "" (2004), and the 2004 version of "Dawn of the Dead". He then started working also as a director, starting with "Slither" (2006). He subsequently wrote and directed the web series "James Gunn's PG Porn", and the superhero films "Super" (2010), "Guardians of the Galaxy" (2014) and "Guardians of the Galaxy Vol. 2" (2017).
