# Robin Hood (Once Upon a Time)

Robin of Locksley, later known as Robin Hood, is a fictional character in ABC's television series "Once Upon a Time". He is portrayed by British actor/singer Sean Maguire, who became a series regular in the fifth season after making recurring appearances in the third and fourth season. He is the second actor to play the role in the series, as it was first played by Tom Ellis in the second season, but scheduling conflicts prevented Ellis from reprising the role, resulting in Maguire taking the role afterwards.
