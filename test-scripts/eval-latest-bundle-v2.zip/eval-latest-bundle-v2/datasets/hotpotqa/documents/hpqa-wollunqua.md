# Wollunqua

In Australian aboriginal mythology, Wollunqua (or Wollunka, Wollunkua) is a snake-god of rain and fertility, who emerged from a watering hole in the Murschison Mountains. Wollunqua is said to be many miles long.
