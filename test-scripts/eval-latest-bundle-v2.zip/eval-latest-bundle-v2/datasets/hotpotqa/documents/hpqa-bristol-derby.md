# Bristol derby

The Bristol derby is the name given to football matches played between Bristol City and Bristol Rovers (a "local derby"). The fans of each club both consider the other to be their main rivals, leading to a heated atmosphere at these matches. The majority of the meetings between the teams have been in the Football League, and they used to meet annually in the Gloucestershire Cup.
