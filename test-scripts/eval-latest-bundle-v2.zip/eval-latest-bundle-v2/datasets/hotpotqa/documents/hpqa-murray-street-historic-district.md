# Murray Street Historic District

Murray Street Historic District is a national historic district located at Mount Morris in Livingston County, New York. The districts consists of the 16 properties on Murray Street between Eagle Street and Stanley Street. The district includes 16 contributing primary buildings, all residences; six contributing outbuildings, carriage houses and garages; and three contributing objects, a carriage step, hitching post, and early 20th century street lights.
