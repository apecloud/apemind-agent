# Nuremberg Trials (film)

The Nuremberg Trials is a 1947 Soviet-made documentary film about the trials of the Nazi leadership. It was produced by Roman Karmen, and was an English-language version of the Russian language film "Суд народов" (Judgment of the Peoples).
