# Liam Cunningham (politician)

Liam Cunningham (25 January 1915 – 29 February 1976) was an Irish Fianna Fáil politician. He was born in County Donegal in 1915. A qualified national school teacher, Cunningham was first elected to Dáil Éireann as a Fianna Fáil Teachta Dála (TD) for the Donegal East constituency at the 1951 general election. At the time the senior Fianna Fáil TD was Neil Blaney who would subsequently become a Government Minister. From 1961 onwards, he was elected for the Donegal North-East constituency.
