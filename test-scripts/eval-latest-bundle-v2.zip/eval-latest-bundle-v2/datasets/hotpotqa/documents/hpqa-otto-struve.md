# Otto Struve

Otto Struve (August 12, 1897 – April 6, 1963) was a astronomer. In Russian, his name is sometimes given as Otto Lyudvigovich Struve (Отто Людвигович Струве); however, he spent most of his life and his entire scientific career in the United States. Otto was the descendant of famous astronomers of the Struve family; he was the son of Ludwig Struve, grandson of Otto Wilhelm von Struve and great-grandson of Friedrich Georg Wilhelm von Struve. He was also the nephew of Karl Hermann Struve.
