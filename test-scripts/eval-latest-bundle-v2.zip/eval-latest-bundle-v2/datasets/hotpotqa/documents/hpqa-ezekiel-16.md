# Ezekiel 16

Ezekiel 16 is the sixteenth chapter of the Book of Ezekiel in the Hebrew Bible or the Old Testament of the Christian Bible. This book contains the prophecies spoken by the prophet Ezekiel, and is a part of the Books of the Prophets. Clements calls this chapter "an Old Testament parable of the prodigal daughter", describing a shocking illustration eof ungrateful Jerusalem in contrast to God's enduring love to her. This chapter is often linked to Ezekiel 23 which deals with two daughters, symbolizing the Kingdoms of Israel and Judah.
