# Final Recipe

Final Recipe is a 2013 South Korean-Thai drama film directed by Gina Kim and written by George Huang, who adapted a story by Kim. It stars Michelle Yeoh, Henry Lau, and Chin Han. Lau plays a young man who must impress the host of a cooking show (Yeoh) and her chef husband (Han) to save his grandfather's restaurant. It premiered at the San Sebastián International Film Festival.
