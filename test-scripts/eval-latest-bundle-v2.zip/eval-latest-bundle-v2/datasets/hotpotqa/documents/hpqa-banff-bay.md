# Banff Bay

Banff Bay is a coastal embayment in Scotland situated between the towns of Banff, Aberdeenshire and Macduff, Aberdeenshire. The Burn of Myrehouse is one of the streams draining to Banff Bay. Banff Bay is a prominent geographical feature along the northern coast of Aberdeenshire, and it is visible from a number of locations along the coastal plain such as Longman Hill situated somewhat distant to the east.
