# One Night Only with Ricky Martin

One Night Only with Ricky Martin (also known as Una Noche con Ricky Martin) was the worldwide concert tour by Puerto Rican singer Ricky Martin, in support of his 2005 album "Life". The tour visited the Americas, Europe, Asia and Africa.
