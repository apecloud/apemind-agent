# Let's Dance 2011

Let's Dance 2011 is the sixth season of the Swedish version of Strictly Come Dancing, and was broadcast on the Swedish television channel TV4 starting on January 7, 2011.
