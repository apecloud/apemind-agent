# Lope Díaz de Haro (d. 1322)

Lope Díaz de Haro (b. ? - d. October, 1322) was a Spanish noble of the House of Haro, the traditional Lords of Biscay. He was the firstborn son of Diego Lopez V de Haro, Lord of Biscay. Whilst he did not inherit his father's title of Lordship over Biscay, he is best known for being the lord of Orduña-Urduña and of Balmaseda. He further served as Alférez to King Ferdinand IV of Castile.
