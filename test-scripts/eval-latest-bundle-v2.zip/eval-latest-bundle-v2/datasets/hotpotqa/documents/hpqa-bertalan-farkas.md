# Bertalan Farkas

Bertalan Farkas (born August 2, 1949) is the first Hungarian cosmonaut and the first Esperantist in space. He is currently the president of Airlines Service and Trade. With Charles Simonyi's travel, Farkas is no longer the only Hungarian who has been to space (he is still the only astronaut, as Simonyi flew as a space tourist).
