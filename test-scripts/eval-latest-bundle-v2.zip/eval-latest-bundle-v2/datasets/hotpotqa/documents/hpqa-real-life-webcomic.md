# Real Life (webcomic)

Real Life is an American webcomic drawn and authored by Greg Dean, begun on November 15, 1999. The comic is loosely based around the lives of fictionalized versions of Dean and his friends, including verbatim conversations, as well as fictional aspects including time travel and mecha combat. Characters regularly break the fourth wall. "Real Life" focuses on humor related to video games and science fiction, and references internet memes.
