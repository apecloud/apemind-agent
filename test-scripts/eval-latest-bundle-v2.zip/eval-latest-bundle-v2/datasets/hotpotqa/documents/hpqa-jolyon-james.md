# Jolyon James

Jolyon James is an Australian-born actor. He performed the role of the Moonshadow in Cat Stevens's musical of the same name which is played in Melbourne’s Princess Theatre for 12 weeks from 31 May 2012.
