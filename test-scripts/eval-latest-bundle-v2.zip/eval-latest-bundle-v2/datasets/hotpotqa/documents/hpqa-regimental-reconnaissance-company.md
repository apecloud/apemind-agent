# Regimental Reconnaissance Company

The 75th Ranger Regiment's Regimental Reconnaissance Company (formerly known as Regimental Reconnaissance Detachment/RRD) is an elite special operations force that is rumored to be the newest operational member of the Joint Special Operations Command. The unit is believed to have become part of JSOC in 2007 due to its extensive training and unique capabilities to conduct special reconnaissance and close target reconnaissance (CTR) operations, and advanced force operations (AFO). It is often referred as a Special Mission Unit (SMU).
