# SEAL Team 8: Behind Enemy Lines

SEAL Team 8: Behind Enemy Lines is a 2014 American war film directed by Roel Reiné and starring Tom Sizemore. It is the fourth installment in the "Behind Enemy Lines" series. The film was released on direct-to-video and Blu-ray on April 1, 2014.
