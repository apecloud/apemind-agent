# Mountbatten family

The Mountbatten family is a European dynasty originating as a branch of the German princely Battenberg family. The name was adopted during World War I by family members residing in the United Kingdom due to rising anti-German sentiment amongst the British public. The name is an Anglicisation of the German Battenberg, a small town in Hesse. The title of count of Battenberg, later prince of Battenberg, was granted to a morganatic branch of the House of Hesse-Darmstadt, itself a cadet branch of the House of Hesse, in the mid 19th century.
