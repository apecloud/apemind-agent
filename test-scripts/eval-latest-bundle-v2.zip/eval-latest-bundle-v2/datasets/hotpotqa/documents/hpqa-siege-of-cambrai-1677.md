# Siege of Cambrai (1677)

The Siege of Cambrai took place from 20 March to 19 April 1677 during the Franco-Dutch War.
