# Trash (2014 film)

Trash is a 2014 Brazilian-British adventure drama thriller film directed by Stephen Daldry and written by Richard Curtis, based on Andy Mulligan's 2010 novel of same name. The film stars Rooney Mara, Martin Sheen, Wagner Moura, and Selton Mello.
