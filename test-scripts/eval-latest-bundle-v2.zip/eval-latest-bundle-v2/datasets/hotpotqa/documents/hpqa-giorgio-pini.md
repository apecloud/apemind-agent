# Giorgio Pini

Giorgio Pini (1 February 1899, in Bologna – 30 March 1987, in Rome) was an Italian politician and journalist.
