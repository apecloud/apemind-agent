# List of Allure cover models

"Allure" is a women's beauty magazine published by Condé Nast Publications. A famous woman, typically an actress, singer, or model, is featured on the cover of each month's issue. Following are the names of each cover subject from the most recent issue to the first issue of Allure in March 1991.
