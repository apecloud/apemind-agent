# The Famines (band)

The Famines are a Canadian indie rock band formed in 2008 in Edmonton, Alberta, Canada now based in Montreal, Quebec, Canada. The two piece band uses a modern and minimalistic approach that draws comparison to mid 1970's protopunk and fuzzy garage rock.The band name is meant to be a commentary on the continued feeling of emptiness and lacking in a society that is materially fulfilled. The band has two members, R. E. Biesinger on guitar and vocals, and Drew Demers on the drums.
