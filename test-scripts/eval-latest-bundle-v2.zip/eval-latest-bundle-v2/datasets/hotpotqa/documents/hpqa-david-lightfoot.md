# David Lightfoot

David Lightfoot worked on the horror films "Wolf Creek" and "Rogue".
