# Battle of Britain Memorial Flight

The Battle of Britain Memorial Flight (BBMF) is a Royal Air Force flight which provides an aerial display group usually comprising an Avro Lancaster, a Supermarine Spitfire and a Hawker Hurricane. The aircraft are regularly seen at events commemorating the Second World War and upon British State occasions, notably Trooping the Colour, celebrating Queen Elizabeth II's 80th birthday in 2006, as well as the wedding of Prince William, Duke of Cambridge and Catherine Middleton in 2011 and at air displays throughout the United Kingdom and Europe.
