# Helter Skelter (Manson scenario)

In the months leading up to the Tate/LaBianca murders in August 1969, Charles Manson often spoke to the members of his "Family" about Helter Skelter, an apocalyptic war arising from racial tensions between blacks and whites. This "chimerical vision"—as it was termed by the court that heard Manson's appeal from his conviction for the killings—involved reference to music of the Beatles (particularly songs from their 1968 double album "The Beatles", also known as "the White Album") and to the New Testament's Book of Revelation.
