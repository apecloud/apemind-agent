# Frank Blake

Francis Stanton "Frank" Blake (born July 30, 1949) is an American businessman and lawyer, who was the chairman and CEO of The Home Depot from January 2007 to May 2014. Prior to this he worked for the U.S. Department of Energy and General Electric. He was a longtime protégé of Robert Nardelli.
