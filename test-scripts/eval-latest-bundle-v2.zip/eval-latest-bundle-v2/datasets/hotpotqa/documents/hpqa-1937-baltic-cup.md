# 1937 Baltic Cup

The 1937 Baltic Cup was the ninth playing of the Baltic Cup football tournament. It was held from September 3–7, 1937 in Kaunas, Lithuania.
