# Walking Back to Happiness

Walking Back to Happiness is the third album by John Cooper Clarke, originally released on 10" clear vinyl in 1979, and long out of print. All tracks were recorded live, with the exception of the final track, "Gimmix", was re-recorded in studio and became a UK top 40 hit that year. The penultimate track refers to "The Marble Index" a 1969 album by Nico, with whom Clarke had a romance in the mid-1980s.
