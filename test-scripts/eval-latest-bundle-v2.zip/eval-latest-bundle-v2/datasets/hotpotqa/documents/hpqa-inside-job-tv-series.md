# Inside Job (TV series)

Inside Job is a reality show on TNT, which premiered on February 28, 2014. In each episode of "Inside Job", a group of four people compete to win a job at a large company; although one of the four contestants is secretly already an employee at that company, and is there not to compete but to judge the others' skills and character.
