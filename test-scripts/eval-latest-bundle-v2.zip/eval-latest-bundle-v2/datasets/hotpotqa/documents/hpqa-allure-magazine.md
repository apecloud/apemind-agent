# Allure (magazine)

Allure is an American women’s beauty magazine, published monthly by Conde Nast in New York City. It was founded in 1991 by Linda Wells. Michelle Lee replaced Wells in 2015. A signature of the magazine is its annual Best of Beauty awards—accolades given in the October issue to beauty products deemed the best by magazine staff.
