# John le Carré: The Biography

John le Carré: The Biography is a 2015 biography of John le Carré written by Adam Sisman and published by Harper.
