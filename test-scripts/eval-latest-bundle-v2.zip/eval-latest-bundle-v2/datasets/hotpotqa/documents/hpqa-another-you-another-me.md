# Another You, Another Me

"Another You, Another Me" is a debut solo song recorded by American country music artist Brady Seals. It was released in September 1996 as the first single from the album "The Truth". The song reached #32 on the "Billboard" Hot Country Singles & Tracks chart. The song was written by Seals' uncle, Troy Seals, along with Will Jennings.
