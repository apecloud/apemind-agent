# The Shins

The Shins are an American indie rock band from Albuquerque, New Mexico, formed in 1996. The band's current lineup consists of James Mercer (vocals, guitar, songwriter), Jon Sortland (drums), Mark Watrous (guitar), Casey Foubert (guitar), Yuuki Matthews (bass), and Patti King (keyboards). The band is based in Portland, Oregon.
