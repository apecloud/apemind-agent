# Astrosat

Astrosat is India's first dedicated multi-wavelength space observatory. It was launched on a PSLV-XL on 28 September 2015.
