# Patagonia picnic table effect

The Patagonia picnic table effect (also known as the Patagonia rest area effect or Patagonia rest stop effect) is a phenomenon associated with birding in which an influx of birdwatchers following the discovery of a rare bird at a location results in the discovery of further rare birds at that location, and so on, with the end result being that the locality becomes well known for rare birds, even though in itself it may be little or no better than other similar localities.
