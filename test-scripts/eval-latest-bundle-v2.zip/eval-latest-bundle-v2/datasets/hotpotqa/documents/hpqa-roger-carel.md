# Roger Carel

Roger Carel (born Roger Bancharel; 14 August 1927) is a French actor and voice talent, known for his recurring film roles as Asterix, the French voice of "Star Wars'" C-3PO, and the French voice of "Winnie the Pooh". He is also dubbing David Suchet as Hercule Poirot in Agatha Christie's Poirot. He voiced Wally Gator, Mickey Mouse and Woody Woodpecker in French. He was born in Paris, France.
