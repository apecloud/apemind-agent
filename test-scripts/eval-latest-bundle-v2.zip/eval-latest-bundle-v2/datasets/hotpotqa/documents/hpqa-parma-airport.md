# Parma Airport

Parma Airport (Italian: "Aeroporto di Parma" , IATA: PMF, ICAO: LIMP ) is located 1.3 NM northwest of Parma, a city in the Emilia-Romagna region of Italy. The airport was opened on 5 May 1991. It is also known as Giuseppe Verdi Airport or Parma "Giuseppe Verdi" Airport, named after Giuseppe Verdi.
