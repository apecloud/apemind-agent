# Clinton, Minnesota

Clinton is a city in Big Stone County, Minnesota, United States. The city was named for New York Governor DeWitt Clinton. The population was 449 at the 2010 census.
