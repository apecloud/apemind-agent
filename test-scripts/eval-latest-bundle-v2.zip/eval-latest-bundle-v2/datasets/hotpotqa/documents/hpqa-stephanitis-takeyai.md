# Stephanitis takeyai

The andromeda lace bug (Stephanitis takeyai) is a pest insect on plants of the genus "Pieris", especially "Pieris japonica", the Japanese andromeda. It originated in Japan with its host plant but has since been introduced to other areas of the globe. At least one "Pieris" species, "Pieris floribunda", is resistant to the bug.
