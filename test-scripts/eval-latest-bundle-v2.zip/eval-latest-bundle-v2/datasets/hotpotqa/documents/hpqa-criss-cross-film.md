# Criss Cross (film)

Criss Cross is a 1949 crime film noir directed by Robert Siodmak starring Burt Lancaster, Yvonne De Carlo and Dan Duryea, from Don Tracy's novel of the same name. This black-and-white film was shot partly on location in the Bunker Hill section of Los Angeles. The film was written by Daniel Fuchs. Franz Planer's cinematography creates a black-and-white film noir world. Miklós Rózsa scored the film's soundtrack. It was remade as "The Underneath" in 1995.
