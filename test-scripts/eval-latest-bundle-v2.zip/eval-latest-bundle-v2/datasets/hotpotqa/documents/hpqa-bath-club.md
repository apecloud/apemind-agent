# Bath Club

The Bath Club was a sports-themed London gentlemen's club in the 20th century. It was established in 1894 at 34 Dover Street. Its swimming pool was a noted feature, and it is thought that the swimming pool of the fictional Drones Club (also on Dover Street) was based on this. Sir Henry "Chips" Channon was a member. Mark Twain stayed here when he visited London.
