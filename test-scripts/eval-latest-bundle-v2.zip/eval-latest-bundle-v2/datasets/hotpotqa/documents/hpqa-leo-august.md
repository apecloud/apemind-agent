# Leo August

Leo August (March 2, 1914 – December 4, 1997), of New Jersey, was a philatelist who, as a stamp dealer and publisher, created interest and awareness in the collecting of first day covers through the introduction in 1939 of "ArtCraft" engraved illustrated (or "cacheted") envelopes for use as first day covers. He also established the landmark line of "White Ace" stamp albums. ArtCraft became one of the world's most popular cachets.
