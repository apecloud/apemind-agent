# Inch Castle

Inch Castle is a ruined castle located on the southern tip of Inch Island in County Donegal, Ireland. The castle was constructed around 1430 by the Gaelic Irish lord Neachtain O'Donnell for his father-in-law Cahir O'Doherty. The O'Doherty's were the dominant family on the nearby peninsula of Inishowen and had close links with the O'Donnells. It came to form part of the defensive network of O'Doherty fortifications designed to protect them from rival clans and to overawe those who accepted their overlordship.
