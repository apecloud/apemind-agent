# University of California

The University of California (UC) is a public university system in the U.S. state of California. Under the California Master Plan for Higher Education, the University of California is a part of the state's three-system public higher education plan, which also include the California State University system and the California Community Colleges System.
