# 2001 Baltic Cup

The 2001 Baltic Cup football competition was the 19th season of the Baltic Cup and took place on July 3–5 at the Daugava Stadium in Riga, Latvia, after it had not been staged for three years. It was the ninth competition of the three Baltic states – Latvia, Lithuania and Estonia – since they regained their independence from the Soviet Union in 1991.
