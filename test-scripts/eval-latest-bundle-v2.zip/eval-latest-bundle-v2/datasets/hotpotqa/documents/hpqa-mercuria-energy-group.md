# Mercuria Energy Group

Mercuria Energy Group Ltd is a privately held Swiss international commodity trading company active over a wide spectrum of global energy markets including crude oil and refined petroleum products, natural gas (including LNG), power, coal, biodiesel, carbon emissions, base metals and agricultural products. In 2014, the company bought the commodities trading arm of J.P. Morgan in a reported US$800 million deal.
