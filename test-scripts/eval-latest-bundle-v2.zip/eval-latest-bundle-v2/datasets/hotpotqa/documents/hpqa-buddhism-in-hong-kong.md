# Buddhism in Hong Kong

Buddhism is a major religion in Hong Kong and has been greatly influential in the traditional culture of its populace. Among the most prominent Buddhist temples in the city there are the Chi Lin Nunnery in Diamond Hill, built in the Tang Dynasty's architectural style; the Po Lin Monastery on Lantau Island, famous for the outdoor bronze statue, Tian Tan Buddha, which attracts a large number of visitors during the weekends and holidays.
