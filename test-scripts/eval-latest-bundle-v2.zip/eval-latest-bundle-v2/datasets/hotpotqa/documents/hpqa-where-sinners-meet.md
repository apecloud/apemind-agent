# Where Sinners Meet

Where Sinners Meet is a 1934 American romantic comedy film directed by J. Walter Ruben and starring Diana Wynyard, Clive Brook and Billie Burke. It was adapted by writer Henry William Hanemann from Clara Beranger's 1927 movie "The Little Adventuress", which in turn was a rewrite from the 1921 British play "The Dover Road" by A. A. Milne. The film used "The Dover Road" as a working title prior to its release.
