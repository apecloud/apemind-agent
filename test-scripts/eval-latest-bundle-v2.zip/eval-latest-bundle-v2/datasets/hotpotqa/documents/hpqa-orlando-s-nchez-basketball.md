# Orlando Sánchez (basketball)

Orlando Emilio Sánchez Caminero (born May 26, 1988) is a Dominican professional basketball player who currently plays for Bucaneros de La Guaira of the Venezuelan Liga Profesional de Baloncesto (LPB). He played college basketball for Monroe College and St. John's University, and has represented the Dominican Republic in international competition.
