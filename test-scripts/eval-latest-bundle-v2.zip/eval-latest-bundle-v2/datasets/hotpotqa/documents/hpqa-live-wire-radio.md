# Live Wire Radio

Live Wire Radio is a radio variety show that was launched in 2004 in Portland, Oregon. Staff at the upstart, weekly show are hoping to position it to possibly be considered by American Public Media as a replacement for Garrison Keillor's "A Prairie Home Companion".
