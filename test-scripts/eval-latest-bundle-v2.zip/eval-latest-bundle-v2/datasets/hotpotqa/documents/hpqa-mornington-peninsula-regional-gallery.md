# Mornington Peninsula Regional Gallery

Mornington Peninsula Regional Gallery is a public art gallery on the Mornington Peninsula, south-east of Melbourne, Australia. The gallery opened in 1971, and holds both traditional and contemporary Australian art. In 2013 the gallery hosted an exhibition of Archibald Prize paintings, setting a gallery attendance record of 48,000. The gallery is host to the National Works on Paper acquisitive art competition, established in 1998. Artists whose work is held by the Mornington Peninsula Regional Gallery include Constance Stokes.
