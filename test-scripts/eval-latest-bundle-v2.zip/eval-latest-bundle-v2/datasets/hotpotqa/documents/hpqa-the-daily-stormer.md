# The Daily Stormer

The Daily Stormer is an American neo-Nazi and white supremacist news and commentary website. It considers itself a part of the alt-right movement. Its editor, Andrew Anglin, founded it on July 4, 2013 as a faster-paced replacement for his previous website "Total Fascism".
