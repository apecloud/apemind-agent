# Welton, Lincolnshire

Welton (or Welton by Lincoln) is a village and civil parish in the West Lindsey district of Lincolnshire, England. The population of the civil parish at the 2011 census was 4,327. It is geographically situated 6 mi north from Lincoln city centre. The name Welton by Lincoln distinguishes it from other Weltons in Lincolnshire: Welton le Wold and Welton le Marsh.
