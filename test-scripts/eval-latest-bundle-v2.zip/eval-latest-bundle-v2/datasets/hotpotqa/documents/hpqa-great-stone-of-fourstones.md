# Great Stone of Fourstones

The Great Stone of Fourstones, or the "Big Stone" as it is known locally, is a glacial deposit on the moorlands of Tatham Fells, situated in North Yorkshire, England, near Bentham in the District of Craven, and 10 m from the county border with Lancashire.
