# Milo Parker

Milo Parker (born 2002) is a British child actor, known for his roles as Connor in "Robot Overlords", Roger Munro in "Mr. Holmes" and Hugh Apiston in "Miss Peregrine's Home for Peculiar Children".
