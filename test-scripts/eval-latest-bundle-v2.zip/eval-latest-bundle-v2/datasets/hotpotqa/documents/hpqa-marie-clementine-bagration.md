# Marie-Clementine Bagration

Princess Marie-Clementine Bagration (German: "Marie-Klementine Bagration" ) (1810-1829) was illegitimate daughter of Prince Klemens von Metternich with Princess Catherine Bagration.
