# Country Living

Country Living is an American lifestyle and home magazine published by the Hearst Corporation since 1978. The monthly magazine focuses on food, home renovation, home decor, DIY and lifestyle. The magazine hosts four Country Living Fairs a year in Rhinebeck, NY, Nashville, TN, Columbus, OH and Atlanta, GA.
