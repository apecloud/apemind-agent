# Oliver Cromwell (disambiguation)

Oliver Cromwell (1599–1658) was an English military and political leader and later Lord Protector of the Commonwealth of England, Scotland and Ireland.
