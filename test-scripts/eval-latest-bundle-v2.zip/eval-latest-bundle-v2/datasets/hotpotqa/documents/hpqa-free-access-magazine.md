# Free Access Magazine

Free Access Magazine is a free computer magazine distributed through major Australian consumer electronics retailers such Harvey Norman, Dick Smith Electronics and Myer. The magazine targets mainstream computer users and is designed to be easy to read. It covers PC and lifestyle technology.
