# Edison Chen (EP)

EDISON also known as 陳冠希EDISON was released on November 30, 2000 by Hong Kong pop singer-actor Edison Chen.
