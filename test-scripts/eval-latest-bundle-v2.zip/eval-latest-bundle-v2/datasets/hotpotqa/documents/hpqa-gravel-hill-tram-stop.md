# Gravel Hill tram stop

Gravel Hill tram stop is a light rail stop serving Addington, in the London Borough of Croydon in the southern suburbs of London. It is the main destination for tourists visiting the historic site of Addington Palace. It is also used by students who attend John Ruskin College and is the nearest stop for Forestdale.
