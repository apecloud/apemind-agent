# Big Three television networks

The Big Three television networks are the three major traditional commercial broadcast television networks in the United States: the American Broadcasting Company (ABC), CBS (formerly known as the Columbia Broadcasting System) and the National Broadcasting Company (NBC). Beginning in 1948 until the late 1980s, the Big Three networks dominated U.S. television. These three channels were also the first three channels on Television in America.
