# Béla Bartók

Béla Viktor János Bartók ( ; ] ; 25 March 1881 – 26 September 1945) was a Hungarian composer, pianist and an ethnomusicologist. He is considered one of the most important composers of the 20th century; he and Liszt are regarded as Hungary's greatest composers . Through his collection and analytical study of folk music, he was one of the founders of comparative musicology, which later became ethnomusicology.
