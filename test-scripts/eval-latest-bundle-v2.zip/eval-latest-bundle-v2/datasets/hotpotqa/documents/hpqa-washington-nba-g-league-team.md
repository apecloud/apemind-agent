# Washington NBA G League team

The Washington NBA G League team is an American professional basketball team in the NBA G League and an affiliate of the Washington Wizards of the National Basketball Association. Based in Washington, D.C., the team will play their home games during the 2018–19 season at the St. Elizabeths East Entertainment and Sports Arena. The team became the twenty-third G League team to be owned by an NBA team.
