# Another Language (album)

Another Language is the third studio album by American post-rock band This Will Destroy You. It was released on September 12, 2014, by Suicide Squeeze Records and Hobbledehoy Record Co. "Another Language" was preceded by the digital release of two singles, "Dustism" and "Invitation".
