# Sixtoo

Sixtoo was the main project of a Canadian underground hip hop DJ, producer and rapper Vaughn Robert Squire between 1996 and 2007. He has since retired the Sixtoo name pursuing other directions in electronic music, with a large genre shift from experimental hip hop to deeper club sounds of various tempos. He is also known as C.L. S.C.A.R.R., Speakerbruiser Rob, and Prison Garde.
