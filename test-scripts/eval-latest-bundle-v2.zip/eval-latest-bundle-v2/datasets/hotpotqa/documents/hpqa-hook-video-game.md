# Hook (video game)

Hook is the title of several video games based on the 1991 film of the same name. A side-scrolling platform game for the Nintendo Entertainment System (NES) and Game Boy was released in the United States in February 1992. Subsequent side-scrolling platform games were released for the Commodore 64 and the Super Nintendo Entertainment System (SNES) later in 1992, followed by versions for the Sega CD, Sega Genesis, and Sega's handheld Game Gear console in 1993. A fighting arcade game was also released in 1993.
