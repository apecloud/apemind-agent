# Edison Chen

Edison Koon-hei Chen (born 7 October 1980) is a Hong Kong film actor, musician, producer, entrepreneur, and fashion designer. Chen is also the founder of "CLOT Inc.", and the CEO of Clot Media Division Limited.
