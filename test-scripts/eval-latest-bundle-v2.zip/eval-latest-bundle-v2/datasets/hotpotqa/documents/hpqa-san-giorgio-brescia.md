# San Giorgio, Brescia

San Giorgio is a Roman Catholic church located on the Piazza of the same name, just outside Porta Bruciata, in Brescia, region of Lombardy, Italy.
