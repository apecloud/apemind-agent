# George Young (Methodist minister)

Reverend George Young (December 31, 1821 – August 1, 1910) was a Canadian Methodist minister and author noted for his role in the Red River Rebellion of 1869–1870. He was a supporter of the pro-Canadian faction led by John Christian Schultz. He is remembered today largely for his memoir of the rebellion "Manitoba memories; leaves from my life in the prairie province, 1868–1884".
