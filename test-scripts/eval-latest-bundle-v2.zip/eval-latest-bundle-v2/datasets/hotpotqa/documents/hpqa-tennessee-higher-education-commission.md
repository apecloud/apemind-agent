# Tennessee Higher Education Commission

The Tennessee Higher Education Commission (THEC) was established by the Tennessee General Assembly in 1967 to coordinate and support the efforts of higher education institutions in the State of Tennessee. One of its statutory requirements is to create a master plan for developing public higher education in Tennessee.
