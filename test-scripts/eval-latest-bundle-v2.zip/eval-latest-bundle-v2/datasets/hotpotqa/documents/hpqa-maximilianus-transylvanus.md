# Maximilianus Transylvanus

Maximilianus Transylvanus (Transilvanus, Transylvanianus), also Maximilianus of Transylvania and Maximilian (Maximiliaen) von Sevenborgen (c. 1490 – c. 1538), was a sixteenth-century author based in Flanders who wrote the earliest account published on Magellan and Elcano's first circumnavigation of the world (1519–22). Written after he interviewed the survivors of the "Victoria", and being a relative of sponsor Christopher de Haro, his account "De Moluccis Insulis" is a main source about the expedition along with that of Antonio Pigafetta.
