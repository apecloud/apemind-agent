# Government of Ireland Act 1914

The Government of Ireland Act 1914 (4 & 5 Geo. 5 c. 90), also known as the Home Rule Act, and before enactment as the Third Home Rule Bill, was an Act passed by the Parliament of the United Kingdom intended to provide home rule (self-government within the United Kingdom) for Ireland. It was the third such bill introduced by a Liberal government in a 28-year period in response to the Irish Home Rule movement.
