# 1952–53 Boston Celtics season

The 1952-53 NBA season was the Celtics' 7th season in the NBA.
