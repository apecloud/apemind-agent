# Inter Milan

F.C. Internazionale Milano, commonly referred to as Internazionale (] ) or simply Inter and colloquially known as Inter Milan outside Italy, is a professional Italian football club based in Milan, Lombardy. The club has played continuously in the top tier of the Italian football league system since its debut in 1909.
