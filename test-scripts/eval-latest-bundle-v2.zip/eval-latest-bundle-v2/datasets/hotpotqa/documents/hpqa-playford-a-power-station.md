# Playford A Power Station

Playford A power station was the first power station built by the Electricity Trust of South Australia at Port Paterson, South Australia near Port Augusta in South Australia. It was built in the early 1950s to generate electricity from coal mined from the Telford Cut at Leigh Creek and transported 250 km by rail. It was joined by the Playford B Power Station soon after, and the Northern Power Station in 1980.
