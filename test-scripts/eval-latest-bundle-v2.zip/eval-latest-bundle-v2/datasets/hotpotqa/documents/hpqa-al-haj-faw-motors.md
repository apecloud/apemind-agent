# Al Haj FAW motors

Al Haj FAW motors is sole distributor and assembler of FAW vehicles in Pakistan. The company is a subsidiary of Al Haj group and has an assembly plant located in Karachi. The assembly plant was inaugurated in 2013. The company assembles passenger vehicles, light commercial vehicles and commercial trucks. Over the time Al Haj FAW has secured the trust of major transport and logistics corporations in Pakistan as one of the major truck providers.
