# Chris White (musician)

Christopher Taylor "Chris" White (born 7 March 1943) is an English singer, songwriter, musician, and record producer.
