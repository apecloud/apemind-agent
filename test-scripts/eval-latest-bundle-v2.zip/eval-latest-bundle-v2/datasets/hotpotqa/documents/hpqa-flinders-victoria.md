# Flinders, Victoria

Flinders once known as Mendi-Moke, is a town south of Melbourne, Victoria, Australia, located on the Mornington Peninsula at the point where Western Port meets Bass Strait. Its local government area is the Shire of Mornington Peninsula. At the 2011 census, Flinders had a population of 860.
