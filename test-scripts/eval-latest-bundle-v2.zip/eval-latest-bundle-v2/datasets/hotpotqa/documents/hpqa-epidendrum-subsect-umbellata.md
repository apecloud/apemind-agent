# Epidendrum subsect. Umbellata

Epidendrum" subsect. "Umbellata is a subsection of section "E". sect. "Planifolia" of subgenus "E". subg. "Epidendrum" of the genus "Epidendrum" of the Orchidaceae (orchid family). Plants of "E". subsect. "Umbellata" differ from the other subsections of "E". sect. "Planifolia" by producing inflorescences which are umbel-like. In 1861, Reichenbach recognized ten species in this subsection. Of these, nine are recognized with the same names by Kew (page numbers refer to Reichenbach):
