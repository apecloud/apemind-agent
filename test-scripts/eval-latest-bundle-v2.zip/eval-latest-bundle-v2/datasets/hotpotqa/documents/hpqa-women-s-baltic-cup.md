# Women's Baltic Cup

The Women's Baltic Cup is a women's association football tournament contested between the Baltic states of Estonia, Latvia, and Lithuania, usually every year. They can also invite other teams to participate, like they did in 2016, when the Faroe Islands were invited. The tournament is the women's equivalent of the men's Baltic Cup.
