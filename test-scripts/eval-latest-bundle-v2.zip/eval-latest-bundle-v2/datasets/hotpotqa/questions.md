# HotpotQA 测试题目与标准答案

共 150 题。

### hpqa-brid-001

**问题：** In what year was the university where Sergei Aleksandrovich Tokarev was a professor founded?

**标准答案：** 1755

**来源文档：** hpqa-sergei-aleksandrovich-tokarev, hpqa-moscow-state-university

### hpqa-brid-002

**问题：** Black Book starred the actress and writer of what heritage?

**标准答案：** Dutch

**来源文档：** hpqa-black-book-film, hpqa-halina-reijn

### hpqa-brid-003

**问题：** Which actor does American Beauty and American Beauty have in common?

**标准答案：** Kevin Spacey

**来源文档：** hpqa-american-beauty-soundtrack, hpqa-american-beauty-1999-film

### hpqa-brid-004

**问题：** Ken Pruitt  was a Republican member of an upper house of the legislature with how many members ?

**标准答案：** 40 members

**来源文档：** hpqa-ken-pruitt, hpqa-florida-senate

### hpqa-comp-005

**问题：** Between Greyia and Calibanus, which genus contains more species?

**标准答案：** Greyia

**来源文档：** hpqa-greyia, hpqa-calibanus

### hpqa-comp-006

**问题：** Did John Updike and Tom Clancy both publish more than 15 bestselling novels?

**标准答案：** yes

**来源文档：** hpqa-john-updike, hpqa-tom-clancy

### hpqa-brid-007

**问题：** Who was hung for assisting the attempted surrender of a defector from the American Continental Army to the British Army?

**标准答案：** John André

**来源文档：** hpqa-john-andr, hpqa-benedict-arnold

### hpqa-brid-008

**问题：** which Mexican and American film actress is Ethel Houbiers  French voice of 

**标准答案：** Salma Hayek Pinault

**来源文档：** hpqa-ethel-houbiers, hpqa-salma-hayek

### hpqa-brid-009

**问题：** Which major international airport in south-east England ranks as the 8th busiest airport in Europe and replaced Croydon Airport?

**标准答案：** Gatwick Airport

**来源文档：** hpqa-croydon-airport, hpqa-gatwick-airport

### hpqa-brid-010

**问题：** Isabella Kelly was born at a ruined castle characterized as one of the most isolated fortifications in Britain by who?

**标准答案：** The Changing Scottish Landscape

**来源文档：** hpqa-isabella-kelly, hpqa-cairnburgh-castle

### hpqa-brid-011

**问题：** The facility where Robert Croft worked as a navy instructor was also known as?

**标准答案：** "Home of the Submarine Force"

**来源文档：** hpqa-robert-croft-diver, hpqa-naval-submarine-base-new-london

### hpqa-brid-012

**问题：** Who released the song "With or Without You" first, Jai McDowall or U2?

**标准答案：** U2

**来源文档：** hpqa-believe-jai-mcdowall-album, hpqa-with-or-without-you

### hpqa-brid-013

**问题：** Which "Roseanne" star is in Scream 2?

**标准答案：** Laurie Metcalf

**来源文档：** hpqa-scream-2, hpqa-laurie-metcalf

### hpqa-brid-014

**问题：** In what city is the company that Fastjet Tanzania was originally founded as a part of prior to rebranding based?

**标准答案：** Nairobi, Kenya

**来源文档：** hpqa-fastjet-tanzania, hpqa-fly540

### hpqa-brid-015

**问题：** What is the name of the Australian specialist electronic music magazine that features avant-rock, experimental sound art, and experimental hip hop?

**标准答案：** Cyclic Defrost

**来源文档：** hpqa-cyclic-defrost, hpqa-experimental-hip-hop

### hpqa-brid-016

**问题：** What is the population of the city that Munsonville is in the northwest corner of?

**标准答案：** 729 at the 2010 census

**来源文档：** hpqa-munsonville-new-hampshire, hpqa-nelson-new-hampshire

### hpqa-brid-017

**问题：** A Pair of Brown Eyes and Wild Mountain Thyme is based from what artists song?

**标准答案：** Francis McPeake

**来源文档：** hpqa-a-pair-of-brown-eyes, hpqa-wild-mountain-thyme

### hpqa-brid-018

**问题：** Armageddon in Retrospect was written by the author who was best known for what 1969 satire novel?

**标准答案：** Slaughterhouse-Five

**来源文档：** hpqa-armageddon-in-retrospect, hpqa-kurt-vonnegut

### hpqa-brid-019

**问题：** What class of instrument does Apatim Majumdar play?

**标准答案：** strings

**来源文档：** hpqa-apratim-majumdar, hpqa-sarod

### hpqa-comp-020

**问题：**  Which movie did Disney produce first,  The Many Adventures of Winnie the Pooh or Ride a Wild Pony?

**标准答案：** Ride a Wild Pony

**来源文档：** hpqa-ride-a-wild-pony, hpqa-the-many-adventures-of-winnie-the-pooh

### hpqa-comp-021

**问题：** Pandikona and Berger Blanc Suisse are both what kinds of animals?

**标准答案：** dogs

**来源文档：** hpqa-pandikona, hpqa-berger-blanc-suisse

### hpqa-brid-022

**问题：** The Prussian General Carl von Clausewitz is associated with what type of realism?

**标准答案：** Modern thinkers associated with classical realism are Carl von Clausewitz

**来源文档：** hpqa-classical-realism-international-relations, hpqa-carl-von-clausewitz

### hpqa-brid-023

**问题：** What where both Hawker Hurricane and No. 1455 Flight apart of?

**标准答案：** Royal Air Force

**来源文档：** hpqa-no-1455-flight-raf, hpqa-hawker-hurricane

### hpqa-brid-024

**问题：** what language did the ethnic group which Torstein Ellingsen was its drumer  speaks 

**标准答案：** Norwegian language

**来源文档：** hpqa-torstein-ellingsen, hpqa-norwegians

### hpqa-brid-025

**问题：** From March 631 to April 631, Farrukhzad Khosrau V was the king of an empire that succeeded which empire?

**标准答案：** the Parthian Empire

**来源文档：** hpqa-farrukhzad-khosrow-v, hpqa-sasanian-empire

### hpqa-brid-026

**问题：** Beer Wars covers the differences between large corporate breweries, and small breweries, such as what brewery that is headquartered in Escondido, california?

**标准答案：** Stone Brewing

**来源文档：** hpqa-beer-wars, hpqa-stone-brewing-co

### hpqa-brid-027

**问题：** Which head coach has led their team for a longer period of time, Tim Cluess or Steve Prohm?

**标准答案：** Tim Cluess

**来源文档：** hpqa-2015-16-iona-gaels-men-s-basketball-team, hpqa-2015-16-iowa-state-cyclones-men-s-basketball-team

### hpqa-brid-028

**问题：** During what war were the Russia-United Kingdom relations in a state of rivalry after the abdication of Emperor Nicholas II? 

**标准答案：** the Cold War (1947–91)

**来源文档：** hpqa-russia-united-kingdom-relations, hpqa-russian-revolution

### hpqa-brid-029

**问题：** How far from Sacramento is the flight school in Atwater?

**标准答案：** about 115 miles (185 km)

**来源文档：** hpqa-sierra-academy-of-aeronautics, hpqa-castle-air-force-base

### hpqa-brid-030

**问题：** Baraki Barak District is situated in the western part of a province whose capital is what?

**标准答案：** Puli Alam

**来源文档：** hpqa-baraki-barak-district, hpqa-logar-province

### hpqa-brid-031

**问题：** What was the 2010 population of the town where Black Crescent Mountain was located? 

**标准答案：** 310

**来源文档：** hpqa-black-crescent-mountain, hpqa-randolph-new-hampshire

### hpqa-brid-032

**问题：** In the NASA mission where Moon trees were taken into space, what was the nickname of the Command Module?

**标准答案：** "Kitty Hawk"

**来源文档：** hpqa-moon-tree, hpqa-stuart-roosa

### hpqa-brid-033

**问题：** Which comic series involves characters such as Nick Fury and Baron von Strucker?

**标准答案：** Marvel

**来源文档：** hpqa-nick-fury-agent-of-s-h-i-e-l-d-film, hpqa-fenris-comics

### hpqa-brid-034

**问题：** College Humor is a 1933 American pre-Code musical comedy film that starred what American singer and actor who has a trademark warm bass-baritone voice?

**标准答案：** Harry Lillis "Bing" Crosby Jr.

**来源文档：** hpqa-college-humor-film, hpqa-bing-crosby

### hpqa-brid-035

**问题：** Who is writing a book about the Koch family who control the second-largest privately owned company in the United States?

**标准答案：** Jane Mayer

**来源文档：** hpqa-dark-money-book, hpqa-koch-family

### hpqa-brid-036

**问题：** New York State Route 9R rejoins its parent in a hamlet located  in what New York County?

**标准答案：** Albany

**来源文档：** hpqa-new-york-state-route-9r, hpqa-boght-corners-new-york

### hpqa-brid-037

**问题：** 12 Years a Slave starred what British actor born 10 July 1977)

**标准答案：** Chiwetel Ejiofor

**来源文档：** hpqa-12-years-a-slave-score, hpqa-chiwetel-ejiofor

### hpqa-brid-038

**问题：** What was the capital of India when the Taj Mahal was commissioned?

**标准答案：** Agra

**来源文档：** hpqa-agra-fort, hpqa-taj-mahal

### hpqa-brid-039

**问题：** In what city did the "Prince of tenors" star in a film based on an opera by Giacomo Puccini?

**标准答案：** Rome

**来源文档：** hpqa-tosca-1956-film, hpqa-franco-corelli

### hpqa-brid-040

**问题：** What river can a  large African bovine be seen bathing in in the Mwabvi Wildlife Reserve?

**标准答案：** Buffalo

**来源文档：** hpqa-mwabvi-wildlife-reserve, hpqa-african-buffalo

### hpqa-brid-041

**问题：** Jalen Jones plays basketball for an NBA team that plays their home games in what arena?

**标准答案：** Smoothie King Center

**来源文档：** hpqa-jalen-jones, hpqa-new-orleans-pelicans

### hpqa-brid-042

**问题：** The On Tour Forever album gave Blues Traveler the opportunity to display what musical trademark?

**标准答案：** extensive use of segues

**来源文档：** hpqa-on-tour-forever, hpqa-blues-traveler

### hpqa-brid-043

**问题：** Which Victorian poet was born in a 15th-century castle home to the Earl of Southesk?

**标准答案：** Charlotte Carnegie

**来源文档：** hpqa-lady-charlotte-elliot, hpqa-kinnaird-castle-brechin

### hpqa-brid-044

**问题：** Alexander Petrovich Nikolayev received the title Hero of the Soviet Union and the Order of Lenin for his actions during the   the final major offensive of the European theatre of what war?

**标准答案：** World War II

**来源文档：** hpqa-alexander-nikolayev, hpqa-battle-of-berlin

### hpqa-brid-045

**问题：** Where did Cale Gundy's brother play football in college?

**标准答案：** Oklahoma State University

**来源文档：** hpqa-cale-gundy, hpqa-mike-gundy

### hpqa-comp-046

**问题：** Who has released more solo albums, Nick Carter or Brady Seals?

**标准答案：** Brady Seals

**来源文档：** hpqa-nick-carter-musician, hpqa-brady-seals

### hpqa-comp-047

**问题：** Which Istanbul mosque is unique for retaining a Baroque style of architecture, the Bayezid II Mosque or the Nusretiye Mosque?

**标准答案：** Nusretiye Mosque

**来源文档：** hpqa-bayezid-ii-mosque, hpqa-nusretiye-mosque

### hpqa-brid-048

**问题：** What university did the last Detroit Pistons player to wear the number retired in honor of a player nicknamed "The Worm" attend?

**标准答案：** Georgetown University

**来源文档：** hpqa-greg-monroe, hpqa-dennis-rodman

### hpqa-comp-049

**问题：** The Atik Valide Mosque and Valens Aqueduct are found in what country?

**标准答案：** Turkey

**来源文档：** hpqa-atik-valide-mosque, hpqa-valens-aqueduct

### hpqa-brid-050

**问题：** Which of the four US Presidents who have been assinated was shot on the grounds of the Pan-American Exposition at the Temple of Music in Buffalo, New York?

**标准答案：** William McKinley

**来源文档：** hpqa-assassination-of-james-a-garfield, hpqa-assassination-of-william-mckinley

### hpqa-brid-051

**问题：** Who created the NBC sitcom that Johnny Pemberton appears in as the character Bo Thompson?

**标准答案：** Justin Spitzer

**来源文档：** hpqa-johnny-pemberton, hpqa-superstore-tv-series

### hpqa-comp-052

**问题：** Were Halldór Laxness and Timothy Leary from the same country?

**标准答案：** no

**来源文档：** hpqa-halld-r-laxness, hpqa-timothy-leary

### hpqa-comp-053

**问题：** Do both Korematsu v. United States and Chaplinsky v. New Hampshire cases regard the rights of U. S. citizens?

**标准答案：** yes

**来源文档：** hpqa-korematsu-v-united-states, hpqa-chaplinsky-v-new-hampshire

### hpqa-brid-054

**问题：**  What is the title of the memoir written by the honoree of the Black and White Ball?

**标准答案：** Personal History

**来源文档：** hpqa-black-and-white-ball, hpqa-katharine-graham

### hpqa-brid-055

**问题：** What country is the theme park served by the Huis Ten Bosch train service themed on?

**标准答案：** Netherlands

**来源文档：** hpqa-huis-ten-bosch-train, hpqa-huis-ten-bosch-theme-park

### hpqa-brid-056

**问题：** The Distribution of Industry act was passed by a man who was prime minister when? 

**标准答案：** 1945 to 1951

**来源文档：** hpqa-distribution-of-industry-act-1950, hpqa-clement-attlee

### hpqa-brid-057

**问题：** What Cantonese slang term can mean both "ghost man" and to refer to Westerners?

**标准答案：** Gweilo

**来源文档：** hpqa-ghosts-2006-film, hpqa-gweilo

### hpqa-brid-058

**问题：** In what year was the most famous statute at Po Lin Monastery built?

**标准答案：** Tian Tan Buddha

**来源文档：** hpqa-buddhism-in-hong-kong, hpqa-tian-tan-buddha

### hpqa-brid-059

**问题：**  The Nike Hoop Summit has had many current NBA players as former participants, including what German player from the Dallas Mavericks?

**标准答案：** Dirk Werner Nowitzki

**来源文档：** hpqa-nike-hoop-summit, hpqa-dirk-nowitzki

### hpqa-brid-060

**问题：** Which actor from the South Korean-Thai drama film Final Recipe debuted as a member of Super Junior-M in 2008?

**标准答案：** Henry Lau

**来源文档：** hpqa-final-recipe, hpqa-henry-lau

### hpqa-comp-061

**问题：** Are Phlebodium and Pieris both species of ferns?

**标准答案：** no

**来源文档：** hpqa-phlebodium, hpqa-pieris-plant

### hpqa-brid-062

**问题：** Who was the great grandfather of Franklin Seaver Pratt's wife?

**标准答案：** Kalokuokamaile

**来源文档：** hpqa-franklin-seaver-pratt, hpqa-elizabeth-kekaaniau

### hpqa-brid-063

**问题：** At what age did Cieli di Toscana's singer become blind?

**标准答案：** Bocelli became completely blind at the age of 12

**来源文档：** hpqa-cieli-di-toscana, hpqa-andrea-bocelli

### hpqa-brid-064

**问题：** Which late 1980s and 1990s English super model was featured in the song nasty girl by The Notorious B.I.G.?

**标准答案：** Naomi Elaine Campbell

**来源文档：** hpqa-nasty-girl-the-notorious-b-i-g-song, hpqa-naomi-campbell

### hpqa-brid-065

**问题：** What is the name of the film directed by Alex Cox  adapted from a 1606 play starring Diana Quick as the Dutchess?

**标准答案：** Revengers Tragedy

**来源文档：** hpqa-revengers-tragedy, hpqa-diana-quick

### hpqa-comp-066

**问题：** Josh Trank and Mike Valerio both work in what industry?

**标准答案：** entertainment

**来源文档：** hpqa-josh-trank, hpqa-mike-valerio

### hpqa-brid-067

**问题：** Which American comedian born on March 21, 1962, appeared in the movie "Sleepless in Seattle?"

**标准答案：** Rosie O'Donnell

**来源文档：** hpqa-sleepless-in-seattle, hpqa-rosie-o-donnell

### hpqa-brid-068

**问题：** Any Questions for Ben? was directed by which Australian producer and actor?

**标准答案：** Robert Ian "Rob" Sitch

**来源文档：** hpqa-any-questions-for-ben, hpqa-rob-sitch

### hpqa-brid-069

**问题：** What American indie rock group first had Jesse Sandoval as the drummer and now has Jon Sortland on drums?

**标准答案：** The Shins

**来源文档：** hpqa-jesse-sandoval, hpqa-the-shins

### hpqa-brid-070

**问题：** What 3 countries are part of the legal name of the airline that merged with Braathens in 2004?

**标准答案：** Denmark–Norway–Sweden

**来源文档：** hpqa-sas-braathens, hpqa-scandinavian-airlines

### hpqa-brid-071

**问题：** What is the ratio of flow velocity past a boundary to the local speed of sound for a Saab JAS 39 Gripen?

**标准答案：** 2

**来源文档：** hpqa-saab-jas-39-gripen, hpqa-mach-number

### hpqa-brid-072

**问题：** SWX Right Now airs on the station that broadcasts on what channel in Billings, Montana?

**标准答案：** 8

**来源文档：** hpqa-swx-right-now, hpqa-kulr-tv

### hpqa-brid-073

**问题：** Which player, who also played for the New Jersey Nets and the Golden State Warriors, finished third in the league with 231 three-point field goals during the 1995-96 Atlanta Hawks season?

**标准答案：** Mookie Blaylock

**来源文档：** hpqa-1995-96-atlanta-hawks-season, hpqa-mookie-blaylock

### hpqa-brid-074

**问题：** Saltillo Engine is an engine plant in Ramos Arizpe that belongs to the American subsidiary of what company?

**标准答案：** Fiat Chrysler Automobiles N.V.

**来源文档：** hpqa-saltillo-engine-plant, hpqa-chrysler

### hpqa-brid-075

**问题：**  What type of television show did Dylan Everett star in, in 2015?

**标准答案：** American-Canadian mystery-drama

**来源文档：** hpqa-dylan-everett, hpqa-open-heart-tv-series

### hpqa-comp-076

**问题：** Which plant, the Chaerophyllum or the Cryptanthus, can be found in various places across the world?

**标准答案：** Chaerophyllum

**来源文档：** hpqa-chaerophyllum, hpqa-cryptanthus

### hpqa-brid-077

**问题：** Johnny Mathis: Wonderful Wonderful aired at what luxury hotel, casino and spa resort located in Atlantic City, New Jersey?

**标准答案：** Tropicana Casino & Resort

**来源文档：** hpqa-johnny-mathis-wonderful-wonderful, hpqa-tropicana-casino-amp-resort-atlantic-city

### hpqa-brid-078

**问题：** Who wrote the lyrics for Linda Eder's Broadway debut?

**标准答案：** Wildhorn, Bricusse and Cuden

**来源文档：** hpqa-linda-eder, hpqa-jekyll-amp-hyde-musical

### hpqa-brid-079

**问题：** The Company They Keep is a book written by Diana Pavlac Glyer, who is a professor at a university in Azusa, California, that was founded in 1899, and is under the auspices of what religion?

**标准答案：** evangelical Christian

**来源文档：** hpqa-the-company-they-keep, hpqa-azusa-pacific-university

### hpqa-brid-080

**问题：** For One Night Only was hosted by the man most well-known for hosting what show from 1962 until 1999?

**标准答案：** The Late Late Show

**来源文档：** hpqa-for-one-night-only-irish-tv-series, hpqa-gay-byrne

### hpqa-brid-081

**问题：** What was the slogan  that came about from the idea of Lebensraum which had its most extreme form supported by the Nazi Party until the end of World War II?

**标准答案：** Blood and soil

**来源文档：** hpqa-blood-and-soil, hpqa-lebensraum

### hpqa-brid-082

**问题：** Olivia DeJonge starred in an American horror film directed by Shyamalan called what

**标准答案：** The Visit

**来源文档：** hpqa-olivia-dejonge, hpqa-the-visit-2015-american-film

### hpqa-brid-083

**问题：** Who conducted the negotiations  with the owners and the longest serving commandant of Auschwitz concentration and extermination camp?

**标准答案：** Rudolf Höss

**来源文档：** hpqa-gerstein-report, hpqa-rudolf-h-ss

### hpqa-brid-084

**问题：** What genre is the novel from which the fast-food restaurant specializing in seafood derives its name?

**标准答案：** an adventure novel

**来源文档：** hpqa-long-john-silver-s, hpqa-treasure-island

### hpqa-brid-085

**问题：** What kind of musicians are Mark Gaudet and Jan Axel Blomberg?

**标准答案：** drummer

**来源文档：** hpqa-mark-gaudet, hpqa-jan-axel-blomberg

### hpqa-brid-086

**问题：** A Wind in the Door is part of a series written by who?

**标准答案：** Madeleine L'Engle

**来源文档：** hpqa-a-wind-in-the-door, hpqa-time-quintet

### hpqa-brid-087

**问题：** The Airport located next to the A13 handled how many passengers in 2016 ?

**标准答案：** 1.6 million passengers

**来源文档：** hpqa-a13-motorway-netherlands, hpqa-rotterdam-the-hague-airport

### hpqa-brid-088

**问题：** The town of Sinclair, West Virginia, is named after the founder of the local oil drilling company. What is on Sinclair Oil's famous logo?

**标准答案：** dinosaur

**来源文档：** hpqa-sinclair-west-virginia, hpqa-sinclair-oil-corporation

### hpqa-brid-089

**问题：** Jihad: A Story of the Others is a documentary by the director who is of what descent?

**标准答案：** Punjabi/Pashtun

**来源文档：** hpqa-jihad-a-story-of-the-others, hpqa-deeyah-khan

### hpqa-brid-090

**问题：** Minor league baseball games that were played between the rivalling teams of the Sooners and the Cowboys were played at the stadium formerly known as what?

**标准答案：** Drillers Stadium

**来源文档：** hpqa-athletics-stadium, hpqa-bedlam-series

### hpqa-brid-091

**问题：** Cooperative Living Organization is located in a city that is the county seat of what county in Florida?

**标准答案：** Alachua

**来源文档：** hpqa-cooperative-living-organization, hpqa-gainesville-florida

### hpqa-brid-092

**问题：** What is the pen name of author Carolyn Janice Cherry, who wrote the Fortress Series?

**标准答案：** Carolyn Janice Cherry (born September 1, 1942), better known by the pen name C. J. Cherryh,

**来源文档：** hpqa-the-fortress-series, hpqa-c-j-cherryh

### hpqa-comp-093

**问题：** Which dog is believed to dispel ghosts and evil spirits, Segugio Italiano or Sapsali?

**标准答案：** Sapsali

**来源文档：** hpqa-segugio-italiano, hpqa-sapsali

### hpqa-brid-094

**问题：** Which French aristocrat and military officer who fought in the American Revolutionary War visited this historic home located at Enfield, Halifax County, North Carolina, known as The Cellar?

**标准答案：** Marquis de Lafayette

**来源文档：** hpqa-the-cellar-enfield-north-carolina, hpqa-gilbert-du-motier-marquis-de-lafayette

### hpqa-brid-095

**问题：** What sports team included both of the brothers Case McCoy and Colt McCoy during different years?

**标准答案：** University of Texas Longhorns

**来源文档：** hpqa-case-mccoy, hpqa-colt-mccoy

### hpqa-brid-096

**问题：** Which member of The New Russian School was both a doctor and a chemist besides being a composer?

**标准答案：** Alexander Porfiryevich Borodin

**来源文档：** hpqa-alexander-borodin, hpqa-the-mighty-handful

### hpqa-brid-097

**问题：** Susanna Thompson appeared in the courtroom drama film Ghosts of Mississippi, directed by who?

**标准答案：** Rob Reiner

**来源文档：** hpqa-susanna-thompson, hpqa-ghosts-of-mississippi

### hpqa-brid-098

**问题：** Live Wire Radio will possibly be considered as a replacement for a variety show created in what year?

**标准答案：** 1974

**来源文档：** hpqa-live-wire-radio, hpqa-a-prairie-home-companion

### hpqa-brid-099

**问题：** Luke Rockhold defeated the MMA fighter who was the first to earn a win against which champion in the UFC?

**标准答案：** Anderson Silva

**来源文档：** hpqa-luke-rockhold, hpqa-chris-weidman

### hpqa-comp-100

**问题：** What type of art does The Consul and Arlecchino have in common?

**标准答案：** music

**来源文档：** hpqa-the-consul, hpqa-arlecchino-opera

### hpqa-brid-101

**问题：** Who is a Brazilian mixed martial artist in the UFC who Namsaknoi Yudthagarngamtorn coached?

**标准答案：** Rafael Souza dos Anjos

**来源文档：** hpqa-namsaknoi-yudthagarngamtorn, hpqa-rafael-dos-anjos

### hpqa-comp-102

**问题：** Which has more species, Lysiloma or Hydrocotyle umbellata?

**标准答案：** Lysiloma

**来源文档：** hpqa-lysiloma, hpqa-hydrocotyle-umbellata

### hpqa-comp-103

**问题：** Are the films Gasland from 2010 and Pumping Iron from 1977 both documentaries?

**标准答案：** yes

**来源文档：** hpqa-gasland, hpqa-pumping-iron

### hpqa-brid-104

**问题：** Rosemary Willis was seen in the grass in what Texas town, where John F. Kennedy was assassinated?

**标准答案：** Dallas

**来源文档：** hpqa-rosemary-willis, hpqa-dealey-plaza

### hpqa-brid-105

**问题：** Which king of Northumbria did The "Historia" gives the abbot central place in his election as king

**标准答案：** Guthred or Guthfrith

**来源文档：** hpqa-eadred-lulisc, hpqa-guthred

### hpqa-brid-106

**问题：** Mooreville, Mississippi is located on which Interstate highway that follows US Route 78?

**标准答案：** Interstate 22

**来源文档：** hpqa-mooreville-mississippi, hpqa-interstate-22

### hpqa-brid-107

**问题：** Where is the casino that Summer Nights takes place in?

**标准答案：** Las Vegas Strip in Paradise, Nevada

**来源文档：** hpqa-summer-nights-residency-show, hpqa-flamingo-las-vegas

### hpqa-brid-108

**问题：** who was the anthropologist who thought that the plaster casts that were discovered by Paul Freeman were a critical piece of evidence?

**标准答案：** Don Jeffrey "Jeff" Meldrum (born May 24, 1958) is a Professor of Anatomy and Anthropology

**来源文档：** hpqa-paul-freeman-cryptozoologist, hpqa-jeffrey-meldrum

### hpqa-brid-109

**问题：** What type of license is the open source roguelike video game video released 2012, in which a subset of it's pricing model is a called free-to-play, licensed under?

**标准答案：** GNU GPLv3

**来源文档：** hpqa-tales-of-maj-eyal, hpqa-freemium

### hpqa-brid-110

**问题：** Mía Maestro had a role in the 2002 biopic directed by whom?

**标准答案：** Julie Taymor

**来源文档：** hpqa-m-a-maestro, hpqa-frida

### hpqa-brid-111

**问题：** UFO Magazine covers what subject named for Charles Hoy Fort?

**标准答案：** Fortean

**来源文档：** hpqa-ufo-magazine, hpqa-charles-fort

### hpqa-comp-112

**问题：** Are both The Straight Story and Frozen films of the same genre?

**标准答案：** no

**来源文档：** hpqa-the-straight-story, hpqa-frozen-2013-film

### hpqa-brid-113

**问题：** What 1876 battle featured the Other Magpie?

**标准答案：** Battle of the Rosebud

**来源文档：** hpqa-the-other-magpie, hpqa-battle-of-the-rosebud

### hpqa-brid-114

**问题：** What Disney movie was the wrestler with the real name of John William Minton in?

**标准答案：** Double Agent

**来源文档：** hpqa-double-agent-1987-film, hpqa-big-john-studd

### hpqa-brid-115

**问题：** Who covered the song I Love You by Chris Write?

**标准答案：** People! and The Carnabeats

**来源文档：** hpqa-i-love-you-the-zombies-song, hpqa-chris-white-musician

### hpqa-comp-116

**问题：** Who was born first, Javier Frana or Sherwood Stewart?

**标准答案：** Sherwood Stewart

**来源文档：** hpqa-javier-frana, hpqa-sherwood-stewart

### hpqa-comp-117

**问题：** Are Dogo Cubano and the Dutch Shepherd both breeds of dog?

**标准答案：** yes

**来源文档：** hpqa-dogo-cubano, hpqa-dutch-shepherd

### hpqa-brid-118

**问题：** Spawn, a fictional character who Mustafa Shakir has expressed interest in playing, was created by?

**标准答案：** Todd McFarlane

**来源文档：** hpqa-mustafa-shakir, hpqa-spawn-comics

### hpqa-brid-119

**问题：** To where did the war criminal who is the fictional defendant in the film After the Truth flee in real life ?

**标准答案：** South America

**来源文档：** hpqa-after-the-truth, hpqa-josef-mengele

### hpqa-brid-120

**问题：** What company did Rex Maughan aquire?

**标准答案：** Aloe Vera of America

**来源文档：** hpqa-rex-maughan, hpqa-forever-living-products

### hpqa-brid-121

**问题：** The 249th episode of "The Simpsons" was aired on what date?

**标准答案：** November 1, 2000

**来源文档：** hpqa-the-simpsons-season-12, hpqa-treehouse-of-horror-xi

### hpqa-comp-122

**问题：** Which was built first Woolworth Building or 1 New York Plaza?

**标准答案：** Woolworth Building

**来源文档：** hpqa-woolworth-building, hpqa-1-new-york-plaza

### hpqa-brid-123

**问题：** Where is the concert venue which hosted the first US performance of "Libuše" located?

**标准答案：** Midtown Manhattan in New York City,

**来源文档：** hpqa-libu-e-opera, hpqa-carnegie-hall

### hpqa-brid-124

**问题：** When was the advisor of Alpher–Bethe–Gamow paper died?

**标准答案：** August 19, 1968

**来源文档：** hpqa-alpher-bethe-gamow-paper, hpqa-george-gamow

### hpqa-brid-125

**问题：** What competition held in Kathmandu, Nepal did Julian Bolling compete in 1984?

**标准答案：** 1984 South Asian Games

**来源文档：** hpqa-julian-bolling, hpqa-1984-south-asian-games

### hpqa-brid-126

**问题：** The Nike Mercurial Vapor is endorsed by a Stoke City football player who also plays for what national team?

**标准答案：** the Switzerland national team

**来源文档：** hpqa-nike-mercurial-vapor, hpqa-xherdan-shaqiri

### hpqa-comp-127

**问题：** Which aired first, Life After People or Werner Herzog Eats His Shoe?

**标准答案：** Werner Herzog Eats His Shoe

**来源文档：** hpqa-werner-herzog-eats-his-shoe, hpqa-life-after-people

### hpqa-brid-128

**问题：** What NIFL Premier Intermediate League team did Sean Connor play for?

**标准答案：** Distillery

**来源文档：** hpqa-sean-connor, hpqa-lisburn-distillery-f-c

### hpqa-brid-129

**问题：** The first female correspondent for Inside the NFL was replaced by who on the show American Ninja Warrior?

**标准答案：** Kristine Leahy

**来源文档：** hpqa-american-ninja-warrior-season-7, hpqa-jenn-brown

### hpqa-brid-130

**问题：** Bridgewater Triangle is an area where the phenomenon associated with what type of tradition has been seen?

**标准答案：** Native American

**来源文档：** hpqa-bridgewater-triangle, hpqa-thunderbird-cryptozoology

### hpqa-brid-131

**问题：** The band who released the debut album "Tinted Windows" had their first performance in what city?

**标准答案：** Tulsa

**来源文档：** hpqa-tinted-windows-album, hpqa-tinted-windows-band

### hpqa-brid-132

**问题：** In the 1970s, which group acquired this department store group in the United Kingdom whose co-founding director is the father of Lieutenant Colonel Donald Swain Lewis?

**标准答案：** Army & Navy Stores

**来源文档：** hpqa-donald-swain-lewis, hpqa-army-amp-navy-stores-united-kingdom

### hpqa-brid-133

**问题：** The Dogwoman telemovies were created by an actress born in what year?

**标准答案：** 1961

**来源文档：** hpqa-dogwoman, hpqa-magda-szubanski

### hpqa-brid-134

**问题：** Who fills in occasionally for the meteorologist who replaced  Ginger Zee ?

**标准答案：** Kait Parker

**来源文档：** hpqa-kait-parker, hpqa-rob-marciano

### hpqa-brid-135

**问题：** In Ancient Egyptian religion how would a citizen be weighted to decide if they where worthy of damnation and would face the torment in the lake of fire ?

**标准答案：** against the feather of truth

**来源文档：** hpqa-damnation, hpqa-ancient-egyptian-religion

### hpqa-brid-136

**问题：** Which town near the county border with North Yorkshire was this Lancashire mill (closed in 1979 and demolished) located?

**标准答案：** Barnoldswick

**来源文档：** hpqa-bancroft-shed, hpqa-barnoldswick

### hpqa-brid-137

**问题：** The Prodigal Daughter, though a book about an American, is by a novelist of what nationality?

**标准答案：** English

**来源文档：** hpqa-the-prodigal-daughter, hpqa-jeffrey-archer

### hpqa-brid-138

**问题：** At what height does State Route 160 start?

**标准答案：** 4145 ft

**来源文档：** hpqa-virginia-state-route-160, hpqa-black-mountain-kentucky

### hpqa-brid-139

**问题：** The alcoholic drink that shares a name with Quintessentially Unreal's 1996 album is commonly reffered to in historical literature as what?

**标准答案：** the green fairy

**来源文档：** hpqa-quintessentially-unreal, hpqa-absinthe

### hpqa-brid-140

**问题：** What actor replaced the Welch actor born in 1978 who played Robin Hood in the first season of "Once upon a Time"?

**标准答案：** Sean Maguire

**来源文档：** hpqa-robin-hood-once-upon-a-time, hpqa-tom-ellis-actor

### hpqa-brid-141

**问题：** Which year was the more recent engine series, the Honda K or Honda H, introduced?

**标准答案：** 2001

**来源文档：** hpqa-honda-k-engine, hpqa-honda-h-engine

### hpqa-brid-142

**问题：** Who is the film dedicated to that Paramount Classics and MTV Films co-purchased the rights to?

**标准答案：** Sam Phillips

**来源文档：** hpqa-beneath-2007-film, hpqa-hustle-amp-flow

### hpqa-brid-143

**问题：** What are some foods that may have been served at the Hawaiin Cottage?

**标准答案：** poi, Kalua pig, poke, lomi salmon, opihi, haupia

**来源文档：** hpqa-hawaiian-cottage, hpqa-luau

### hpqa-brid-144

**问题：** In what year was the coach who led the 2007 South Carolina Gamecocks football team in his third season as USC head coach born?

**标准答案：** 1945

**来源文档：** hpqa-2007-south-carolina-gamecocks-football-team, hpqa-steve-spurrier

### hpqa-brid-145

**问题：** What team did Travis Cortez Mays play on which currently compete in the Big 12 Conference.?

**标准答案：** Texas Longhorns men's basketball team

**来源文档：** hpqa-travis-mays, hpqa-texas-longhorns-men-s-basketball

### hpqa-brid-146

**问题：** Which film does "Naked Weapon" follow in the "Naked" series?

**标准答案：** "Naked Killer"

**来源文档：** hpqa-naked-soldier, hpqa-naked-weapon

### hpqa-brid-147

**问题：** Which award David Hersey had got for Equus a play by Peter Shaffer ?

**标准答案：** Outstanding Lighting Design

**来源文档：** hpqa-david-hersey, hpqa-equus-play

### hpqa-comp-148

**问题：** What mine was operated by Royal Oak Mines at at earlier date, Kemess Mine or Colomac Mine?

**标准答案：** The Colomac Mine

**来源文档：** hpqa-kemess-mine, hpqa-colomac-mine

### hpqa-comp-149

**问题：** Are The Man from Snowy River II and Miracle of the White Stallions filmed in different countries?

**标准答案：** yes

**来源文档：** hpqa-the-man-from-snowy-river-ii, hpqa-miracle-of-the-white-stallions

### hpqa-comp-150

**问题：** Do Lush and P.O.D. both consist of four band members?

**标准答案：** yes

**来源文档：** hpqa-lush-band, hpqa-p-o-d
