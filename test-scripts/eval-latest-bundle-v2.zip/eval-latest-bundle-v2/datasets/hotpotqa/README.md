# HotpotQA 导出包

线上四集评测使用的 HotpotQA 固定 150 题。

## 内容

- `questions.csv` / `questions.jsonl` / `questions.md`：题目与标准答案
- `documents/`：测试文档

## 规模

- 题目：150
- 文档：4955
