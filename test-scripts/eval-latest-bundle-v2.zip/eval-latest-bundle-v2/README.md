# 最新测评数据包

本包收录当前最新冻结集文档、ApeMind / Dify / RAGFlow 完整跑题结果、打分结果、出图脚本和说明。

## 数据集

| 集合 | 题目 | 文档 | 目录 |
|---|---:|---:|---|
| NQ V2 | 118 | 118 | `datasets/nq-v2/` |
| MuSiQue V3 | 100 | 1,697 | `datasets/musique-v3/` |
| HotpotQA | 150 | 4,955 | `datasets/hotpotqa/` |
| RGB | 200 | 1,506 | `datasets/rgb/` |

每个数据集目录包含：

- `questions.csv` / `questions.jsonl` / `questions.md`：题目、`case_key`、标准答案
- `documents/`：该集合全部测试文档

建库时每个集合单独建库，上传对应 `documents/` 全部文件。按 `questions.csv` 原文逐题问，一题一次新对话，不要改问题。

## 跑题结果

### ApeMind

`results/apemind/`

- NQ V2、MuSiQue V3 四个模型的 chat export（jsonl）
- 分数见 `results/reports/`

四模型：DeepSeek V4 Pro、DeepSeek V4 Flash、Qwen3.6 27B、Qwen3.8 27B。

### Dify

`results/dify/`

- `dify-nq-v2.jsonl`、`dify-musique-v3.jsonl`：最新集
- `dify-hotpotqa-en.jsonl`、`dify-rgb-zh.jsonl`：上一轮同口径跑题

配置：jina-clip-v2 检索 + DeepSeek V4 Flash 生成。

### RAGFlow

`results/ragflow/`

- `ragflow-nq-v2.jsonl`、`ragflow-musique-v3.jsonl`：最新集
- `ragflow-hotpotqa-en.jsonl`、`ragflow-rgb-zh.jsonl`：上一轮同口径跑题

配置：jina-clip-v2 检索 + DeepSeek V4 Flash 生成。基础问答 `tool_calls` 为 0。

回答文件字段至少包含 `case_key` + `answer`。部分文件另有 `elapsed_s`、`tool_calls`、`retrieved_chunks`。

## 打分

裁判：DeepSeek V4 Pro，只出 PASS / FAIL。

- 有标准答案：回答里明确包含至少一条标准答案的事实即通过，允许换说法、翻译、加引用。
- NQ 中标准答案为空的题：明确说知识库没有 / 找不到才算对；编出具体事实算错。
- 失败题计入分母。

打分结果：`results/reports/horizontal-scored.json`

## 主要分数

NQ V2（118 题）

- ApeMind Qwen3.6 27B：98/118
- RAGFlow：81/118
- Dify：57/118

MuSiQue V3（100 题）

- ApeMind V4 Pro / Qwen3.8：90/100
- Dify：37/100
- RAGFlow：35/100

HotpotQA（150 题）

- ApeMind Qwen3.6 27B：145/150
- Dify：123/150
- RAGFlow：110/150

RGB（200 题）

- ApeMind V4 Pro：200/200
- Dify：194/200
- RAGFlow：194/200

长图：`results/reports/three-way-latest.png`

## 脚本

`scripts/`

- `score_horizontal_four.py`：对 Dify/RAGFlow 的 NQ V2 与 MuSiQue V3 做 Layer-C 打分
- `judge_musique_v3_qwen38.py`：ApeMind MuSiQue V3 Qwen3.8 打分
- `resume_musique_v3_qwen38.py`：ApeMind MuSiQue V3 Qwen3.8 补跑
- `build_three_way_latest.py`：三方横向长图
- `build_latest_four_dataset_report.py`：ApeMind 四集长图
- `build_horizontal_compare_report.py`：NQ/MuSiQue 三方简图

Dify / RAGFlow 本地跑题脚本若不在本包，见 `MISSING.md`。

## 使用注意

- 文档请用本包里的冻结切片，不要重新从网上下载 Wikipedia 或新闻页。
- 四个集合分开报通过率，不要合成一个总分去跟 ApeMind 比。
- ApeMind 取该集四模型最高分时，Dify / RAGFlow 是 Flash 检索+生成，配置不同。
